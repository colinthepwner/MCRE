#include "OptionStrings.h"

const char* OptionStrings::Multiplayer_Username        = "mp_username";
const char* OptionStrings::Multiplayer_ServerVisible   = "mp_server_visible_default";

const char* OptionStrings::Graphics_Fancy              = "gfx_fancygraphics";
const char* OptionStrings::Graphics_LowQuality         = "gfx_lowquality";
const char* OptionStrings::Graphics_AmbientOcclusion   = "gfx_ambientocclusion";
const char* OptionStrings::Graphics_FancyClouds      = "gfx_fancyclouds";
const char* OptionStrings::Graphics_Fov              = "gfx_fov";
const char* OptionStrings::Graphics_ViewDistance     = "gfx_viewdistance";
const char* OptionStrings::Graphics_Fog              = "gfx_fog";
const char* OptionStrings::Graphics_FogStart         = "gfx_fogstart";
const char* OptionStrings::Audio_Sound               = "audio_sound";
const char* OptionStrings::Audio_Music               = "audio_music";
const char* OptionStrings::Graphics_ShowFps          = "gfx_showfps";
const char* OptionStrings::Graphics_BiomeBlend       = "gfx_biomeblend";
const char* OptionStrings::Graphics_BiomeSky         = "gfx_biomesky";

const char* OptionStrings::Controls_Sensitivity        = "ctrl_sensitivity";
const char* OptionStrings::Controls_InvertMouse        = "ctrl_invertmouse";
const char* OptionStrings::Controls_UseTouchScreen     = "ctrl_usetouchscreen";
const char* OptionStrings::Controls_UseTouchJoypad     = "ctrl_usetouchjoypad";
const char* OptionStrings::Controls_IsLefthanded       = "ctrl_islefthanded";
const char* OptionStrings::Controls_FeedbackVibration  = "feedback_vibration";

const char* OptionStrings::Game_DifficultyLevel = "game_difficulty";
const char* OptionStrings::Game_SprintingEnabled = "game_sprinting_enabled";
const char* OptionStrings::Game_HungerEnabled = "game_hunger_enabled";
