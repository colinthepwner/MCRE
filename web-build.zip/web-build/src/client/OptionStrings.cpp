#include "OptionStrings.h"

const char* OptionStrings::Multiplayer_Username        = "mp_username";
const char* OptionStrings::Multiplayer_ServerVisible   = "mp_server_visible_default";

const char* OptionStrings::Graphics_Fancy              = "gfx_fancygraphics";
const char* OptionStrings::Graphics_LowQuality         = "gfx_lowquality";
const char* OptionStrings::Graphics_AmbientOcclusion   = "gfx_ambientocclusion";
const char* OptionStrings::Graphics_FancyClouds      = "gfx_fancyclouds";
const char* OptionStrings::Graphics_Fov              = "gfx_fov";
const char* OptionStrings::Graphics_ViewDistance     = "gfx_viewdistance";
const char* OptionStrings::Graphics_Fog              = "gfx_fog";
const char* OptionStrings::Graphics_FogStart         = "gfx_fogstart";
const char* OptionStrings::Audio_Sound               = "audio_sound";
const char* OptionStrings::Audio_Music               = "audio_music";
const char* OptionStrings::Graphics_ShowFps          = "gfx_showfps";
const char* OptionStrings::Graphics_BiomeBlend       = "gfx_biomeblend";
const char* OptionStrings::Graphics_BiomeSky         = "gfx_biomesky";
const char* OptionStrings::Graphics_LazyChunks       = "gfx_lazychunks";
const char* OptionStrings::Graphics_PreloadChunks    = "gfx_preloadchunks";
const char* OptionStrings::Graphics_EntityLighting   = "gfx_entitylighting";
const char* OptionStrings::Graphics_LightingStyle    = "gfx_lightingstyle";
const char* OptionStrings::Game_AutoTool             = "game_autotool";
const char* OptionStrings::Controls_SprintToggle     = "ctrl_sprinttoggle";
const char* OptionStrings::Graphics_Leaves           = "gfx_leaves";
const char* OptionStrings::Graphics_UiStyle          = "gfx_uistyle";
const char* OptionStrings::Controls_MineAssist       = "ctrl_mineassist";
const char* OptionStrings::Controls_EasyBridgePc     = "ctrl_easybridge_pc";
const char* OptionStrings::Controls_EasyBridgeTouch  = "ctrl_easybridge_touch";
const char* OptionStrings::Controls_TouchCrosshair   = "ctrl_touch_crosshair";
const char* OptionStrings::Controls_EdgeAssist       = "ctrl_edge_assist";
const char* OptionStrings::Sound_KeepMyMusic         = "snd_keep_my_music";
const char* OptionStrings::Game_ToolRefill           = "game_toolrefill";
const char* OptionStrings::Game_AutoHarvest          = "game_autoharvest";
const char* OptionStrings::Game_SaveNotices          = "game_savenotices";
const char* OptionStrings::Game_SoundStyle           = "game_soundstyle";
const char* OptionStrings::Game_ViewBobbing          = "game_bobbing2";
const char* OptionStrings::Game_ViewBobbingOld       = "game_bobbing";
const char* OptionStrings::Graphics_RenderScale      = "gfx_renderscale";
const char* OptionStrings::Graphics_GuiScale         = "gfx_guiscale";
const char* OptionStrings::Graphics_DistantDetail    = "gfx_distantdetail2";

const char* OptionStrings::Controls_Sensitivity        = "ctrl_sensitivity";
const char* OptionStrings::Controls_InvertMouse        = "ctrl_invertmouse";
const char* OptionStrings::Controls_UseTouchScreen     = "ctrl_usetouchscreen";
const char* OptionStrings::Controls_UseTouchJoypad     = "ctrl_usetouchjoypad";
const char* OptionStrings::Controls_IsLefthanded       = "ctrl_islefthanded";
const char* OptionStrings::Controls_TouchControls      = "ctrl_touchcontrols";
const char* OptionStrings::Controls_FeedbackVibration  = "feedback_vibration";

const char* OptionStrings::Game_DifficultyLevel = "game_difficulty";
const char* OptionStrings::Game_SprintingEnabled = "game_sprinting_enabled";
const char* OptionStrings::Game_HungerEnabled = "game_hunger_enabled";
