#include "Particle.h"
#include "../renderer/LightMap.h"
#include "../../world/level/LightLayer.h"
#include "../../util/Mth.h"

float
	Particle::xOff = 0,
	Particle::yOff = 0,
	Particle::zOff = 0;

Particle::Particle( Level* level, float x, float y, float z, float xa, float ya, float za )
:	super(level),
	age(0),
	gravity(0),
	rCol(1), gCol(1), bCol(1),
	tex(0)
{
	setSize(0.2f, 0.2f);
	heightOffset = bbHeight / 2.0f;
	setPos(x, y, z);

	xd = xa + (float) (Mth::random() * 2 - 1) * 0.4f;
	yd = ya + (float) (Mth::random() * 2 - 1) * 0.4f;
	zd = za + (float) (Mth::random() * 2 - 1) * 0.4f;
	float speed = (float) (Mth::random() + Mth::random() + 1) * 0.15f;

	float dd = (float) (Mth::sqrt(xd * xd + yd * yd + zd * zd));
	const float mul = 0.4f * speed / dd;
	xd = xd * mul;
	yd = yd * mul + 0.1f;
	zd = zd * mul;

	uo = sharedRandom.nextFloat() * 3;
	vo = sharedRandom.nextFloat() * 3;

	size = (sharedRandom.nextFloat() * 0.5f + 0.5f) * 2;

	lifetime = (int) (4.0f / (sharedRandom.nextFloat() * 0.9f + 0.1f));
	makeStepSound = false;
}

Particle* Particle::setPower( float power )
{
	xd *= power;
	yd = (yd - 0.1f) * power + 0.1f;
	zd *= power;
	return this;
}

Particle* Particle::scale( float scale )
{
	setSize(0.2f * scale, 0.2f * scale);
	size *= scale;
	return this;
}

void Particle::tick()
{
	xo = x;
	yo = y;
	zo = z;

	if (age++ >= lifetime) remove();

	yd -= 0.04f * gravity;
	move(xd, yd, zd);
	xd *= 0.98f;
	yd *= 0.98f;
	zd *= 0.98f;

	if (onGround) {
		xd *= 0.7f;
		zd *= 0.7f;
	}
}

void Particle::render( Tesselator& t, float a, float xa, float ya, float za, float xa2, float za2 )
{
	float u0 = (tex % 16) / 16.0f;
	float u1 = u0 + 0.999f / 16.0f;
	float v0 = (tex / 16) / 16.0f;
	float v1 = v0 + 0.999f / 16.0f;
	float r = 0.1f * size;

	float x = (float) (xo + (this->x - xo) * a - xOff);
	float y = (float) (yo + (this->y - yo) * a - yOff);
	float z = (float) (zo + (this->z - zo) * a - zOff);

	float lr, lg, lb;
	litColour(a, lr, lg, lb);
	t.color(rCol * lr, gCol * lg, bCol * lb);

	t.vertexUV(x - xa * r - xa2 * r, y - ya * r, z - za * r - za2 * r, u1, v1);
	t.vertexUV(x - xa * r + xa2 * r, y + ya * r, z - za * r + za2 * r, u1, v0);
	t.vertexUV(x + xa * r + xa2 * r, y + ya * r, z + za * r + za2 * r, u0, v0);
	t.vertexUV(x + xa * r - xa2 * r, y - ya * r, z + za * r - za2 * r, u0, v1);
	//printf("uv: %f, %f, %f, %f\n", u0, v0, u1, v1);
}

void Particle::litColour(float a, float& r, float& g, float& b)
{
	const float br = getBrightness(a);
	if (!javaLight || !level || !LightMap::ready()) { r = g = b = br; return; }
	if (!level->hasChunksAt(Mth::floor(bb.x0), Mth::floor(bb.y0), Mth::floor(bb.z0), Mth::floor(bb.x1), Mth::floor(bb.y1), Mth::floor(bb.z1))) { r = g = b = br; return; }
	const int xt = Mth::floor(x), yt = Mth::floor(y - heightOffset + (bb.y1 - bb.y0) * 0.66f), zt = Mth::floor(z);
	int sky, block;
	if (litLevel == level && litX == xt && litY == yt && litZ == zt) { sky = litSky; block = litBlock; }
	else { sky = level->getBrightness(LightLayer::Sky, xt, yt, zt); block = level->getBrightness(LightLayer::Block, xt, yt, zt); }
	float lr, lg, lb;
	LightMap::colour(sky, block, lr, lg, lb);
	const float g0 = (lr + lg + lb) / 3.0f;
	if (br >= g0) {
		float k = g0 < 0.999f ? (br - g0) / (1.0f - g0) : 0.0f;
		if (k > 1.0f) k = 1.0f;
		r = lr + (1.0f - lr) * k;
		g = lg + (1.0f - lg) * k;
		b = lb + (1.0f - lb) * k;
	} else {
		const float k = g0 > 0.001f ? br / g0 : 0.0f;
		r = lr * k; g = lg * k; b = lb * k;
	}
}

int Particle::getParticleTexture()
{
	return ParticleEngine::MISC_TEXTURE;
}
