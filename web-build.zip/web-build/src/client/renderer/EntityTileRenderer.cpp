#include "EntityTileRenderer.h"
#include "gles.h"
#include "tileentity/ChestRenderer.h"
#include "../../world/level/tile/Tile.h"
#include "../../world/ExtrasIds.h"

EntityTileRenderer* EntityTileRenderer::instance = new EntityTileRenderer();

void EntityTileRenderer::render( Tile* tile, int data, float brightness )
{
	TileEntityRenderDispatcher* d = TileEntityRenderDispatcher::getInstance();
	if (d->textures == NULL || tile == NULL) return;
	glPushMatrix();
	glRotatef(90.0f, 0.0f, 1.0f, 0.0f);
	glTranslatef(-0.5f, -0.5f, -0.5f);
	if (tile->id == ExtrasIds::ENDER_CHEST) {
		d->render(&enderChest, 0, 0, 0, 0);
	} else {
		ChestRenderer::itemTileId = tile->id;
		d->render(&chest, 0, 0, 0, 0);
		ChestRenderer::itemTileId = 0;
	}
	glPopMatrix();
}
