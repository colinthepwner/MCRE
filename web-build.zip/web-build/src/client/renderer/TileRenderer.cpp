#include "../../world/Content17.h"
#include "../../world/level/tile/Tiles17.h"
#include "TileRenderer.h"
#include "../../world/level/biome/modern/ModernBiome.h"
#include "../Minecraft.h"
#include "Tesselator.h"
#include "TerrainLight.h"

#include "../../world/level/LevelSource.h"
#include "../../world/level/tile/Tile.h"
#include "../../world/level/tile/DoorTile.h"
#include "../../world/level/tile/LiquidTile.h"
#include "../../world/level/tile/FenceTile.h"
#include "../../world/level/tile/FenceGateTile.h"
#include "../../world/level/tile/ThinFenceTile.h"
#include "../../world/level/tile/BedTile.h"
#include "../../world/level/tile/StemTile.h"
#include "../../world/level/tile/StairTile.h"
#include "../../world/level/tile/FireTile.h"
#include "../../world/level/tile/RedstoneUpdate.h"
#include "../../world/level/tile/EnchantBrewTiles.h"
#include "../../world/level/tile/EndTiles.h"
#include "TileRendererMods.h"
#include "../../world/ModContent.h"
#include "../../world/Direction.h"
#include "../../world/Facing.h"
#include "tileentity/TileEntityRenderer.h"
#include "EntityTileRenderer.h"
#include "../../world/ModLiquids.h"

static thread_local int s_uvTurn = 0;
static inline void turnUV(float* u, float* v) {
	const float u0 = u[0], v0 = v[0];
	for (int i = 0; i < 3; ++i) { u[i] = u[i + 1]; v[i] = v[i + 1]; }
	u[3] = u0; v[3] = v0;
}

static const int GRASS_SIDE_CELL = 3, GRASS_OVERLAY_CELL = 38, GRASS_BAND = 4;
static const int GRASS_TOP_CELL = 0;
static const signed char GRASS_TINTED[][4] = {
	{0, 0, 16, 1}, {0, 1, 5, 2}, {6, 1, 16, 2}, {0, 2, 1, 3}, {2, 2, 5, 3}, {6, 2, 7, 3},
	{8, 2, 12, 3}, {13, 2, 15, 3}, {4, 3, 5, 4}, {8, 3, 9, 4}, {10, 3, 11, 4} };
static const signed char GRASS_PLAIN[][4] = {
	{5, 1, 6, 4}, {1, 2, 2, 4}, {7, 2, 8, 4}, {12, 2, 13, 4}, {15, 2, 16, 4}, {0, 3, 1, 4},
	{2, 3, 4, 4}, {6, 3, 7, 4}, {9, 3, 10, 4}, {11, 3, 12, 4}, {13, 3, 15, 4},
	{0, GRASS_BAND, 16, 16} };

static void grassSideSplit(Tesselator& t, int face, float x, float y, float z, const float C[4][3], float tr, float tg, float tb, const int* L = 0) {
	static const signed char POS[4][4][3] = {
		{ {0, 1, 0}, {1, 1, 0}, {1, 0, 0}, {0, 0, 0} },
		{ {0, 1, 1}, {0, 0, 1}, {1, 0, 1}, {1, 1, 1} },
		{ {0, 1, 1}, {0, 1, 0}, {0, 0, 0}, {0, 0, 1} },
		{ {1, 0, 1}, {1, 0, 0}, {1, 1, 0}, {1, 1, 1} } };
	static const signed char SR[4][4][2] = {
		{ {1, 0}, {0, 0}, {0, 1}, {1, 1} },
		{ {0, 0}, {0, 1}, {1, 1}, {1, 0} },
		{ {1, 0}, {0, 0}, {0, 1}, {1, 1} },
		{ {0, 1}, {1, 1}, {1, 0}, {0, 0} } };
	const int f = face - 2;
	static const float BACK_INSET = 1.0f / 2048.0f;
	static const float BACK_EXTEND = 1.0f / 256.0f;
	static const signed char IN[4][3] = { {0, 0, 1}, {0, 0, -1}, {1, 0, 0}, {-1, 0, 0} };
	static const signed char BACKING_BAND[1][4] = { {0, 0, 16, GRASS_BAND} };
	static const signed char BACKING_REST[1][4] = { {0, GRASS_BAND, 16, 16} };
	int Q[2][2];
	float ox, oy, oz;
	t.getOffset(ox, oy, oz);
	const float lx = x + ox, ly = y + oy, lz = z + oz;
	t.offset(0, 0, 0);
	for (int k = 0; k < 4; ++k) Q[(int)SR[f][k][0]][(int)SR[f][k][1]] = k;
	for (int pass = 0; pass < 4; ++pass) {
		const signed char (*R)[4] = pass == 0 ? BACKING_BAND : pass == 1 ? BACKING_REST : pass == 3 ? GRASS_TINTED : GRASS_PLAIN;
		const int n = pass < 2 ? 1 : pass == 3 ? (int)(sizeof(GRASS_TINTED) / sizeof(GRASS_TINTED[0])) : (int)(sizeof(GRASS_PLAIN) / sizeof(GRASS_PLAIN[0]));
		const int cell = pass == 0 ? GRASS_TOP_CELL : pass == 3 ? GRASS_OVERLAY_CELL : GRASS_SIDE_CELL;
		const float cu = (float)Atlas::cellPx(cell), cv = (float)Atlas::cellPy(cell);
		const bool tinted = pass == 0 || pass == 3;
		const float mr = tinted ? tr : 1.0f, mg = tinted ? tg : 1.0f, mb = tinted ? tb : 1.0f;
		const float ix = pass < 2 ? IN[f][0] * BACK_INSET : 0.0f, iz = pass < 2 ? IN[f][2] * BACK_INSET : 0.0f;
		for (int i = 0; i < n; ++i) {
			for (int k = 0; k < 4; ++k) {
				const float s = (float)R[i][SR[f][k][0] ? 2 : 0], r = (float)R[i][SR[f][k][1] ? 3 : 1];
				const float a = s / 16.0f, b = r / 16.0f;
				const int k00 = Q[0][0], k10 = Q[1][0], k01 = Q[0][1], k11 = Q[1][1];
				const float w00 = (1 - a) * (1 - b), w10 = a * (1 - b), w01 = (1 - a) * b, w11 = a * b;
				float ap = a, bp = b;
				if (pass < 2) {
					if (s <= 0) ap = -BACK_EXTEND; else if (s >= 16) ap = 1 + BACK_EXTEND;
					if (r <= 0) bp = -BACK_EXTEND; else if (r >= 16) bp = 1 + BACK_EXTEND;
				}
				const float v00 = (1 - ap) * (1 - bp), v10 = ap * (1 - bp), v01 = (1 - ap) * bp, v11 = ap * bp;
				float p[3];
				for (int d = 0; d < 3; ++d)
					p[d] = v00 * POS[f][k00][d] + v10 * POS[f][k10][d] + v01 * POS[f][k01][d] + v11 * POS[f][k11][d];
				const float cr = w00 * C[k00][0] + w10 * C[k10][0] + w01 * C[k01][0] + w11 * C[k11][0];
				const float cg = w00 * C[k00][1] + w10 * C[k10][1] + w01 * C[k01][1] + w11 * C[k11][1];
				const float cb = w00 * C[k00][2] + w10 * C[k10][2] + w01 * C[k01][2] + w11 * C[k11][2];
				t.color(cr * mr, cg * mg, cb * mb);
				if (L) {
					const float ls = w00 * TerrainLight::sky16(L[k00]) + w10 * TerrainLight::sky16(L[k10]) + w01 * TerrainLight::sky16(L[k01]) + w11 * TerrainLight::sky16(L[k11]);
					const float lb = w00 * TerrainLight::block16(L[k00]) + w10 * TerrainLight::block16(L[k10]) + w01 * TerrainLight::block16(L[k01]) + w11 * TerrainLight::block16(L[k11]);
					TerrainLight::set(TerrainLight::packRaw((int)(ls + 0.5f), (int)(lb + 0.5f)));
				}
				t.vertexUV(lx + (p[0] + ix), ly + p[1], lz + (p[2] + iz), (cu + (s >= 16 ? 15.99f : s)) / Atlas::W, (cv + (r >= 16 ? 15.99f : r)) / Atlas::H);
			}
		}
	}
	t.offset(ox, oy, oz);
}
static inline bool grassSideSplits(const Tile* tt, int tex, int face, int fixedTexture, bool xFlip, float r, float g, float b) {
	return tex == GRASS_SIDE_CELL && !ModernBiome::pocketLook && fixedTexture < 0 && !xFlip && !(s_uvTurn & (1 << face))
		&& !(r >= 0.999f && g >= 0.999f && b >= 0.999f)
		&& tt->xx0 == 0 && tt->yy0 == 0 && tt->zz0 == 0 && tt->xx1 == 1 && tt->yy1 == 1 && tt->zz1 == 1;
}



TileRenderer::TileRenderer( LevelSource* level /* = NULL */ )
:	level(level),
	fixedTexture(-1),
	xFlipTexture(false),
	noCulling(false),
	blsmooth(1),
	applyAmbienceOcclusion(false)
{
}

bool TileRenderer::tesselateBlockInWorld(Tile* tt, int x, int y, int z) {
	int col = tt->getColor(level, x, y, z);
	float r = ((col >> 16) & 0xff) / 255.0f;
	float g = ((col >> 8) & 0xff) / 255.0f;
	float b = ((col) & 0xff) / 255.0f; // xFlipTexture = (x & 1) != (y & 1);

	if (Minecraft::useAmbientOcclusion) {
		if (TerrainLight::capturing()) {
			if (Tile::lightEmission[tt->id] == 0)
				return tesselateBlockInWorldWithAmbienceOcclusionLit(tt, x, y, z, r, g, b);
		} else
			return tesselateBlockInWorldWithAmbienceOcclusion(tt, x, y, z, r, g, b);
	}
	return tesselateBlockInWorld(tt, x, y, z, r, g, b);
}

bool TileRenderer::tesselateBlockInWorld( Tile* tt, int x, int y, int z, float r, float g, float b )
{
	applyAmbienceOcclusion = false;
	float xf = (float)x;
	float yf = (float)y;
	float zf = (float)z;

	Tesselator& t = Tesselator::forThread();

	bool changed = false;
	float c10 = 0.5f;
	float c11 = 1;
	float c2 = 0.8f;
	float c3 = 0.6f;

	float r11 = c11 * r;
	float g11 = c11 * g;
	float b11 = c11 * b;

	const float tintR = r, tintG = g, tintB = b;
	if (tt == (Tile*)Tile::grass) {
		r = g = b = 1.0f;
	}

	float r10 = c10 * r;
	float r2 = c2 * r;
	float r3 = c3 * r;

	float g10 = c10 * g;
	float g2 = c2 * g;
	float g3 = c3 * g;

	float b10 = c10 * b;
	float b2 = c2 * b;
	float b3 = c3 * b;

	float centerBrightness = tt->getBrightness(level, x, y, z);

	if (TerrainLight::capturing()) TerrainLight::beginTile();
	const bool lm = TerrainLight::capturing();
	const int centerLight = lm ? lightAt(x, y, z) : 0;

	if (noCulling || tt->shouldRenderFace(level, x, y - 1, z, Facing::DOWN)) {
		float br = tt->getBrightness(level, x, y - 1, z);
		if (lm) TerrainLight::set(lightAt(x, y - 1, z));
		t.color(r10 * br, g10 * br, b10 * br);
		renderFaceDown(tt, xf, yf, zf, tt->getTexture(level, x, y, z, 0));
		changed = true;
	}

	if (noCulling || tt->shouldRenderFace(level, x, y + 1, z, Facing::UP)) {
		float br = tt->getBrightness(level, x, y + 1, z);
		if (tt->yy1 != 1 && !tt->material->isLiquid()) br = centerBrightness;
		if (lm) TerrainLight::set(tt->yy1 != 1 && !tt->material->isLiquid() ? centerLight : lightAt(x, y + 1, z));
		t.color(r11 * br, g11 * br, b11 * br);
		renderFaceUp(tt, xf, yf, zf, tt->getTexture(level, x, y, z, 1));
		changed = true;
	}

	if (noCulling || tt->shouldRenderFace(level, x, y, z - 1, Facing::NORTH)) {
		float br = tt->getBrightness(level, x, y, z - 1);
		if (tt->zz0 > 0) br = centerBrightness;
		if (lm) TerrainLight::set(tt->zz0 > 0 ? centerLight : lightAt(x, y, z - 1));
		const int ft = tt->getTexture(level, x, y, z, 2);
		if (grassSideSplits(tt, ft, 2, fixedTexture, xFlipTexture, tintR, tintG, tintB)) {
			const float s = c2 * br, C[4][3] = { {s, s, s}, {s, s, s}, {s, s, s}, {s, s, s} };
			grassSideSplit(t, 2, xf, yf, zf, C, tintR, tintG, tintB);
		} else {
			t.color(r2 * br, g2 * br, b2 * br);
			renderNorth(tt, xf, yf, zf, ft);
		}
		changed = true;
	}

	if (noCulling || tt->shouldRenderFace(level, x, y, z + 1, Facing::SOUTH)) {
		float br = tt->getBrightness(level, x, y, z + 1);
		if (tt->zz1 < 1) br = centerBrightness;
		if (lm) TerrainLight::set(tt->zz1 < 1 ? centerLight : lightAt(x, y, z + 1));
		const int ft = tt->getTexture(level, x, y, z, 3);
		if (grassSideSplits(tt, ft, 3, fixedTexture, xFlipTexture, tintR, tintG, tintB)) {
			const float s = c2 * br, C[4][3] = { {s, s, s}, {s, s, s}, {s, s, s}, {s, s, s} };
			grassSideSplit(t, 3, xf, yf, zf, C, tintR, tintG, tintB);
		} else {
			t.color(r2 * br, g2 * br, b2 * br);
			renderSouth(tt, xf, yf, zf, ft);
		}
		changed = true;
	}

	if (noCulling || tt->shouldRenderFace(level, x - 1, y, z, Facing::WEST)) {
		float br = tt->getBrightness(level, x - 1, y, z);
		if (tt->xx0 > 0) br = centerBrightness;
		if (lm) TerrainLight::set(tt->xx0 > 0 ? centerLight : lightAt(x - 1, y, z));
		const int ft = tt->getTexture(level, x, y, z, 4);
		if (grassSideSplits(tt, ft, 4, fixedTexture, xFlipTexture, tintR, tintG, tintB)) {
			const float s = c3 * br, C[4][3] = { {s, s, s}, {s, s, s}, {s, s, s}, {s, s, s} };
			grassSideSplit(t, 4, xf, yf, zf, C, tintR, tintG, tintB);
		} else {
			t.color(r3 * br, g3 * br, b3 * br);
			renderWest(tt, xf, yf, zf, ft);
		}
		changed = true;
	}

	if (noCulling || tt->shouldRenderFace(level, x + 1, y, z, Facing::EAST)) {
		float br = tt->getBrightness(level, x + 1, y, z);
		if (tt->xx1 < 1) br = centerBrightness;
		if (lm) TerrainLight::set(tt->xx1 < 1 ? centerLight : lightAt(x + 1, y, z));
		const int ft = tt->getTexture(level, x, y, z, 5);
		if (grassSideSplits(tt, ft, 5, fixedTexture, xFlipTexture, tintR, tintG, tintB)) {
			const float s = c3 * br, C[4][3] = { {s, s, s}, {s, s, s}, {s, s, s}, {s, s, s} };
			grassSideSplit(t, 5, xf, yf, zf, C, tintR, tintG, tintB);
		} else {
			t.color(r3 * br, g3 * br, b3 * br);
			renderEast(tt, xf, yf, zf, ft);
		}
		changed = true;
	}

	return changed;
}

void TileRenderer::tesselateInWorld( Tile* tile, int x, int y, int z, int fixedTexture )
{
	this->fixedTexture = fixedTexture;
	tesselateInWorld(tile, x, y, z);
	this->fixedTexture = -1;
}

bool TileRenderer::tesselateInWorld( Tile* tt, int x, int y, int z )
{
	if (TerrainLight::capturing()) {
		TerrainLight::beginTile();
		TerrainLight::setBlock(tt->id, level->getData(x, y, z));
	}
	if (Tile* px = ModContent::stateProxy(tt->id)) if (Tile::tiles[tt->id] == tt) tt = px;
	int shape = tt->getRenderShape();
	tt->updateShape(level, x, y, z);

	if (shape == Tile::SHAPE_BLOCK) {
		int turn = ModContent::uvTurn(tt->id, level->getData(x, y, z));
		if (!turn) turn = Content17::uvTurn(tt->id, level->getData(x, y, z));
		if (turn) {
			s_uvTurn = turn;
			const bool drawn = tesselateBlockInWorld(tt, x, y, z);
			s_uvTurn = 0;
			return drawn;
		}
		return tesselateBlockInWorld(tt, x, y, z);
	} else if (shape == Tile::SHAPE_WATER) {
		return tesselateWaterInWorld(tt, x, y, z);
    } else if (shape == Tile::SHAPE_CACTUS) {
        return tesselateCactusInWorld(tt, x, y, z);
	} else if (shape == Tile::SHAPE_CROSS_TEXTURE) {
		return tesselateCrossInWorld(tt, x, y, z);
	} else if(shape == Tile::SHAPE_STEM) {
		return tesselateStemInWorld(tt, x, y, z);
	} else if (shape == Tile::SHAPE_ROWS) {
        return tesselateRowInWorld(tt, x, y, z);
	} else if (shape == Tile::SHAPE_TORCH) {
		return tesselateTorchInWorld(tt, x, y, z);
	} else if (shape == Tile::SHAPE_FIRE) {
		return tesselateFireInWorld(tt, x, y, z);
	} else if (shape == Tile::SHAPE_RED_DUST) {
		return tesselateDustInWorld(tt, x, y, z);
	} else if (shape == Tile::SHAPE_LADDER) {
		return tesselateLadderInWorld(tt, x, y, z);
	} else if (shape == Tile::SHAPE_DOOR) {
		return tesselateDoorInWorld(tt, x, y, z);
	} else if (shape == Tile::SHAPE_RAIL) {
		return tesselateRailInWorld(tt, x, y, z);
	} else if (shape == Tile::SHAPE_STAIRS) {
		return tesselateStairsInWorld((StairTile*)tt, x, y, z);
    } else if (shape == Tile::SHAPE_FENCE) {
        return tesselateFenceInWorld((FenceTile*)tt, x, y, z);
	} else if (shape == Tile::SHAPE_FENCE_GATE) {
		return tesselateFenceGateInWorld((FenceGateTile*) tt, x, y, z);
	} else if (shape == Tile::SHAPE_LEVER) {
		return tesselateLeverInWorld(tt, x, y, z);
    //} else if (shape == Tile::SHAPE_BED) {
    //    return tesselateBedInWorld(tt, x, y, z);
	} else if (shape == Tile::SHAPE_DIODE) {
		return tesselateDiodeInWorld(tt, x, y, z);
	} else if (shape == Tile::SHAPE_IRON_FENCE) {
		return tesselateThinFenceInWorld((ThinFenceTile*) tt, x, y, z);
	} else if(shape == Tile::SHAPE_BED) {
		return tesselateBedInWorld(tt, x, y, z);
	} else if (shape == Tile::SHAPE_PISTON_BASE) {
		return tesselatePistonBaseInWorld(tt, x, y, z, false, noCulling);
	} else if (shape == Tile::SHAPE_PISTON_EXTENSION) {
		return tesselatePistonExtensionInWorld(tt, x, y, z, true, noCulling);
	} else if (shape == Tile::SHAPE_VINE) {
		return tesselateVineInWorld(tt, x, y, z);
	} else if (shape == Tile::SHAPE_LILYPAD) {
		return tesselateLilyPadInWorld(tt, x, y, z);
	} else if (shape == Tile::SHAPE_COCOA) {
		return tesselateCocoaInWorld(tt, x, y, z);
	} else if (shape == DoublePlantTile::SHAPE) {
		return tesselateDoublePlantInWorld(tt, x, y, z);
	} else if (RedstoneUpdate::isOwnShape(shape)) {
		return tesselateRedstoneUpdateInWorld(tt, x, y, z);
	} else if (isEnchantBrewShape(shape)) {
		return tesselateEnchantBrewInWorld(tt, x, y, z);
	} else if (endIsOwnShape(shape)) {
		return tesselateEndInWorld(tt, x, y, z);
	} else if (modIsOwnShape(shape)) {
		return tesselateModModelInWorld(tt, x, y, z);
	} else {
		return false;
	}
}

void TileRenderer::tesselateInWorldNoCulling( Tile* tile, int x, int y, int z )
{
	noCulling = true;
	tesselateInWorld(tile, x, y, z);
	noCulling = false;
}

bool TileRenderer::tesselateTorchInWorld( Tile* tt, int x, int y, int z )
{
	int dir = level->getData(x, y, z);

	Tesselator& t = Tesselator::forThread();

	float br = tt->getBrightness(level, x, y, z);
	if (Tile::lightEmission[tt->id] > 0) br = 1.0f; if (Tile::lightEmission[tt->id] > 0 && TerrainLight::capturing()) TerrainLight::set(TerrainLight::FULL);
	t.color(br, br, br);

	float r = 0.40f;
	float r2 = 0.5f - r;
	float h = 0.20f;
	if (dir == 1) {
		tesselateTorch(tt, (float)x - r2, (float)y + h, (float)z, -r, 0);
	} else if (dir == 2) {
		tesselateTorch(tt, (float)x + r2, (float)y + h, (float)z, +r, 0);
	} else if (dir == 3) {
		tesselateTorch(tt, (float)x, (float)y + h, (float)z - r2, 0, -r);
	} else if (dir == 4) {
		tesselateTorch(tt, (float)x, (float)y + h, (float)z + r2, 0, +r);
	} else {
		tesselateTorch(tt, (float)x, (float)y, (float)z, 0, 0);
	}
	return true;
}

bool TileRenderer::tesselateLadderInWorld( Tile* tt, int x, int y, int z )
{
	Tesselator& t = Tesselator::forThread();

	int tex = tt->getTexture(0);

	if (fixedTexture >= 0) tex = fixedTexture;

	float br = tt->getBrightness(level, x, y, z);
	t.color(br, br, br);
	int xt = ((tex & 0xf) << 4);
	int yt = Atlas::cellPy(tex);

	float u0 = (xt) / Atlas::W;
	float u1 = (xt + 15.99f) / Atlas::W;
	float v0 = (yt) / Atlas::H;
	float v1 = (yt + 15.99f) / Atlas::H;

	int face = level->getData(x, y, z);

	float o = 0 / 16.0f;
	float r = 0.05f;
	if (face == 5) {
		t.vertexUV(x + r, y + 1 + o, z + 1 + o, u0, v0);
		t.vertexUV(x + r, y + 0 - o, z + 1 + o, u0, v1);
		t.vertexUV(x + r, y + 0 - o, z + 0 - o, u1, v1);
		t.vertexUV(x + r, y + 1 + o, z + 0 - o, u1, v0);
	}
	if (face == 4) {
		t.vertexUV(x + 1 - r, y + 0 - o, z + 1 + o, u1, v1);
		t.vertexUV(x + 1 - r, y + 1 + o, z + 1 + o, u1, v0);
		t.vertexUV(x + 1 - r, y + 1 + o, z + 0 - o, u0, v0);
		t.vertexUV(x + 1 - r, y + 0 - o, z + 0 - o, u0, v1);
	}
	if (face == 3) {
		t.vertexUV(x + 1 + o, y + 0 - o, z + r, u1, v1);
		t.vertexUV(x + 1 + o, y + 1 + o, z + r, u1, v0);
		t.vertexUV(x + 0 - o, y + 1 + o, z + r, u0, v0);
		t.vertexUV(x + 0 - o, y + 0 - o, z + r, u0, v1);
	}
	if (face == 2) {
		t.vertexUV(x + 1 + o, y + 1 + o, z + 1 - r, u0, v0);
		t.vertexUV(x + 1 + o, y + 0 - o, z + 1 - r, u0, v1);
		t.vertexUV(x + 0 - o, y + 0 - o, z + 1 - r, u1, v1);
		t.vertexUV(x + 0 - o, y + 1 + o, z + 1 - r, u1, v0);
	}

	return true;
}

bool TileRenderer::tesselateFireInWorld( Tile* tt, int x, int y, int z )
{
	Tesselator& t = Tesselator::forThread();
	const int tex = tt->getTexture(0);
	const float br = tt->getBrightness(level, x, y, z);
	t.color(br, br, br);
	const int xt = (tex & 0xf) << 4;
	const int yt = Atlas::cellPy(tex);
	float u0 = xt / Atlas::W, u1 = (xt + 15.99f) / Atlas::W;
	float v0 = yt / Atlas::H, v1 = (yt + 15.99f) / Atlas::H;
	const float h = 1.4f;
	const float X = (float)x, Y = (float)y, Z = (float)z;

	if (level->isSolidBlockingTile(x, y - 1, z) || Tile::fire->canBurn(level, x, y - 1, z)) {
		float x0 = X + 0.5f + 0.2f, x1 = X + 0.5f - 0.2f;
		float z0 = Z + 0.5f + 0.2f, z1 = Z + 0.5f - 0.2f;
		float x0_ = X + 0.5f - 0.3f, x1_ = X + 0.5f + 0.3f;
		float z0_ = Z + 0.5f - 0.3f, z1_ = Z + 0.5f + 0.3f;
		t.vertexUV(x0_, Y + h, Z + 1, u1, v0);
		t.vertexUV(x0, Y + 0, Z + 1, u1, v1);
		t.vertexUV(x0, Y + 0, Z + 0, u0, v1);
		t.vertexUV(x0_, Y + h, Z + 0, u0, v0);
		t.vertexUV(x1_, Y + h, Z + 0, u1, v0);
		t.vertexUV(x1, Y + 0, Z + 0, u1, v1);
		t.vertexUV(x1, Y + 0, Z + 1, u0, v1);
		t.vertexUV(x1_, Y + h, Z + 1, u0, v0);
		v0 = (yt + 16) / Atlas::H; v1 = (yt + 15.99f + 16) / Atlas::H;
		t.vertexUV(X + 1, Y + h, z1_, u1, v0);
		t.vertexUV(X + 1, Y + 0, z1, u1, v1);
		t.vertexUV(X + 0, Y + 0, z1, u0, v1);
		t.vertexUV(X + 0, Y + h, z1_, u0, v0);
		t.vertexUV(X + 0, Y + h, z0_, u1, v0);
		t.vertexUV(X + 0, Y + 0, z0, u1, v1);
		t.vertexUV(X + 1, Y + 0, z0, u0, v1);
		t.vertexUV(X + 1, Y + h, z0_, u0, v0);
		x0 = X + 0.5f - 0.5f; x1 = X + 0.5f + 0.5f;
		z0 = Z + 0.5f - 0.5f; z1 = Z + 0.5f + 0.5f;
		x0_ = X + 0.5f - 0.4f; x1_ = X + 0.5f + 0.4f;
		z0_ = Z + 0.5f - 0.4f; z1_ = Z + 0.5f + 0.4f;
		t.vertexUV(x0_, Y + h, Z + 0, u0, v0);
		t.vertexUV(x0, Y + 0, Z + 0, u0, v1);
		t.vertexUV(x0, Y + 0, Z + 1, u1, v1);
		t.vertexUV(x0_, Y + h, Z + 1, u1, v0);
		t.vertexUV(x1_, Y + h, Z + 1, u0, v0);
		t.vertexUV(x1, Y + 0, Z + 1, u0, v1);
		t.vertexUV(x1, Y + 0, Z + 0, u1, v1);
		t.vertexUV(x1_, Y + h, Z + 0, u1, v0);
		v0 = yt / Atlas::H; v1 = (yt + 15.99f) / Atlas::H;
		t.vertexUV(X + 0, Y + h, z1_, u0, v0);
		t.vertexUV(X + 0, Y + 0, z1, u0, v1);
		t.vertexUV(X + 1, Y + 0, z1, u1, v1);
		t.vertexUV(X + 1, Y + h, z1_, u1, v0);
		t.vertexUV(X + 1, Y + h, z0_, u0, v0);
		t.vertexUV(X + 1, Y + 0, z0, u0, v1);
		t.vertexUV(X + 0, Y + 0, z0, u1, v1);
		t.vertexUV(X + 0, Y + h, z0_, u1, v0);
	} else {
		const float f3 = 0.2f, f4 = 1 / 16.0f;
		if (((x + y + z) & 1) == 1) {
			v0 = (yt + 16) / Atlas::H; v1 = (yt + 15.99f + 16) / Atlas::H;
		}
		if (((x / 2 + y / 2 + z / 2) & 1) == 1) {
			const float tmp = u1; u1 = u0; u0 = tmp;
		}
		if (Tile::fire->canBurn(level, x - 1, y, z)) {
			t.vertexUV(X + f3, Y + h + f4, Z + 1, u1, v0);
			t.vertexUV(X + 0, Y + 0 + f4, Z + 1, u1, v1);
			t.vertexUV(X + 0, Y + 0 + f4, Z + 0, u0, v1);
			t.vertexUV(X + f3, Y + h + f4, Z + 0, u0, v0);
			t.vertexUV(X + f3, Y + h + f4, Z + 0, u0, v0);
			t.vertexUV(X + 0, Y + 0 + f4, Z + 0, u0, v1);
			t.vertexUV(X + 0, Y + 0 + f4, Z + 1, u1, v1);
			t.vertexUV(X + f3, Y + h + f4, Z + 1, u1, v0);
		}
		if (Tile::fire->canBurn(level, x + 1, y, z)) {
			t.vertexUV(X + 1 - f3, Y + h + f4, Z + 0, u0, v0);
			t.vertexUV(X + 1, Y + 0 + f4, Z + 0, u0, v1);
			t.vertexUV(X + 1, Y + 0 + f4, Z + 1, u1, v1);
			t.vertexUV(X + 1 - f3, Y + h + f4, Z + 1, u1, v0);
			t.vertexUV(X + 1 - f3, Y + h + f4, Z + 1, u1, v0);
			t.vertexUV(X + 1, Y + 0 + f4, Z + 1, u1, v1);
			t.vertexUV(X + 1, Y + 0 + f4, Z + 0, u0, v1);
			t.vertexUV(X + 1 - f3, Y + h + f4, Z + 0, u0, v0);
		}
		if (Tile::fire->canBurn(level, x, y, z - 1)) {
			t.vertexUV(X + 0, Y + h + f4, Z + f3, u1, v0);
			t.vertexUV(X + 0, Y + 0 + f4, Z + 0, u1, v1);
			t.vertexUV(X + 1, Y + 0 + f4, Z + 0, u0, v1);
			t.vertexUV(X + 1, Y + h + f4, Z + f3, u0, v0);
			t.vertexUV(X + 1, Y + h + f4, Z + f3, u0, v0);
			t.vertexUV(X + 1, Y + 0 + f4, Z + 0, u0, v1);
			t.vertexUV(X + 0, Y + 0 + f4, Z + 0, u1, v1);
			t.vertexUV(X + 0, Y + h + f4, Z + f3, u1, v0);
		}
		if (Tile::fire->canBurn(level, x, y, z + 1)) {
			t.vertexUV(X + 1, Y + h + f4, Z + 1 - f3, u0, v0);
			t.vertexUV(X + 1, Y + 0 + f4, Z + 1, u0, v1);
			t.vertexUV(X + 0, Y + 0 + f4, Z + 1, u1, v1);
			t.vertexUV(X + 0, Y + h + f4, Z + 1 - f3, u1, v0);
			t.vertexUV(X + 0, Y + h + f4, Z + 1 - f3, u1, v0);
			t.vertexUV(X + 0, Y + 0 + f4, Z + 1, u1, v1);
			t.vertexUV(X + 1, Y + 0 + f4, Z + 1, u0, v1);
			t.vertexUV(X + 1, Y + h + f4, Z + 1 - f3, u0, v0);
		}
		if (Tile::fire->canBurn(level, x, y + 1, z)) {
			const float yy = Y + 1, f2 = -0.2f;
			float a0 = xt / Atlas::W, a1 = (xt + 15.99f) / Atlas::W;
			float b0 = yt / Atlas::H, b1 = (yt + 15.99f) / Atlas::H;
			if (((x + y + 1 + z) & 1) == 0) {
				t.vertexUV(X + 0, yy + f2, Z + 0, a1, b0);
				t.vertexUV(X + 1, yy + 0, Z + 0, a1, b1);
				t.vertexUV(X + 1, yy + 0, Z + 1, a0, b1);
				t.vertexUV(X + 0, yy + f2, Z + 1, a0, b0);
				b0 = (yt + 16) / Atlas::H; b1 = (yt + 15.99f + 16) / Atlas::H;
				t.vertexUV(X + 1, yy + f2, Z + 1, a1, b0);
				t.vertexUV(X + 0, yy + 0, Z + 1, a1, b1);
				t.vertexUV(X + 0, yy + 0, Z + 0, a0, b1);
				t.vertexUV(X + 1, yy + f2, Z + 0, a0, b0);
			} else {
				t.vertexUV(X + 0, yy + f2, Z + 1, a1, b0);
				t.vertexUV(X + 0, yy + 0, Z + 0, a1, b1);
				t.vertexUV(X + 1, yy + 0, Z + 0, a0, b1);
				t.vertexUV(X + 1, yy + f2, Z + 1, a0, b0);
				b0 = (yt + 16) / Atlas::H; b1 = (yt + 15.99f + 16) / Atlas::H;
				t.vertexUV(X + 1, yy + f2, Z + 0, a1, b0);
				t.vertexUV(X + 1, yy + 0, Z + 1, a1, b1);
				t.vertexUV(X + 0, yy + 0, Z + 1, a0, b1);
				t.vertexUV(X + 0, yy + f2, Z + 0, a0, b0);
			}
		}
	}
	return true;
}

bool TileRenderer::tesselateCrossInWorld( Tile* tt, int x, int y, int z )
{
	Tesselator& t = Tesselator::forThread();

	float br = tt->getBrightness(level, x, y, z);
	int col = tt->getColor(level, x, y, z);
	float r = ((col >> 16) & 0xff) / 255.0f;
	float g = ((col >> 8) & 0xff) / 255.0f;
	float b = ((col) & 0xff) / 255.0f;
	t.color(br * r, br * g, br * b);

	float xt = float(x);
	float yt = float(y);
	float zt = float(z);

	if (tt == Tile::tallgrass) {
		long seed = (x * 3129871) ^ (z * 116129781l) ^ (y);
		seed = seed * seed * 42317861 + seed * 11;

		xt += ((((seed >> 16) & 0xf) / 15.0f) - 0.5f) * 0.5f;
		yt += ((((seed >> 20) & 0xf) / 15.0f) - 1.0f) * 0.2f;
		zt += ((((seed >> 24) & 0xf) / 15.0f) - 0.5f) * 0.5f;
	}

	tesselateCrossTexture(tt, level->getData(x, y, z), xt, yt, zt);
	return true;
	//return true;
}
bool TileRenderer::tesselateStemInWorld( Tile* _tt, int x, int y, int z ) {
	StemTile* tt = (StemTile*) _tt;
	Tesselator& t = Tesselator::forThread();

	float br = tt->getBrightness(level, x, y, z);

	int col = tt->getColor(level, x, y, z);
	float r = ((col >> 16) & 0xff) / 255.0f;
	float g = ((col >> 8) & 0xff) / 255.0f;
	float b = ((col) & 0xff) / 255.0f;

	t.color(br * r, br * g, br * b);

	tt->updateShape(level, x, y, z);
	int dir = tt->getConnectDir(level, x, y, z);
	if (dir < 0) {
		tesselateStemTexture(tt, level->getData(x, y, z), tt->yy1, float(x), float(y - 1 / 16.0f), float(z));
	} else {
		tesselateStemTexture(tt, level->getData(x, y, z), 0.5f, float(x), float(y - 1 / 16.0f), float(z));
		tesselateStemDirTexture(tt, level->getData(x, y, z), dir, tt->yy1, float(x), float(y - 1 / 16.0f), float(z));
	}
	return true;
}
void TileRenderer::tesselateTorch( Tile* tt, float x, float y, float z, float xxa, float zza )
{
	Tesselator& t = Tesselator::forThread();
	int tex = tt->getTexture(0);

	if (fixedTexture >= 0) tex = fixedTexture;
	int xt = (tex & 0xf) << 4;
	int yt = Atlas::cellPy(tex);
	float u0 = (xt) / Atlas::W;
	float u1 = (xt + 15.99f) / Atlas::W;
	float v0 = (yt) / Atlas::H;
	float v1 = (yt + 15.99f) / Atlas::H;


	float uc0 = u0 + 7 / Atlas::W;
	float vc0 = v0 + 6 / Atlas::H;
	float uc1 = u0 + 9 / Atlas::W;
	float vc1 = v0 + 8 / Atlas::H;
	x += 0.5f;
	z += 0.5f;

	float x0 = x - 0.5f;
	float x1 = x + 0.5f;
	float z0 = z - 0.5f;
	float z1 = z + 0.5f;
	float r = 1 / 16.0f;

	float h = 10.0f / 16.0f;
	t.vertexUV(x + xxa * (1 - h) - r, y + h, z + zza * (1 - h) - r, uc0, vc0);
	t.vertexUV(x + xxa * (1 - h) - r, y + h, z + zza * (1 - h) + r, uc0, vc1);
	t.vertexUV(x + xxa * (1 - h) + r, y + h, z + zza * (1 - h) + r, uc1, vc1);
	t.vertexUV(x + xxa * (1 - h) + r, y + h, z + zza * (1 - h) - r, uc1, vc0);

	t.vertexUV(x - r, y + 1, z0, u0, v0);
	t.vertexUV(x - r + xxa, y + 0, z0 + zza, u0, v1);
	t.vertexUV(x - r + xxa, y + 0, z1 + zza, u1, v1);
	t.vertexUV(x - r, y + 1, z1, u1, v0);

	t.vertexUV(x + r, y + 1, z1, u0, v0);
	t.vertexUV(x + xxa + r, y + 0, z1 + zza, u0, v1);
	t.vertexUV(x + xxa + r, y + 0, z0 + zza, u1, v1);
	t.vertexUV(x + r, y + 1, z0, u1, v0);

	t.vertexUV(x0, y + 1, z + r, u0, v0);
	t.vertexUV(x0 + xxa, y + 0, z + r + zza, u0, v1);
	t.vertexUV(x1 + xxa, y + 0, z + r + zza, u1, v1);
	t.vertexUV(x1, y + 1, z + r, u1, v0);

	t.vertexUV(x1, y + 1, z - r, u0, v0);
	t.vertexUV(x1 + xxa, y + 0, z - r + zza, u0, v1);
	t.vertexUV(x0 + xxa, y + 0, z - r + zza, u1, v1);
	t.vertexUV(x0, y + 1, z - r, u1, v0);
}

void TileRenderer::tesselateCrossTexture( Tile* tt, int data, float x, float y, float z )
{
	Tesselator& t = Tesselator::forThread();

	int tex = tt->getTexture(0, data);

	if (fixedTexture >= 0) tex = fixedTexture;
	int xt = (tex & 0xf) << 4;
	int yt = Atlas::cellPy(tex);
	float u0 = (xt) / Atlas::W;
	float u1 = (xt + 15.99f) / Atlas::W;
	float v0 = (yt) / Atlas::H;
	float v1 = (yt + 15.99f) / Atlas::H;

	float x0 = x + 0.5f - 0.45f;
	float x1 = x + 0.5f + 0.45f;
	float z0 = z + 0.5f - 0.45f;
	float z1 = z + 0.5f + 0.45f;

	t.vertexUV(x0, y + 1, z0, u0, v0);
	t.vertexUV(x0, y + 0, z0, u0, v1);
	t.vertexUV(x1, y + 0, z1, u1, v1);
	t.vertexUV(x1, y + 1, z1, u1, v0);

	t.vertexUV(x1, y + 1, z1, u0, v0);
	t.vertexUV(x1, y + 0, z1, u0, v1);
	t.vertexUV(x0, y + 0, z0, u1, v1);
	t.vertexUV(x0, y + 1, z0, u1, v0);

	t.vertexUV(x0, y + 1, z1, u0, v0);
	t.vertexUV(x0, y + 0, z1, u0, v1);
	t.vertexUV(x1, y + 0, z0, u1, v1);
	t.vertexUV(x1, y + 1, z0, u1, v0);

	t.vertexUV(x1, y + 1, z0, u0, v0);
	t.vertexUV(x1, y + 0, z0, u0, v1);
	t.vertexUV(x0, y + 0, z1, u1, v1);
	t.vertexUV(x0, y + 1, z1, u1, v0);
}
void TileRenderer::tesselateStemTexture( Tile* tt, int data, float h, float x, float y, float z ) {
	Tesselator& t = Tesselator::forThread();
	int tex = tt->getTexture(0, data);
	if(fixedTexture >= 0) tex = fixedTexture;
	int xt = (tex & 0xf) << 4;
	int yt = Atlas::cellPy(tex);
	float u0 = (xt) / Atlas::W;
	float u1 = (xt + 15.99f) / Atlas::W;
	float v0 = (yt) / Atlas::H;
	float v1 = (yt + 15.99f * h) / Atlas::H;

	float x0 = x + 0.5f - 0.45f;
	float x1 = x + 0.5f + 0.45f;
	float z0 = z + 0.5f - 0.45f;
	float z1 = z + 0.5f + 0.45f;

	t.vertexUV(x0, y + h, z0, u0, v0);
	t.vertexUV(x0, y + 0, z0, u0, v1);
	t.vertexUV(x1, y + 0, z1, u1, v1);
	t.vertexUV(x1, y + h, z1, u1, v0);

	t.vertexUV(x1, y + h, z1, u0, v0);
	t.vertexUV(x1, y + 0, z1, u0, v1);
	t.vertexUV(x0, y + 0, z0, u1, v1);
	t.vertexUV(x0, y + h, z0, u1, v0);

	t.vertexUV(x0, y + h, z1, u0, v0);
	t.vertexUV(x0, y + 0, z1, u0, v1);
	t.vertexUV(x1, y + 0, z0, u1, v1);
	t.vertexUV(x1, y + h, z0, u1, v0);

	t.vertexUV(x1, y + h, z0, u0, v0);
	t.vertexUV(x1, y + 0, z0, u0, v1);
	t.vertexUV(x0, y + 0, z1, u1, v1);
	t.vertexUV(x0, y + h, z1, u1, v0);
}
void TileRenderer::tesselateStemDirTexture( Tile* tt, int data, int dir, float h, float x, float y, float z ) {
	Tesselator& t = Tesselator::forThread();

	int tex = tt->getTexture(0, data) + 16;

	if (fixedTexture >= 0) tex = fixedTexture;
	int xt = (tex & 0xf) << 4;
	int yt = Atlas::cellPy(tex);
	float u0 = (xt) / Atlas::W;
	float u1 = (xt + 15.99f) / Atlas::W;
	float v0 = (yt) / Atlas::H;
	float v1 = (yt + 15.99f * h) / Atlas::H;

	float x0 = x + 0.5f - 0.5f;
	float x1 = x + 0.5f + 0.5f;
	float z0 = z + 0.5f - 0.5f;
	float z1 = z + 0.5f + 0.5f;

	float xm = x + 0.5f;
	float zm = z + 0.5f;

	if ((dir + 1) / 2 % 2 == 1) {
		float tmp = u1;
		u1 = u0;
		u0 = tmp;
	}

	if (dir < 2) {
		t.vertexUV(x0, y + h, zm, u0, v0);
		t.vertexUV(x0, y + 0, zm, u0, v1);
		t.vertexUV(x1, y + 0, zm, u1, v1);
		t.vertexUV(x1, y + h, zm, u1, v0);

		t.vertexUV(x1, y + h, zm, u1, v0);
		t.vertexUV(x1, y + 0, zm, u1, v1);
		t.vertexUV(x0, y + 0, zm, u0, v1);
		t.vertexUV(x0, y + h, zm, u0, v0);
	} else {

		t.vertexUV(xm, y + h, z1, u0, v0);
		t.vertexUV(xm, y + 0, z1, u0, v1);
		t.vertexUV(xm, y + 0, z0, u1, v1);
		t.vertexUV(xm, y + h, z0, u1, v0);

		t.vertexUV(xm, y + h, z0, u1, v0);
		t.vertexUV(xm, y + 0, z0, u1, v1);
		t.vertexUV(xm, y + 0, z1, u0, v1);
		t.vertexUV(xm, y + h, z1, u0, v0);
	}
}

bool TileRenderer::tesselateWaterInWorld( Tile* tt, int x, int y, int z )
{
	Tesselator& t = Tesselator::forThread();

	bool up = tt->shouldRenderFace(level, x, y + 1, z, 1);
	bool down = tt->shouldRenderFace(level, x, y - 1, z, 0);

	bool dirs[4]; // static?
	dirs[0] = tt->shouldRenderFace(level, x, y, z - 1, 2);
	dirs[1] = tt->shouldRenderFace(level, x, y, z + 1, 3);
	dirs[2] = tt->shouldRenderFace(level, x - 1, y, z, 4);
	dirs[3] = tt->shouldRenderFace(level, x + 1, y, z, 5);

	if (!up && !down && !dirs[0] && !dirs[1] && !dirs[2] && !dirs[3]) return false;

	bool changed = false;
	float c10 = 0.5f;
	float c11 = 1;
	float c2 = 0.8f;
	float c3 = 0.6f;

	const float yo0 = 0;
	const float yo1 = 1;

	const Material* m = tt->material;
	float tr = 1, tg = 1, tb = 1;
	const int tint = ModLiquids::tintOf(tt->id);
	if (tint >= 0) { tr = ((tint >> 16) & 255) / 255.0f; tg = ((tint >> 8) & 255) / 255.0f; tb = (tint & 255) / 255.0f; }
	int data = level->getData(x, y, z);

	float h0 = getWaterHeight(x, y, z, m);
	float h1 = getWaterHeight(x, y, z + 1, m);
	float h2 = getWaterHeight(x + 1, y, z + 1, m);
	float h3 = getWaterHeight(x + 1, y, z, m);

	// renderFaceUp(tt, x, y, z, tt->getTexture(0));
	if (noCulling || up) {
		changed = true;
		int tex = tt->getTexture(1, data);
		float angle = (float) LiquidTile::getSlopeAngle(level, x, y, z, m);
		if (angle > -999) {
			tex = tt->getTexture(2, data);
		}
		int xt = (tex & 0xf) << 4;
		int yt = Atlas::cellPy(tex);

		float uc = (xt + 0.5f * 16) / Atlas::W;
		float vc = (yt + 0.5f * 16) / Atlas::H;
		if (angle < -999) {
			angle = 0;
		} else {
			uc = (xt + 1 * 16) / Atlas::W;
			vc = (yt + 1 * 16) / Atlas::H;
		}
		float s = (Mth::sin(angle) * 8) / 256.5f; // @attn: to get rid of "jitter" (caused
		float c = (Mth::cos(angle) * 8) / 256.5f; //  of fp rounding errors) in big oceans)
		const float sv = s * (Atlas::W / Atlas::H), cv = c * (Atlas::W / Atlas::H);

		float br = tt->getBrightness(level, x, y, z);
		t.color(c11 * br * tr, c11 * br * tg, c11 * br * tb);
		t.vertexUV((float)x + 0, (float)y + h0, (float)z + 0, uc - c - s, vc - cv + sv);
		t.vertexUV((float)x + 0, (float)y + h1, (float)z + 1, uc - c + s, vc + cv + sv);
		t.vertexUV((float)x + 1, (float)y + h2, (float)z + 1, uc + c + s, vc + cv - sv);
		t.vertexUV((float)x + 1, (float)y + h3, (float)z + 0, uc + c - s, vc - cv - sv);
	}

	if (noCulling || down) {
		float br = tt->getBrightness(level, x, y - 1, z);
		t.color(c10 * br * tr, c10 * br * tg, c10 * br * tb);
		renderFaceDown(tt, (float)x, (float)y, (float)z, tt->getTexture(0));
		changed = true;
	}

	for (int face = 0; face < 4; face++) {
		int xt = x;
		int yt = y;
		int zt = z;

		if (face == 0) zt--;
		if (face == 1) zt++;
		if (face == 2) xt--;
		if (face == 3) xt++;

		int tex = tt->getTexture(face + 2, data);
		int xTex = (tex & 0xf) << 4;
		int yTex = Atlas::cellPy(tex);

		if (noCulling || dirs[face]) {
			float hh0;
			float hh1;
			float x0, z0, x1, z1;
			if (face == 0) {
				hh0 = h0;
				hh1 = h3;
				x0 = (float)(x    );
				x1 = (float)(x + 1);
				z0 = (float)(z    );
				z1 = (float)(z    );
			} else if (face == 1) {
				hh0 = h2;
				hh1 = h1;
				x0 = (float)(x + 1);
				x1 = (float)(x    );
				z0 = (float)(z + 1);
				z1 = (float)(z + 1);
			} else if (face == 2) {
				hh0 = h1;
				hh1 = h0;
				x0 = (float)(x    );
				x1 = (float)(x    );
				z0 = (float)(z + 1);
				z1 = (float)(z    );
			} else {
				hh0 = h3;
				hh1 = h2;
				x0 = (float)(x + 1);
				x1 = (float)(x + 1);
				z0 = (float)(z    );
				z1 = (float)(z + 1);
			}

			changed = true;
			float u0 = (xTex + 0 * 16) / Atlas::W;
			float u1 = (xTex + 1 * 16 - 0.01f) / Atlas::W;

			float v01 = (yTex + (1 - hh0) * 16) / Atlas::H;
			float v02 = (yTex + (1 - hh1) * 16) / Atlas::H;
			float v1 = (yTex + 1 * 16 - 0.01f) / Atlas::H;

			float br = tt->getBrightness(level, xt, yt, zt);
			if (face < 2) br *= c2;
			else br *= c3;

			float yf = (float)y;
			t.color(c11 * br * tr, c11 * br * tg, c11 * br * tb);
			t.vertexUV(x0, yf + hh0, z0, u0, v01);
			t.vertexUV(x1, yf + hh1, z1, u1, v02);
			t.vertexUV(x1, yf + 0, z1, u1, v1);
			t.vertexUV(x0, yf + 0, z0, u0, v1);
		}
	}

	//printf("w: %d ", (dirs[0] + dirs[1] + dirs[2] + dirs[3] + up + down));

	tt->yy0 = yo0;
	tt->yy1 = yo1;

	return changed;
}

float TileRenderer::getWaterHeight( int x, int y, int z, const Material* m )
{
	int count = 0;
	float h = 0;
	for (int i = 0; i < 4; i++) {
		int xx = x - (i & 1);
		int yy = y;
		int zz = z - ((i >> 1) & 1);
		if (level->getMaterial(xx, yy + 1, zz) == m) {
			return 1;
		}
		const Material* tm = level->getMaterial(xx, yy, zz);
		if (tm == m) {
			int d = tm->liquidDepth(level->getData(xx, yy, zz));
			if (d >= 8 || d == 0) {
				h += (LiquidTile::getHeight(d)) * 10;
				count += 10;
			}
			h += LiquidTile::getHeight(d);
			count++;
		} else if (!tm->isSolid()) {
			h += 1;
			count++;
		}
	}
	return 1 - h / count;
}

void TileRenderer::renderBlock(Tile* tt, LevelSource* level, int x, int y, int z, int data) {
#define RB_TEX(f) (data >= 0 ? tt->getTexture(f, data) : tt->getTexture(f))
    float c10 = 0.5f;
    float c11 = 1;
    float c2 = 0.8f;
    float c3 = 0.6f;

    Tesselator& t = Tesselator::forThread();
    t.begin();

    float center = tt->getBrightness(level, x, y, z);
    float br = tt->getBrightness(level, x, y - 1, z);
    if (br < center) br = center;

    t.color(c10 * br, c10 * br, c10 * br);
    renderFaceDown(tt, -0.5f, -0.5f, -0.5f, RB_TEX(0));

    br = tt->getBrightness(level, x, y + 1, z);
    if (br < center) br = center;
    t.color(c11 * br, c11 * br, c11 * br);
    renderFaceUp(tt, -0.5f, -0.5f, -0.5f, RB_TEX(1));

    br = tt->getBrightness(level, x, y, z - 1);
    if (br < center) br = center;
    t.color(c2 * br, c2 * br, c2 * br);
    renderNorth(tt, -0.5f, -0.5f, -0.5f, RB_TEX(2));

    br = tt->getBrightness(level, x, y, z + 1);
    if (br < center) br = center;
    t.color(c2 * br, c2 * br, c2 * br);
    renderSouth(tt, -0.5f, -0.5f, -0.5f, RB_TEX(3));

    br = tt->getBrightness(level, x - 1, y, z);
    if (br < center) br = center;
    t.color(c3 * br, c3 * br, c3 * br);
    renderWest(tt, -0.5f, -0.5f, -0.5f, RB_TEX(4));

    br = tt->getBrightness(level, x + 1, y, z);
    if (br < center) br = center;
    t.color(c3 * br, c3 * br, c3 * br);
    renderEast(tt, -0.5f, -0.5f, -0.5f, RB_TEX(5));
    t.draw();
}
#undef RB_TEX

bool TileRenderer::tesselateBlockInWorldWithAmbienceOcclusion( Tile* tt, int pX, int pY, int pZ, float pBaseRed, float pBaseGreen, float pBaseBlue )
{
	applyAmbienceOcclusion = true;
	bool i = false;
	float ll1 = ll000;
	float ll2 = ll000;
	float ll3 = ll000;
	float ll4 = ll000;
	bool tint0 = true;
	bool tint1 = true;
	bool tint2 = true;
	bool tint3 = true;
	bool tint4 = true;
	bool tint5 = true;

	ll000 = tt->getBrightness(level, pX, pY, pZ);
	llx00 = tt->getBrightness(level, pX - 1, pY, pZ);
	ll0y0 = tt->getBrightness(level, pX, pY - 1, pZ);
	ll00z = tt->getBrightness(level, pX, pY, pZ - 1);
	llX00 = tt->getBrightness(level, pX + 1, pY, pZ);
	ll0Y0 = tt->getBrightness(level, pX, pY + 1, pZ);
	ll00Z = tt->getBrightness(level, pX, pY, pZ + 1);

	llTransXY0 = Tile::translucent[level->getTile(pX + 1, pY + 1, pZ)];
	llTransXy0 = Tile::translucent[level->getTile(pX + 1, pY - 1, pZ)];
	llTransX0Z = Tile::translucent[level->getTile(pX + 1, pY, pZ + 1)];
	llTransX0z = Tile::translucent[level->getTile(pX + 1, pY, pZ - 1)];
	llTransxY0 = Tile::translucent[level->getTile(pX - 1, pY + 1, pZ)];
	llTransxy0 = Tile::translucent[level->getTile(pX - 1, pY - 1, pZ)];
	llTransx0z = Tile::translucent[level->getTile(pX - 1, pY, pZ - 1)];
	llTransx0Z = Tile::translucent[level->getTile(pX - 1, pY, pZ + 1)];
	llTrans0YZ = Tile::translucent[level->getTile(pX, pY + 1, pZ + 1)];
	llTrans0Yz = Tile::translucent[level->getTile(pX, pY + 1, pZ - 1)];
	llTrans0yZ = Tile::translucent[level->getTile(pX, pY - 1, pZ + 1)];
	llTrans0yz = Tile::translucent[level->getTile(pX, pY - 1, pZ - 1)];

	if (tt->tex == 3) tint0 = tint2 = tint3 = tint4 = tint5 = false;

	if ((noCulling) || (tt->shouldRenderFace(level, pX, pY - 1, pZ, 0))) {
		if (blsmooth > 0) {
			pY--;

			llxy0 = tt->getBrightness(level, pX - 1, pY, pZ);
			ll0yz = tt->getBrightness(level, pX, pY, pZ - 1);
			ll0yZ = tt->getBrightness(level, pX, pY, pZ + 1);
			llXy0 = tt->getBrightness(level, pX + 1, pY, pZ);

			if (llTrans0yz || llTransxy0) {
				llxyz = tt->getBrightness(level, pX - 1, pY, pZ - 1);
			} else {
				llxyz = llxy0;
			}
			if (llTrans0yZ || llTransxy0) {
				llxyZ = tt->getBrightness(level, pX - 1, pY, pZ + 1);
			} else {
				llxyZ = llxy0;
			}
			if (llTrans0yz || llTransXy0) {
				llXyz = tt->getBrightness(level, pX + 1, pY, pZ - 1);
			} else {
				llXyz = llXy0;
			}
			if (llTrans0yZ || llTransXy0) {
				llXyZ = tt->getBrightness(level, pX + 1, pY, pZ + 1);
			} else {
				llXyZ = llXy0;
			}

			pY++;
			ll1 = (llxyZ + llxy0 + ll0yZ + ll0y0) / 4.0f;
			ll4 = (ll0yZ + ll0y0 + llXyZ + llXy0) / 4.0f;
			ll3 = (ll0y0 + ll0yz + llXy0 + llXyz) / 4.0f;
			ll2 = (llxy0 + llxyz + ll0y0 + ll0yz) / 4.0f;
		} else ll1 = ll2 = ll3 = ll4 = ll0y0;
		c1r = c2r = c3r = c4r = (tint0 ? pBaseRed : 1.0f) * 0.5f;
		c1g = c2g = c3g = c4g = (tint0 ? pBaseGreen : 1.0f) * 0.5f;
		c1b = c2b = c3b = c4b = (tint0 ? pBaseBlue : 1.0f) * 0.5f;
		c1r *= ll1;
		c1g *= ll1;
		c1b *= ll1;
		c2r *= ll2;
		c2g *= ll2;
		c2b *= ll2;
		c3r *= ll3;
		c3g *= ll3;
		c3b *= ll3;
		c4r *= ll4;
		c4g *= ll4;
		c4b *= ll4;

		renderFaceDown(tt, (float) pX, (float) pY, (float) pZ, tt->getTexture(level, pX, pY, pZ, 0));
		i = true;
	}
	if ((noCulling) || (tt->shouldRenderFace(level, pX, pY + 1, pZ, 1))) {
		if (blsmooth > 0) {
			pY++;

			llxY0 = tt->getBrightness(level, pX - 1, pY, pZ);
			llXY0 = tt->getBrightness(level, pX + 1, pY, pZ);
			ll0Yz = tt->getBrightness(level, pX, pY, pZ - 1);
			ll0YZ = tt->getBrightness(level, pX, pY, pZ + 1);

			if (llTrans0Yz || llTransxY0) {
				llxYz = tt->getBrightness(level, pX - 1, pY, pZ - 1);
			} else {
				llxYz = llxY0;
			}
			if (llTrans0Yz || llTransXY0) {
				llXYz = tt->getBrightness(level, pX + 1, pY, pZ - 1);
			} else {
				llXYz = llXY0;
			}
			if (llTrans0YZ || llTransxY0) {
				llxYZ = tt->getBrightness(level, pX - 1, pY, pZ + 1);
			} else {
				llxYZ = llxY0;
			}
			if (llTrans0YZ || llTransXY0) {
				llXYZ = tt->getBrightness(level, pX + 1, pY, pZ + 1);
			} else {
				llXYZ = llXY0;
			}
			pY--;

			ll4 = (llxYZ + llxY0 + ll0YZ + ll0Y0) / 4.0f;
			ll1 = (ll0YZ + ll0Y0 + llXYZ + llXY0) / 4.0f;
			ll2 = (ll0Y0 + ll0Yz + llXY0 + llXYz) / 4.0f;
			ll3 = (llxY0 + llxYz + ll0Y0 + ll0Yz) / 4.0f;
		} else ll1 = ll2 = ll3 = ll4 = ll0Y0;
		c1r = c2r = c3r = c4r = (tint1 ? pBaseRed : 1.0f);
		c1g = c2g = c3g = c4g = (tint1 ? pBaseGreen : 1.0f);
		c1b = c2b = c3b = c4b = (tint1 ? pBaseBlue : 1.0f);
		c1r *= ll1;
		c1g *= ll1;
		c1b *= ll1;
		c2r *= ll2;
		c2g *= ll2;
		c2b *= ll2;
		c3r *= ll3;
		c3g *= ll3;
		c3b *= ll3;
		c4r *= ll4;
		c4g *= ll4;
		c4b *= ll4;
		renderFaceUp(tt, (float) pX, (float) pY, (float) pZ, tt->getTexture(level, pX, pY, pZ, 1));
		i = true;
	}
	if ((noCulling) || (tt->shouldRenderFace(level, pX, pY, pZ - 1, 2))) {
		if (blsmooth > 0) {
			pZ--;
			llx0z = tt->getBrightness(level, pX - 1, pY, pZ);
			ll0yz = tt->getBrightness(level, pX, pY - 1, pZ);
			ll0Yz = tt->getBrightness(level, pX, pY + 1, pZ);
			llX0z = tt->getBrightness(level, pX + 1, pY, pZ);

			if (llTransx0z || llTrans0yz) {
				llxyz = tt->getBrightness(level, pX - 1, pY - 1, pZ);
			} else {
				llxyz = llx0z;
			}
			if (llTransx0z || llTrans0Yz) {
				llxYz = tt->getBrightness(level, pX - 1, pY + 1, pZ);
			} else {
				llxYz = llx0z;
			}
			if (llTransX0z || llTrans0yz) {
				llXyz = tt->getBrightness(level, pX + 1, pY - 1, pZ);
			} else {
				llXyz = llX0z;
			}
			if (llTransX0z || llTrans0Yz) {
				llXYz = tt->getBrightness(level, pX + 1, pY + 1, pZ);
			} else {
				llXYz = llX0z;
			}
			pZ++;
			ll1 = (llx0z + llxYz + ll00z + ll0Yz) / 4.0f;
			ll2 = (ll00z + ll0Yz + llX0z + llXYz) / 4.0f;
			ll3 = (ll0yz + ll00z + llXyz + llX0z) / 4.0f;
			ll4 = (llxyz + llx0z + ll0yz + ll00z) / 4.0f;
		} else ll1 = ll2 = ll3 = ll4 = ll00z;
		const int ft = tt->getTexture(level, pX, pY, pZ, 2);
		const bool split = grassSideSplits(tt, ft, 2, fixedTexture, xFlipTexture, pBaseRed, pBaseGreen, pBaseBlue);
		const bool tintF = tint2 && !split;
		c1r = c2r = c3r = c4r = (tintF ? pBaseRed : 1.0f) * 0.8f;
		c1g = c2g = c3g = c4g = (tintF ? pBaseGreen : 1.0f) * 0.8f;
		c1b = c2b = c3b = c4b = (tintF ? pBaseBlue : 1.0f) * 0.8f;
		c1r *= ll1;
		c1g *= ll1;
		c1b *= ll1;
		c2r *= ll2;
		c2g *= ll2;
		c2b *= ll2;
		c3r *= ll3;
		c3g *= ll3;
		c3b *= ll3;
		c4r *= ll4;
		c4g *= ll4;
		c4b *= ll4;
		if (split) {
			const float C[4][3] = { {c1r, c1g, c1b}, {c2r, c2g, c2b}, {c3r, c3g, c3b}, {c4r, c4g, c4b} };
			grassSideSplit(Tesselator::forThread(), 2, (float) pX, (float) pY, (float) pZ, C, pBaseRed, pBaseGreen, pBaseBlue);
		} else renderNorth(tt, (float) pX, (float) pY, (float) pZ, ft);
		i = true;
	}
	if ((noCulling) || (tt->shouldRenderFace(level, pX, pY, pZ + 1, 3))) {
		if (blsmooth > 0) {
			pZ++;

			llx0Z = tt->getBrightness(level, pX - 1, pY, pZ);
			llX0Z = tt->getBrightness(level, pX + 1, pY, pZ);
			ll0yZ = tt->getBrightness(level, pX, pY - 1, pZ);
			ll0YZ = tt->getBrightness(level, pX, pY + 1, pZ);

			if (llTransx0Z || llTrans0yZ) {
				llxyZ = tt->getBrightness(level, pX - 1, pY - 1, pZ);
			} else {
				llxyZ = llx0Z;
			}
			if (llTransx0Z || llTrans0YZ) {
				llxYZ = tt->getBrightness(level, pX - 1, pY + 1, pZ);
			} else {
				llxYZ = llx0Z;
			}
			if (llTransX0Z || llTrans0yZ) {
				llXyZ = tt->getBrightness(level, pX + 1, pY - 1, pZ);
			} else {
				llXyZ = llX0Z;
			}
			if (llTransX0Z || llTrans0YZ) {
				llXYZ = tt->getBrightness(level, pX + 1, pY + 1, pZ);
			} else {
				llXYZ = llX0Z;
			}
			pZ--;
			ll1 = (llx0Z + llxYZ + ll00Z + ll0YZ) / 4.0f;
			ll4 = (ll00Z + ll0YZ + llX0Z + llXYZ) / 4.0f;
			ll3 = (ll0yZ + ll00Z + llXyZ + llX0Z) / 4.0f;
			ll2 = (llxyZ + llx0Z + ll0yZ + ll00Z) / 4.0f;
		} else ll1 = ll2 = ll3 = ll4 = ll00Z;
		const int ft = tt->getTexture(level, pX, pY, pZ, 3);
		const bool split = grassSideSplits(tt, ft, 3, fixedTexture, xFlipTexture, pBaseRed, pBaseGreen, pBaseBlue);
		const bool tintF = tint3 && !split;
		c1r = c2r = c3r = c4r = (tintF ? pBaseRed : 1.0f) * 0.8f;
		c1g = c2g = c3g = c4g = (tintF ? pBaseGreen : 1.0f) * 0.8f;
		c1b = c2b = c3b = c4b = (tintF ? pBaseBlue : 1.0f) * 0.8f;
		c1r *= ll1;
		c1g *= ll1;
		c1b *= ll1;
		c2r *= ll2;
		c2g *= ll2;
		c2b *= ll2;
		c3r *= ll3;
		c3g *= ll3;
		c3b *= ll3;
		c4r *= ll4;
		c4g *= ll4;
		c4b *= ll4;
		if (split) {
			const float C[4][3] = { {c1r, c1g, c1b}, {c2r, c2g, c2b}, {c3r, c3g, c3b}, {c4r, c4g, c4b} };
			grassSideSplit(Tesselator::forThread(), 3, (float) pX, (float) pY, (float) pZ, C, pBaseRed, pBaseGreen, pBaseBlue);
		} else renderSouth(tt, (float) pX, (float) pY, (float) pZ, ft);
		i = true;
	}
	if ((noCulling) || (tt->shouldRenderFace(level, pX - 1, pY, pZ, 4))) {
		if (blsmooth > 0) {
			pX--;
			llxy0 = tt->getBrightness(level, pX, pY - 1, pZ);
			llx0z = tt->getBrightness(level, pX, pY, pZ - 1);
			llx0Z = tt->getBrightness(level, pX, pY, pZ + 1);
			llxY0 = tt->getBrightness(level, pX, pY + 1, pZ);

			if (llTransx0z || llTransxy0) {
				llxyz = tt->getBrightness(level, pX, pY - 1, pZ - 1);
			} else {
				llxyz = llx0z;
			}
			if (llTransx0Z || llTransxy0) {
				llxyZ = tt->getBrightness(level, pX, pY - 1, pZ + 1);
			} else {
				llxyZ = llx0Z;
			}
			if (llTransx0z || llTransxY0) {
				llxYz = tt->getBrightness(level, pX, pY + 1, pZ - 1);
			} else {
				llxYz = llx0z;
			}
			if (llTransx0Z || llTransxY0) {
				llxYZ = tt->getBrightness(level, pX, pY + 1, pZ + 1);
			} else {
				llxYZ = llx0Z;
			}
			pX++;
			ll4 = (llxy0 + llxyZ + llx00 + llx0Z) / 4.0f;
			ll1 = (llx00 + llx0Z + llxY0 + llxYZ) / 4.0f;
			ll2 = (llx0z + llx00 + llxYz + llxY0) / 4.0f;
			ll3 = (llxyz + llxy0 + llx0z + llx00) / 4.0f;
		} else ll1 = ll2 = ll3 = ll4 = llx00;
		const int ft = tt->getTexture(level, pX, pY, pZ, 4);
		const bool split = grassSideSplits(tt, ft, 4, fixedTexture, xFlipTexture, pBaseRed, pBaseGreen, pBaseBlue);
		const bool tintF = tint4 && !split;
		c1r = c2r = c3r = c4r = (tintF ? pBaseRed : 1.0f) * 0.6f;
		c1g = c2g = c3g = c4g = (tintF ? pBaseGreen : 1.0f) * 0.6f;
		c1b = c2b = c3b = c4b = (tintF ? pBaseBlue : 1.0f) * 0.6f;
		c1r *= ll1;
		c1g *= ll1;
		c1b *= ll1;
		c2r *= ll2;
		c2g *= ll2;
		c2b *= ll2;
		c3r *= ll3;
		c3g *= ll3;
		c3b *= ll3;
		c4r *= ll4;
		c4g *= ll4;
		c4b *= ll4;
		if (split) {
			const float C[4][3] = { {c1r, c1g, c1b}, {c2r, c2g, c2b}, {c3r, c3g, c3b}, {c4r, c4g, c4b} };
			grassSideSplit(Tesselator::forThread(), 4, (float) pX, (float) pY, (float) pZ, C, pBaseRed, pBaseGreen, pBaseBlue);
		} else renderWest(tt, (float) pX, (float) pY, (float) pZ, ft);
		i = true;
	}
	if ((noCulling) || (tt->shouldRenderFace(level, pX + 1, pY, pZ, 5))) {
		if (blsmooth > 0) {
			pX++;
			llXy0 = tt->getBrightness(level, pX, pY - 1, pZ);
			llX0z = tt->getBrightness(level, pX, pY, pZ - 1);
			llX0Z = tt->getBrightness(level, pX, pY, pZ + 1);
			llXY0 = tt->getBrightness(level, pX, pY + 1, pZ);

			if (llTransXy0 || llTransX0z) {
				llXyz = tt->getBrightness(level, pX, pY - 1, pZ - 1);
			} else {
				llXyz = llX0z;
			}
			if (llTransXy0 || llTransX0Z) {
				llXyZ = tt->getBrightness(level, pX, pY - 1, pZ + 1);
			} else {
				llXyZ = llX0Z;
			}
			if (llTransXY0 || llTransX0z) {
				llXYz = tt->getBrightness(level, pX, pY + 1, pZ - 1);
			} else {
				llXYz = llX0z;
			}
			if (llTransXY0 || llTransX0Z) {
				llXYZ = tt->getBrightness(level, pX, pY + 1, pZ + 1);
			} else {
				llXYZ = llX0Z;
			}
			pX--;
			ll1 = (llXy0 + llXyZ + llX00 + llX0Z) / 4.0f;
			ll4 = (llX00 + llX0Z + llXY0 + llXYZ) / 4.0f;
			ll3 = (llX0z + llX00 + llXYz + llXY0) / 4.0f;
			ll2 = (llXyz + llXy0 + llX0z + llX00) / 4.0f;
		} else ll1 = ll2 = ll3 = ll4 = llX00;
		const int ft = tt->getTexture(level, pX, pY, pZ, 5);
		const bool split = grassSideSplits(tt, ft, 5, fixedTexture, xFlipTexture, pBaseRed, pBaseGreen, pBaseBlue);
		const bool tintF = tint5 && !split;
		c1r = c2r = c3r = c4r = (tintF ? pBaseRed : 1.0f) * 0.6f;
		c1g = c2g = c3g = c4g = (tintF ? pBaseGreen : 1.0f) * 0.6f;
		c1b = c2b = c3b = c4b = (tintF ? pBaseBlue : 1.0f) * 0.6f;
		c1r *= ll1;
		c1g *= ll1;
		c1b *= ll1;
		c2r *= ll2;
		c2g *= ll2;
		c2b *= ll2;
		c3r *= ll3;
		c3g *= ll3;
		c3b *= ll3;
		c4r *= ll4;
		c4g *= ll4;
		c4b *= ll4;

		if (split) {
			const float C[4][3] = { {c1r, c1g, c1b}, {c2r, c2g, c2b}, {c3r, c3g, c3b}, {c4r, c4g, c4b} };
			grassSideSplit(Tesselator::forThread(), 5, (float) pX, (float) pY, (float) pZ, C, pBaseRed, pBaseGreen, pBaseBlue);
		} else renderEast(tt, (float) pX, (float) pY, (float) pZ, ft);
		i = true;
	}
	applyAmbienceOcclusion = false;
	return i;
}

int TileRenderer::lightAt(int x, int y, int z)
{
	const int lp = level->getLightPair(x, y, z);
	return TerrainLight::pack(lp >> 8, lp & 15);
}

namespace {
	struct AoFace {
		signed char n[3], a[3], b[3];
		signed char corner[4][2];
		bool diagAlongB;
	};
	const AoFace AO_FACES[6] = {
		{ { 0, -1, 0 }, { 1, 0, 0 }, { 0, 0, 1 }, { { -1, 1 }, { -1, -1 }, { 1, -1 }, { 1, 1 } }, false },
		{ { 0, 1, 0 },  { 1, 0, 0 }, { 0, 0, 1 }, { { 1, 1 }, { 1, -1 }, { -1, -1 }, { -1, 1 } }, false },
		{ { 0, 0, -1 }, { 1, 0, 0 }, { 0, 1, 0 }, { { -1, 1 }, { 1, 1 }, { 1, -1 }, { -1, -1 } }, false },
		{ { 0, 0, 1 },  { 1, 0, 0 }, { 0, 1, 0 }, { { -1, 1 }, { -1, -1 }, { 1, -1 }, { 1, 1 } }, false },
		{ { -1, 0, 0 }, { 0, 1, 0 }, { 0, 0, 1 }, { { 1, 1 }, { 1, -1 }, { -1, -1 }, { -1, 1 } }, true },
		{ { 1, 0, 0 },  { 0, 1, 0 }, { 0, 0, 1 }, { { -1, 1 }, { -1, -1 }, { 1, -1 }, { 1, 1 } }, true },
	};
	inline int aoBrightness(int a, int b, int c, int face) {
		if (a == 0) a = face;
		if (b == 0) b = face;
		if (c == 0) c = face;
		const int sky = (TerrainLight::sky16(a) + TerrainLight::sky16(b) + TerrainLight::sky16(c) + TerrainLight::sky16(face)) >> 2;
		const int block = (TerrainLight::block16(a) + TerrainLight::block16(b) + TerrainLight::block16(c) + TerrainLight::block16(face)) >> 2;
		return TerrainLight::packRaw(sky, block);
	}
}

void TileRenderer::aoCorners(Tile* tt, int x, int y, int z, int face, bool flush)
{
	const AoFace& f = AO_FACES[face];
	const int fx = x + f.n[0], fy = y + f.n[1], fz = z + f.n[2];
	const int lx = flush ? fx : x, ly = flush ? fy : y, lz = flush ? fz : z;
	const int faceLight = (flush || !level->isSolidRenderTile(fx, fy, fz)) ? lightAt(fx, fy, fz) : lightAt(x, y, z);
	const float aoFront = level->isSolidBlockingTile(fx, fy, fz) ? 0.2f : 1.0f;
	int eL[4];
	float eA[4];
	bool eT[4];
	for (int i = 0; i < 4; ++i) {
		const signed char* d = i < 2 ? f.a : f.b;
		const int s = (i & 1) ? 1 : -1;
		const int cx = lx + d[0] * s, cy = ly + d[1] * s, cz = lz + d[2] * s;
		eL[i] = lightAt(cx, cy, cz);
		eA[i] = level->isSolidBlockingTile(cx, cy, cz) ? 0.2f : 1.0f;
		eT[i] = Tile::translucent[level->getTile(fx + d[0] * s, fy + d[1] * s, fz + d[2] * s)];
	}
	int L[4];
	float O[4];
	for (int k = 0; k < 4; ++k) {
		const int sa = f.corner[k][0], sb = f.corner[k][1];
		const int ia = sa > 0 ? 1 : 0, ib = sb > 0 ? 3 : 2;
		int dL;
		float dA;
		if (eT[ia] || eT[ib]) {
			const int cx = lx + f.a[0] * sa + f.b[0] * sb, cy = ly + f.a[1] * sa + f.b[1] * sb, cz = lz + f.a[2] * sa + f.b[2] * sb;
			dL = lightAt(cx, cy, cz);
			dA = level->isSolidBlockingTile(cx, cy, cz) ? 0.2f : 1.0f;
		} else {
			const int stand = f.diagAlongB ? ib : ia;
			dL = eL[stand];
			dA = eA[stand];
		}
		L[k] = aoBrightness(eL[ia], eL[ib], dL, faceLight);
		O[k] = (eA[ia] + eA[ib] + dA + aoFront) * 0.25f;
	}
	l1 = L[0]; l2 = L[1]; l3 = L[2]; l4 = L[3];
	c1r = O[0]; c2r = O[1]; c3r = O[2]; c4r = O[3];
}

bool TileRenderer::tesselateBlockInWorldWithAmbienceOcclusionLit( Tile* tt, int pX, int pY, int pZ, float pBaseRed, float pBaseGreen, float pBaseBlue )
{
	bool drew = false;
	const bool sidesTinted = tt->tex != 3;
	static const float SHADE[6] = { 0.5f, 1.0f, 0.8f, 0.8f, 0.6f, 0.6f };
	const bool flushOf[6] = { tt->yy0 <= 0, tt->yy1 >= 1, tt->zz0 <= 0, tt->zz1 >= 1, tt->xx0 <= 0, tt->xx1 >= 1 };
	static const int NB[6][3] = { { 0, -1, 0 }, { 0, 1, 0 }, { 0, 0, -1 }, { 0, 0, 1 }, { -1, 0, 0 }, { 1, 0, 0 } };
	applyAmbienceOcclusion = true;
	for (int face = 0; face < 6; ++face) {
		if (!noCulling && !tt->shouldRenderFace(level, pX + NB[face][0], pY + NB[face][1], pZ + NB[face][2], face)) continue;
		aoCorners(tt, pX, pY, pZ, face, flushOf[face]);
		const float o[4] = { c1r, c2r, c3r, c4r };
		const int ft = tt->getTexture(level, pX, pY, pZ, face);
		const bool split = face >= 2 && grassSideSplits(tt, ft, face, fixedTexture, xFlipTexture, pBaseRed, pBaseGreen, pBaseBlue);
		const bool tinted = (face == 1 || sidesTinted) && !split;
		const float s = SHADE[face];
		const float br = (tinted ? pBaseRed : 1.0f) * s, bg = (tinted ? pBaseGreen : 1.0f) * s, bb = (tinted ? pBaseBlue : 1.0f) * s;
		c1r = br * o[0]; c1g = bg * o[0]; c1b = bb * o[0];
		c2r = br * o[1]; c2g = bg * o[1]; c2b = bb * o[1];
		c3r = br * o[2]; c3g = bg * o[2]; c3b = bb * o[2];
		c4r = br * o[3]; c4g = bg * o[3]; c4b = bb * o[3];
		if (split) {
			const float C[4][3] = { {c1r, c1g, c1b}, {c2r, c2g, c2b}, {c3r, c3g, c3b}, {c4r, c4g, c4b} };
			const int L[4] = { l1, l2, l3, l4 };
			grassSideSplit(Tesselator::forThread(), face, (float) pX, (float) pY, (float) pZ, C, pBaseRed, pBaseGreen, pBaseBlue, L);
		} else {
			switch (face) {
				case 0: renderFaceDown(tt, (float) pX, (float) pY, (float) pZ, ft); break;
				case 1: renderFaceUp(tt, (float) pX, (float) pY, (float) pZ, ft); break;
				case 2: renderNorth(tt, (float) pX, (float) pY, (float) pZ, ft); break;
				case 3: renderSouth(tt, (float) pX, (float) pY, (float) pZ, ft); break;
				case 4: renderWest(tt, (float) pX, (float) pY, (float) pZ, ft); break;
				default: renderEast(tt, (float) pX, (float) pY, (float) pZ, ft); break;
			}
		}
		drew = true;
	}
	applyAmbienceOcclusion = false;
	return drew;
}

bool TileRenderer::tesselateCactusInWorld(Tile* tt, int x, int y, int z) {
    int col = tt->getColor(level, x, y, z);
    float r = ((col >> 16) & 0xff) / 255.0f;
    float g = ((col >> 8) & 0xff) / 255.0f;
    float b = ((col) & 0xff) / 255.0f;
    return tesselateCactusInWorld(tt, x, y, z, r, g, b);
}

bool TileRenderer::tesselateCactusInWorld(Tile* tt, int x, int y, int z, float r, float g, float b) {
    Tesselator& t = Tesselator::forThread();

    bool changed = false;
    float c10 = 0.5f;
    float c11 = 1;
    float c2 = 0.8f;
    float c3 = 0.6f;

    float r10 = c10 * r;
    float r11 = c11 * r;
    float r2 = c2 * r;
    float r3 = c3 * r;

    float g10 = c10 * g;
    float g11 = c11 * g;
    float g2 = c2 * g;
    float g3 = c3 * g;

    float b10 = c10 * b;
    float b11 = c11 * b;
    float b2 = c2 * b;
    float b3 = c3 * b;

    float s = 1 / 16.0f;
	const float X = (float)x;
	const float Y = (float)y;
	const float Z = (float)z;

    float centerBrightness = tt->getBrightness(level, x, y, z);

    if (TerrainLight::capturing()) TerrainLight::beginTile();

    if (noCulling || tt->shouldRenderFace(level, x, y - 1, z, 0)) {
        float br = tt->getBrightness(level, x, y - 1, z);
        // if (Tile::lightEmission[tt->id] > br*Level.MAX_BRIGHTNESS) br =
// Tile::lightEmission[tt->id]/Level.MAX_BRIGHTNESS;
        t.color(r10 * br, g10 * br, b10 * br);
        renderFaceDown(tt, X, Y, Z, tt->getTexture(level, x, y, z, 0));
        changed = true;
    }

    if (noCulling || tt->shouldRenderFace(level, x, y + 1, z, 1)) {
        float br = tt->getBrightness(level, x, y + 1, z);
        if (tt->yy1 != 1 && !tt->material->isLiquid()) br = centerBrightness;
        if (TerrainLight::capturing()) TerrainLight::set((tt->yy1 != 1 && !tt->material->isLiquid()) ? lightAt(x, y, z) : lightAt(x, y + 1, z));
        // if (Tile::lightEmission[tt->id] > br*Level.MAX_BRIGHTNESS) br =
// Tile::lightEmission[tt->id]/Level.MAX_BRIGHTNESS;
        t.color(r11 * br, g11 * br, b11 * br);
        renderFaceUp(tt, X, Y, Z, tt->getTexture(level, x, y, z, 1));
        changed = true;
    }

    if (noCulling || tt->shouldRenderFace(level, x, y, z - 1, 2)) {
        float br = tt->getBrightness(level, x, y, z - 1);
        if (tt->zz0 > 0) br = centerBrightness;
        if (TerrainLight::capturing()) TerrainLight::set((tt->zz0 > 0) ? lightAt(x, y, z) : lightAt(x, y, z - 1));
        // if (Tile::lightEmission[tt->id] > br*Level.MAX_BRIGHTNESS) br =
// Tile::lightEmission[tt->id]/Level.MAX_BRIGHTNESS;
        t.color(r2 * br, g2 * br, b2 * br);
        t.addOffset(0, 0, s);
        renderNorth(tt, X, Y, Z, tt->getTexture(level, x, y, z, 2));
        t.addOffset(0, 0, -s);
        changed = true;
    }

    if (noCulling || tt->shouldRenderFace(level, x, y, z + 1, 3)) {
        float br = tt->getBrightness(level, x, y, z + 1);
        if (tt->zz1 < 1) br = centerBrightness;
        if (TerrainLight::capturing()) TerrainLight::set((tt->zz1 < 1) ? lightAt(x, y, z) : lightAt(x, y, z + 1));
        // if (Tile::lightEmission[tt->id] > br*Level.MAX_BRIGHTNESS) br =
// Tile::lightEmission[tt->id]/Level.MAX_BRIGHTNESS;
        t.color(r2 * br, g2 * br, b2 * br);
        t.addOffset(0, 0, -s);
        renderSouth(tt, X, Y, Z, tt->getTexture(level, x, y, z, 3));
        t.addOffset(0, 0, s);
        changed = true;
    }

    if (noCulling || tt->shouldRenderFace(level, x - 1, y, z, 4)) {
        float br = tt->getBrightness(level, x - 1, y, z);
        if (tt->xx0 > 0) br = centerBrightness;
        if (TerrainLight::capturing()) TerrainLight::set((tt->xx0 > 0) ? lightAt(x, y, z) : lightAt(x - 1, y, z));
        // if (Tile::lightEmission[tt->id] > br*Level.MAX_BRIGHTNESS) br =
// Tile::lightEmission[tt->id]/Level.MAX_BRIGHTNESS;
        t.color(r3 * br, g3 * br, b3 * br);
        t.addOffset(s, 0, 0);
        renderWest(tt, X, Y, Z, tt->getTexture(level, x, y, z, 4));
        t.addOffset(-s, 0, 0);
        changed = true;
    }

    if (noCulling || tt->shouldRenderFace(level, x + 1, y, z, 5)) {
        float br = tt->getBrightness(level, x + 1, y, z);
        if (tt->xx1 < 1) br = centerBrightness;
        if (TerrainLight::capturing()) TerrainLight::set((tt->xx1 < 1) ? lightAt(x, y, z) : lightAt(x + 1, y, z));
        // if (Tile::lightEmission[tt->id] > br*Level.MAX_BRIGHTNESS) br =
// Tile::lightEmission[tt->id]/Level.MAX_BRIGHTNESS;
        t.color(r3 * br, g3 * br, b3 * br);
        t.addOffset(-s, 0, 0);
        renderEast(tt, X, Y, Z, tt->getTexture(level, x, y, z, 5));
        t.addOffset(s, 0, 0);
        changed = true;
    }

    return changed;
}

bool TileRenderer::tesselateFenceInWorld(FenceTile* tt, int x, int y, int z) {
    bool changed = true;

    float a = 6 / 16.0f;
    float b = 10 / 16.0f;
    tt->setShape(a, 0, a, b, 1, b);
    tesselateBlockInWorld(tt, x, y, z);

    bool vertical = false;
    bool horizontal = false;

	bool l = tt->connectsTo(level, x - 1, y, z);
	bool r = tt->connectsTo(level, x + 1, y, z);
	bool u = tt->connectsTo(level, x, y, z - 1);
	bool d = tt->connectsTo(level, x, y, z + 1);

	if (l || r) vertical = true;
    if (u || d) horizontal = true;

    if (!vertical && !horizontal) vertical = true;

    a = 7 / 16.0f;
    b = 9 / 16.0f;
    float h0 = 12 / 16.0f;
    float h1 = 15 / 16.0f;

    float x0 = l ? 0 : a;
    float x1 = r ? 1 : b;
    float z0 = u ? 0 : a;
    float z1 = d ? 1 : b;

    if (vertical) {
        tt->setShape(x0, h0, a, x1, h1, b);
        tesselateBlockInWorld(tt, x, y, z);
    }
    if (horizontal) {
        tt->setShape(a, h0, z0, b, h1, z1);
        tesselateBlockInWorld(tt, x, y, z);
    }

    h0 = 6 / 16.0f;
    h1 = 9 / 16.0f;
    if (vertical) {
        tt->setShape(x0, h0, a, x1, h1, b);
        tesselateBlockInWorld(tt, x, y, z);
    }
    if (horizontal) {
        tt->setShape(a, h0, z0, b, h1, z1);
        tesselateBlockInWorld(tt, x, y, z);
    }

    tt->setShape(0, 0, 0, 1, 1, 1);
    return changed;
}

bool TileRenderer::tesselateFenceGateInWorld(FenceGateTile* tt, int x, int y, int z) {
	bool changed = true;

	int data = level->getData(x, y, z);
	bool isOpen = FenceGateTile::isOpen(data);
	int direction = FenceGateTile::getDirection(data);

	const float h00 = 6 / 16.0f;
	const float h01 = 9 / 16.0f;
	const float h10 = 12 / 16.0f;
	const float h11 = 15 / 16.0f;
	const float h20 = 5 / 16.0f;
	const float h21 = 16 / 16.0f;

	// edge sticks
	if (direction == Direction::EAST || direction == Direction::WEST) {
		float x0 = 7 / 16.0f;
		float x1 = 9 / 16.0f;
		float z0 = 0 / 16.0f;
		float z1 = 2 / 16.0f;
		tt->setShape(x0, h20, z0, x1, h21, z1);
		tesselateBlockInWorld(tt, x, y, z);

		z0 = 14 / 16.0f;
		z1 = 16 / 16.0f;
		tt->setShape(x0, h20, z0, x1, h21, z1);
		tesselateBlockInWorld(tt, x, y, z);
	} else {
		float x0 = 0 / 16.0f;
		float x1 = 2 / 16.0f;
		float z0 = 7 / 16.0f;
		float z1 = 9 / 16.0f;
		tt->setShape(x0, h20, z0, x1, h21, z1);
		tesselateBlockInWorld(tt, x, y, z);

		x0 = 14 / 16.0f;
		x1 = 16 / 16.0f;
		tt->setShape(x0, h20, z0, x1, h21, z1);
		tesselateBlockInWorld(tt, x, y, z);
	}
	if (!isOpen) {
		if (direction == Direction::EAST || direction == Direction::WEST) {
			float x0 = 7 / 16.0f;
			float x1 = 9 / 16.0f;
			float z0 = 6 / 16.0f;
			float z1 = 8 / 16.0f;
			tt->setShape(x0, h00, z0, x1, h11, z1);
			tesselateBlockInWorld(tt, x, y, z);
			z0 = 8 / 16.0f;
			z1 = 10 / 16.0f;
			tt->setShape(x0, h00, z0, x1, h11, z1);
			tesselateBlockInWorld(tt, x, y, z);
			z0 = 10 / 16.0f;
			z1 = 14 / 16.0f;
			tt->setShape(x0, h00, z0, x1, h01, z1);
			tesselateBlockInWorld(tt, x, y, z);
			tt->setShape(x0, h10, z0, x1, h11, z1);
			tesselateBlockInWorld(tt, x, y, z);
			z0 = 2 / 16.0f;
			z1 = 6 / 16.0f;
			tt->setShape(x0, h00, z0, x1, h01, z1);
			tesselateBlockInWorld(tt, x, y, z);
			tt->setShape(x0, h10, z0, x1, h11, z1);
			tesselateBlockInWorld(tt, x, y, z);
		} else {
			float x0 = 6 / 16.0f;
			float x1 = 8 / 16.0f;
			float z0 = 7 / 16.0f;
			float z1 = 9 / 16.0f;
			tt->setShape(x0, h00, z0, x1, h11, z1);
			tesselateBlockInWorld(tt, x, y, z);
			x0 = 8 / 16.0f;
			x1 = 10 / 16.0f;
			tt->setShape(x0, h00, z0, x1, h11, z1);
			tesselateBlockInWorld(tt, x, y, z);
			x0 = 10 / 16.0f;
			x1 = 14 / 16.0f;
			tt->setShape(x0, h00, z0, x1, h01, z1);
			tesselateBlockInWorld(tt, x, y, z);
			tt->setShape(x0, h10, z0, x1, h11, z1);
			tesselateBlockInWorld(tt, x, y, z);
			x0 = 2 / 16.0f;
			x1 = 6 / 16.0f;
			tt->setShape(x0, h00, z0, x1, h01, z1);
			tesselateBlockInWorld(tt, x, y, z);
			tt->setShape(x0, h10, z0, x1, h11, z1);
			tesselateBlockInWorld(tt, x, y, z);

		}
	} else {
		if (direction == Direction::EAST) {

			const float z00 = 0 / 16.0f;
			const float z01 = 2 / 16.0f;
			const float z10 = 14 / 16.0f;
			const float z11 = 16 / 16.0f;

			const float x0 = 9 / 16.0f;
			const float x1 = 13 / 16.0f;
			const float x2 = 15 / 16.0f;

			tt->setShape(x1, h00, z00, x2, h11, z01);
			tesselateBlockInWorld(tt, x, y, z);
			tt->setShape(x1, h00, z10, x2, h11, z11);
			tesselateBlockInWorld(tt, x, y, z);

			tt->setShape(x0, h00, z00, x1, h01, z01);
			tesselateBlockInWorld(tt, x, y, z);
			tt->setShape(x0, h00, z10, x1, h01, z11);
			tesselateBlockInWorld(tt, x, y, z);

			tt->setShape(x0, h10, z00, x1, h11, z01);
			tesselateBlockInWorld(tt, x, y, z);
			tt->setShape(x0, h10, z10, x1, h11, z11);
			tesselateBlockInWorld(tt, x, y, z);
		} else if (direction == Direction::WEST) {
			const float z00 = 0 / 16.0f;
			const float z01 = 2 / 16.0f;
			const float z10 = 14 / 16.0f;
			const float z11 = 16 / 16.0f;

			const float x0 = 1 / 16.0f;
			const float x1 = 3 / 16.0f;
			const float x2 = 7 / 16.0f;

			tt->setShape(x0, h00, z00, x1, h11, z01);
			tesselateBlockInWorld(tt, x, y, z);
			tt->setShape(x0, h00, z10, x1, h11, z11);
			tesselateBlockInWorld(tt, x, y, z);

			tt->setShape(x1, h00, z00, x2, h01, z01);
			tesselateBlockInWorld(tt, x, y, z);
			tt->setShape(x1, h00, z10, x2, h01, z11);
			tesselateBlockInWorld(tt, x, y, z);

			tt->setShape(x1, h10, z00, x2, h11, z01);
			tesselateBlockInWorld(tt, x, y, z);
			tt->setShape(x1, h10, z10, x2, h11, z11);
			tesselateBlockInWorld(tt, x, y, z);
		} else if (direction == Direction::SOUTH) {

			const float x00 = 0 / 16.0f;
			const float x01 = 2 / 16.0f;
			const float x10 = 14 / 16.0f;
			const float x11 = 16 / 16.0f;

			const float z0 = 9 / 16.0f;
			const float z1 = 13 / 16.0f;
			const float z2 = 15 / 16.0f;

			tt->setShape(x00, h00, z1, x01, h11, z2);
			tesselateBlockInWorld(tt, x, y, z);
			tt->setShape(x10, h00, z1, x11, h11, z2);
			tesselateBlockInWorld(tt, x, y, z);

			tt->setShape(x00, h00, z0, x01, h01, z1);
			tesselateBlockInWorld(tt, x, y, z);
			tt->setShape(x10, h00, z0, x11, h01, z1);
			tesselateBlockInWorld(tt, x, y, z);

			tt->setShape(x00, h10, z0, x01, h11, z1);
			tesselateBlockInWorld(tt, x, y, z);
			tt->setShape(x10, h10, z0, x11, h11, z1);
			tesselateBlockInWorld(tt, x, y, z);
		} else if (direction == Direction::NORTH) {
			const float x00 = 0 / 16.0f;
			const float x01 = 2 / 16.0f;
			const float x10 = 14 / 16.0f;
			const float x11 = 16 / 16.0f;

			const float z0 = 1 / 16.0f;
			const float z1 = 3 / 16.0f;
			const float z2 = 7 / 16.0f;

			tt->setShape(x00, h00, z0, x01, h11, z1);
			tesselateBlockInWorld(tt, x, y, z);
			tt->setShape(x10, h00, z0, x11, h11, z1);
			tesselateBlockInWorld(tt, x, y, z);

			tt->setShape(x00, h00, z1, x01, h01, z2);
			tesselateBlockInWorld(tt, x, y, z);
			tt->setShape(x10, h00, z1, x11, h01, z2);
			tesselateBlockInWorld(tt, x, y, z);

			tt->setShape(x00, h10, z1, x01, h11, z2);
			tesselateBlockInWorld(tt, x, y, z);
			tt->setShape(x10, h10, z1, x11, h11, z2);
			tesselateBlockInWorld(tt, x, y, z);
		}
	}

	tt->setShape(0, 0, 0, 1, 1, 1);
	return changed;
}

bool TileRenderer::tesselateBedInWorld(Tile *tt, int x, int y, int z) {
	Tesselator& t = Tesselator::forThread();
	int data = level->getData(x, y, z);
	int direction = BedTile::getDirection(data);
	bool isHead = BedTile::isHeadPiece(data);

	float c10 = 0.5f;
	float c11 = 1;
	float c2 = 0.8f;
	float c3 = 0.6f;

	float r11 = c11;
	float g11 = c11;
	float b11 = c11;

	float r10 = c10;
	float r2 = c2;
	float r3 = c3;

	float g10 = c10;
	float g2 = c2;
	float g3 = c3;

	float b10 = c10;
	float b2 = c2;
	float b3 = c3;

	float centerBrightness = tt->getBrightness(level, x, y, z);

	if (TerrainLight::capturing()) TerrainLight::beginTile();
	// render wooden underside
	{
		t.color(r10 * centerBrightness, g10 * centerBrightness, b10 * centerBrightness);
		int tex = tt->getTexture(level, x, y, z, Facing::DOWN);

		int xt = (tex & 0xf) << 4;
		int yt = Atlas::cellPy(tex);

		float u0 = (xt) / Atlas::W;
		float u1 = (xt + 16 - 0.01f) / Atlas::W;
		float v0 = (yt) / Atlas::H;
		float v1 = (yt + 16 - 0.01f) / Atlas::H;

		float x0 = x + tt->xx0;
		float x1 = x + tt->xx1;
		float y0 = y + tt->yy0 + 3.0f / 16.0f;
		float z0 = z + tt->zz0;
		float z1 = z + tt->zz1;

		t.vertexUV(x0, y0, z1, u0, v1);
		t.vertexUV(x0, y0, z0, u0, v0);
		t.vertexUV(x1, y0, z0, u1, v0);
		t.vertexUV(x1, y0, z1, u1, v1);
	}

	// render bed top

	float brightness = tt->getBrightness(level, x, y + 1, z);
	t.color(r11 * brightness, g11 * brightness, b11 * brightness);

	int tex = tt->getTexture(level, x, y, z, Facing::UP);

	int xt = (tex & 0xf) << 4;
	int yt = Atlas::cellPy(tex);

	float u0 = (xt) / Atlas::W;
	float u1 = (xt + 16 ) / Atlas::W;
	float v0 = (yt) / Atlas::H;
	float v1 = (yt + 16) / Atlas::H;

	// Default is west
	float topLeftU = u0;
	float topRightU = u1;
	float topLeftV = v0;
	float topRightV = v0;
	float bottomLeftU = u0;
	float bottomRightU = u1;
	float bottomLeftV = v1;
	float bottomRightV = v1;

	if (direction == Direction::SOUTH) {
		// rotate 90 degrees clockwise
		topRightU = u0;
		topLeftV = v1;
		bottomLeftU = u1;
		bottomRightV = v0;
	} else if (direction == Direction::NORTH) {
		// rotate 90 degrees counter-clockwise
		topLeftU = u1;
		topRightV = v1;
		bottomRightU = u0;
		bottomLeftV = v0;
	} else if (direction == Direction::EAST) {
		// rotate 180 degrees
		topLeftU = u1;
		topRightV = v1;
		bottomRightU = u0;
		bottomLeftV = v0;
		topRightU = u0;
		topLeftV = v1;
		bottomLeftU = u1;
		bottomRightV = v0;
	}

	float x0 = x + tt->xx0;
	float x1 = x + tt->xx1;
	float y1 = y + tt->yy1;
	float z0 = z + tt->zz0;
	float z1 = z + tt->zz1;

	t.vertexUV(x1, y1, z1, bottomLeftU, bottomLeftV);
	t.vertexUV(x1, y1, z0, topLeftU, topLeftV);
	t.vertexUV(x0, y1, z0, topRightU, topRightV);
	t.vertexUV(x0, y1, z1, bottomRightU, bottomRightV);

	// determine which edge to skip (the one between foot and head piece)
	int skipEdge = Direction::DIRECTION_FACING[direction];
	if (isHead) {
		skipEdge = Direction::DIRECTION_FACING[Direction::DIRECTION_OPPOSITE[direction]];
	}
	// and which edge to x-flip
	int flipEdge = Facing::WEST;
	switch (direction) {
	case Direction::NORTH:
		break;
	case Direction::SOUTH:
		flipEdge = Facing::EAST;
		break;
	case Direction::EAST:
		flipEdge = Facing::NORTH;
		break;
	case Direction::WEST:
		flipEdge = Facing::SOUTH;
		break;
	}

	if ((skipEdge != Facing::NORTH) && (noCulling || tt->shouldRenderFace(level, x, y, z - 1, Facing::NORTH))) {
		float br = tt->getBrightness(level, x, y, z - 1);
		if (tt->zz0 > 0) br = centerBrightness;
		if (TerrainLight::capturing()) TerrainLight::set((tt->zz0 > 0) ? lightAt(x, y, z) : lightAt(x, y, z - 1));

		t.color(r2 * br, g2 * br, b2 * br);
		xFlipTexture = flipEdge == Facing::NORTH;
		renderNorth(tt, float(x), float(y), float(z), tt->getTexture(level, x, y, z, 2));
	}

	if ((skipEdge != Facing::SOUTH) && (noCulling || tt->shouldRenderFace(level, x, y, z + 1, Facing::SOUTH))) {
		float br = tt->getBrightness(level, x, y, z + 1);
		if (tt->zz1 < 1) br = centerBrightness;
		if (TerrainLight::capturing()) TerrainLight::set((tt->zz1 < 1) ? lightAt(x, y, z) : lightAt(x, y, z + 1));

		t.color(r2 * br, g2 * br, b2 * br);

		xFlipTexture = flipEdge == Facing::SOUTH;
		renderSouth(tt, float(x), float(y), float(z), tt->getTexture(level, x, y, z, 3));
	}

	if ((skipEdge != Facing::WEST) && (noCulling || tt->shouldRenderFace(level, x - 1, y, z, Facing::WEST))) {
		float br = tt->getBrightness(level, x - 1, y, z);
		if (tt->xx0 > 0) br = centerBrightness;
		if (TerrainLight::capturing()) TerrainLight::set((tt->xx0 > 0) ? lightAt(x, y, z) : lightAt(x - 1, y, z));

		t.color(r3 * br, g3 * br, b3 * br);
		xFlipTexture = flipEdge == Facing::WEST;
		renderWest(tt, float(x), float(y), float(z), tt->getTexture(level, x, y, z, 4));
	}

	if ((skipEdge != Facing::EAST) && (noCulling || tt->shouldRenderFace(level, x + 1, y, z, Facing::EAST))) {
		float br = tt->getBrightness(level, x + 1, y, z);
		if (tt->xx1 < 1) br = centerBrightness;
		if (TerrainLight::capturing()) TerrainLight::set((tt->xx1 < 1) ? lightAt(x, y, z) : lightAt(x + 1, y, z));

		t.color(r3 * br, g3 * br, b3 * br);
		xFlipTexture = flipEdge == Facing::EAST;
		renderEast(tt, float(x), float(y), float(z), tt->getTexture(level, x, y, z, 5));
	}
	xFlipTexture = false;
	return true;
}

bool TileRenderer::tesselateStairsInWorld( StairTile* tt, int x, int y, int z )
{

	tt->setBaseShape(level, x, y, z);
	tesselateBlockInWorld(tt, x, y, z);

	bool checkInnerPiece = tt->setStepShape(level, x, y, z);
	tesselateBlockInWorld(tt, x, y, z);

	if (checkInnerPiece) {
		if (tt->setInnerPieceShape(level, x, y, z)) {
			tesselateBlockInWorld(tt, x, y, z);
		}
	}

	//        setShape(0, 0, 0, 1, 1, 1);
	return true;
}

bool TileRenderer::tesselateDoorInWorld( Tile* tt, int x, int y, int z )
{
	Tesselator& t = Tesselator::forThread();

	DoorTile* dt = (DoorTile*) tt;

	bool changed = false;
	float c10 = 0.5f;
	float c11 = 1;
	float c2 = 0.8f;
	float c3 = 0.6f;

	float centerBrightness = tt->getBrightness(level, x, y, z);

	if (TerrainLight::capturing()) TerrainLight::beginTile();

	{
		float br = tt->getBrightness(level, x, y - 1, z);
		if (dt->yy0 > 0) br = centerBrightness;
		if (TerrainLight::capturing()) TerrainLight::set((dt->yy0 > 0) ? lightAt(x, y, z) : lightAt(x, y - 1, z));
		if (Tile::lightEmission[tt->id] > 0) br = 1.0f; if (Tile::lightEmission[tt->id] > 0 && TerrainLight::capturing()) TerrainLight::set(TerrainLight::FULL);
		t.color(c10 * br, c10 * br, c10 * br);
		renderFaceDown(tt, (float)x, (float)y, (float)z, tt->getTexture(level, x, y, z, 0));
		changed = true;
	}

	{
		float br = tt->getBrightness(level, x, y + 1, z);
		if (dt->yy1 < 1) br = centerBrightness;
		if (TerrainLight::capturing()) TerrainLight::set((dt->yy1 < 1) ? lightAt(x, y, z) : lightAt(x, y + 1, z));
		if (Tile::lightEmission[tt->id] > 0) br = 1.0f; if (Tile::lightEmission[tt->id] > 0 && TerrainLight::capturing()) TerrainLight::set(TerrainLight::FULL);
		t.color(c11 * br, c11 * br, c11 * br);
		renderFaceUp(tt, (float)x, (float)y, (float)z, tt->getTexture(level, x, y, z, 1));
		changed = true;
	}

	{
		float br = tt->getBrightness(level, x, y, z - 1);
		if (dt->zz0 > 0) br = centerBrightness;
		if (TerrainLight::capturing()) TerrainLight::set((dt->zz0 > 0) ? lightAt(x, y, z) : lightAt(x, y, z - 1));
		if (Tile::lightEmission[tt->id] > 0) br = 1.0f; if (Tile::lightEmission[tt->id] > 0 && TerrainLight::capturing()) TerrainLight::set(TerrainLight::FULL);
		t.color(c2 * br, c2 * br, c2 * br);
		int tex = tt->getTexture(level, x, y, z, 2);
		if (tex < 0) {
			xFlipTexture = true;
			tex = -tex;
		}
		renderNorth(tt, (float)x, (float)y, (float)z, tex);
		changed = true;
		xFlipTexture = false;
	}

	{
		float br = tt->getBrightness(level, x, y, z + 1);
		if (dt->zz1 < 1) br = centerBrightness;
		if (TerrainLight::capturing()) TerrainLight::set((dt->zz1 < 1) ? lightAt(x, y, z) : lightAt(x, y, z + 1));
		if (Tile::lightEmission[tt->id] > 0) br = 1.0f; if (Tile::lightEmission[tt->id] > 0 && TerrainLight::capturing()) TerrainLight::set(TerrainLight::FULL);
		t.color(c2 * br, c2 * br, c2 * br);
		int tex = tt->getTexture(level, x, y, z, 3);
		if (tex < 0) {
			xFlipTexture = true;
			tex = -tex;
		}
		renderSouth(tt, (float)x, (float)y, (float)z, tex);
		changed = true;
		xFlipTexture = false;
	}

	{
		float br = tt->getBrightness(level, x - 1, y, z);
		if (dt->xx0 > 0) br = centerBrightness;
		if (TerrainLight::capturing()) TerrainLight::set((dt->xx0 > 0) ? lightAt(x, y, z) : lightAt(x - 1, y, z));
		if (Tile::lightEmission[tt->id] > 0) br = 1.0f; if (Tile::lightEmission[tt->id] > 0 && TerrainLight::capturing()) TerrainLight::set(TerrainLight::FULL);
		t.color(c3 * br, c3 * br, c3 * br);
		int tex = tt->getTexture(level, x, y, z, 4);
		if (tex < 0) {
			xFlipTexture = true;
			tex = -tex;
		}
		renderWest(tt, (float)x, (float)y, (float)z, tex);
		changed = true;
		xFlipTexture = false;
	}

	{
		float br = tt->getBrightness(level, x + 1, y, z);
		if (dt->xx1 < 1) br = centerBrightness;
		if (TerrainLight::capturing()) TerrainLight::set((dt->xx1 < 1) ? lightAt(x, y, z) : lightAt(x + 1, y, z));
		if (Tile::lightEmission[tt->id] > 0) br = 1.0f; if (Tile::lightEmission[tt->id] > 0 && TerrainLight::capturing()) TerrainLight::set(TerrainLight::FULL);
		t.color(c3 * br, c3 * br, c3 * br);
		int tex = tt->getTexture(level, x, y, z, 5);
		if (tex < 0) {
			xFlipTexture = true;
			tex = -tex;
		}
		renderEast(tt, (float)x, (float)y, (float)z, tex);
		changed = true;
		xFlipTexture = false;
	}

	return changed;
}

bool TileRenderer::tesselateRowInWorld( Tile* tt, int x, int y, int z ) {
	Tesselator& t = Tesselator::forThread();
	float br = tt->getBrightness(level, x, y, z);
	t.color(br, br, br);
	tesselateRowTexture(tt, level->getData(x, y, z), float(x), y - 1 / 16.0f, float(z));
	return true;
}

void TileRenderer::renderFaceDown( Tile* tt, float x, float y, float z, int tex )
{
	Tesselator& t = Tesselator::forThread();

	if (fixedTexture >= 0) tex = fixedTexture;
	int xt = (tex & 0xf) << 4;
	int yt = Atlas::cellPy(tex);

	float u0 = (xt + tt->xx0 * 16) / Atlas::W;
	float u1 = (xt + tt->xx1 * 16 - 0.01f) / Atlas::W;
	float v0 = (yt + tt->zz0 * 16) / Atlas::H;
	float v1 = (yt + tt->zz1 * 16 - 0.01f) / Atlas::H;

	if (tt->xx0 < 0 || tt->xx1 > 1) {
		u0 = (xt + 0 * 15.99f) / Atlas::W;
		u1 = (xt + 1 * 15.99f) / Atlas::W;
	}
	if (tt->zz0 < 0 || tt->zz1 > 1) {
		v0 = (yt + 0 * 15.99f) / Atlas::H;
		v1 = (yt + 1 * 15.99f) / Atlas::H;
	}

	float x0 = x + tt->xx0;
	float x1 = x + tt->xx1;
	float y0 = y + tt->yy0;
	float z0 = z + tt->zz0;
	float z1 = z + tt->zz1;

	float U[4] = { u0, u0, u1, u1 }, V[4] = { v1, v0, v0, v1 };
	if (s_uvTurn & (1 << 0)) turnUV(U, V);

	if (applyAmbienceOcclusion) {
		const bool lit = TerrainLight::capturing();
		if (lit) TerrainLight::set(l1);
		t.color(c1r, c1g, c1b);
		t.vertexUV(x0, y0, z1, U[0], V[0]);
		if (lit) TerrainLight::set(l2);
		t.color(c2r, c2g, c2b);
		t.vertexUV(x0, y0, z0, U[1], V[1]);
		if (lit) TerrainLight::set(l3);
		t.color(c3r, c3g, c3b);
		t.vertexUV(x1, y0, z0, U[2], V[2]);
		if (lit) TerrainLight::set(l4);
		t.color(c4r, c4g, c4b);
		t.vertexUV(x1, y0, z1, U[3], V[3]);
	} else {
		t.vertexUV(x0, y0, z1, U[0], V[0]);
		t.vertexUV(x0, y0, z0, U[1], V[1]);
		t.vertexUV(x1, y0, z0, U[2], V[2]);
		t.vertexUV(x1, y0, z1, U[3], V[3]);
	}
}

void TileRenderer::renderFaceUp( Tile* tt, float x, float y, float z, int tex )
{
	Tesselator& t = Tesselator::forThread();

	if (fixedTexture >= 0) tex = fixedTexture;
	int xt = (tex & 0xf) << 4;
	int yt = Atlas::cellPy(tex);

	float u0 = (xt + tt->xx0 * 16) / Atlas::W;
	float u1 = (xt + tt->xx1 * 16 - 0.01f) / Atlas::W;
	float v0 = (yt + tt->zz0 * 16) / Atlas::H;
	float v1 = (yt + tt->zz1 * 16 - 0.01f) / Atlas::H;

	if (tt->xx0 < 0 || tt->xx1 > 1) {
		u0 = (xt + 0 * 15.99f) / Atlas::W;
		u1 = (xt + 1 * 15.99f) / Atlas::W;
	}
	if (tt->zz0 < 0 || tt->zz1 > 1) {
		v0 = (yt + 0 * 15.99f) / Atlas::H;
		v1 = (yt + 1 * 15.99f) / Atlas::H;
	}

	float x0 = x + tt->xx0;
	float x1 = x + tt->xx1;
	float y1 = y + tt->yy1;
	float z0 = z + tt->zz0;
	float z1 = z + tt->zz1;

	float U[4] = { u1, u1, u0, u0 }, V[4] = { v1, v0, v0, v1 };
	if (s_uvTurn & (1 << 1)) turnUV(U, V);

	if (applyAmbienceOcclusion) {
		const bool lit = TerrainLight::capturing();
		if (lit) TerrainLight::set(l1);
		t.color(c1r, c1g, c1b);
		t.vertexUV(x1, y1, z1, U[0], V[0]);
		if (lit) TerrainLight::set(l2);
		t.color(c2r, c2g, c2b);
		t.vertexUV(x1, y1, z0, U[1], V[1]);
		if (lit) TerrainLight::set(l3);
		t.color(c3r, c3g, c3b);
		t.vertexUV(x0, y1, z0, U[2], V[2]);
		if (lit) TerrainLight::set(l4);
		t.color(c4r, c4g, c4b);
		t.vertexUV(x0, y1, z1, U[3], V[3]);
	} else {
		t.vertexUV(x1, y1, z1, U[0], V[0]);
		t.vertexUV(x1, y1, z0, U[1], V[1]);
		t.vertexUV(x0, y1, z0, U[2], V[2]);
		t.vertexUV(x0, y1, z1, U[3], V[3]);
	}
}

void TileRenderer::renderNorth( Tile* tt, float x, float y, float z, int tex )
{
	Tesselator& t = Tesselator::forThread();

	if (fixedTexture >= 0) tex = fixedTexture;
	int xt = (tex & 0xf) << 4;
	int yt = Atlas::cellPy(tex);
	float u0 = (xt + tt->xx0 * 16) / Atlas::W;
	float u1 = (xt + tt->xx1 * 16 - 0.01f) / Atlas::W;
	float v0 = (yt + 16 - tt->yy1 * 16) / Atlas::H;
	float v1 = (yt + 16 - tt->yy0 * 16 - 0.01f) / Atlas::H;
	if (xFlipTexture) {
		float tmp = u0;
		u0 = u1;
		u1 = tmp;
	}

	if (tt->xx0 < 0 || tt->xx1 > 1) {
		u0 = (xt + 0 * 15.99f) / Atlas::W;
		u1 = (xt + 1 * 15.99f) / Atlas::W;
	}
	if (tt->yy0 < 0 || tt->yy1 > 1) {
		v0 = (yt + 0 * 15.99f) / Atlas::H;
		v1 = (yt + 1 * 15.99f) / Atlas::H;
	}

	float x0 = x + tt->xx0;
	float x1 = x + tt->xx1;
	float y0 = y + tt->yy0;
	float y1 = y + tt->yy1;
	float z0 = z + tt->zz0;

	float U[4] = { u1, u0, u0, u1 }, V[4] = { v0, v0, v1, v1 };
	if (s_uvTurn & (1 << 2)) turnUV(U, V);

	if (applyAmbienceOcclusion) {
		const bool lit = TerrainLight::capturing();
		if (lit) TerrainLight::set(l1);
		t.color(c1r, c1g, c1b);
		t.vertexUV(x0, y1, z0, U[0], V[0]);
		if (lit) TerrainLight::set(l2);
		t.color(c2r, c2g, c2b);
		t.vertexUV(x1, y1, z0, U[1], V[1]);
		if (lit) TerrainLight::set(l3);
		t.color(c3r, c3g, c3b);
		t.vertexUV(x1, y0, z0, U[2], V[2]);
		if (lit) TerrainLight::set(l4);
		t.color(c4r, c4g, c4b);
		t.vertexUV(x0, y0, z0, U[3], V[3]);
	} else {
		t.vertexUV(x0, y1, z0, U[0], V[0]);
		t.vertexUV(x1, y1, z0, U[1], V[1]);
		t.vertexUV(x1, y0, z0, U[2], V[2]);
		t.vertexUV(x0, y0, z0, U[3], V[3]);
	}
}

void TileRenderer::renderSouth( Tile* tt, float x, float y, float z, int tex )
{
	Tesselator& t = Tesselator::forThread();

	if (fixedTexture >= 0) tex = fixedTexture;
	int xt = (tex & 0xf) << 4;
	int yt = Atlas::cellPy(tex);

	float u0 = (xt + tt->xx0 * 16) / Atlas::W;
	float u1 = (xt + tt->xx1 * 16 - 0.01f) / Atlas::W;
	float v0 = (yt + 16 - tt->yy1 * 16) / Atlas::H;
	float v1 = (yt + 16 - tt->yy0 * 16 - 0.01f) / Atlas::H;
	if (xFlipTexture) {
		float tmp = u0;
		u0 = u1;
		u1 = tmp;
	}

	if (tt->xx0 < 0 || tt->xx1 > 1) {
		u0 = (xt + 0 * 15.99f) / Atlas::W;
		u1 = (xt + 1 * 15.99f) / Atlas::W;
	}
	if (tt->yy0 < 0 || tt->yy1 > 1) {
		v0 = (yt + 0 * 15.99f) / Atlas::H;
		v1 = (yt + 1 * 15.99f) / Atlas::H;
	}

	float x0 = x + tt->xx0;
	float x1 = x + tt->xx1;
	float y0 = y + tt->yy0;
	float y1 = y + tt->yy1;
	float z1 = z + tt->zz1;

	float U[4] = { u0, u0, u1, u1 }, V[4] = { v0, v1, v1, v0 };
	if (s_uvTurn & (1 << 3)) turnUV(U, V);

	if (applyAmbienceOcclusion) {
		const bool lit = TerrainLight::capturing();
		if (lit) TerrainLight::set(l1);
		t.color(c1r, c1g, c1b);
		t.vertexUV(x0, y1, z1, U[0], V[0]);
		if (lit) TerrainLight::set(l2);
		t.color(c2r, c2g, c2b);
		t.vertexUV(x0, y0, z1, U[1], V[1]);
		if (lit) TerrainLight::set(l3);
		t.color(c3r, c3g, c3b);
		t.vertexUV(x1, y0, z1, U[2], V[2]);
		if (lit) TerrainLight::set(l4);
		t.color(c4r, c4g, c4b);
		t.vertexUV(x1, y1, z1, U[3], V[3]);
	} else {
		t.vertexUV(x0, y1, z1, U[0], V[0]);
		t.vertexUV(x0, y0, z1, U[1], V[1]);
		t.vertexUV(x1, y0, z1, U[2], V[2]);
		t.vertexUV(x1, y1, z1, U[3], V[3]);
	}
}

void TileRenderer::renderWest( Tile* tt, float x, float y, float z, int tex )
{
	Tesselator& t = Tesselator::forThread();

	if (fixedTexture >= 0) tex = fixedTexture;
	int xt = (tex & 0xf) << 4;
	int yt = Atlas::cellPy(tex);

	float u0 = (xt + tt->zz0 * 16) / Atlas::W;
	float u1 = (xt + tt->zz1 * 16 - 0.01f) / Atlas::W;
	float v0 = (yt + 16 - tt->yy1 * 16) / Atlas::H;
	float v1 = (yt + 16 - tt->yy0 * 16 - 0.01f) / Atlas::H;
	if (xFlipTexture) {
		float tmp = u0;
		u0 = u1;
		u1 = tmp;
	}

	if (tt->zz0 < 0 || tt->zz1 > 1) {
		u0 = (xt + 0 * 15.99f) / Atlas::W;
		u1 = (xt + 1 * 15.99f) / Atlas::W;
	}
	if (tt->yy0 < 0 || tt->yy1 > 1) {
		v0 = (yt + 0 * 15.99f) / Atlas::H;
		v1 = (yt + 1 * 15.99f) / Atlas::H;
	}

	float x0 = x + tt->xx0;
	float y0 = y + tt->yy0;
	float y1 = y + tt->yy1;
	float z0 = z + tt->zz0;
	float z1 = z + tt->zz1;

	float U[4] = { u1, u0, u0, u1 }, V[4] = { v0, v0, v1, v1 };
	if (s_uvTurn & (1 << 4)) turnUV(U, V);

	if (applyAmbienceOcclusion) {
		const bool lit = TerrainLight::capturing();
		if (lit) TerrainLight::set(l1);
		t.color(c1r, c1g, c1b);
		t.vertexUV(x0, y1, z1, U[0], V[0]);
		if (lit) TerrainLight::set(l2);
		t.color(c2r, c2g, c2b);
		t.vertexUV(x0, y1, z0, U[1], V[1]);
		if (lit) TerrainLight::set(l3);
		t.color(c3r, c3g, c3b);
		t.vertexUV(x0, y0, z0, U[2], V[2]);
		if (lit) TerrainLight::set(l4);
		t.color(c4r, c4g, c4b);
		t.vertexUV(x0, y0, z1, U[3], V[3]);
	} else {
		t.vertexUV(x0, y1, z1, U[0], V[0]);
		t.vertexUV(x0, y1, z0, U[1], V[1]);
		t.vertexUV(x0, y0, z0, U[2], V[2]);
		t.vertexUV(x0, y0, z1, U[3], V[3]);
	}
}

void TileRenderer::renderEast( Tile* tt, float x, float y, float z, int tex )
{
	Tesselator& t = Tesselator::forThread();

	if (fixedTexture >= 0) tex = fixedTexture;
	int xt = (tex & 0xf) << 4;
	int yt = Atlas::cellPy(tex);

	float u0 = (xt + tt->zz0 * 16) / Atlas::W;
	float u1 = (xt + tt->zz1 * 16 - 0.01f) / Atlas::W;
	float v0 = (yt + 16 - tt->yy1 * 16) / Atlas::H;
	float v1 = (yt + 16 - tt->yy0 * 16 - 0.01f) / Atlas::H;
	if (xFlipTexture) {
		float tmp = u0;
		u0 = u1;
		u1 = tmp;
	}

	if (tt->zz0 < 0 || tt->zz1 > 1) {
		u0 = (xt + 0 * 15.99f) / Atlas::W;
		u1 = (xt + 1 * 15.99f) / Atlas::W;
	}
	if (tt->yy0 < 0 || tt->yy1 > 1) {
		v0 = (yt + 0 * 15.99f) / Atlas::H;
		v1 = (yt + 1 * 15.99f) / Atlas::H;
	}

	float x1 = x + tt->xx1;
	float y0 = y + tt->yy0;
	float y1 = y + tt->yy1;
	float z0 = z + tt->zz0;
	float z1 = z + tt->zz1;

	float U[4] = { u0, u1, u1, u0 }, V[4] = { v1, v1, v0, v0 };
	if (s_uvTurn & (1 << 5)) turnUV(U, V);

	if (applyAmbienceOcclusion) {
		const bool lit = TerrainLight::capturing();
		if (lit) TerrainLight::set(l1);
		t.color(c1r, c1g, c1b);
		t.vertexUV(x1, y0, z1, U[0], V[0]);
		if (lit) TerrainLight::set(l2);
		t.color(c2r, c2g, c2b);
		t.vertexUV(x1, y0, z0, U[1], V[1]);
		if (lit) TerrainLight::set(l3);
		t.color(c3r, c3g, c3b);
		t.vertexUV(x1, y1, z0, U[2], V[2]);
		if (lit) TerrainLight::set(l4);
		t.color(c4r, c4g, c4b);
		t.vertexUV(x1, y1, z1, U[3], V[3]);
	} else {
		t.vertexUV(x1, y0, z1, U[0], V[0]);
		t.vertexUV(x1, y0, z0, U[1], V[1]);
		t.vertexUV(x1, y1, z0, U[2], V[2]);
		t.vertexUV(x1, y1, z1, U[3], V[3]);
	}
}

void TileRenderer::renderTile( Tile* tile, int data )
{
	Tesselator& t = Tesselator::forThread();

	t.color(0xff, 0xff, 0xff);
	int shape = tile->getRenderShape();

	if (RedstoneUpdate::hasItemModel(shape)) {
		renderRedstoneUpdateItem(tile, data, false);
		return;
	}
	if (hasEnchantBrewItemModel(shape)) {
		renderEnchantBrewItem(tile, data, false);
		return;
	}
	if (endIsOwnShape(shape)) {
		renderEndItem(tile, data, false);
		return;
	}
	if (modIsOwnShape(shape)) {
		renderModModelItem(tile, data, false);
		return;
	}

	if (shape == Tile::SHAPE_BLOCK || shape == Tile::SHAPE_PISTON_BASE) {
		tile->updateDefaultShape();
		float ib[6];
		if (ModContent::itemBox(tile->id, data, ib)) tile->setShape(ib[0], ib[1], ib[2], ib[3], ib[4], ib[5]);
		t.addOffset(-0.5f, -0.5f, -0.5f);
		t.begin();
		const int tint = tile->getRenderColor(data);
		t.color((tint >> 16) & 0xff, (tint >> 8) & 0xff, tint & 0xff);
		renderFaceDown(tile, 0, 0, 0, tile->getTexture(0, data));
		renderFaceUp(tile, 0, 0, 0, tile->getTexture(1, data));
		renderNorth(tile, 0, 0, 0, tile->getTexture(2, data));
		renderSouth(tile, 0, 0, 0, tile->getTexture(3, data));
		renderWest(tile, 0, 0, 0, tile->getTexture(4, data));
		renderEast(tile, 0, 0, 0, tile->getTexture(5, data));
		t.draw();

		t.addOffset(0.5f, 0.5f, 0.5f);

	} else if (shape == Tile::SHAPE_CROSS_TEXTURE) {
		t.begin();
		tesselateCrossTexture(tile, data, -0.5f, -0.5f, -0.5f);
		t.draw();
	} else if(shape == Tile::SHAPE_STEM) {
		t.begin();
		tile->updateDefaultShape();
		tesselateStemTexture(tile, data, tile->yy1, -0.5f, -0.5f, -0.5f);
		t.draw();
	} else if (shape == Tile::SHAPE_CACTUS) {
		tile->updateDefaultShape();
		t.offset(-0.5f, -0.5f, -0.5f);
		float s = 1 / 16.0f;
		t.begin();
		renderFaceDown(tile, 0, 0, 0, tile->getTexture(0));
		renderFaceUp(tile, 0, 0, 0, tile->getTexture(1));
		t.addOffset(0, 0, s);
		renderNorth(tile, 0, 0, 0, tile->getTexture(2));
		t.addOffset(0, 0, -s);
		t.addOffset(0, 0, -s);
		renderSouth(tile, 0, 0, 0, tile->getTexture(3));
		t.addOffset(0, 0, s);
		t.addOffset(s, 0, 0);
		renderWest(tile, 0, 0, 0, tile->getTexture(4));
		t.addOffset(-s, 0, 0);
		t.addOffset(-s, 0, 0);
		renderEast(tile, 0, 0, 0, tile->getTexture(5));
		t.addOffset(s, 0, 0);
		t.draw();
		t.offset(0, 0, 0);//0.5f, 0.5f, 0.5f);
		} else if (shape == Tile::SHAPE_ROWS) {
			t.begin();
			t.normal(0, -1, 0);
			tesselateRowTexture(tile, data, -0.5f, -0.5f, -0.5f);
		//}  else if (shape == Tile::SHAPE_TORCH) {
		////    t.begin();
		////    t.normal(0, -1, 0);
		////    tesselateTorch(tile, -0.5f, -0.5f, -0.5f, 0, 0);
		////    t.end();
        } else if (shape == Tile::SHAPE_ENTITYTILE_ANIMATED) {
            EntityTileRenderer::instance->render(tile, data, 1.0f);
            //glEnable(GL_RESCALE_NORMAL);
		} else if (shape == Tile::SHAPE_STAIRS) {
		    t.addOffset(-0.5f, -0.5f, -0.5f);
			t.begin();
			for (int i = 0; i < 2; i++) {
		        if (i == 0) tile->setShape(0, 0, 0, 1, 1, 0.5f);
		        if (i == 1) tile->setShape(0, 0, 0.5f, 1, 0.5f, 1);

		        renderFaceDown(tile, 0, 0, 0, tile->getTexture(0));
		        renderFaceUp(tile, 0, 0, 0, tile->getTexture(1));
		        renderNorth(tile, 0, 0, 0, tile->getTexture(2));
		        renderSouth(tile, 0, 0, 0, tile->getTexture(3));
		        renderWest(tile, 0, 0, 0, tile->getTexture(4));
		        renderEast(tile, 0, 0, 0, tile->getTexture(5));
		    }
			t.draw();
			t.addOffset(0.5f, 0.5f, 0.5f);
		}
		else if (shape == Tile::SHAPE_FENCE) {
			t.addOffset(-0.5f, -0.5f, -0.5f);
			t.begin();
			for (int i = 0; i < 4; i++) {
				float w = 2 / 16.0f;
				if (i == 0) tile->setShape(0.5f - w, 0, 0, 0.5f + w, 1, w * 2);
				if (i == 1) tile->setShape(0.5f - w, 0, 1 - w * 2, 0.5f + w, 1, 1);
				w = 1 / 16.0f;
				if (i == 2) tile->setShape(0.5f - w, 1 - w * 3, -w * 2, 0.5f + w, 1 - w, 1 + w * 2);
				if (i == 3) tile->setShape(0.5f - w, 0.5f - w * 3, -w * 2, 0.5f + w, 0.5f - w, 1 + w * 2);

				renderFaceDown(tile, 0, 0, 0, tile->getTexture(0));
				renderFaceUp(tile, 0, 0, 0, tile->getTexture(1));
				renderNorth(tile, 0, 0, 0, tile->getTexture(2));
				renderSouth(tile, 0, 0, 0, tile->getTexture(3));
				renderWest(tile, 0, 0, 0, tile->getTexture(4));
				renderEast(tile, 0, 0, 0, tile->getTexture(5));
			}
			t.draw();
			t.addOffset(0.5f, 0.5f, 0.5f);
			tile->setShape(0, 0, 0, 1, 1, 1);
		} else if (shape == Tile::SHAPE_FENCE_GATE) {
			t.addOffset(-0.5f, -0.5f, -0.5f);
			t.begin();
			for (int i = 0; i < 3; i++) {
				float w = 1 / 16.0f;
				if (i == 0) tile->setShape(0.5f - w, .3f, 0, 0.5f + w, 1, w * 2);
				if (i == 1) tile->setShape(0.5f - w, .3f, 1 - w * 2, 0.5f + w, 1, 1);
				if (i == 2) tile->setShape(0.5f - w, .5f, w * 2, 0.5f + w, 1 - w, 1 - w * 2);

				renderFaceUp(tile, 0, 0, 0, tile->getTexture(0));
				renderFaceDown(tile, 0, 0, 0, tile->getTexture(1));
				renderNorth(tile, 0, 0, 0, tile->getTexture(2));
				renderSouth(tile, 0, 0, 0, tile->getTexture(3));
				renderWest(tile, 0, 0, 0, tile->getTexture(4));
				renderEast(tile, 0, 0, 0, tile->getTexture(5));
			}
			t.draw();
			t.addOffset(0.5f, 0.5f, 0.5f);
			tile->setShape(0, 0, 0, 1, 1, 1);
		}

}

bool TileRenderer::drawsItemAsBlock(const ItemInstance* item)
{
	if (!item || item->id <= 0 || item->id >= 256 || !Tile::tiles[item->id]) return false;
	if (!canRender(Tile::tiles[item->id]->getRenderShape())) return false;
	return !ModContent::itemFlat(item->id, item->getAuxValue());
}

bool TileRenderer::canRender( int renderShape )
{
	if (renderShape == Tile::SHAPE_BLOCK) return true;
	if (renderShape == Tile::SHAPE_CACTUS) return true;
	if (renderShape == Tile::SHAPE_STAIRS) return true;
	if (renderShape == Tile::SHAPE_FENCE) return true;
	if (renderShape == Tile::SHAPE_FENCE_GATE) return true;
	if (renderShape == Tile::SHAPE_PISTON_BASE) return true;
	if (RedstoneUpdate::hasItemModel(renderShape)) return true;
	if (hasEnchantBrewItemModel(renderShape)) return true;
	if (endIsOwnShape(renderShape)) return true;
	if (modIsOwnShape(renderShape)) return true;
	//if (renderShape == Tile::SHAPE_CROSS_TEXTURE) return true;
	if (renderShape == Tile::SHAPE_ENTITYTILE_ANIMATED) return true;

	return false;
}

void TileRenderer::renderGuiTile( Tile* tile, int data )
{
	Tesselator& t = Tesselator::forThread();

	int shape = tile->getRenderShape();

	if (RedstoneUpdate::hasItemModel(shape)) {
		renderRedstoneUpdateItem(tile, data, true);
		return;
	}
	if (hasEnchantBrewItemModel(shape)) {
		renderEnchantBrewItem(tile, data, true);
		return;
	}
	if (endIsOwnShape(shape)) {
		renderEndItem(tile, data, true);
		return;
	}
	if (modIsOwnShape(shape)) {
		renderModModelItem(tile, data, true);
		return;
	}
	if (shape == Tile::SHAPE_ENTITYTILE_ANIMATED) {
		EntityTileRenderer::instance->render(tile, data, 1.0f);
		return;
	}

	if (shape == Tile::SHAPE_BLOCK || shape == Tile::SHAPE_PISTON_BASE) {
		tile->updateDefaultShape();
		float ib[6];
		if (ModContent::itemBox(tile->id, data, ib)) tile->setShape(ib[0], ib[1], ib[2], ib[3], ib[4], ib[5]);

		t.begin();
		t.addOffset(-0.5f, -0.5f, -0.5f);
		const int tint = tile->getRenderColor(data);
		const int tr = (tint >> 16) & 0xff, tg = (tint >> 8) & 0xff, tb = tint & 0xff;
		t.color(tr, tg, tb);
		renderFaceUp(tile, 0, 0, 0, tile->getTexture(1, data));
		renderFaceDown(tile, 0, 0, 0, tile->getTexture(0, data));

		t.color(tr * 0x80 / 0xff, tg * 0x80 / 0xff, tb * 0x80 / 0xff);
		renderNorth(tile, 0, 0, 0, tile->getTexture(2, data));
		renderSouth(tile, 0, 0, 0, tile->getTexture(3, data));

		t.color(tr * 0xbb / 0xff, tg * 0xbb / 0xff, tb * 0xbb / 0xff);
		renderEast(tile, 0, 0, 0, tile->getTexture(5, data));
		renderWest(tile, 0, 0, 0, tile->getTexture(4, data));
		t.draw();
		t.addOffset(0.5f, 0.5f, 0.5f);

	} else if (shape == Tile::SHAPE_CROSS_TEXTURE) {
		t.begin();
		//t.normal(0, -1, 0);
		tesselateCrossTexture(tile, data, -0.5f, -0.5f, -0.5f);
		//t.end();
		t.draw();
	} else if (shape == Tile::SHAPE_CACTUS) {
		tile->updateDefaultShape();
		t.begin();
		t.offset(-0.5f, -0.5f, -0.5f);
		float s = 1 / 16.0f;
		t.color(0xff, 0xff, 0xff);
		renderFaceDown(tile, 0, 0, 0, tile->getTexture(0));
		renderFaceUp(tile, 0, 0, 0, tile->getTexture(1));

		t.color(0x80, 0x80, 0x80);
		t.addOffset(0, 0, s);
		renderNorth(tile, 0, 0, 0, tile->getTexture(2));
		t.addOffset(0, 0, -s-s);
		renderSouth(tile, 0, 0, 0, tile->getTexture(3));

		t.color(0xbb, 0xbb, 0xbb);
		t.addOffset(s, 0, s);
		renderWest(tile, 0, 0, 0, tile->getTexture(4));
		t.addOffset(-s-s, 0, 0);
		renderEast(tile, 0, 0, 0, tile->getTexture(5));

		t.draw();
		t.addOffset(s+0.5f, 0.5f, 0.5f);
	} else if (shape == Tile::SHAPE_STAIRS) {
		t.offset(-0.5f, -0.5f, -0.5f);
		t.begin();
		for (int i = 0; i < 2; i++) {
			if (i == 0) tile->setShape(0, 0, 0, 1, 1, 0.5f);
			if (i == 1) tile->setShape(0, 0, 0.5f, 1, 0.5f, 1);

			t.color(0xff, 0xff, 0xff);
			renderFaceDown(tile, 0, 0, 0, tile->getTexture(0));
			renderFaceUp(tile, 0, 0, 0, tile->getTexture(1));

			t.color(0x80, 0x80, 0x80);
			renderNorth(tile, 0, 0, 0, tile->getTexture(2));
			renderSouth(tile, 0, 0, 0, tile->getTexture(3));

			t.color(0xbb, 0xbb, 0xbb);
			renderWest(tile, 0, 0, 0, tile->getTexture(4));
			renderEast(tile, 0, 0, 0, tile->getTexture(5));
		}
		t.draw();
		t.offset(0, 0, 0);
	}
	else if (shape == Tile::SHAPE_FENCE) {
		t.addOffset(-0.5f, -0.5f, -0.5f);
		t.begin();
		for (int i = 0; i < 4; i++) {
			float w = 2 / 16.0f;
			if (i == 0) tile->setShape(0.5f - w, 0, 0, 0.5f + w, 1, w * 2);
			if (i == 1) tile->setShape(0.5f - w, 0, 1 - w * 2, 0.5f + w, 1, 1);
			w = 1 / 16.0f;
			if (i == 2) tile->setShape(0.5f - w, 1 - w * 3, -w * 2, 0.5f + w, 1 - w, 1 + w * 2);
			if (i == 3) tile->setShape(0.5f - w, 0.5f - w * 3, -w * 2, 0.5f + w, 0.5f - w, 1 + w * 2);

			t.color(0xff, 0xff, 0xff);

			renderFaceDown(tile, 0, 0, 0, tile->getTexture(0));
			renderFaceUp(tile, 0, 0, 0, tile->getTexture(1));

			t.color(0x80, 0x80, 0x80);
			renderNorth(tile, 0, 0, 0, tile->getTexture(2));
			renderSouth(tile, 0, 0, 0, tile->getTexture(3));

			t.color(0xbb, 0xbb, 0xbb);
			renderWest(tile, 0, 0, 0, tile->getTexture(4));
			renderEast(tile, 0, 0, 0, tile->getTexture(5));
		}
		t.draw();
		t.addOffset(0.5f, 0.5f, 0.5f);
		tile->setShape(0, 0, 0, 1, 1, 1);
	}
	else if (shape == Tile::SHAPE_FENCE_GATE) {
		t.addOffset(-0.5f, -0.5f, -0.5f);
		t.begin();
		for (int i = 0; i < 3; i++) {
			float w = 1 / 16.0f;
			if (i == 0) tile->setShape(0.5f - w, .3f, 0, 0.5f + w, 1, w * 2);
			if (i == 1) tile->setShape(0.5f - w, .3f, 1 - w * 2, 0.5f + w, 1, 1);
			w = 1 / 16.0f;
			if (i == 2) tile->setShape(0.5f - w, .5f, 0, 0.5f + w, 1 - w, 1);

			t.color(0xff, 0xff, 0xff);
			renderFaceUp(tile, 0, 0, 0, tile->getTexture(0));
			renderFaceDown(tile, 0, 0, 0, tile->getTexture(1));

			t.color(0x80, 0x80, 0x80);
			renderNorth(tile, 0, 0, 0, tile->getTexture(2));
			renderSouth(tile, 0, 0, 0, tile->getTexture(3));

			t.color(0xbb, 0xbb, 0xbb);
			renderWest(tile, 0, 0, 0, tile->getTexture(4));
			renderEast(tile, 0, 0, 0, tile->getTexture(5));
		}
		t.draw();
		tile->setShape(0, 0, 0, 1, 1, 1);
		t.addOffset(0.5f, 0.5f, 0.5f);
	}
}

bool TileRenderer::tesselateThinFenceInWorld(ThinFenceTile* tt, int x, int y, int z) {
	const int depth = 128;
	Tesselator& t = Tesselator::forThread();

	float br = tt->getBrightness(level, x, y, z);
	int col = tt->getColor(level, x, y, z);
	float r = ((col >> 16) & 0xff) / 255.0f;
	float g = ((col >> 8) & 0xff) / 255.0f;
	float b = ((col) & 0xff) / 255.0f;

	//if (GameRenderer::anaglyph3d) {
	//	float cr = (r * 30 + g * 59 + b * 11) / 100;
	//	float cg = (r * 30 + g * 70) / (100);
	//	float cb = (r * 30 + b * 70) / (100);

	//	r = cr;
	//	g = cg;
	//	b = cb;
	//}
	t.color(br * r, br * g, br * b);

	int tex = 0;
	int edgeTex = 0;

	if (fixedTexture >= 0) {
		tex = fixedTexture;
		edgeTex = fixedTexture;
	} else {
		int data = level->getData(x, y, z);
		tex = tt->getTexture(0, data);
		edgeTex = tt->getEdgeTexture(data);
	}

	const int xt = (tex & 0xf) << 4;
	const int yt = Atlas::cellPy(tex);
	float u0 = (xt) / Atlas::W;
	const float u1 = (xt + 7.99f) / Atlas::W;
	const float u2 = (xt + 15.99f) / Atlas::W;
	const float v0 = (yt) / Atlas::H;
	const float v2 = (yt + 15.99f) / Atlas::H;

	const int xet = (edgeTex & 0xf) << 4;
	const int yet = Atlas::cellPy(edgeTex);

	const float iu0 = (xet + 7) / Atlas::W;
	const float iu1 = (xet + 8.99f) / Atlas::W;
	const float iv0 = (yet) / Atlas::H;
	const float iv1 = (yet + 8) / Atlas::H;
	const float iv2 = (yet + 15.99f) / Atlas::H;

	const float x0 = (float)x;
	const float x1 = x0 + .5f;
	const float x2 = x0 + 1;
	const float y0 = (float)y + 0.001f;
	const float y1 = y0 + 1 - 0.002f;
	const float z0 = (float)z;
	const float z1 = z0 + .5f;
	const float z2 = z0 + 1;
	const float ix0 = x0 + .5f - 1.0f / 16.0f;
	const float ix1 = x0 + .5f + 1.0f / 16.0f;
	const float iz0 = z0 + .5f - 1.0f / 16.0f;
	const float iz1 = z0 + .5f + 1.0f / 16.0f;

	const bool n = tt->attachsTo(level->getTile(x, y, z - 1));
	const bool s = tt->attachsTo(level->getTile(x, y, z + 1));
	const bool w = tt->attachsTo(level->getTile(x - 1, y, z));
	const bool e = tt->attachsTo(level->getTile(x + 1, y, z));

	const bool up = tt->shouldRenderFace(level, x, y + 1, z, Facing::UP);
	const bool down = tt->shouldRenderFace(level, x, y - 1, z, Facing::DOWN);

	const float noZFightingOffset = 0.01f;

	if ((w && e) || (!w && !e && !n && !s)) {
		t.vertexUV(x0, y1, z1, u0, v0);
		t.vertexUV(x0, y0, z1, u0, v2);
		t.vertexUV(x2, y0, z1, u2, v2);
		t.vertexUV(x2, y1, z1, u2, v0);

		t.vertexUV(x2, y1, z1, u0, v0);
		t.vertexUV(x2, y0, z1, u0, v2);
		t.vertexUV(x0, y0, z1, u2, v2);
		t.vertexUV(x0, y1, z1, u2, v0);

		if (up) {
			// small edge texture
			t.vertexUV(x0, y1 + noZFightingOffset, iz1, iu1, iv2);
			t.vertexUV(x2, y1 + noZFightingOffset, iz1, iu1, iv0);
			t.vertexUV(x2, y1 + noZFightingOffset, iz0, iu0, iv0);
			t.vertexUV(x0, y1 + noZFightingOffset, iz0, iu0, iv2);

			t.vertexUV(x2, y1 + noZFightingOffset, iz1, iu1, iv2);
			t.vertexUV(x0, y1 + noZFightingOffset, iz1, iu1, iv0);
			t.vertexUV(x0, y1 + noZFightingOffset, iz0, iu0, iv0);
			t.vertexUV(x2, y1 + noZFightingOffset, iz0, iu0, iv2);
		} else {
			if (y < (depth - 1) && level->isEmptyTile(x - 1, y + 1, z)) {
				t.vertexUV(x0, y1 + noZFightingOffset, iz1, iu1, iv1);
				t.vertexUV(x1, y1 + noZFightingOffset, iz1, iu1, iv2);
				t.vertexUV(x1, y1 + noZFightingOffset, iz0, iu0, iv2);
				t.vertexUV(x0, y1 + noZFightingOffset, iz0, iu0, iv1);

				t.vertexUV(x1, y1 + noZFightingOffset, iz1, iu1, iv1);
				t.vertexUV(x0, y1 + noZFightingOffset, iz1, iu1, iv2);
				t.vertexUV(x0, y1 + noZFightingOffset, iz0, iu0, iv2);
				t.vertexUV(x1, y1 + noZFightingOffset, iz0, iu0, iv1);
			}
			if (y < (depth - 1) && level->isEmptyTile(x + 1, y + 1, z)) {
				t.vertexUV(x1, y1 + noZFightingOffset, iz1, iu1, iv0);
				t.vertexUV(x2, y1 + noZFightingOffset, iz1, iu1, iv1);
				t.vertexUV(x2, y1 + noZFightingOffset, iz0, iu0, iv1);
				t.vertexUV(x1, y1 + noZFightingOffset, iz0, iu0, iv0);

				t.vertexUV(x2, y1 + noZFightingOffset, iz1, iu1, iv0);
				t.vertexUV(x1, y1 + noZFightingOffset, iz1, iu1, iv1);
				t.vertexUV(x1, y1 + noZFightingOffset, iz0, iu0, iv1);
				t.vertexUV(x2, y1 + noZFightingOffset, iz0, iu0, iv0);
			}
		}
		if (down) {
			// small edge texture
			t.vertexUV(x0, y0 - noZFightingOffset, iz1, iu1, iv2);
			t.vertexUV(x2, y0 - noZFightingOffset, iz1, iu1, iv0);
			t.vertexUV(x2, y0 - noZFightingOffset, iz0, iu0, iv0);
			t.vertexUV(x0, y0 - noZFightingOffset, iz0, iu0, iv2);

			t.vertexUV(x2, y0 - noZFightingOffset, iz1, iu1, iv2);
			t.vertexUV(x0, y0 - noZFightingOffset, iz1, iu1, iv0);
			t.vertexUV(x0, y0 - noZFightingOffset, iz0, iu0, iv0);
			t.vertexUV(x2, y0 - noZFightingOffset, iz0, iu0, iv2);
		} else {
			if (y > 1 && level->isEmptyTile(x - 1, y - 1, z)) {
				t.vertexUV(x0, y0 - noZFightingOffset, iz1, iu1, iv1);
				t.vertexUV(x1, y0 - noZFightingOffset, iz1, iu1, iv2);
				t.vertexUV(x1, y0 - noZFightingOffset, iz0, iu0, iv2);
				t.vertexUV(x0, y0 - noZFightingOffset, iz0, iu0, iv1);

				t.vertexUV(x1, y0 - noZFightingOffset, iz1, iu1, iv1);
				t.vertexUV(x0, y0 - noZFightingOffset, iz1, iu1, iv2);
				t.vertexUV(x0, y0 - noZFightingOffset, iz0, iu0, iv2);
				t.vertexUV(x1, y0 - noZFightingOffset, iz0, iu0, iv1);
			}
			if (y > 1 && level->isEmptyTile(x + 1, y - 1, z)) {
				t.vertexUV(x1, y0 - noZFightingOffset, iz1, iu1, iv0);
				t.vertexUV(x2, y0 - noZFightingOffset, iz1, iu1, iv1);
				t.vertexUV(x2, y0 - noZFightingOffset, iz0, iu0, iv1);
				t.vertexUV(x1, y0 - noZFightingOffset, iz0, iu0, iv0);

				t.vertexUV(x2, y0 - noZFightingOffset, iz1, iu1, iv0);
				t.vertexUV(x1, y0 - noZFightingOffset, iz1, iu1, iv1);
				t.vertexUV(x1, y0 - noZFightingOffset, iz0, iu0, iv1);
				t.vertexUV(x2, y0 - noZFightingOffset, iz0, iu0, iv0);
			}
		}

	} else if (w && !e) {
		// half-step towards west
		t.vertexUV(x0, y1, z1, u0, v0);
		t.vertexUV(x0, y0, z1, u0, v2);
		t.vertexUV(x1, y0, z1, u1, v2);
		t.vertexUV(x1, y1, z1, u1, v0);

		t.vertexUV(x1, y1, z1, u0, v0);
		t.vertexUV(x1, y0, z1, u0, v2);
		t.vertexUV(x0, y0, z1, u1, v2);
		t.vertexUV(x0, y1, z1, u1, v0);

		// small edge texture
		if (!s && !n) {
			t.vertexUV(x1, y1, iz1, iu0, iv0);
			t.vertexUV(x1, y0, iz1, iu0, iv2);
			t.vertexUV(x1, y0, iz0, iu1, iv2);
			t.vertexUV(x1, y1, iz0, iu1, iv0);

			t.vertexUV(x1, y1, iz0, iu0, iv0);
			t.vertexUV(x1, y0, iz0, iu0, iv2);
			t.vertexUV(x1, y0, iz1, iu1, iv2);
			t.vertexUV(x1, y1, iz1, iu1, iv0);
		}

		if (up || (y < (depth - 1) && level->isEmptyTile(x - 1, y + 1, z))) {
			// small edge texture
			t.vertexUV(x0, y1 + noZFightingOffset, iz1, iu1, iv1);
			t.vertexUV(x1, y1 + noZFightingOffset, iz1, iu1, iv2);
			t.vertexUV(x1, y1 + noZFightingOffset, iz0, iu0, iv2);
			t.vertexUV(x0, y1 + noZFightingOffset, iz0, iu0, iv1);

			t.vertexUV(x1, y1 + noZFightingOffset, iz1, iu1, iv1);
			t.vertexUV(x0, y1 + noZFightingOffset, iz1, iu1, iv2);
			t.vertexUV(x0, y1 + noZFightingOffset, iz0, iu0, iv2);
			t.vertexUV(x1, y1 + noZFightingOffset, iz0, iu0, iv1);
		}
		if (down || (y > 1 && level->isEmptyTile(x - 1, y - 1, z))) {
			// small edge texture
			t.vertexUV(x0, y0 - noZFightingOffset, iz1, iu1, iv1);
			t.vertexUV(x1, y0 - noZFightingOffset, iz1, iu1, iv2);
			t.vertexUV(x1, y0 - noZFightingOffset, iz0, iu0, iv2);
			t.vertexUV(x0, y0 - noZFightingOffset, iz0, iu0, iv1);

			t.vertexUV(x1, y0 - noZFightingOffset, iz1, iu1, iv1);
			t.vertexUV(x0, y0 - noZFightingOffset, iz1, iu1, iv2);
			t.vertexUV(x0, y0 - noZFightingOffset, iz0, iu0, iv2);
			t.vertexUV(x1, y0 - noZFightingOffset, iz0, iu0, iv1);
		}

	} else if (!w && e) {
		// half-step towards east
		t.vertexUV(x1, y1, z1, u1, v0);
		t.vertexUV(x1, y0, z1, u1, v2);
		t.vertexUV(x2, y0, z1, u2, v2);
		t.vertexUV(x2, y1, z1, u2, v0);

		t.vertexUV(x2, y1, z1, u1, v0);
		t.vertexUV(x2, y0, z1, u1, v2);
		t.vertexUV(x1, y0, z1, u2, v2);
		t.vertexUV(x1, y1, z1, u2, v0);

		// small edge texture
		if (!s && !n) {
			t.vertexUV(x1, y1, iz0, iu0, iv0);
			t.vertexUV(x1, y0, iz0, iu0, iv2);
			t.vertexUV(x1, y0, iz1, iu1, iv2);
			t.vertexUV(x1, y1, iz1, iu1, iv0);

			t.vertexUV(x1, y1, iz1, iu0, iv0);
			t.vertexUV(x1, y0, iz1, iu0, iv2);
			t.vertexUV(x1, y0, iz0, iu1, iv2);
			t.vertexUV(x1, y1, iz0, iu1, iv0);
		}

		if (up || (y < (depth - 1) && level->isEmptyTile(x + 1, y + 1, z))) {
			// small edge texture
			t.vertexUV(x1, y1 + noZFightingOffset, iz1, iu1, iv0);
			t.vertexUV(x2, y1 + noZFightingOffset, iz1, iu1, iv1);
			t.vertexUV(x2, y1 + noZFightingOffset, iz0, iu0, iv1);
			t.vertexUV(x1, y1 + noZFightingOffset, iz0, iu0, iv0);

			t.vertexUV(x2, y1 + noZFightingOffset, iz1, iu1, iv0);
			t.vertexUV(x1, y1 + noZFightingOffset, iz1, iu1, iv1);
			t.vertexUV(x1, y1 + noZFightingOffset, iz0, iu0, iv1);
			t.vertexUV(x2, y1 + noZFightingOffset, iz0, iu0, iv0);
		}
		if (down || (y > 1 && level->isEmptyTile(x + 1, y - 1, z))) {
			// small edge texture
			t.vertexUV(x1, y0 - noZFightingOffset, iz1, iu1, iv0);
			t.vertexUV(x2, y0 - noZFightingOffset, iz1, iu1, iv1);
			t.vertexUV(x2, y0 - noZFightingOffset, iz0, iu0, iv1);
			t.vertexUV(x1, y0 - noZFightingOffset, iz0, iu0, iv0);

			t.vertexUV(x2, y0 - noZFightingOffset, iz1, iu1, iv0);
			t.vertexUV(x1, y0 - noZFightingOffset, iz1, iu1, iv1);
			t.vertexUV(x1, y0 - noZFightingOffset, iz0, iu0, iv1);
			t.vertexUV(x2, y0 - noZFightingOffset, iz0, iu0, iv0);
		}

	}

	if ((n && s) || (!w && !e && !n && !s)) {
		// straight north-south
		t.vertexUV(x1, y1, z2, u0, v0);
		t.vertexUV(x1, y0, z2, u0, v2);
		t.vertexUV(x1, y0, z0, u2, v2);
		t.vertexUV(x1, y1, z0, u2, v0);

		t.vertexUV(x1, y1, z0, u0, v0);
		t.vertexUV(x1, y0, z0, u0, v2);
		t.vertexUV(x1, y0, z2, u2, v2);
		t.vertexUV(x1, y1, z2, u2, v0);

		if (up) {
			// small edge texture
			t.vertexUV(ix1, y1, z2, iu1, iv2);
			t.vertexUV(ix1, y1, z0, iu1, iv0);
			t.vertexUV(ix0, y1, z0, iu0, iv0);
			t.vertexUV(ix0, y1, z2, iu0, iv2);

			t.vertexUV(ix1, y1, z0, iu1, iv2);
			t.vertexUV(ix1, y1, z2, iu1, iv0);
			t.vertexUV(ix0, y1, z2, iu0, iv0);
			t.vertexUV(ix0, y1, z0, iu0, iv2);
		} else {
			if (y < (depth - 1) && level->isEmptyTile(x, y + 1, z - 1)) {
				t.vertexUV(ix0, y1, z0, iu1, iv0);
				t.vertexUV(ix0, y1, z1, iu1, iv1);
				t.vertexUV(ix1, y1, z1, iu0, iv1);
				t.vertexUV(ix1, y1, z0, iu0, iv0);

				t.vertexUV(ix0, y1, z1, iu1, iv0);
				t.vertexUV(ix0, y1, z0, iu1, iv1);
				t.vertexUV(ix1, y1, z0, iu0, iv1);
				t.vertexUV(ix1, y1, z1, iu0, iv0);
			}
			if (y < (depth - 1) && level->isEmptyTile(x, y + 1, z + 1)) {
				t.vertexUV(ix0, y1, z1, iu0, iv1);
				t.vertexUV(ix0, y1, z2, iu0, iv2);
				t.vertexUV(ix1, y1, z2, iu1, iv2);
				t.vertexUV(ix1, y1, z1, iu1, iv1);

				t.vertexUV(ix0, y1, z2, iu0, iv1);
				t.vertexUV(ix0, y1, z1, iu0, iv2);
				t.vertexUV(ix1, y1, z1, iu1, iv2);
				t.vertexUV(ix1, y1, z2, iu1, iv1);
			}
		}
		if (down) {
			// small edge texture
			t.vertexUV(ix1, y0, z2, iu1, iv2);
			t.vertexUV(ix1, y0, z0, iu1, iv0);
			t.vertexUV(ix0, y0, z0, iu0, iv0);
			t.vertexUV(ix0, y0, z2, iu0, iv2);

			t.vertexUV(ix1, y0, z0, iu1, iv2);
			t.vertexUV(ix1, y0, z2, iu1, iv0);
			t.vertexUV(ix0, y0, z2, iu0, iv0);
			t.vertexUV(ix0, y0, z0, iu0, iv2);
		} else {
			if (y > 1 && level->isEmptyTile(x, y - 1, z - 1)) {
				// north half-step
				t.vertexUV(ix0, y0, z0, iu1, iv0);
				t.vertexUV(ix0, y0, z1, iu1, iv1);
				t.vertexUV(ix1, y0, z1, iu0, iv1);
				t.vertexUV(ix1, y0, z0, iu0, iv0);

				t.vertexUV(ix0, y0, z1, iu1, iv0);
				t.vertexUV(ix0, y0, z0, iu1, iv1);
				t.vertexUV(ix1, y0, z0, iu0, iv1);
				t.vertexUV(ix1, y0, z1, iu0, iv0);
			}
			if (y > 1 && level->isEmptyTile(x, y - 1, z + 1)) {
				// south half-step
				t.vertexUV(ix0, y0, z1, iu0, iv1);
				t.vertexUV(ix0, y0, z2, iu0, iv2);
				t.vertexUV(ix1, y0, z2, iu1, iv2);
				t.vertexUV(ix1, y0, z1, iu1, iv1);

				t.vertexUV(ix0, y0, z2, iu0, iv1);
				t.vertexUV(ix0, y0, z1, iu0, iv2);
				t.vertexUV(ix1, y0, z1, iu1, iv2);
				t.vertexUV(ix1, y0, z2, iu1, iv1);
			}
		}

	} else if (n && !s) {
		// half-step towards north
		t.vertexUV(x1, y1, z0, u0, v0);
		t.vertexUV(x1, y0, z0, u0, v2);
		t.vertexUV(x1, y0, z1, u1, v2);
		t.vertexUV(x1, y1, z1, u1, v0);

		t.vertexUV(x1, y1, z1, u0, v0);
		t.vertexUV(x1, y0, z1, u0, v2);
		t.vertexUV(x1, y0, z0, u1, v2);
		t.vertexUV(x1, y1, z0, u1, v0);

		// small edge texture
		if (!e && !w) {
			t.vertexUV(ix0, y1, z1, iu0, iv0);
			t.vertexUV(ix0, y0, z1, iu0, iv2);
			t.vertexUV(ix1, y0, z1, iu1, iv2);
			t.vertexUV(ix1, y1, z1, iu1, iv0);

			t.vertexUV(ix1, y1, z1, iu0, iv0);
			t.vertexUV(ix1, y0, z1, iu0, iv2);
			t.vertexUV(ix0, y0, z1, iu1, iv2);
			t.vertexUV(ix0, y1, z1, iu1, iv0);
		}

		if (up || (y < (depth - 1) && level->isEmptyTile(x, y + 1, z - 1))) {
			// small edge texture
			t.vertexUV(ix0, y1, z0, iu1, iv0);
			t.vertexUV(ix0, y1, z1, iu1, iv1);
			t.vertexUV(ix1, y1, z1, iu0, iv1);
			t.vertexUV(ix1, y1, z0, iu0, iv0);

			t.vertexUV(ix0, y1, z1, iu1, iv0);
			t.vertexUV(ix0, y1, z0, iu1, iv1);
			t.vertexUV(ix1, y1, z0, iu0, iv1);
			t.vertexUV(ix1, y1, z1, iu0, iv0);
		}

		if (down || (y > 1 && level->isEmptyTile(x, y - 1, z - 1))) {
			// small edge texture
			t.vertexUV(ix0, y0, z0, iu1, iv0);
			t.vertexUV(ix0, y0, z1, iu1, iv1);
			t.vertexUV(ix1, y0, z1, iu0, iv1);
			t.vertexUV(ix1, y0, z0, iu0, iv0);

			t.vertexUV(ix0, y0, z1, iu1, iv0);
			t.vertexUV(ix0, y0, z0, iu1, iv1);
			t.vertexUV(ix1, y0, z0, iu0, iv1);
			t.vertexUV(ix1, y0, z1, iu0, iv0);
		}

	} else if (!n && s) {
		// half-step towards south
		t.vertexUV(x1, y1, z1, u1, v0);
		t.vertexUV(x1, y0, z1, u1, v2);
		t.vertexUV(x1, y0, z2, u2, v2);
		t.vertexUV(x1, y1, z2, u2, v0);

		t.vertexUV(x1, y1, z2, u1, v0);
		t.vertexUV(x1, y0, z2, u1, v2);
		t.vertexUV(x1, y0, z1, u2, v2);
		t.vertexUV(x1, y1, z1, u2, v0);

		// small edge texture
		if (!e && !w) {
			t.vertexUV(ix1, y1, z1, iu0, iv0);
			t.vertexUV(ix1, y0, z1, iu0, iv2);
			t.vertexUV(ix0, y0, z1, iu1, iv2);
			t.vertexUV(ix0, y1, z1, iu1, iv0);

			t.vertexUV(ix0, y1, z1, iu0, iv0);
			t.vertexUV(ix0, y0, z1, iu0, iv2);
			t.vertexUV(ix1, y0, z1, iu1, iv2);
			t.vertexUV(ix1, y1, z1, iu1, iv0);
		}

		if (up || (y < (depth - 1) && level->isEmptyTile(x, y + 1, z + 1))) {
			// small edge texture
			t.vertexUV(ix0, y1, z1, iu0, iv1);
			t.vertexUV(ix0, y1, z2, iu0, iv2);
			t.vertexUV(ix1, y1, z2, iu1, iv2);
			t.vertexUV(ix1, y1, z1, iu1, iv1);

			t.vertexUV(ix0, y1, z2, iu0, iv1);
			t.vertexUV(ix0, y1, z1, iu0, iv2);
			t.vertexUV(ix1, y1, z1, iu1, iv2);
			t.vertexUV(ix1, y1, z2, iu1, iv1);
		}
		if (down || (y > 1 && level->isEmptyTile(x, y - 1, z + 1))) {
			// small edge texture
			t.vertexUV(ix0, y0, z1, iu0, iv1);
			t.vertexUV(ix0, y0, z2, iu0, iv2);
			t.vertexUV(ix1, y0, z2, iu1, iv2);
			t.vertexUV(ix1, y0, z1, iu1, iv1);

			t.vertexUV(ix0, y0, z2, iu0, iv1);
			t.vertexUV(ix0, y0, z1, iu0, iv2);
			t.vertexUV(ix1, y0, z1, iu1, iv2);
			t.vertexUV(ix1, y0, z2, iu1, iv1);
		}

	}

	return true;
}

void TileRenderer::tesselateRowTexture( Tile* tt, int data, float x, float y, float z ) {
	Tesselator& t = Tesselator::forThread();

	int tex = tt->getTexture(0, data);
	if(fixedTexture >= 0)
		tex = fixedTexture;

	int xt = (tex & 0xf) << 4;
	int yt = Atlas::cellPy(tex);
	float u0 = (xt) / Atlas::W;
	float u1 = (xt + 15.99f) / Atlas::W;
	float v0 = (yt) / Atlas::H;
	float v1 = (yt + 15.99f) / Atlas::H;

	float x0 = x + 0.5f - 0.25f;
	float x1 = x + 0.5f + 0.25f;
	float z0 = z + 0.5f - 0.5f;
	float z1 = z + 0.5f + 0.5f;
	t.vertexUV(x0, y + 1, z0, u0, v0);
	t.vertexUV(x0, y + 0, z0, u0, v1);
	t.vertexUV(x0, y + 0, z1, u1, v1);
	t.vertexUV(x0, y + 1, z1, u1, v0);

	t.vertexUV(x0, y + 1, z1, u0, v0);
	t.vertexUV(x0, y + 0, z1, u0, v1);
	t.vertexUV(x0, y + 0, z0, u1, v1);
	t.vertexUV(x0, y + 1, z0, u1, v0);

	t.vertexUV(x1, y + 1, z1, u0, v0);
	t.vertexUV(x1, y + 0, z1, u0, v1);
	t.vertexUV(x1, y + 0, z0, u1, v1);
	t.vertexUV(x1, y + 1, z0, u1, v0);

	t.vertexUV(x1, y + 1, z0, u0, v0);
	t.vertexUV(x1, y + 0, z0, u0, v1);
	t.vertexUV(x1, y + 0, z1, u1, v1);
	t.vertexUV(x1, y + 1, z1, u1, v0);

	x0 = x + 0.5f - 0.5f;
	x1 = x + 0.5f + 0.5f;
	z0 = z + 0.5f - 0.25f;
	z1 = z + 0.5f + 0.25f;

	t.vertexUV(x0, y + 1, z0, u0, v0);
	t.vertexUV(x0, y + 0, z0, u0, v1);
	t.vertexUV(x1, y + 0, z0, u1, v1);
	t.vertexUV(x1, y + 1, z0, u1, v0);

	t.vertexUV(x1, y + 1, z0, u0, v0);
	t.vertexUV(x1, y + 0, z0, u0, v1);
	t.vertexUV(x0, y + 0, z0, u1, v1);
	t.vertexUV(x0, y + 1, z0, u1, v0);

	t.vertexUV(x1, y + 1, z1, u0, v0);
	t.vertexUV(x1, y + 0, z1, u0, v1);
	t.vertexUV(x0, y + 0, z1, u1, v1);
	t.vertexUV(x0, y + 1, z1, u1, v0);

	t.vertexUV(x0, y + 1, z1, u0, v0);
	t.vertexUV(x0, y + 0, z1, u0, v1);
	t.vertexUV(x1, y + 0, z1, u1, v1);
	t.vertexUV(x1, y + 1, z1, u1, v0);
}
