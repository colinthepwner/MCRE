#ifndef NET_MINECRAFT_CLIENT_RENDERER_TILEENTITY__ChestRenderer_H__
#define NET_MINECRAFT_CLIENT_RENDERER_TILEENTITY__ChestRenderer_H__

//package net.minecraft.client.renderer.tileentity;


#include "TileEntityRenderer.h"
#include "../../model/ChestModel.h"
#include "../../model/BookModel.h"

class ChestTileEntity;
class EnderChestTileEntity;
class EnchantTableTileEntity;

class ChestRenderer: public TileEntityRenderer
{
public:
	ChestRenderer();

    /*@Override*/
    void render(TileEntity* entity, float x, float y, float z, float a);

	void onGraphicsReset();

	static int itemTileId;

private:
	void renderChest(ChestTileEntity* chest, float x, float y, float z, float a);
	void renderEnderChest(EnderChestTileEntity* chest, float x, float y, float z, float a);
	void renderBook(EnchantTableTileEntity* table, float x, float y, float z, float a);
	void drawModel(ChestModel* model, int data, bool pairedX, bool pairedZ, float lid, float x, float y, float z);

    ChestModel chestModel;
    LargeChestModel largeChestModel;
	BookModel bookModel;
	bool christmas;
};

#endif /*NET_MINECRAFT_CLIENT_RENDERER_TILEENTITY__ChestRenderer_H__*/
