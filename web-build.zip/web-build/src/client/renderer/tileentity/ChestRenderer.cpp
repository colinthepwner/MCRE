#include "ChestRenderer.h"
#include "TileEntityRenderer.h"
#include "../gles.h"
#include "../ModelCull.h"
#include "../../model/ChestModel.h"
#include "../../../world/ExtrasIds.h"
#include "../../../world/level/Level.h"
#include "../../../world/level/tile/entity/ChestTileEntity.h"
#include "../../../world/level/tile/entity/ExtrasTileEntities.h"
#include "../../../world/level/tile/ChestTile.h"
#include "../../../world/level/tile/RedstoneUpdate.h"
#include "../../../util/Mth.h"

#include <ctime>

int ChestRenderer::itemTileId = 0;

ChestRenderer::ChestRenderer()
:	christmas(false)
{
	const time_t now = time(NULL);
	if (const struct tm* t = localtime(&now))
		christmas = t->tm_mon == 11 && t->tm_mday >= 24 && t->tm_mday <= 26;
}

void ChestRenderer::onGraphicsReset() {
	chestModel.onGraphicsReset();
	largeChestModel.onGraphicsReset();
	bookModel.onGraphicsReset();
}

void ChestRenderer::render( TileEntity* entity, float x, float y, float z, float a )
{
	if (entity->type == TileEntityType::Chest) renderChest((ChestTileEntity*) entity, x, y, z, a);
	else if (entity->type == ExtrasIds::TE_ENDER_CHEST) renderEnderChest((EnderChestTileEntity*) entity, x, y, z, a);
	else if (entity->type == ExtrasIds::TE_ENCHANT_TABLE) renderBook((EnchantTableTileEntity*) entity, x, y, z, a);
}

void ChestRenderer::drawModel(ChestModel* model, int data, bool pairedX, bool pairedZ, float lid,
		float x, float y, float z) {
	glPushMatrix2();
	glTranslatef2(x, y + 1, z + 1);
	glScalef2(1, -1, -1);

	glTranslatef2(0.5f, 0.5f, 0.5f);
	GLfloat rot = 0;
	if (data == 2) rot = 180;
	if (data == 3) rot = 0;
	if (data == 4) rot = 90;
	if (data == 5) rot = -90;

	if (data == 2 && pairedX) glTranslatef2(1, 0, 0);
	if (data == 5 && pairedZ) glTranslatef2(0, 0, -1);
	glRotatef2(rot, 0, 1, 0);
	glTranslatef2(-0.5f, -0.5f, -0.5f);

	lid = 1 - lid;
	lid = 1 - lid * lid * lid;
	model->lid.xRot = -(lid * Mth::PI / 2);
	ModelCull::cullFront();
	model->render();
	glFrontFace(GL_CCW);
	glPopMatrix2();
}

void ChestRenderer::renderChest( ChestTileEntity* chest, float x, float y, float z, float a )
{
	int data = 0;
	int tileId = itemTileId;

	if (chest->level) {
		Tile* tile = chest->getTile();
		data = chest->getData();
		tileId = tile != NULL ? tile->id : 0;

		if (tile != NULL && data == 0) {
			((ChestTile*)tile)->recalcLockDir(chest->level, chest->x, chest->y, chest->z);
			data = chest->getData();
		}

		chest->checkNeighbors();
	}
	if (chest->n != NULL || chest->w != NULL) return;

	const bool trapped = RedstoneUpdate::chestTrapped != NULL && tileId == RedstoneUpdate::chestTrapped->id;
	const bool large = chest->e != NULL || chest->s != NULL;
	ChestModel* model;
	if (large) {
		model = &largeChestModel;
		bindTexture(christmas ? "item/largexmaschest.png" : trapped ? "item/chests/trap_large.png" : "item/largechest.png");
	} else {
		model = &chestModel;
		bindTexture(christmas ? "item/xmaschest.png" : trapped ? "item/chests/trap_small.png" : "item/chest.png");
	}

	float open = chest->oOpenness + (chest->openness - chest->oOpenness) * a;
	ChestTileEntity* other = chest->e != NULL ? chest->e : chest->s;
	if (other != NULL) {
		const float o = other->oOpenness + (other->openness - other->oOpenness) * a;
		if (o > open) open = o;
	}

	drawModel(model, data, chest->e != NULL, chest->s != NULL, open, x, y, z);
}

void ChestRenderer::renderEnderChest( EnderChestTileEntity* chest, float x, float y, float z, float a )
{
	const int data = chest->level ? chest->getData() : 0;
	bindTexture("item/enderchest.png");
	const float open = chest->oOpenness + (chest->openness - chest->oOpenness) * a;
	drawModel(&chestModel, data, false, false, open, x, y, z);
}

void ChestRenderer::renderBook( EnchantTableTileEntity* t, float x, float y, float z, float a )
{
	glPushMatrix2();
	glTranslatef2(x + 0.5f, y + 0.75f, z + 0.5f);
	const float time = t->time + a;
	glTranslatef2(0.0f, 0.1f + Mth::sin(time * 0.1f) * 0.01f, 0.0f);
	float d = t->rot - t->oRot;
	while (d >= Mth::PI) d -= Mth::PI * 2;
	while (d < -Mth::PI) d += Mth::PI * 2;
	const float r = t->oRot + d * a;
	glRotatef2(-r * 180.0f / Mth::PI, 0.0f, 1.0f, 0.0f);
	glRotatef2(80.0f, 0.0f, 0.0f, 1.0f);
	bindTexture("item/book.png");
	float flipR = t->oFlip + (t->flip - t->oFlip) * a + 0.25f;
	float flipL = t->oFlip + (t->flip - t->oFlip) * a + 0.75f;
	flipR = (flipR - Mth::floor(flipR)) * 1.6f - 0.3f;
	flipL = (flipL - Mth::floor(flipL)) * 1.6f - 0.3f;
	if (flipR < 0.0f) flipR = 0.0f;
	if (flipL < 0.0f) flipL = 0.0f;
	if (flipR > 1.0f) flipR = 1.0f;
	if (flipL > 1.0f) flipL = 1.0f;
	const float open = t->oOpen + (t->open - t->oOpen) * a;
	ModelCull::cullFront();
	bookModel.render(time, flipR, flipL, open, 1.0f / 16.0f);
	glFrontFace(GL_CCW);
	glPopMatrix2();
}
