#include "DynamicTexture.h"

#include <cstring>
#include <cstdlib>
#include "../Textures.h"
#include "../../../world/level/tile/Tile.h"
#include "../../../world/level/tile/FireTile.h"
#include "../../../util/Mth.h"

//
// DynamicTexture
//
DynamicTexture::DynamicTexture(int tex_)
:   tex(tex_),
	replicate(1)
{
	memset(pixels, 0, 16*16*4);
}

void DynamicTexture::bindTexture(Textures* tex) {
	tex->loadAndBindTexture("terrain.png");
}

//
// WaterTexture
// I was thinking of adding something simple (a simple frame copy from a
// "still water image sequence") every n:th tick for calm water, and shifting
// the rows of a texture for the running water. I might do that, but I got
// impressed over the java code, so I will try that first.. and I suspect they
// wont mix very good.
/*
WaterTexture::WaterTexture()
:   super(Tile::water->tex),
	_tick(0),
	_frame(0)
{
}

void WaterTexture::tick() {
}
*/

WaterTexture::WaterTexture()
:   super(Tile::water->tex),
	_tick(0),
	_frame(0)
{
	current = new float[16*16];
	next = new float[16*16];
	heat = new float[16*16];
	heata = new float[16*16];

	for (int i = 0; i < 256; ++i) {
		current[i] = 0;
		next[i] = 0;
		heat[i] = 0;
		heata[i] = 0;
	}
}

WaterTexture::~WaterTexture() {
	delete[] current;
	delete[] next;
	delete[] heat;
	delete[] heata;
}

void WaterTexture::tick()
{
	for (int x = 0; x < 16; x++)
		for (int y = 0; y < 16; y++) {
			float pow = 0;
			for (int xx = x - 1; xx <= x + 1; xx++) {
				int xi = (xx) & 15;
				int yi = (y) & 15;
				pow += current[xi + yi * 16];
			}
			next[x + y * 16] = pow / 3.3f + heat[x + y * 16] * 0.8f;
		}

	for (int x = 0; x < 16; x++)
		for (int y = 0; y < 16; y++) {
			heat[x + y * 16] += heata[x + y * 16] * 0.05f;

			if (heat[x + y * 16] < 0) heat[x + y * 16] = 0;
			heata[x + y * 16] -= 0.1f;
			if (Mth::random() < 0.05f) {
				heata[x + y * 16] = 0.5f;
			}
		}

	float* tmp = next;
	next = current;
	current = tmp;

	for (int i = 0; i < 256; i++) {
		float pow = current[i];
		if (pow > 1) pow = 1;
		if (pow < 0) pow = 0;

		float pp = pow * pow;

		int r = (int) (32 + pp * 32);
		int g = (int) (50 + pp * 64);
		int b = (int) (255);
		int a = (int) (146 + pp * 50);

		//if (anaglyph3d) {
		//	int rr = (r * 30 + g * 59 + b * 11) / 100;
		//	int gg = (r * 30 + g * 70) / (100);
		//	int bb = (r * 30 + b * 70) / (100);

		//	r = rr;
		//	g = gg;
		//	b = bb;
		//}

		pixels[i * 4 + 0] = r;
		pixels[i * 4 + 1] = g;
		pixels[i * 4 + 2] = b;
		pixels[i * 4 + 3] = a;
	}
}

//
// WaterSideTexture
//
WaterSideTexture::WaterSideTexture()
:   super(Tile::water->tex + 1),
	_tick(0),
	_frame(0),
	_tickCount(0)
{
	replicate = 2;

	current = new float[16*16];
	next = new float[16*16];
	heat = new float[16*16];
	heata = new float[16*16];

	for (int i = 0; i < 256; ++i) {
		current[i] = 0;
		next[i] = 0;
		heat[i] = 0;
		heata[i] = 0;
	}
}

WaterSideTexture::~WaterSideTexture() {
	delete[] current;
	delete[] next;
	delete[] heat;
	delete[] heata;
}

void WaterSideTexture::tick() {
	++_tickCount;
	for (int x = 0; x < 16; x++)
		for (int y = 0; y < 16; y++) {
			float pow = 0;
			for (int xx = y - 2; xx <= y; xx++) {
				int xi = (x) & 15;
				int yi = (xx) & 15;
				pow += current[xi + yi * 16];
			}
			next[x + y * 16] = pow / 3.2f + heat[x + y * 16] * 0.8f;
		}

	for (int x = 0; x < 16; x++)
		for (int y = 0; y < 16; y++) {
			heat[x + y * 16] += heata[x + y * 16] * 0.05f;

			if (heat[x + y * 16] < 0) heat[x + y * 16] = 0;
			heata[x + y * 16] -= 0.3f;
			if (Mth::random() < 0.2) {
				heata[x + y * 16] = 0.5f;
			}
		}
	float* tmp = next;
	next = current;
	current = tmp;

	for (int i = 0; i < 256; i++) {
		float pow = current[(i - _tickCount * 16) & 255];
		if (pow > 1) pow = 1;
		if (pow < 0) pow = 0;

		float pp = pow * pow;

		int r = (int) (32 + pp * 32);
		int g = (int) (50 + pp * 64);
		int b = (int) (255);
		int a = (int) (146 + pp * 50);

		//if (anaglyph3d) {
		//	int rr = (r * 30 + g * 59 + b * 11) / 100;
		//	int gg = (r * 30 + g * 70) / (100);
		//	int bb = (r * 30 + b * 70) / (100);

		//	r = rr;
		//	g = gg;
		//	b = bb;
		//}

		pixels[i * 4 + 0] = r;
		pixels[i * 4 + 1] = g;
		pixels[i * 4 + 2] = b;
		pixels[i * 4 + 3] = a;
	}
}

//
//
FireTexture::FireTexture(int frame)
:	super(Tile::fire->tex + frame * 16)
{
	for (int i = 0; i < 16 * 20; ++i) current[i] = next[i] = 0;
}

static float fireRand() { return (float)rand() / (float)RAND_MAX; }

void FireTexture::tick() {
	for (int x = 0; x < 16; ++x) {
		for (int y = 0; y < 20; ++y) {
			int count = 18;
			float pow = current[x + ((y + 1) % 20) * 16] * count;
			for (int xx = x - 1; xx <= x + 1; ++xx) {
				for (int yy = y; yy <= y + 1; ++yy) {
					if (xx >= 0 && yy >= 0 && xx < 16 && yy < 20)
						pow += current[xx + yy * 16];
					++count;
				}
			}
			next[x + y * 16] = pow / (count * 1.06f);
			if (y >= 19)
				next[x + y * 16] = fireRand() * fireRand() * fireRand() * 4 + fireRand() * 0.1f + 0.2f;
		}
	}
	for (int i = 0; i < 16 * 20; ++i) {
		const float t = current[i]; current[i] = next[i]; next[i] = t;
	}
	for (int i = 0; i < 256; ++i) {
		float pp = current[i] * 1.8f;
		if (pp > 1) pp = 1;
		if (pp < 0) pp = 0;
		const int r = (int)(pp * 155 + 100);
		const int g = (int)(pp * pp * 255);
		const int b = (int)(pp * pp * pp * pp * pp * pp * pp * pp * pp * pp * 255);
		pixels[i * 4 + 0] = (unsigned char)r;
		pixels[i * 4 + 1] = (unsigned char)g;
		pixels[i * 4 + 2] = (unsigned char)b;
		pixels[i * 4 + 3] = pp < 0.5f ? 0 : 255;
	}
}

//
//
LavaTexture::LavaTexture()
:	LavaTexture(Tile::lava->tex)
{
}

LavaTexture::LavaTexture(int tex_)
:	super(tex_)
{
	for (int i = 0; i < 256; ++i)
		current[i] = next[i] = heat[i] = heata[i] = 0;

	for (int i = 0; i < 100; ++i)
		step();
}

void LavaTexture::step()
{
	for (int x = 0; x < 16; ++x) {
		for (int y = 0; y < 16; ++y) {
			float pow = 0;
			const int xo = (int) (Mth::sin(y * Mth::PI * 2.0f / 16.0f) * 1.2f);
			const int yo = (int) (Mth::sin(x * Mth::PI * 2.0f / 16.0f) * 1.2f);
			for (int xx = x - 1; xx <= x + 1; ++xx)
				for (int yy = y - 1; yy <= y + 1; ++yy)
					pow += current[((xx + xo) & 15) + ((yy + yo) & 15) * 16];

			const int i = x + y * 16;
			next[i] = pow / 10.0f
			        + (heat[i]
			         + heat[((x + 1) & 15) + y * 16]
			         + heat[((x + 1) & 15) + ((y + 1) & 15) * 16]
			         + heat[x + ((y + 1) & 15) * 16]) / 4.0f * 0.8f;

			heat[i] += heata[i] * 0.01f;
			if (heat[i] < 0) heat[i] = 0;
			heata[i] -= 0.06f;
			if (Mth::random() < 0.005f) {
				heata[i] = 1.5f;
			}
		}
	}

	for (int i = 0; i < 256; ++i) {
		const float t = current[i]; current[i] = next[i]; next[i] = t;
	}
}

void LavaTexture::writePixels(int shift)
{
	for (int i = 0; i < 256; ++i) {
		float pow = current[(i - shift) & 255] * 2.0f;
		if (pow > 1) pow = 1;
		if (pow < 0) pow = 0;

		const int r = (int) (pow * 100 + 155);
		const int g = (int) (pow * pow * 255);
		const int b = (int) (pow * pow * pow * pow * 128);

		pixels[i * 4 + 0] = (unsigned char)r;
		pixels[i * 4 + 1] = (unsigned char)g;
		pixels[i * 4 + 2] = (unsigned char)b;
		pixels[i * 4 + 3] = 255;
	}
}

void LavaTexture::tick()
{
	step();
	writePixels(0);
}

//
//
LavaSideTexture::LavaSideTexture()
:	super(Tile::lava->tex + 1),
	_tickCount(0)
{
	replicate = 2;
}

void LavaSideTexture::tick()
{
	if (++_tickCount >= 48) _tickCount = 0;
	step();
	writePixels(_tickCount / 3 * 16);
}
