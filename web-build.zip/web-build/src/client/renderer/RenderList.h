#ifndef NET_MINECRAFT_CLIENT_RENDERER__RenderList_H__
#define NET_MINECRAFT_CLIENT_RENDERER__RenderList_H__

//package net.minecraft.client.renderer;

class RenderChunk;

class RenderList
{
	static const int START_NUM_OBJECTS = 1024 * 3;

public:
	RenderList();
	~RenderList();

    void init(double xOff, double yOff, double zOff);

	void add(int list);
	void addR(const RenderChunk& chunk);

	__inline void next() { ++listIndex; }

    void render();
	void renderChunks();

    void clear();


	double xOff, yOff, zOff;
	int* lists;
	RenderChunk* rlists;

	int listIndex;
	bool inited;
	bool rendered;

private:
	void ensure(int n);

	int capacity;
	int bufferLimit;
};

#endif /*NET_MINECRAFT_CLIENT_RENDERER__RenderList_H__*/
