#ifndef NET_MINECRAFT_CLIENT_RENDERER__Tesselator_H__
#define NET_MINECRAFT_CLIENT_RENDERER__Tesselator_H__

//package net.minecraft.client.renderer;

#include <map>
#include "RenderChunk.h"
#include "gles.h"
#include "VertecDecl.h"

extern const int VertexSizeBytes;

typedef VertexDeclPTC VERTEX;
typedef std::map<GLuint, GLsizei> IntGLMap;


class Tesselator
{
    static const int MAX_MEMORY_USE = 16 * 1024 * 1024;
    static const int MAX_FLOATS = MAX_MEMORY_USE / 4 / 2;

	Tesselator(int size);

public:
	static const int ACCESS_DYNAMIC = 1;
	static const int ACCESS_STATIC = 2;

	static Tesselator instance;

	static Tesselator& forThread();
	static void bindToThisThread(Tesselator* t);
	static Tesselator* createForWorker();

	~Tesselator();

	void init();
    void clear();

    void begin();
    void begin(int mode);
	void draw();
	bool drawAgain();
	RenderChunk end(bool useMine, int bufferId);

	int endRaw(const VERTEX*& out);
	const unsigned short* lightArray() const { return _lit ? _larray : 0; }
	const unsigned short* blockArray() const { return _blk ? _barray : 0; }

	void color(int c);
	void color(int c, int alpha);
    void color(float r, float g, float b);
    void color(float r, float g, float b, float a);
    void color(int r, int g, int b);
    void color(int r, int g, int b, int a);
    void color(char r, char g, char b);
	void colorABGR( int c );

	void normal(float x, float y, float z);
	void bakeNormals() { _bakeNormals = true; }
	void voidBeginAndEndCalls(bool doVoid);
	
	void tex(float u, float v);
    
	void vertex(float x, float y, float z);
	void vertexUV(float x, float y, float z, float u, float v);
	
	void scale2d(float x, float y);
	void resetScale();

    void noColor();
	void enableColor();
private:
	void setAccessMode(int mode);
public:

    void offset(float xo, float yo, float zo);
	void getOffset(float& x, float& y, float& z) const { x = xo; y = yo; z = zo; }
	void offset(const Vec3& v);
    void addOffset(float x, float y, float z);
	void addOffset(const Vec3& v);

	int getVboCount();

	int getColor();

	__inline void beginOverride() {
		begin();
		voidBeginAndEndCalls(true);
	}
	__inline void endOverrideAndDraw() {
		voidBeginAndEndCalls(false);
		draw();
	}
	__inline bool isOverridden() {
		return _voidBeginEnd;
	}
	__inline RenderChunk endOverride(int bufferId) {
		voidBeginAndEndCalls(false);
		return end(true, bufferId);
	}

private:
	Tesselator(const Tesselator& rhs) {}
	Tesselator& operator=(const Tesselator& rhs) { return *this; }
	VERTEX* _varray;
	unsigned short* _larray;
	bool _lit;
	unsigned short* _barray;
	bool _blk;

	int vertices;

	float xo, yo, zo;
	float u, v;
	unsigned int _color;
	int _normal;
	float _sx, _sy;

	bool hasColor;
	bool hasTexture;
	bool hasNormal;
	bool _noColor;
	bool _voidBeginEnd;
	bool _bakeNormals;

	int p;
	int count;

	bool tesselating;

	bool vboMode;
	int vboCounts;
	int vboId;
	GLuint* vboIds;

	int size;
	int totalSize;
	int maxVertices;

	int mode;
	int accessMode;

	GLuint _againBuffer;
	int _againVertices;
	unsigned int _againMode;
	int _againFlags;

	IntGLMap map;
};

#endif /*NET_MINECRAFT_CLIENT_RENDERER__Tesselator_H__*/
