#include "MobRenderer.h"
#include "EntityRenderDispatcher.h"
#include "../../gui/Font.h"
#include "../Tesselator.h"
#include "../../Minecraft.h"
#include "../../model/Model.h"
#include "../../../world/entity/Mob.h"
#include "../../../world/effect/MobEffect.h"
#include "../../../util/Mth.h"

MobRenderer::MobRenderer(Model* model, float shadow)
:	model(model),
	armor(NULL),
	tagAlpha(1.0f),
	tagIcon(0)
{
	shadowRadius = shadow;
}

MobRenderer::~MobRenderer() {
	delete model;
}

void MobRenderer::setArmor(Model* armor) {
	this->armor = armor;
}

Model* MobRenderer::getArmor() {
	return armor;
}

void MobRenderer::render(Entity* e, float x, float y, float z, float rot, float a)
{
	Mob* mob = (Mob*) e;
	const bool bodyHidden = mob->effects.has(MobEffect::INVISIBILITY);

	glPushMatrix2();
	glDisable2(GL_CULL_FACE);

	model->attackTime = getAttackAnim(mob, a);
	model->riding = mob->isRiding();
	model->young = mob->isBaby();

	if (armor) {
		armor->riding = model->riding;
		armor->young  = model->young;
		armor->attackTime = model->attackTime;
	}

	float bodyRot = (mob->yBodyRotO + (mob->yBodyRot - mob->yBodyRotO) * a);
	float headRot = (mob->yRotO + (mob->yRot - mob->yRotO) * a);
	float headRotx = (mob->xRotO + (mob->xRot - mob->xRotO) * a);

	float yoffset = mob->heightOffset;
	setupPosition(mob, x, y - yoffset, z);

	float bob = getBob(mob, a);
	setupRotations(mob, bob, bodyRot, a);

	float ascale = 1 / 16.0f;
	glScalef2(-1, -1, 1);

	scale(mob, a);
	glTranslatef2(0, -24 * ascale - 0.125f / 16.0f, 0);

	float ws = mob->walkAnimSpeedO + (mob->walkAnimSpeed - mob->walkAnimSpeedO) * a;
	float wp = mob->walkAnimPos - mob->walkAnimSpeed * (1 - a);
	if (mob->isBaby()) {
		wp *= 3.0f;
	}

	if (ws > 1) ws = 1;

	bindTexture(mob->getTexture());
	//glEnable2(GL_ALPHA_TEST);

	const float fade = renderAlpha(mob);
	if (fade < 1.0f) {
		const float br = mob->getBrightness(a);
		glEnable2(GL_BLEND);
		glBlendFunc2(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
		glColor4f2(br, br, br, fade);
	}

	model->prepareMobModel(mob, wp, ws, a);
	if (bodyHidden) model->setupAnim(wp, ws, bob, headRot - bodyRot, headRotx, ascale); else model->render(e, wp, ws, bob, headRot - bodyRot, headRotx, ascale);

	for (int i = 0; i < MAX_ARMOR_LAYERS; i++) {
		if (prepareArmor(mob, i, a) < 0) continue;

		armor->prepareMobModel(mob, wp, ws, a);
		armor->render(e, wp, ws, bob, headRot - bodyRot, headRotx, ascale);
		glDisable2(GL_BLEND);
		glEnable2(GL_ALPHA_TEST);
		if (fade < 1.0f) { glEnable2(GL_BLEND); glBlendFunc2(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA); }
	}

	additionalRendering(mob, a);
	if (fade < 1.0f) {
		glDisable2(GL_BLEND);
		const float br0 = mob->getBrightness(a);
		glColor4f2(br0, br0, br0, 1);
	}
	float br = mob->getBrightness(a);
	int overlayColor = getOverlayColor(mob, br, a);

	bool renderOverlay = ((overlayColor >> 24) & 0xff) > 0;
	bool renderHurt = (mob->hurtTime > 0) || (mob->deathTime > 0);

	if (renderOverlay || renderHurt) {
		glDisable2(GL_TEXTURE_2D);
		glDisable2(GL_ALPHA_TEST);
		glEnable2(GL_BLEND);
		glBlendFunc2(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
		glDepthFunc(GL_EQUAL);

		if (renderHurt) {
			glEnable(GL_COLOR_MATERIAL);
			glColor4f2(br, 0, 0, 0.4f);
			if (bodyHidden) model->setupAnim(wp, ws, bob, headRot - bodyRot, headRotx, ascale); else model->render(e, wp, ws, bob, headRot - bodyRot, headRotx, ascale);
			for (int i = 0; i < MAX_ARMOR_LAYERS; i++) {
				if (prepareArmor(mob, i, a) < 0) continue;

				glColor4f2(br, 0, 0, 0.4f);
				armor->prepareMobModel(mob, wp, ws, a);
				armor->render(e, wp, ws, bob, headRot - bodyRot, headRotx, ascale);
			}
		}

		if (renderOverlay) {
			float r = ((overlayColor >> 16) & 0xff) / 255.0f;
			float g = ((overlayColor >> 8) & 0xff) / 255.0f;
			float b = ((overlayColor) & 0xff) / 255.0f;
			float aa = ((overlayColor >> 24) & 0xff) / 255.0f;
			glColor4f2(r, g, b, aa);
			if (bodyHidden) model->setupAnim(wp, ws, bob, headRot - bodyRot, headRotx, ascale); else model->render(e, wp, ws, bob, headRot - bodyRot, headRotx, ascale);
			for (int i = 0; i < MAX_ARMOR_LAYERS; i++) {
				if (prepareArmor(mob, i, a) < 0) continue;

				glColor4f2(r, g, b, aa);
				armor->prepareMobModel(mob, wp, ws, a);
				armor->render(e, wp, ws, bob, headRot - bodyRot, headRotx, ascale);
			}
		}

		glDepthFunc(GL_LEQUAL);
		glDisable2(GL_BLEND);
		glEnable2(GL_ALPHA_TEST);
		glEnable2(GL_TEXTURE_2D);
	}

	glEnable2(GL_CULL_FACE);
	//glEnable2(GL_DEPTH_TEST);

	glPopMatrix2();

	renderName(mob, x, y, z);
}

void MobRenderer::setupPosition(Entity* mob, float x, float y, float z) {
	glTranslatef2((float) x, (float) y, (float) z);
}

void MobRenderer::setupRotations(Entity* mob_, float bob, float bodyRot, float a) {
	glRotatef2(180 - bodyRot, 0, 1, 0);

	Mob* mob = (Mob*)mob_;
	if (mob->deathTime > 0) {
		float fall = (mob->deathTime + a - 1) / 20.0f * 1.6f;
		fall = Mth::sqrt(fall);
		if (fall > 1) fall = 1;
		glRotatef2(fall * getFlipDegrees(mob), 0, 0, 1);
	}
}

float MobRenderer::getAttackAnim(Mob* mob, float a) {
	return mob->getAttackAnim(a);
}

float MobRenderer::getBob(Mob* mob, float a) {
	return (mob->tickCount + a);
}

void MobRenderer::additionalRendering(Mob* mob, float a) {
}

void MobRenderer::onGraphicsReset() {
	if (model) model->onGraphicsReset();
	if (armor) armor->onGraphicsReset();
}

int MobRenderer::prepareArmor(Mob* mob, int layer, float a) {
	return -1;
}

float MobRenderer::getFlipDegrees(Mob* mob) {
	return 90;
}

int MobRenderer::getOverlayColor(Mob* mob, float br, float a) {
	return 0;
}

void MobRenderer::scale(Mob* mob, float a) {
}

void MobRenderer::renderName(Mob* mob, float x, float y, float z) {
	/*
	std::stringstream ss; ss << mob->entityId;
	renderNameTag(mob, ss.str(), x, y, z, 64);
	*/
}

void MobRenderer::renderTagIcon(float x0, float alpha) {
	static const char* const PC[7] = {
		"#########",
		"#.......#",
		"#.......#",
		"#.......#",
		"#########",
		"....#....",
		"..#####..",
	};
	static const char* const PHONE[8] = {
		"#####",
		"#...#",
		"#...#",
		"#...#",
		"#...#",
		"#####",
		"#.#.#",
		"#####",
	};
	const char* const* rows = tagIcon == 1 ? PC : PHONE;
	const int n = tagIcon == 1 ? 7 : 8;
	const float y0 = tagIcon == 1 ? 0.5f : 0.0f;
	Tesselator& t = Tesselator::instance;
	t.begin();
	t.color(0.85f, 0.85f, 0.85f, alpha);
	for (int r = 0; r < n; ++r)
		for (int c = 0; rows[r][c]; ++c) {
			if (rows[r][c] != '#') continue;
			const float x = x0 + c, y = y0 + r;
			t.vertex(x, y, 0);
			t.vertex(x, y + 1, 0);
			t.vertex(x + 1, y + 1, 0);
			t.vertex(x + 1, y, 0);
		}
	t.draw();
}

void MobRenderer::renderNameTag(Mob* mob, const std::string& name, float x, float y, float z, int maxDist) {
	float dist = mob->distanceToSqr(entityRenderDispatcher->cameraEntity);

	if (dist > maxDist*maxDist)
		return;

	Font* font = getFont();

	float size = 1.60f;
	float s = 1 / 60.0f * size;

	glPushMatrix2();
	glTranslatef2((float) x + 0, (float) y + 1.0f /*2.3f*/, (float) z);

	glRotatef2(-entityRenderDispatcher->playerRotY, 0, 1, 0);
	glRotatef2(entityRenderDispatcher->playerRotX, 1, 0, 0);

	glScalef2(-s, -s, s);

	glDepthMask(false);
	glDisable2(GL_DEPTH_TEST);
	glEnable2(GL_BLEND);
	glBlendFunc2(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
	Tesselator& t = Tesselator::instance;

	glDisable2(GL_TEXTURE_2D);
	t.begin();
	const int iconW = tagIcon == 1 ? 9 : tagIcon == 2 ? 5 : 0;
	const int iconGap = iconW ? 2 : 0;
	const int textW = font->width(name);
	const int total = iconW + iconGap + textW;
	int w = total / 2;
	const float ta = tagAlpha < 0 ? 0 : tagAlpha > 1 ? 1 : tagAlpha;
	t.color(0.0f, 0.0f, 0.0f, 0.25f * ta);
	t.vertex(-(float)w - 1, -1, 0);
	t.vertex(-(float)w - 1, +8, 0);
	t.vertex(+(float)(total - w) + 1, +8, 0);
	t.vertex(+(float)(total - w) + 1, -1, 0);
	//t.end();
	t.draw();
	if (iconW) renderTagIcon(-(float)w, ta * 0.125f);
	glEnable2(GL_TEXTURE_2D);
	const float fnameWidth = (float)(-w + iconW + iconGap);
	const int A = (int)(ta * 255.0f);
	font->draw(name, fnameWidth, 0, ((A * 0x20 / 255) << 24) | 0xffffff);
	glEnable2(GL_DEPTH_TEST);

	glDepthMask(true);
	if (iconW) { glDisable2(GL_TEXTURE_2D); renderTagIcon(-(float)w, ta); glEnable2(GL_TEXTURE_2D); }
	font->draw(name, (float) fnameWidth, 0, (A << 24) | 0xffffff);
	glDisable2(GL_BLEND);
	glColor4f2(1, 1, 1, 1);
	glPopMatrix2();
}
