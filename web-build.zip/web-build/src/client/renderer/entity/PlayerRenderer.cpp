#include "PlayerRenderer.h"
#include "EntityRenderDispatcher.h"
#include "../../../world/entity/player/Player.h"
#include "../../../world/level/Level.h"
#include "../../../world/item/ArmorItem.h"
#include "../../model/HumanoidModel.h"
#include "../gles.h"
#include "../tileentity/SkullRenderer.h"
#include "../../../world/WoodContent.h"
#include "../../../util/Mth.h"
#ifdef EMSCRIPTEN
#include "../../WebSkin.h"
#endif

static const std::string armorFilenames[10] = {
	"armor/cloth_1.png",	"armor/cloth_2.png",
	"armor/chain_1.png",	"armor/chain_2.png",
	"armor/iron_1.png",		"armor/iron_2.png",
	"armor/diamond_1.png",	"armor/diamond_2.png",
	"armor/gold_1.png",		"armor/gold_2.png",
};

PlayerRenderer::PlayerRenderer( HumanoidModel* humanoidModel, float shadow )
:	super(humanoidModel, shadow),
	armorParts1(new HumanoidModel(1.0f)),
	armorParts2(new HumanoidModel(0.5f))
{
}

PlayerRenderer::~PlayerRenderer() {
	delete armorParts1;
	delete armorParts2;
}

void PlayerRenderer::setupPosition( Entity* mob, float x, float y, float z ) {
	Player* player = (Player*) mob;
	if(player->isAlive() && player->isSleeping()) {
		return super::setupPosition(mob, x + player->bedOffsetX, y + player->bedOffsetY, z + player->bedOffsetZ);
	}
	return super::setupPosition(mob, x, y, z);
}

void PlayerRenderer::setupRotations( Entity* mob, float bob, float bodyRot, float a ) {
	Player* player = (Player*) mob;
	if(player->isAlive() && player->isSleeping()) {
		glRotatef(player->getSleepRotation(), 0, 1, 0);
		glRotatef(getFlipDegrees(player), 0, 0, 1);
		glRotatef(270, 0, 1, 0);
		return;
	}
	super::setupRotations(mob, bob, bodyRot, a);
}

void PlayerRenderer::renderName( Mob* mob, float x, float y, float z ){
	//@todo: figure out how to handle HideGUI
	if (mob != entityRenderDispatcher->cameraEntity && mob->level->adventureSettings.showNameTags) {
		renderNameTag(mob, ((Player*)mob)->name, x, y, z, 32);
	}
}

int PlayerRenderer::prepareArmor(Mob* mob, int layer, float a) {
	Player* player = (Player*) mob;

	ItemInstance* itemInstance = player->getArmor(layer);
	if (!ItemInstance::isArmorItem(itemInstance))
		return -1;

	ArmorItem* armorItem = (ArmorItem*) itemInstance->getItem();
	int fnIndex = (armorItem->modelIndex + armorItem->modelIndex) + (layer == 2 ? 1 : 0);
	bindTexture(armorFilenames[fnIndex]);

	HumanoidModel* armor = layer == 2 ? armorParts2 : armorParts1;

	armor->head.visible = layer == 0;
	//armor.hair.visible = layer == 0;
	armor->body.visible = layer == 1 || layer == 2;
	armor->arm0.visible = layer == 1;
	armor->arm1.visible = layer == 1;
	armor->leg0.visible = layer == 2 || layer == 3;
	armor->leg1.visible = layer == 2 || layer == 3;

	setArmor(armor);

	/*if (itemInstance.isEnchanted())
		return 15; */

	return 1;
}

void PlayerRenderer::additionalRendering(Mob* mob, float a) {
#ifdef EMSCRIPTEN
	if (mob == WebSkin::localPlayer && humanoidModel) {
		Player* p = (Player*) mob;
		HumanoidModel* m = humanoidModel;
		const float s = 1 / 16.0f;
		if (!WebSkin::skinTexture.empty()) {
			bindTexture(WebSkin::skinTexture);
			glEnable2(GL_ALPHA_TEST);
			m->hair.x = m->head.x; m->hair.y = m->head.y; m->hair.z = m->head.z;
			m->hair.xRot = m->head.xRot; m->hair.yRot = m->head.yRot; m->hair.zRot = m->head.zRot;
			m->hair.render(s);
		}
		if (!WebSkin::capeTexture.empty() && !p->isSleeping()) {
			bindTexture(WebSkin::capeTexture);
			glPushMatrix2();
			glTranslatef2(0, 0, 2 / 16.0f);
			const float vx = p->x - p->xo, vy = p->y - p->yo, vz = p->z - p->zo;
			const float xd = -3 * vx, yd = -3 * vy, zd = -3 * vz;
			const float yr = p->yBodyRotO + (p->yBodyRot - p->yBodyRotO) * a;
			const float xa = Mth::sin(yr * Mth::PI / 180), za = -Mth::cos(yr * Mth::PI / 180);
			float flap = yd * 10;
			if (flap < -6) flap = -6;
			if (flap > 32) flap = 32;
			float lean = (xd * xa + zd * za) * 100;
			const float lean2 = (xd * za - zd * xa) * 100;
			if (lean < 0) lean = 0;
			const float pow = p->oBob + (p->bob - p->oBob) * a;
			flap += Mth::sin((p->walkDistO + (p->walkDist - p->walkDistO) * a) * 6) * 32 * pow;
			if (p->isSneaking()) flap += 25;
			glRotatef2(6 + lean / 2 + flap, 1, 0, 0);
			glRotatef2(lean2 / 2, 0, 0, 1);
			glRotatef2(-lean2 / 2, 0, 1, 0);
			glRotatef2(180, 0, 1, 0);
			m->cloak.render(s);
			glPopMatrix2();
		}
	}
#endif
	{
		const int skull = WoodContent::wornSkullType(((Player*) mob)->getArmor(0));
		if (skull >= 0 && humanoidModel)
			SkullRenderer::drawOnHead(entityRenderDispatcher->textures, humanoidModel, skull);
	}
	super::additionalRendering(mob, a);
}

void PlayerRenderer::onGraphicsReset() {
	super::onGraphicsReset();

	if (armorParts1) armorParts1->onGraphicsReset();
	if (armorParts2) armorParts2->onGraphicsReset();
}
