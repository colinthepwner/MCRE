#include "HumanoidMobRenderer.h"
#include "EntityRenderDispatcher.h"
#include "../ItemInHandRenderer.h"
#include "../TileRenderer.h"
#include "../EntityLighting.h"
#include "../../model/HumanoidModel.h"
#include "../../../world/level/tile/Tile.h"
#include "../../../world/entity/player/Player.h"
#include "../../player/LocalPlayer.h"
#include "../../../world/entity/player/Inventory.h"
#include "../../../world/item/ItemInstance.h"
#include "../../../world/item/Item.h"
#include "../../../world/item/BowItem.h"
#include "../../../world/item/ArmorItem.h"
#include "../../../world/ModTraits.h"
#include "../../../world/ModContent.h"

static const std::string mobArmorFilenames[10] = {
	"armor/cloth_1.png",	"armor/cloth_2.png",
	"armor/chain_1.png",	"armor/chain_2.png",
	"armor/iron_1.png",		"armor/iron_2.png",
	"armor/diamond_1.png",	"armor/diamond_2.png",
	"armor/gold_1.png",		"armor/gold_2.png",
};

HumanoidMobRenderer::HumanoidMobRenderer(HumanoidModel* humanoidModel, float shadow)
:	super(humanoidModel, shadow),
	humanoidModel(humanoidModel),
	mobArmor1(NULL),
	mobArmor2(NULL)
{
}

HumanoidMobRenderer::~HumanoidMobRenderer() {
	delete mobArmor1;
	delete mobArmor2;
}

int HumanoidMobRenderer::prepareArmor(Mob* mob, int layer, float a) {
	if (!ModTraits::any()) return -1;
	ItemInstance* piece = ModTraits::gearSlot(mob, layer == 0 ? 1 : layer == 1 ? 2 : layer == 2 ? 3 : 4);
	if (!ItemInstance::isArmorItem(piece)) return -1;

	ArmorItem* armorItem = (ArmorItem*) piece->getItem();
	const int fnIndex = (armorItem->modelIndex + armorItem->modelIndex) + (layer == 2 ? 1 : 0);
	const std::string modTex = ModContent::armorTexture(piece->id, layer == 2);
	bindTexture(modTex.empty() ? mobArmorFilenames[fnIndex] : modTex);

	if (!mobArmor1) mobArmor1 = new HumanoidModel(1.0f);
	if (!mobArmor2) mobArmor2 = new HumanoidModel(0.5f);
	HumanoidModel* armor = layer == 2 ? mobArmor2 : mobArmor1;

	armor->head.visible = layer == 0;
	armor->body.visible = layer == 1 || layer == 2;
	armor->arm0.visible = layer == 1;
	armor->arm1.visible = layer == 1;
	armor->leg0.visible = layer == 2 || layer == 3;
	armor->leg1.visible = layer == 2 || layer == 3;

	setArmor(armor);
	return 1;
}

void HumanoidMobRenderer::renderHand() {
	humanoidModel->attackTime = 0;
	humanoidModel->sneaking = false;
	humanoidModel->setupAnim(0, 0, 0, 0, 0, 1 / 16.0f);

	//@attn @cuberender @enableClientState @vertexarray
	glEnableClientState2(GL_VERTEX_ARRAY);
	glEnableClientState2(GL_TEXTURE_COORD_ARRAY);
	//glEnableClientState2(GL_COLOR_ARRAY); 
	humanoidModel->arm0.render(1 / 16.0f);
	glDisableClientState2(GL_VERTEX_ARRAY);
	glDisableClientState2(GL_TEXTURE_COORD_ARRAY);
	//glDisableClientState2(GL_COLOR_ARRAY); 
}

void HumanoidMobRenderer::additionalRendering(Mob* mob, float a) {
	ItemInstance* item = mob->getCarriedItem();
	if (item != NULL && item->count > 0) {
		glPushMatrix2();
		humanoidModel->arm0.translateTo(1 / 16.0f);
		glTranslatef2(-1.0f / 16.0f, 7.0f / 16.0f, 1.0f / 16.0f);

		if (item->id < 256 && TileRenderer::canRender(Tile::tiles[item->id]->getRenderShape())) {
			float s = 8.0f / 16.0f;
			glTranslatef2(0.0f, 3.0f / 16.0f, -5 / 16.0f);
			s *= 0.75f;
			glRotatef2(20.0f, 1.0f, 0.0f, 0.0f);
			glRotatef2(45.0f, 0.0f, 1.0f, 0.0f);
			glScalef2(s, -s, s);
		} else if (item->id == Item::bow->id) {
			const float s = 10.0f / 16.0f;
			glTranslatef2(0 / 16.0f, 2 / 16.0f, 5 / 16.0f);
			glRotatef2(-20, 0, 1, 0);
			glScalef2(s, -s, s);
			glRotatef2(-100, 1, 0, 0);
			glRotatef2(45, 0, 1, 0);
		} else if (Item::items[item->id]->isHandEquipped()) {
			float s = 10.0f / 16.0f;
			glTranslatef2(0.0f, 3.0f / 16.0f, 0.0f);
			glScalef2(s, -s, s);
			glRotatef2(-100.0f, 1.0f, 0.0f, 0.0f);
			glRotatef2(45.0f, 0.0f, 1.0f, 0.0f);
		} else {
			float s = 6 / 16.0f;
			glTranslatef2(+4 / 16.0f, +3 / 16.0f, -3 / 16.0f);
			glScalef2(s, s, s);
			glRotatef2(60.0f, 0.0f, 0.0f, 1.0f);
			glRotatef2(-90.0f, 1.0f, 0.0f, 0.0f);
			glRotatef2(20.0f, 0.0f, 0.0f, 1.0f);
		}
		entityRenderDispatcher->itemInHandRenderer->renderItem(mob, item, EntityLighting::brightnessOf(mob, a));
		glPopMatrix2();
	}
}

void HumanoidMobRenderer::render( Entity* mob_, float x, float y, float z, float rot, float a ) {
	Mob* mob = (Mob*)mob_;
	ItemInstance* carriedItem = mob->getCarriedItem();
	if(carriedItem != NULL)
		humanoidModel->holdingRightHand = true;

	humanoidModel->sneaking = mob->isSneaking();
	if (humanoidModel->sneaking && mob->isPlayer() && dynamic_cast<LocalPlayer*>(mob) == NULL)
		y -= 0.125f;

	super::render(mob_, x, y, z, rot, a);
	humanoidModel->holdingRightHand = false;
}
