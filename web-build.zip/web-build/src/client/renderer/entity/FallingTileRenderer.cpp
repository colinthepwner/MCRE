#include "FallingTileRenderer.h"
#include "../TileRenderer.h"
#include "../../../world/entity/item/FallingTile.h"
#include "../../../world/level/tile/Tile.h"
#include "../../../world/level/Level.h"
#include "../../../world/level/tile/EnchantBrewTiles.h"
#include "../../../world/level/tile/EndTiles.h"

FallingTileRenderer::FallingTileRenderer() {
    this->shadowRadius = 0.5f;
    tileRenderer = new TileRenderer();
}

FallingTileRenderer::~FallingTileRenderer() {
    delete tileRenderer;
}

void FallingTileRenderer::render( Entity* e, float x, float y, float z, float rot, float a ) {
    FallingTile* tile = (FallingTile*) e;

    glPushMatrix();
    glTranslatef(x, y, z);

    bindTexture("terrain.png");
    Tile* tt = Tile::tiles[tile->tile];

    Level* level = tile->getLevel();

    if (tt != NULL && endIsOwnShape(tt->getRenderShape())) {
        tileRenderer->renderFallingEnd(tt, tile->data, tile->getBrightness(a));
    } else
    if (tt != NULL && tt->getRenderShape() == AnvilTile::SHAPE) {
        tileRenderer->renderFallingEnchantBrew(tt, tile->data, tile->getBrightness(a));
    } else if (tt != NULL) {
        tileRenderer->renderBlock(tt, level, Mth::floor(tile->x), Mth::floor(tile->y), Mth::floor(tile->z), tile->data);

    }
    glPopMatrix();
}
