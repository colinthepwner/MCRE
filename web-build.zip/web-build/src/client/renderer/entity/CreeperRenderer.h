#ifndef NET_MINECRAFT_CLIENT_RENDERER_ENTITY__CreeperRenderer_H__
#define NET_MINECRAFT_CLIENT_RENDERER_ENTITY__CreeperRenderer_H__

//package net.minecraft.client.renderer.entity;

#include "MobRenderer.h"

#include "../../model/CreeperModel.h"
#include "../../model/Model.h"
#include "../../../world/entity/monster/Creeper.h"
#include "../../../util/Mth.h"

class CreeperRenderer: public MobRenderer
{
	typedef MobRenderer super;
public:
    CreeperRenderer()
	:	super(new CreeperModel(), 0.5f), armorModel(NULL)
	{
    }
	~CreeperRenderer() { delete armorModel; }

protected:
    void scale(Mob* mob, float a) {
        Creeper* creeper = (Creeper*) mob;

        float g = creeper->getSwelling(a);

        float wobble = 1.0f + Mth::sin(g * 100) * g * 0.01f;
        if (g < 0) g = 0;
        if (g > 1) g = 1;
        g = g * g;
        g = g * g;
        float s = (1.0f + g * 0.4f) * wobble;
        float hs = (1.0f + g * 0.1f) / wobble;
        glScalef(s, hs, s);
    }

    int getOverlayColor(Mob* mob, float br, float a) {
        Creeper* creeper = (Creeper*) mob;

        float step = creeper->getSwelling(a);

        if ((int) (step * 10) % 2 == 0) return 0;

        int _a = (int) (step * 0.2f * 255);
        if (_a < 0) _a = 0;
        if (_a > 255) _a = 255;

        int r = 255;
        int g = 255;
        int b = 255;

        return (_a << 24) | (r << 16) | (g << 8) | b;
    }

	int prepareArmor(Mob* mob, int layer, float a) {
		if (!((Creeper*) mob)->isPowered()) return -1;
		if (layer == 1) {
			if (!armorModel) armorModel = new CreeperModel(2);
			const float time = mob->tickCount + a;
			bindTexture("armor/power.png");
			glMatrixMode(GL_TEXTURE);
			glLoadIdentity();
			glTranslatef(time * 0.01f, time * 0.01f, 0);
			setArmor(armorModel);
			glMatrixMode(GL_MODELVIEW);
			glEnable2(GL_BLEND);
			glColor4f2(0.5f, 0.5f, 0.5f, 1);
			glBlendFunc2(GL_ONE, GL_ONE);
			return 1;
		}
		if (layer == 2) {
			glMatrixMode(GL_TEXTURE);
			glLoadIdentity();
			glMatrixMode(GL_MODELVIEW);
			glDisable2(GL_BLEND);
		}
		return -1;
	}
private:
	Model* armorModel;
};

#endif /*NET_MINECRAFT_CLIENT_RENDERER_ENTITY__CreeperRenderer_H__*/
