#ifndef NET_MINECRAFT_CLIENT_RENDERER_ENTITY__HumanoidMobRenderer_H__
#define NET_MINECRAFT_CLIENT_RENDERER_ENTITY__HumanoidMobRenderer_H__

//package net.minecraft.client.renderer.entity;

#include "MobRenderer.h"

class HumanoidModel;
class Mob;

class HumanoidMobRenderer: public MobRenderer
{
	typedef MobRenderer super;
public:
    HumanoidMobRenderer(HumanoidModel* humanoidModel, float shadow);
	~HumanoidMobRenderer();

	void renderHand();
	void render(Entity* mob_, float x, float y, float z, float rot, float a);
	virtual int prepareArmor(Mob* mob, int layer, float a);
protected:
    void additionalRendering(Mob* mob, float a);

	HumanoidModel* humanoidModel;
private:
	HumanoidModel* mobArmor1;
	HumanoidModel* mobArmor2;
};

#endif /*NET_MINECRAFT_CLIENT_RENDERER_ENTITY__HumanoidMobRenderer_H__*/
