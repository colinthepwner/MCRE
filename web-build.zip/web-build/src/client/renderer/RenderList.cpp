#include "RenderList.h"
#include <cstring>

#include "gles.h"
#include "RenderChunk.h"
#include "Tesselator.h"

#ifdef __EMSCRIPTEN__
#include <emscripten.h>
#include <vector>

EM_JS(int, mcFastChunkDraws, (const void* recs, int n, int stride), {
	var drawn = 0;
	var r = null;
	var vaoBound = false;
	var lastVbo = 0;
	try {
		if (Module.mcFastChunkError || typeof GLImmediate === 'undefined' || !GLImmediate.getRenderer || !GLImmediate.matrixLib || GL.currProgram) return 0;
		r = GLImmediate.getRenderer();
		if (!r || !r.program || !r.modelViewLocation || r.hasNormal || r.hasLighting || r.hasClipPlane || typeof r.cleanup !== 'function') { r = null; return 0; }
		var pos = r.positionLocation;
		var tex = (r.hasTextures && r.texCoordLocations && r.texCoordLocations[0] >= 0) ? r.texCoordLocations[0] : -1;
		var col = (GLImmediate.enabledClientAttributes[GLImmediate.COLOR] && r.colorLocation >= 0) ? r.colorLocation : -1;
		if (!(pos >= 0)) { r = null; return 0; }
		var mat4 = GLImmediate.matrixLib.mat4;
		var base = GLImmediate.matrix[0];
		var m = Module.mcChunkMatrix || (Module.mcChunkMatrix = new Float32Array(16));
		var v = Module.mcChunkOffset || (Module.mcChunkOffset = [0, 0, 0]);
		GLctx.useProgram(r.program);
		GLImmediate.fixedFunctionProgram = r.program;
		GLctx.enableVertexAttribArray(pos);
		if (tex >= 0) GLctx.enableVertexAttribArray(tex);
		if (col >= 0) GLctx.enableVertexAttribArray(col);
		var p = recs >> 2;
		lastVbo = GLctx.currentArrayBufferBinding;
		if (GLctx.createVertexArray && !Module.mcChunkNoVao) {
			var layouts = Module.mcChunkVaos || (Module.mcChunkVaos = {});
			var lkey = pos + 16 * (tex + 1) + 256 * (col + 1) + 4096 * stride;
			var vaos = layouts[lkey] || (layouts[lkey] = new Map());
			vaoBound = true;
			for (var i = 0; i < n; i++, p += 5) {
				var vbo = HEAP32[p], count = HEAP32[p + 1];
				var buf = GL.buffers[vbo];
				var vao = vaos.get(vbo);
				if (!vao || vao.mcBuffer !== buf) {
					if (vao) GLctx.deleteVertexArray(vao);
					vao = GLctx.createVertexArray();
					vao.mcBuffer = buf;
					GLctx.bindVertexArray(vao);
					GLctx.bindBuffer(0x8892, buf);
					lastVbo = vbo;
					GLctx.enableVertexAttribArray(pos);
					GLctx.vertexAttribPointer(pos, 3, 0x1406, false, stride, 0);
					if (tex >= 0) { GLctx.enableVertexAttribArray(tex); GLctx.vertexAttribPointer(tex, 2, 0x1406, false, stride, 12); }
					if (col >= 0) { GLctx.enableVertexAttribArray(col); GLctx.vertexAttribPointer(col, 4, 0x1401, true, stride, 20); }
					vaos.set(vbo, vao);
				} else {
					GLctx.bindVertexArray(vao);
				}
				v[0] = HEAPF32[p + 2]; v[1] = HEAPF32[p + 3]; v[2] = HEAPF32[p + 4];
				mat4.translate(base, v, m);
				GLctx.uniformMatrix4fv(r.modelViewLocation, false, m);
				GLctx.drawArrays(4, 0, count);
				drawn = i + 1;
			}
		} else {
			GLctx.enableVertexAttribArray(pos);
			if (tex >= 0) GLctx.enableVertexAttribArray(tex);
			if (col >= 0) GLctx.enableVertexAttribArray(col);
			for (var i = 0; i < n; i++, p += 5) {
				var vbo = HEAP32[p], count = HEAP32[p + 1];
				v[0] = HEAPF32[p + 2]; v[1] = HEAPF32[p + 3]; v[2] = HEAPF32[p + 4];
				mat4.translate(base, v, m);
				GLctx.uniformMatrix4fv(r.modelViewLocation, false, m);
				GLctx.bindBuffer(0x8892, GL.buffers[vbo]);
				lastVbo = vbo;
				GLctx.vertexAttribPointer(pos, 3, 0x1406, false, stride, 0);
				if (tex >= 0) GLctx.vertexAttribPointer(tex, 2, 0x1406, false, stride, 12);
				if (col >= 0) GLctx.vertexAttribPointer(col, 4, 0x1401, true, stride, 20);
				GLctx.drawArrays(4, 0, count);
				drawn = i + 1;
			}
		}
	} catch (e) {
		if (!Module.mcFastChunkError) { Module.mcFastChunkError = true; console.warn('fast chunk draws disabled:', e); }
	} finally {
		if (vaoBound) { try { GLctx.bindVertexArray(null); } catch (e3) {} }
		if (r) {
			try {
				if (drawn > 0) {
					var lastRec = (recs >> 2) + (drawn - 1) * 5;
					lastVbo = HEAP32[lastRec];
				}
				GLctx.bindBuffer(0x8892, lastVbo ? GL.buffers[lastVbo] : null);
				GLctx.currentArrayBufferBinding = lastVbo;
			} catch (e4) {}
			r.modelViewMatrixVersion = -1;
			try { r.cleanup(); } catch (e2) {}
		}
	}
	return drawn;
});
static std::vector<int> s_fastChunkRecs;
#endif


RenderList::RenderList()
	:	inited(false),
	rendered(false)
{
	lists = new int[MAX_NUM_OBJECTS];
	rlists = new RenderChunk[MAX_NUM_OBJECTS];

	for (int i = 0; i < MAX_NUM_OBJECTS; ++i)
		rlists[i].vboId = -1;
}

RenderList::~RenderList() {
	delete[] lists;
	delete[] rlists;
}

void RenderList::init(float xOff, float yOff, float zOff) {
	inited = true;
	listIndex = 0;

	this->xOff = (float) xOff;
	this->yOff = (float) yOff;
	this->zOff = (float) zOff;
}

void RenderList::add(int list) {
	lists[listIndex] = list;
	if (listIndex == MAX_NUM_OBJECTS) /*lists.remaining() == 0)*/ render();
}

void RenderList::addR(const RenderChunk& chunk) {
	rlists[listIndex] = chunk;
}

void RenderList::render() {

	if (!inited) return;
	if (!rendered) {
		bufferLimit = listIndex;
		listIndex = 0;
		rendered = true;
	}
	if (listIndex < bufferLimit) {
		glPushMatrix2();
		glTranslatef2(-xOff, -yOff, -zOff);

		#ifndef USE_VBO
			glCallLists(bufferLimit, GL_UNSIGNED_INT, lists);
		#else
			renderChunks();
		#endif/*!USE_VBO*/

		glPopMatrix2();
	}
}

void RenderList::renderChunks() {
	//glDisableClientState2(GL_NORMAL_ARRAY);
	glEnableClientState2(GL_VERTEX_ARRAY);
	glEnableClientState2(GL_COLOR_ARRAY);
	glEnableClientState2(GL_TEXTURE_COORD_ARRAY);

	const int Stride = VertexSizeBytes;

	for (int i = 0; i < bufferLimit; ++i) {
#ifdef __EMSCRIPTEN__
		if (i == 1) {
			s_fastChunkRecs.resize((bufferLimit - 1) * 5);
			for (int k = 1; k < bufferLimit; ++k) {
				const RenderChunk& c = rlists[k];
				int* rec = &s_fastChunkRecs[(k - 1) * 5];
				rec[0] = (int)c.vboId;
				rec[1] = (int)c.vertexCount;
				float xyz[3] = {c.pos.x, c.pos.y, c.pos.z};
				memcpy(rec + 2, xyz, sizeof xyz);
			}
			const int drawn = mcFastChunkDraws(&s_fastChunkRecs[0], bufferLimit - 1, Stride);
			i += drawn;
			if (i >= bufferLimit) break;
		}
#endif
		RenderChunk& rc = rlists[i];

		glPushMatrix2();
		glTranslatef2(rc.pos.x, rc.pos.y, rc.pos.z);
		glBindBuffer2(GL_ARRAY_BUFFER, rc.vboId);

		glVertexPointer2	(3, GL_FLOAT, Stride,  0);
		glTexCoordPointer2	(2, GL_FLOAT, Stride, (GLvoid*) (3 * 4));
		glColorPointer2		(4, GL_UNSIGNED_BYTE, Stride, (GLvoid*) (5 * 4));

		glDrawArrays2(GL_TRIANGLES, 0, rc.vertexCount);

		glPopMatrix2();
	}

	glDisableClientState2(GL_VERTEX_ARRAY);
	glDisableClientState2(GL_COLOR_ARRAY);
	glDisableClientState2(GL_TEXTURE_COORD_ARRAY);
}

void RenderList::clear() {
	inited = false;
	rendered = false;
}
