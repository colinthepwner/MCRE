#include "RenderList.h"
#include <cstring>

#include "gles.h"
#include "RenderChunk.h"
#include "Tesselator.h"
#include "TerrainLight.h"

#ifdef __EMSCRIPTEN__
#include <emscripten.h>
#include <vector>

EM_JS(int, mcTerrainDraws, (const void* recs, int n, int stride), {
	var drawn = 0;
	var gl = (typeof GLctx !== 'undefined') ? GLctx : null;
	var T = Module.mcTerrain;
	var vaoBound = false;
	var began = false;
	var lastVbo = 0;
	var P = null;
	try {
		if (!gl || !T || !T.lm || T.lmCtx !== gl || T.broken || GL.currProgram
				|| typeof GLImmediate === 'undefined' || typeof GLEmulation === 'undefined' || !GLImmediate.matrix) return 0;
		var fogMode = GLEmulation.fogEnabled ? (GLEmulation.fogMode | 0) : 0;
		var at = GLEmulation.alphaTestEnabled ? (GLEmulation.alphaTestFunc | 0) : 0x207;
		var key = fogMode + '/' + at;
		P = T.progs[key];
		if (P === undefined) {
			P = null;
			var cen = !!(Module.mcCentroid && Module.mcCentroid.state === 'on');
			var fogFormula = null;
			if (fogMode == 0x801) fogFormula = '  float fog = exp(-u_fogDensity * u_fogDensity * v_fog * v_fog);';
			else if (fogMode == 0x2601) fogFormula = '  float fog = (u_fogEnd - v_fog) * u_fogScale;';
			else if (fogMode != 0) fogFormula = '  float fog = exp(-u_fogDensity * v_fog);';
			var atTest = '';
			switch (at) {
				case 0x200: atTest = '  discard;'; break;
				case 0x201: atTest = '  if (!(gl_FragColor.a < u_alphaRef)) discard;'; break;
				case 0x202: atTest = '  if (!(gl_FragColor.a == u_alphaRef)) discard;'; break;
				case 0x203: atTest = '  if (!(gl_FragColor.a <= u_alphaRef)) discard;'; break;
				case 0x204: atTest = '  if (!(gl_FragColor.a > u_alphaRef)) discard;'; break;
				case 0x205: atTest = '  if (!(gl_FragColor.a != u_alphaRef)) discard;'; break;
				case 0x206: atTest = '  if (!(gl_FragColor.a >= u_alphaRef)) discard;'; break;
				default: atTest = ''; break;
			}
			var mkVs = function (c) { var O = c ? 'centroid out' : 'varying'; return [
				c ? '#version 300 es' : '',
				(c ? 'in' : 'attribute') + ' vec3 a_pos;',
				(c ? 'in' : 'attribute') + ' vec2 a_light;',
				(c ? 'in' : 'attribute') + ' vec2 a_uv;',
				(c ? 'in' : 'attribute') + ' vec4 a_color;',
				'uniform mat4 u_mv;',
				'uniform mat4 u_proj;',
				'uniform vec3 u_off;',
				O + ' vec2 v_uv;',
				O + ' vec4 v_color;',
				O + ' vec2 v_lm;',
				fogFormula ? O + ' float v_fog;' : '',
				'void main() {',
				'  vec4 ec = u_mv * vec4(a_pos * 0.00048828125 + 8.0 + u_off, 1.0);',
				'  gl_Position = u_proj * ec;',
				'  v_uv = a_uv;',
				'  v_color = a_color;',
				'  v_lm = (a_light + 8.0) * 0.00390625;',
				fogFormula ? '  v_fog = length(ec.xyz);' : '',
				'}'].join('\n'); };
			var mkFs = function (c) {
				var I = c ? 'centroid in' : 'varying', TX = c ? 'texture' : 'texture2D', OUT = c ? 'mc_FragColor' : 'gl_FragColor';
				return [
				c ? '#version 300 es' : '',
				'precision mediump float;',
				c ? 'out vec4 mc_FragColor;' : '',
				'uniform sampler2D u_tex;',
				'uniform sampler2D u_lm;',
				I + ' vec2 v_uv;',
				I + ' vec4 v_color;',
				I + ' vec2 v_lm;',
				fogFormula ? I + ' float v_fog; uniform vec4 u_fogColor; uniform float u_fogEnd; uniform float u_fogScale; uniform float u_fogDensity;' : '',
				atTest ? 'uniform float u_alphaRef;' : '',
				'void main() {',
				'  vec4 c = ' + TX + '(u_tex, v_uv) * v_color;',
				'  c.rgb *= ' + TX + '(u_lm, v_lm).rgb;',
				fogFormula ? fogFormula + ' fog = clamp(fog, 0.0, 1.0); c.rgb = mix(u_fogColor.rgb, c.rgb, fog);' : '',
				'  ' + OUT + ' = c;',
				atTest.split('gl_FragColor').join(OUT),
				'}'].join('\n'); };
			var mk = function (type, src) {
				var sh = gl.createShader(type);
				gl.shaderSource(sh, src);
				gl.compileShader(sh);
				if (!gl.getShaderParameter(sh, gl.COMPILE_STATUS)) { console.warn('terrain shader:', gl.getShaderInfoLog(sh)); gl.deleteShader(sh); return null; }
				return sh;
			};
			var v = mk(gl.VERTEX_SHADER, mkVs(cen)), f = mk(gl.FRAGMENT_SHADER, mkFs(cen));
			if (cen && !(v && f)) {
				console.warn('terrain: no GLSL ES 3.00, drawing without centroid');
				if (v) gl.deleteShader(v);
				if (f) gl.deleteShader(f);
				cen = false;
				v = mk(gl.VERTEX_SHADER, mkVs(false)); f = mk(gl.FRAGMENT_SHADER, mkFs(false));
			}
			if (v && f) {
				var prog = gl.createProgram();
				gl.attachShader(prog, v);
				gl.attachShader(prog, f);
				gl.bindAttribLocation(prog, 0, 'a_pos');
				gl.bindAttribLocation(prog, 1, 'a_light');
				gl.bindAttribLocation(prog, 2, 'a_uv');
				gl.bindAttribLocation(prog, 3, 'a_color');
				gl.linkProgram(prog);
				if (gl.getProgramParameter(prog, gl.LINK_STATUS)) {
					P = { prog: prog, fog: !!fogFormula, at: !!atTest,
						uMv: gl.getUniformLocation(prog, 'u_mv'), uProj: gl.getUniformLocation(prog, 'u_proj'),
						uOff: gl.getUniformLocation(prog, 'u_off'), uFogColor: gl.getUniformLocation(prog, 'u_fogColor'),
						uFogEnd: gl.getUniformLocation(prog, 'u_fogEnd'), uFogScale: gl.getUniformLocation(prog, 'u_fogScale'),
						uFogDensity: gl.getUniformLocation(prog, 'u_fogDensity'), uAlphaRef: gl.getUniformLocation(prog, 'u_alphaRef') };
					gl.useProgram(prog);
					gl.uniform1i(gl.getUniformLocation(prog, 'u_tex'), 0);
					gl.uniform1i(gl.getUniformLocation(prog, 'u_lm'), 1);
					gl.useProgram(null);
				} else {
					console.warn('terrain program:', gl.getProgramInfoLog(prog));
				}
			}
			T.progs[key] = P;
			if (!P) { T.broken = true; return 0; }
		}
		if (!P) return 0;

		began = true;
		gl.useProgram(P.prog);
		GLImmediate.fixedFunctionProgram = 0;
		gl.uniformMatrix4fv(P.uProj, false, GLImmediate.matrix[1]);
		gl.uniformMatrix4fv(P.uMv, false, GLImmediate.matrix[0]);
		if (P.fog) {
			gl.uniform4fv(P.uFogColor, GLEmulation.fogColor);
			gl.uniform1f(P.uFogEnd, GLEmulation.fogEnd);
			gl.uniform1f(P.uFogScale, 1 / (GLEmulation.fogEnd - GLEmulation.fogStart));
			gl.uniform1f(P.uFogDensity, GLEmulation.fogDensity);
		}
		if (P.at) gl.uniform1f(P.uAlphaRef, GLEmulation.alphaTestRef);
		gl.activeTexture(gl.TEXTURE1);
		gl.bindTexture(gl.TEXTURE_2D, T.lm);
		gl.activeTexture(gl.TEXTURE0);

		var p = recs >> 2;
		lastVbo = gl.currentArrayBufferBinding;
		var setPointers = function () {
			gl.vertexAttribPointer(0, 3, 0x1402, false, stride, 0);
			gl.vertexAttribPointer(1, 2, 0x1401, false, stride, 6);
			gl.vertexAttribPointer(2, 2, 0x1406, false, stride, 8);
			gl.vertexAttribPointer(3, 4, 0x1401, true, stride, 16);
		};
		if (gl.createVertexArray && !Module.mcChunkNoVao) {
			var vaos = T.vaos;
			vaoBound = true;
			for (var i = 0; i < n; i++, p += 5) {
				var vbo = HEAP32[p], count = HEAP32[p + 1];
				var buf = GL.buffers[vbo];
				var vao = vaos.get(vbo);
				if (!vao || vao.mcBuffer !== buf) {
					if (vao) gl.deleteVertexArray(vao);
					vao = gl.createVertexArray();
					vao.mcBuffer = buf;
					gl.bindVertexArray(vao);
					gl.bindBuffer(0x8892, buf);
					lastVbo = vbo;
					gl.enableVertexAttribArray(0);
					gl.enableVertexAttribArray(1);
					gl.enableVertexAttribArray(2);
					gl.enableVertexAttribArray(3);
					setPointers();
					vaos.set(vbo, vao);
				} else {
					gl.bindVertexArray(vao);
				}
				gl.uniform3f(P.uOff, HEAPF32[p + 2], HEAPF32[p + 3], HEAPF32[p + 4]);
				gl.drawArrays(4, 0, count);
				drawn = i + 1;
			}
		} else {
			gl.enableVertexAttribArray(0);
			gl.enableVertexAttribArray(1);
			gl.enableVertexAttribArray(2);
			gl.enableVertexAttribArray(3);
			for (var i = 0; i < n; i++, p += 5) {
				var vbo = HEAP32[p], count = HEAP32[p + 1];
				gl.bindBuffer(0x8892, GL.buffers[vbo]);
				lastVbo = vbo;
				setPointers();
				gl.uniform3f(P.uOff, HEAPF32[p + 2], HEAPF32[p + 3], HEAPF32[p + 4]);
				gl.drawArrays(4, 0, count);
				drawn = i + 1;
			}
		}
	} catch (e) {
		if (!Module.mcTerrainError) { Module.mcTerrainError = true; console.warn('terrain draws disabled:', e); }
		if (T) T.broken = true;
	} finally {
		if (began) {
			try {
				if (vaoBound) gl.bindVertexArray(null);
				else { gl.disableVertexAttribArray(1); gl.disableVertexAttribArray(2); gl.disableVertexAttribArray(3); }
				if (drawn > 0) lastVbo = HEAP32[(recs >> 2) + (drawn - 1) * 5];
				gl.bindBuffer(0x8892, lastVbo ? GL.buffers[lastVbo] : null);
				gl.currentArrayBufferBinding = lastVbo;
				gl.useProgram(null);
				GLImmediate.fixedFunctionProgram = 0;
			} catch (e2) {}
		}
	}
	return drawn;
});
static std::vector<int> s_chunkRecs;
#endif


RenderList::RenderList()
	:	inited(false),
	rendered(false)
{
	lists = new int[MAX_NUM_OBJECTS];
	rlists = new RenderChunk[MAX_NUM_OBJECTS];

	for (int i = 0; i < MAX_NUM_OBJECTS; ++i)
		rlists[i].vboId = -1;
}

RenderList::~RenderList() {
	delete[] lists;
	delete[] rlists;
}

void RenderList::init(double xOff, double yOff, double zOff) {
	inited = true;
	listIndex = 0;

	this->xOff = xOff;
	this->yOff = yOff;
	this->zOff = zOff;
}

void RenderList::add(int list) {
	lists[listIndex] = list;
	if (listIndex == MAX_NUM_OBJECTS) /*lists.remaining() == 0)*/ render();
}

void RenderList::addR(const RenderChunk& chunk) {
	rlists[listIndex] = chunk;
}

void RenderList::render() {

	if (!inited) return;
	if (!rendered) {
		bufferLimit = listIndex;
		listIndex = 0;
		rendered = true;
	}
	if (listIndex < bufferLimit) {
		glPushMatrix2();

		#ifndef USE_VBO
			glTranslatef2((float)-xOff, (float)-yOff, (float)-zOff);
			glCallLists(bufferLimit, GL_UNSIGNED_INT, lists);
		#else
			renderChunks();
		#endif/*!USE_VBO*/

		glPopMatrix2();
	}
}

void RenderList::renderChunks() {
	const int Stride = TerrainMesh::STRIDE;

#ifdef __EMSCRIPTEN__
	int first = 0;
	if (bufferLimit > 0) {
		s_chunkRecs.resize(bufferLimit * 5);
		for (int k = 0; k < bufferLimit; ++k) {
			const RenderChunk& c = rlists[k];
			int* rec = &s_chunkRecs[k * 5];
			rec[0] = (int)c.vboId;
			rec[1] = (int)c.vertexCount;
			float xyz[3] = {(float)((double)c.pos.x - xOff), (float)((double)c.pos.y - yOff), (float)((double)c.pos.z - zOff)};
			memcpy(rec + 2, xyz, sizeof xyz);
		}
		first = mcTerrainDraws(&s_chunkRecs[0], bufferLimit, Stride);
	}
	if (first >= bufferLimit) return;
#else
	const int first = 0;
#endif

	glEnableClientState2(GL_VERTEX_ARRAY);
	glEnableClientState2(GL_COLOR_ARRAY);
	glEnableClientState2(GL_TEXTURE_COORD_ARRAY);
	const float S = 1.0f / TerrainMesh::POS_SCALE;
	for (int i = first; i < bufferLimit; ++i) {
		RenderChunk& rc = rlists[i];

		glPushMatrix2();
		const float B = TerrainMesh::POS_BIAS;
		glTranslatef2((float)((double)rc.pos.x - xOff) + B, (float)((double)rc.pos.y - yOff) + B, (float)((double)rc.pos.z - zOff) + B);
		glScalef2(S, S, S);
		glBindBuffer2(GL_ARRAY_BUFFER, rc.vboId);

		glVertexPointer2	(3, GL_SHORT, Stride,  0);
		glTexCoordPointer2	(2, GL_FLOAT, Stride, (GLvoid*) 8);
		glColorPointer2		(4, GL_UNSIGNED_BYTE, Stride, (GLvoid*) 16);

		glDrawArrays2(GL_TRIANGLES, 0, rc.vertexCount);

		glPopMatrix2();
	}

	glDisableClientState2(GL_VERTEX_ARRAY);
	glDisableClientState2(GL_COLOR_ARRAY);
	glDisableClientState2(GL_TEXTURE_COORD_ARRAY);
}

void RenderList::clear() {
	inited = false;
	rendered = false;
}
