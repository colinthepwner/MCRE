#ifndef NET_MINECRAFT_CLIENT_MODEL__ChestModel_H__
#define NET_MINECRAFT_CLIENT_MODEL__ChestModel_H__

//package net.minecraft.client.model;


#include "Model.h"
#include "geom/ModelPart.h"
#include "geom/ModelTexSize.h"

class ChestModel: public Model
{
public:
    ChestModel()
    :   lid(0, 0),
        lock(0, 0),
        bottom(0, 19)
    {
        init(64, 14, 8);
    }

    void render() {
        lock.xRot = lid.xRot;

        lid.render(1 / 16.0f);
        lock.render(1 / 16.0f);
        bottom.render(1 / 16.0f);
    }

    ModelPart lid;
    ModelPart bottom;
    ModelPart lock;

protected:
    ChestModel(int texW, int boxW, float knobX)
    :   lid(0, 0),
        lock(0, 0),
        bottom(0, 19)
    {
        init(texW, boxW, knobX);
    }

private:
    void init(int texW, int boxW, float knobX) {
        const int texH = 64;
        lid.setModel(this);
        lid.setTexSize(texW, texH);
        ModelTexSize::addBox(lid, 0.0f, -5, -14, boxW, 5, 14, 0, texW, texH);
        lid.x = 1;
        lid.y = 7;
        lid.z = 15;

        lock.setModel(this);
        lock.setTexSize(texW, texH);
        ModelTexSize::addBox(lock, -1, -2, -15, 2, 4, 1, 0, texW, texH);
        lock.x = knobX;
        lock.y = 7;
        lock.z = 15;

        bottom.setModel(this);
        bottom.setTexSize(texW, texH);
        ModelTexSize::addBox(bottom, 0.0f, 0, 0, boxW, 10, 14, 0, texW, texH);
        bottom.x = 1;
        bottom.y = 6;
        bottom.z = 1;
    }
};

class LargeChestModel: public ChestModel
{
public:
    LargeChestModel() : ChestModel(128, 30, 16) {}
};

#endif /*NET_MINECRAFT_CLIENT_MODEL__ChestModel_H__*/
