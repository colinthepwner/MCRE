#ifndef NET_MINECRAFT_CLIENT__Minecraft_H__
#define NET_MINECRAFT_CLIENT__Minecraft_H__

#include "Options.h"
#ifndef STANDALONE_SERVER
#include "MouseHandler.h"
#endif
#include "Timer.h"
#include "player/input/ITurnInput.h"
#ifndef STANDALONE_SERVER
#include "gui/Gui.h"
#include "gui/screens/ScreenChooser.h"
#endif
//#include "../network/RakNetInstance.h"
#include "../world/phys/HitResult.h"
#include "../world/level/levelgen/WorldGenOptions.h"

class User;
class Level;
class LocalPlayer;
class IInputHolder;
class Mob;
class Player;
class LevelRenderer;
class GameRenderer;
class ParticleEngine;
class Entity;
class ICreator;
class GameMode;
class Textures;
class CThread;
class SoundEngine;
class Screen;
class Font;
class LevelStorageSource;
class BuildActionIntention;
class PerfRenderer;
class LevelSettings;
class IRakNetInstance;
class NetEventCallback;
class CommandServer;
struct PingedCompatibleServer;
//class ExternalFileLevelStorageSource;


#include "../App.h"
#include "PixelCalc.h"
class AppPlatform;
class AppPlatform_android;

class Minecraft: public App
{
protected:
	Minecraft();
public:
	virtual ~Minecraft();

	void init();
	void setSize(int width, int height);
	void reloadOptions();

	bool supportNonTouchScreen();
	bool useTouchscreen();
	void grabMouse();
	void releaseMouse();

	void handleBuildAction(BuildActionIntention*);

	void toggleDimension(){}
	int getGameType();
	void setGameType(int gameType);
	bool isCreativeMode() { return getGameType() == 1; }
	void setScreen(Screen*);

	virtual void selectLevel(const std::string& levelId, const std::string& levelName, const LevelSettings& settings);
	virtual void setLevel(Level* level, const std::string& message = "", LocalPlayer* forceInsertPlayer = NULL);

	void generateLevel( const std::string& message, Level* level );
	LevelStorageSource* getLevelSource();

	bool isLookingForMultiplayer;
	void locateMultiplayer();
	void cancelLocateMultiplayer();
	bool joinMultiplayer(const PingedCompatibleServer& server);
	void hostMultiplayer(int port=19132);
	Player* respawnPlayer(int playerId);
	void respawnPlayer();
	void resetPlayer(Player* player);
	void doActuallyRespawnPlayer();

	void update();

	void tick(int nTick, int maxTick);
	void tickInput();

	bool isOnlineClient();
	bool isOnline();
	void pauseGame(bool isBackPaused);
	void gameLostFocus();

	void prepareLevel(const std::string& message);
	void prepareLevelBegin(const std::string& message);
	bool prepareLevelStep(double budgetMs);
	void prepareLevelEnd();

	void leaveGame(bool renameLevel = false);

	int getProgressStatusId();
	const char* getProgressMessage();

	ICreator* getCreator();

	// void onGraphicsLost() {}
	void onGraphicsReset();

	bool isLevelGenerated();
	int getLicenseId();

#ifdef __EMSCRIPTEN__
	// Defer level creation to next frame so ProgressScreen can render before blocking generation
	void scheduleLevelCreation(const std::string& levelId, const std::string& levelName, long seed, int gameType, const WorldGenOptions& gen);
	void runScheduledLevelCreation();
#endif

    void audioEngineOn();
    void audioEngineOff();
    
	bool isPowerVR() { return _powerVr; }
	bool isKindleFire(int kindleVersion);
	bool transformResolution(int* w, int* h);
	void optionUpdated(const Options::Option* option, bool value);
	void optionUpdated(const Options::Option* option, float value);
	void optionUpdated(const Options::Option* option, int value);
#ifdef __APPLE__
    bool _isSuperFast;
    bool isSuperFast() { return _isSuperFast; }
#endif

protected:
	void _levelGenerated();

private:
	static void* prepareLevel_tspawn(void *p_param);

#if defined(EMSCRIPTEN)
	void dropSelectedItem(bool wholeStack);
	bool tunnelTarget(int& x, int& y, int& z, int& face);
#endif
	void handleMouseClick(int button);
	void handleMouseDown(int button, bool down);

	void _reloadInput();
public:
	int width;
	int height;

	// Vars that the platform is allowed to use in the future
	int commandPort;
	int reserved_d1, reserved_d2;
	float reserved_f1, reserved_f2;

	Options options;

	static bool useAmbientOcclusion;
	//static bool threadInterrupt;

	volatile bool pause;

	LevelRenderer*  levelRenderer;
	GameRenderer*   gameRenderer;
	ParticleEngine* particleEngine;
	SoundEngine*    soundEngine;

	GameMode* gameMode;
#ifndef STANDALONE_SERVER
	Textures* textures;
	ScreenChooser screenChooser;
	Font* font;
#endif
	IRakNetInstance*  raknetInstance;
	NetEventCallback* netCallback;

	int lastTime;
	int lastTickTime;
	float ticksSinceLastUpdate;

	User*  user;
	Level* level;

	LocalPlayer*	player;
	IInputHolder*	inputHolder;
	Mob*			cameraTargetPlayer;
#ifndef STANDALONE_SERVER
	Gui gui;
#endif
	CThread* generateLevelThread;
	Screen* screen;
	static int customDebugId;

	static const int CDI_NONE = 0;
	static const int CDI_GRAPHICS = 1;
#ifndef STANDALONE_SERVER
	MouseHandler mouseHandler;
#endif
	bool mouseGrabbed;

    PixelCalc pixelCalc;
    PixelCalc pixelCalcUi;

	HitResult hitResult;
	bool holdMineRetarget = false;
#if defined(EMSCRIPTEN)
	bool touchCombatTouch();

	struct BridgeSpot {
		int sx, sy, sz, face;
		int tx, ty, tz;
	};
	bool bridgeSpot(BridgeSpot& out);
	bool pillarTap();
	void pillarTick();
	int pillarX, pillarY, pillarZ;
	int pillarTicks;
	int pillarItem;
	Mob* touchAssistTarget();
	bool touchAttackable(Entity* e);
	void touchHoldAttackTick();
	int touchHoldMode = 0;
	int touchHoldAttackTicks = 0;

	bool treeChainActive = false;
	int treeChainX = 0, treeChainY = 0, treeChainZ = 0, treeChainFace = 0;
	bool treeChainHaveLocal = false;
	float treeChainLocal[3] = {0, 0, 1};
	float treeChainDrag = 0;
	bool treeChainEasing = false;
	float treeChainLastTime = 0;
	bool treeChainNext(int bx, int by, int bz, int woodType);
	int treeChainTile = 0;
	bool treeChainMatches(int tileId) const;
	static bool isChainOre(int tileId);
	bool oreChainNext(int bx, int by, int bz, int oreId);
	bool treeChainIsTree(int x, int y, int z, int woodType);
	void treeChainTurn();
	void treeChainStop() { treeChainActive = false; treeChainEasing = false; }

	bool mineAssistActive = false;
	bool mineAssistCentre = false;
	bool mineAssistTurns = false;
	int mineAssistX = 0, mineAssistY = 0, mineAssistZ = 0, mineAssistFace = 0;
	float mineAssistDrag = 0;
	float mineAssistLastTime = 0;
	bool mineAssistHaveView = false;
	float mineAssistYaw = 0, mineAssistPitch = 0;
	float mineAssistManual = 0;
	bool touchMineAnchorSet = false;
	int touchMineX = 0, touchMineY = 0, touchMineZ = 0;
	float touchMineFX = 0, touchMineFY = 0;
	float touchMineAX = 0, touchMineAY = 0, touchMineAZ = 0;
	void mineAssistStart(int x, int y, int z, int f, bool fromCentre = false);
	void mineAssistTurn();
	void mineAssistStop() { mineAssistActive = false; }
#endif
	volatile int progressStagePercentage;
	std::string progressTitle;

	// This field is initialized in main()
	// It sets the base path to where worlds can be written (sdcard on android)
	std::string externalStoragePath;
	std::string externalCacheStoragePath;
protected:
	Timer timer;
    // @note @attn @warn: this is dangerous as fuck!
	volatile bool isGeneratingLevel;
	bool _hasSignaledGeneratingLevelFinished;

	LevelStorageSource* storageSource;
	bool _running;
	bool _powerVr;

private:
	volatile int progressStageStatusId;
	static const char* progressMessages[];

	int missTime;
	int ticks;
	bool screenMutex;
	bool hasScheduledScreen;
	Screen* scheduledScreen;

	int _licenseId;
	bool _supportsNonTouchscreen;

	int _gameType;
	//int _respawnPlayerTicks;
	Player* _pendingRemovePlayer; // @attn @todo @fix: remove this shait and fix the respawn behaviour

#ifdef __EMSCRIPTEN__
	std::string _scheduledLevelId;
	std::string _scheduledLevelName;
	long _scheduledLevelSeed;
	int _scheduledLevelGameType;
	WorldGenOptions _scheduledLevelGen;
	bool _hasScheduledLevelCreation;
#endif

	PerfRenderer* _perfRenderer;
	CommandServer* _commandServer;
};

#endif /*NET_MINECRAFT_CLIENT__Minecraft_H__*/
