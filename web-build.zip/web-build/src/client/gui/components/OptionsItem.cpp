#include "OptionsItem.h"
#include "../../Minecraft.h"
#include "../../../util/Mth.h"
#include "Slider.h"
#include "../../../world/level/Level.h"
#include "../../../world/level/LevelSettings.h"
#include "ImageButton.h"
#include "../../../world/ModContent.h"
#include "../Font.h"
#include "../../renderer/Textures.h"
#include "../../renderer/gles.h"
#include <cstdio>
OptionsItem::OptionsItem( std::string label, GuiElement* element )
: GuiElementContainer(false, true, 0, 0, 24, 12),
  label(label) {
	  addChild(element);
}

bool OptionsItem::javaStyle = false;

void OptionsItem::setupPositions() {
	if (javaStyle) {
		const int cw = hasReset() ? width - RESET_W - 2 : width;
		for (unsigned int i = 0; i < children.size(); ++i) {
			children[i]->x = x; children[i]->y = y;
			children[i]->width = cw; children[i]->height = JAVA_CELL_H;
		}
		height = JAVA_CELL_H;
		return;
	}
	int currentHeight = 0;
	for(std::vector<GuiElement*>::iterator it = children.begin(); it != children.end(); ++it) {
		(*it)->x = x + width - (*it)->width - 15;
		(*it)->y = y + currentHeight;
		currentHeight += (*it)->height;
	}
	height = currentHeight;
}

bool OptionsItem::hasReset() const {
	const Slider* sl = children.empty() ? NULL : dynamic_cast<const Slider*>(children[0]);
	return sl && sl->getOption() == &Options::Option::FOG_START;
}

bool OptionsItem::resetRect(int& rx, int& ry, int& rw, int& rh) const {
	if (!hasReset()) return false;
	rw = RESET_W;
	if (javaStyle) { rx = x + width - RESET_W; ry = y; rh = JAVA_CELL_H; return true; }
	const GuiElement* sl = children[0];
	rx = sl->x - RESET_W - 4; ry = sl->y; rh = sl->height > 0 ? sl->height : 20;
	return true;
}

void OptionsItem::mouseClicked(Minecraft* minecraft, int mx, int my, int buttonNum) {
	int rx, ry, rw, rh;
	if (resetRect(rx, ry, rw, rh) && mx >= rx && mx < rx + rw && my >= ry && my < ry + rh) {
		minecraft->options.set(&Options::Option::FOG_START, 0.6f);
		minecraft->options.save();
		((Slider*)children[0])->refresh(minecraft);
		return;
	}
	super::mouseClicked(minecraft, mx, my, buttonNum);
}

void OptionsItem::render( Minecraft* minecraft, int xm, int ym ) {
	int yOffset = (height - 8) / 2;
	std::string text = label;
	if (!children.empty()) {
		OptionButton* ob = dynamic_cast<OptionButton*>(children[0]);
		const bool in404 = minecraft->level != NULL
			&& minecraft->level->getLevelData()->getGameType() == GameType::Challenge404;
		if (ob && ob->getOption() == &Options::Option::SPRINTING) {
			ob->active = !minecraft->options.hungerEnabled && !in404;
			ob->updateImage(&minecraft->options);
			if (in404) text += " (off in 404)";
			else if (!ob->active) text += " (Hunger)";
		}
		if (ob && (ob->getOption() == &Options::Option::ENTITY_LIGHTING || ob->getOption() == &Options::Option::BIOME_SKY)) {
			const bool pocket = minecraft->options.pocketLighting();
			ob->active = !pocket;
			ob->updateImage(&minecraft->options);
			if (pocket) text += " (Pocket)";
		}
		if (ob && ob->getOption() == &Options::Option::HUNGER) {
			ob->active = !in404;
			if (in404) text += " (off in 404)";
		}
		Slider* sl = dynamic_cast<Slider*>(children[0]);
		if (sl && sl->getOption() == &Options::Option::FOV) {
			char buf[16];
			sprintf(buf, ": %d", (int)(minecraft->options.fov + 0.5f));
			text += buf;
		}
		if (sl && sl->getOption() == &Options::Option::VIEW_DISTANCE) {
			static const char* names[4] = { "Far", "Normal", "Short", "Tiny" };
			const int v = minecraft->options.viewDistance;
			text += std::string(": ") + names[v < 0 ? 0 : v > 3 ? 3 : v];
		}
		if (sl && sl->getOption() == &Options::Option::DIFFICULTY_SLIDER) {
			static const char* names[5] = { "Peaceful", "Easy", "Normal", "Hard", "Brutal" };
			const int v = minecraft->options.difficulty;
			const bool lock404 = minecraft->level != NULL
				&& minecraft->level->getLevelData()->getGameType() == GameType::Challenge404;
			std::string why;
			const int forced = lock404 ? 3 : ModContent::forcedDifficulty(&why);
			sl->locked = forced >= 0;
			sl->lockedPercentage = forced >= 0 ? forced / 4.0f : 1.0f;
			if (lock404) text += ": Hard (404 Challenge)";
			else if (forced >= 0) text += ": " + ModContent::difficultyName(forced) + (why == "Hardcore" ? " (Hardcore)" : " (locked)");
			else text += std::string(": ") + names[v < 0 ? 0 : v > 4 ? 4 : v];
		}
		if (sl && sl->getOption() == &Options::Option::TOUCH_CONTROLS) {
			static const char* names[3] = { "Joystick", "D-pad", "Invisible Joystick" };
			const int v = minecraft->options.touchControls;
			text += std::string(": ") + names[v < 0 ? 0 : v > 2 ? 2 : v];
		}
		if (sl && sl->getOption() == &Options::Option::RENDER_SCALE) {
			static const char* names[5] = { "Auto", "100%", "75%", "50%", "35%" };
			const int v = Options::renderScale;
			text += std::string(": ") + names[v < 0 ? 0 : v > 4 ? 4 : v];
		}
		if (sl && sl->getOption() == &Options::Option::GUI_SCALE) {
			const int v = minecraft->options.guiScale;
			if (v <= 0) text += ": Auto";
			else {
				char buf[16];
				sprintf(buf, ": %d", v < Options::guiScaleMax ? v : Options::guiScaleMax);
				text += buf;
			}
		}
		if (sl && sl->getOption() == &Options::Option::DISTANT_DETAIL) {
			static const char* names[2] = { "Full", "Reduced" };
			const int v = Options::distantDetail;
			text += std::string(": ") + names[v < 0 ? 0 : v > 1 ? 1 : v];
		}
		if (sl && sl->getOption() == &Options::Option::LIGHTING_STYLE) {
			static const char* names[2] = { "Rocket", "Pocket" };
			text += std::string(": ") + names[minecraft->options.lightingStyle == 1 ? 1 : 0];
		}
		if (sl && sl->getOption() == &Options::Option::SOUND_STYLE) {
			static const char* names[2] = { "Old", "New (1.7)" };
			text += std::string(": ") + names[minecraft->options.soundStyle == 1 ? 1 : 0];
		}
		if (sl && sl->getOption() == &Options::Option::UI_STYLE) {
			static const char* names[3] = { "Auto", "Java", "Pocket" };
			const int v = Options::uiStyle;
			text += std::string(": ") + names[v < 0 ? 0 : v > 2 ? 2 : v];
		}
		if (sl && sl->getOption() == &Options::Option::VIEW_BOBBING) {
			static const char* names[3] = { "Off", "Fast", "Fancy" };
			const int v = minecraft->options.bobMode;
			text += std::string(": ") + names[v < 0 ? 0 : v > 2 ? 2 : v];
		}
		if (sl && sl->getOption() == &Options::Option::LEAVES) {
			static const char* names[3] = { "Fast", "Fancy", "Fanciest" };
			const int v = minecraft->options.leavesMode;
			text += std::string(": ") + names[v < 0 ? 0 : v > 2 ? 2 : v];
		}
		if (sl && sl->getOption() == &Options::Option::BIOME_BLEND) {
			static const char* names[4] = { "Off", "3x3", "5x5", "7x7" };
			const int v = minecraft->options.biomeBlend;
			text += std::string(": ") + names[v < 0 ? 0 : v > 3 ? 3 : v];
		}
		if (sl && sl->getOption() == &Options::Option::FOG_START) {
			char buf[16];
			sprintf(buf, ": %d%%", (int)(minecraft->options.fogStart * 100 + 0.5f));
			text += buf;
		}
	}
	if (javaStyle && !children.empty()) { renderJava(minecraft, xm, ym, text); return; }
	minecraft->font->draw(text, (float)x, (float)y + yOffset, 0xffd8d8d8, false);
	super::render(minecraft, xm, ym);
	int rx, ry, rw, rh;
	if (resetRect(rx, ry, rw, rh)) {
		const bool over = xm >= rx && ym >= ry && xm < rx + rw && ym < ry + rh;
		fill(rx, ry, rx + rw, ry + rh, over ? 0xff6a6a6a : 0xff4a4a4a);
		fill(rx, ry, rx + rw, ry + 1, 0xff8a8a8a);
		drawCenteredString(minecraft->font, "Reset", rx + rw / 2, ry + (rh - 8) / 2, over ? 0xffffffa0 : 0xffe0e0e0);
	}
}

void OptionsItem::renderJava(Minecraft* minecraft, int xm, int ym, std::string text) {
	GuiElement* c = children[0];
	OptionButton* ob = dynamic_cast<OptionButton*>(c);
	Slider* sl = dynamic_cast<Slider*>(c);
	const bool on = sl ? !sl->locked : c->active;
	const bool hover = on && xm >= x && ym >= y && xm < x + width && ym < y + height;
	minecraft->textures->loadAndBindTexture("gui/button_java.png");
	glColor4f2(1, 1, 1, 1);
	const int w = hasReset() ? width - RESET_W - 2 : width, h = height;
	if (sl) {
		blit(x, y, 0, 0, w / 2, h, 0, 20);
		blit(x + w / 2, y, 200 - w / 2, 0, w - w / 2, h, 0, 20);
		const Options::Option* o = sl->getOption();
		const float lo = minecraft->options.getProgrssMin(o), hi = minecraft->options.getProgrssMax(o);
		float p = sl->locked ? sl->lockedPercentage
			: hi > lo ? (minecraft->options.getProgressValue(o) - lo) / (hi - lo) : 0.0f;
		p = p < 0 ? 0 : p > 1 ? 1 : p;
		const int kx = x + (int)(p * (float)(w - 8));
		const int row = on ? 20 : 0;
		blit(kx, y, 0, row, 4, h, 0, 20);
		blit(kx + 4, y, 196, row, 4, h, 0, 20);
	} else {
		const int row = !on ? 0 : hover ? 40 : 20;
		blit(x, y, 0, row, w / 2, h, 0, 20);
		blit(x + w / 2, y, 200 - w / 2, row, w - w / 2, h, 0, 20);
		if (ob && ob->getOption() && ob->getOption()->isBoolean())
			if (ob->getOption() != &Options::Option::OPTIMIZE)
				text += minecraft->options.getBooleanValue(ob->getOption()) ? ": ON" : ": OFF";
	}
	const int col = !on ? 0xffa0a0a0 : hover ? 0xffffffa0 : 0xffe0e0e0;
	Font* font = minecraft->font;
	while (text.size() > 4 && font->width(text) > w - 6) text = text.substr(0, text.size() - 4) + "...";
	drawCenteredString(font, text, x + w / 2, y + (h - 8) / 2, col);
	int rx, ry, rw, rh;
	if (resetRect(rx, ry, rw, rh)) {
		const bool over = xm >= rx && ym >= ry && xm < rx + rw && ym < ry + rh;
		minecraft->textures->loadAndBindTexture("gui/button_java.png");
		glColor4f2(1, 1, 1, 1);
		const int row = over ? 40 : 20;
		blit(rx, ry, 0, row, rw / 2, rh, 0, 20);
		blit(rx + rw / 2, ry, 200 - (rw - rw / 2), row, rw - rw / 2, rh, 0, 20);
		drawCenteredString(font, "Reset", rx + rw / 2, ry + (rh - 8) / 2, over ? 0xffffffa0 : 0xffe0e0e0);
	}
}