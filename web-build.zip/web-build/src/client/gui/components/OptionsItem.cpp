#include "OptionsItem.h"
#include "../../Minecraft.h"
#include "../../../util/Mth.h"
#include "Slider.h"
#include "ImageButton.h"
#include <cstdio>
OptionsItem::OptionsItem( std::string label, GuiElement* element )
: GuiElementContainer(false, true, 0, 0, 24, 12),
  label(label) {
	  addChild(element);
}

void OptionsItem::setupPositions() {
	int currentHeight = 0;
	for(std::vector<GuiElement*>::iterator it = children.begin(); it != children.end(); ++it) {
		(*it)->x = x + width - (*it)->width - 15;
		(*it)->y = y + currentHeight;
		currentHeight += (*it)->height;
	}
	height = currentHeight;
}

void OptionsItem::render( Minecraft* minecraft, int xm, int ym ) {
	int yOffset = (height - 8) / 2;
	std::string text = label;
	if (!children.empty()) {
		OptionButton* ob = dynamic_cast<OptionButton*>(children[0]);
		if (ob && ob->getOption() == &Options::Option::SPRINTING) {
			ob->active = !minecraft->options.hungerEnabled;
			ob->updateImage(&minecraft->options);
			if (!ob->active) text += " (Hunger)";
		}
		Slider* sl = dynamic_cast<Slider*>(children[0]);
		if (sl && sl->getOption() == &Options::Option::FOV) {
			char buf[16];
			sprintf(buf, ": %d", (int)(minecraft->options.fov + 0.5f));
			text += buf;
		}
		if (sl && sl->getOption() == &Options::Option::VIEW_DISTANCE) {
			static const char* names[4] = { "Far", "Normal", "Short", "Tiny" };
			const int v = minecraft->options.viewDistance;
			text += std::string(": ") + names[v < 0 ? 0 : v > 3 ? 3 : v];
		}
		if (sl && sl->getOption() == &Options::Option::DIFFICULTY_SLIDER) {
			static const char* names[4] = { "Peaceful", "Easy", "Normal", "Hard" };
			const int v = minecraft->options.difficulty;
			text += std::string(": ") + names[v < 0 ? 0 : v > 3 ? 3 : v];
		}
		if (sl && sl->getOption() == &Options::Option::TOUCH_CONTROLS) {
			static const char* names[3] = { "Joystick", "D-pad", "Invisible Joystick" };
			const int v = minecraft->options.touchControls;
			text += std::string(": ") + names[v < 0 ? 0 : v > 2 ? 2 : v];
		}
		if (sl && sl->getOption() == &Options::Option::RENDER_SCALE) {
			static const char* names[5] = { "Auto", "100%", "75%", "50%", "35%" };
			const int v = Options::renderScale;
			text += std::string(": ") + names[v < 0 ? 0 : v > 4 ? 4 : v];
		}
		if (sl && sl->getOption() == &Options::Option::DISTANT_DETAIL) {
			static const char* names[2] = { "Full", "Reduced" };
			const int v = Options::distantDetail;
			text += std::string(": ") + names[v < 0 ? 0 : v > 1 ? 1 : v];
		}
		if (sl && sl->getOption() == &Options::Option::BIOME_BLEND) {
			static const char* names[4] = { "Off", "3x3", "5x5", "7x7" };
			const int v = minecraft->options.biomeBlend;
			text += std::string(": ") + names[v < 0 ? 0 : v > 3 ? 3 : v];
		}
		if (sl && sl->getOption() == &Options::Option::FOG_START) {
			char buf[16];
			sprintf(buf, ": %d%%", (int)(minecraft->options.fogStart * 100 + 0.5f));
			text += buf;
		}
	}
	minecraft->font->draw(text, (float)x, (float)y + yOffset, 0xffd8d8d8, false);
	super::render(minecraft, xm, ym);
}