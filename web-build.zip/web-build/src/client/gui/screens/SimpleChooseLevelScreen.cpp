#include <cstdlib>
#include "SimpleChooseLevelScreen.h"
#include "ProgressScreen.h"
#include "ScreenChooser.h"
#include "../components/Button.h"
#include "../../Minecraft.h"
#include "../../../world/level/LevelSettings.h"
#include "../../../platform/time.h"
#include "../../../util/Mth.h"

static WorldGenOptions s_options;
static bool s_chosen = false;
static std::string s_seedText;
static bool s_creative = false;

#ifdef EMSCRIPTEN
#include <emscripten.h>
static bool takeSeedFromPage(std::string& out) {
	char buf[64];
	const int got = EM_ASM_INT({
		var s = Module.mcSeedPending;
		if (typeof s !== 'string') return 0;
		Module.mcSeedPending = null;
		stringToUTF8(s, $0, $1);
		return 1;
	}, buf, (int)sizeof buf);
	if (!got) return false;
	out = buf;
	return true;
}
#endif

long SimpleChooseLevelScreen::seedFromText(const std::string& text) {
	if (text.empty()) return getEpochTimeS();
	char* end = NULL;
	const long long v = strtoll(text.c_str(), &end, 10);
	if (end && *end == 0) return (long)(int)v;
	int h = 0;
	for (unsigned int i = 0; i < text.size(); ++i) h = 31 * h + (unsigned char)text[i];
	return (long)h;
}

#ifdef EMSCRIPTEN
extern "C" int mcIsPhoneDevice();
static bool phoneDevice(Minecraft*) { return mcIsPhoneDevice() != 0; }
#else
static bool phoneDevice(Minecraft* mc) { return mc->useTouchscreen(); }
#endif

static const char* const TYPE_NAMES[WorldType::COUNT] = { "Default", "Island", "Inland", "Floating", "Flat" };
static const char* const THEME_NAMES[WorldTheme::COUNT] = { "Normal", "Hell", "Paradise", "Woods" };

int SimpleChooseLevelScreen::sizeChoices(bool phone, const SizeChoice** out, int* defaultIndex) {
	static const SizeChoice pc[] = {
		{ WorldSize::TINY,    "Tiny (128)" },
		{ WorldSize::SMALL,   "Small (256)" },
		{ WorldSize::NORMAL,  "Normal (512)" },
		{ WorldSize::LARGE,   "Large (1024)" },
		{ WorldSize::EXTREME, "Extreme (2048)" },
		{ WorldSize::INFINITE_CHUNKS, "Infinite" },
	};
	static const SizeChoice mobile[] = {
		{ WorldSize::TINY,    "Small (128)" },
		{ WorldSize::SMALL,   "Normal (256)" },
		{ WorldSize::NORMAL,  "Large (512)" },
	};
	if (phone) { *out = mobile; *defaultIndex = 1; return 3; }
	*out = pc; *defaultIndex = 2;
	return 6;
}

SimpleChooseLevelScreen::SimpleChooseLevelScreen(const std::string& levelName)
:	bMode(0),
	bCreate(0),
	bBack(0),
	bSize(0), bType(0), bTheme(0), bBiomes(0), bSeed(0),
	levelName(levelName),
	hasChosen(false)
{
}

SimpleChooseLevelScreen::~SimpleChooseLevelScreen()
{
	delete bMode;
	delete bCreate;
	delete bBack;
	delete bSize;
	delete bType;
	delete bTheme;
	delete bBiomes;
	delete bSeed;
}

void SimpleChooseLevelScreen::init()
{
	const bool phone = phoneDevice(minecraft);
	if (!s_chosen) {
		const SizeChoice* list; int def;
		sizeChoices(phone, &list, &def);
		s_options = WorldGenOptions();
		s_options.size = list[def].chunks;
		s_options.biomes = WorldBiomes::MODERN;
		s_chosen = true;
	} else {
		const SizeChoice* list; int def;
		const int n = sizeChoices(phone, &list, &def);
		bool ok = false;
		for (int i = 0; i < n; ++i) ok = ok || list[i].chunks == s_options.size;
		if (!ok) s_options.size = list[def].chunks;
	}

	if (minecraft->useTouchscreen()) {
		bCreate   = new Touch::TButton(1, "Create World");
		bMode     = new Touch::TButton(2, "");
		bBack	  = new Touch::TButton(3, "Back");
		bSize     = new Touch::TButton(4, "");
		bType     = new Touch::TButton(5, "");
		bTheme    = new Touch::TButton(6, "");
		bBiomes   = new Touch::TButton(7, "");
		bSeed     = new Touch::TButton(8, "");
	} else {
		bCreate   = new Button(1, "Create World");
		bMode     = new Button(2, "");
		bBack	  = new Button(3, "Back");
		bSize     = new Button(4, "");
		bType     = new Button(5, "");
		bTheme    = new Button(6, "");
		bBiomes   = new Button(7, "");
		bSeed     = new Button(8, "");
	}
	updateLabels();
	Button* all[] = { bSize, bType, bTheme, bBiomes, bSeed, bMode, bCreate, bBack };
	for (int i = 0; i < 8; ++i) {
		buttons.push_back(all[i]);
		tabButtons.push_back(all[i]);
	}
}

void SimpleChooseLevelScreen::updateLabels()
{
	const SizeChoice* list; int def;
	const int n = sizeChoices(phoneDevice(minecraft), &list, &def);
	const char* sizeName = list[def].name;
	for (int i = 0; i < n; ++i) if (list[i].chunks == s_options.size) sizeName = list[i].name;
	bSize->msg = std::string("Size: ") + sizeName;
	bType->msg = std::string("Type: ") + TYPE_NAMES[s_options.type];
	bTheme->msg = std::string("Theme: ") + THEME_NAMES[s_options.theme];
	bBiomes->msg = std::string("Biomes: ") + (s_options.biomes == WorldBiomes::MODERN ? "1.5" : "Classic PE");
	bSeed->msg = std::string("Seed: ") + (s_seedText.empty() ? "Random" : s_seedText);
	bMode->msg = std::string("Game Mode: ") + (s_creative ? "Creative" : "Survival");
	bBiomes->active = s_options.type == WorldType::DEFAULT;
}

void SimpleChooseLevelScreen::setupPositions()
{
	const int bw = Mth::Min(150, (width - 30) / 2);
	const int bh = bSize->height;
	const int colL = width / 2 - bw - 5, colR = width / 2 + 5;
	const int top = Mth::Max(18, height / 7);
	const int rowGap = Mth::Max(bh + 2, Mth::Min(bh + 6, height / 9));

	bSize->width = bType->width = bTheme->width = bBiomes->width = bw;
	bSize->x = colL;   bSize->y = top;
	bType->x = colR;   bType->y = top;
	bTheme->x = colL;  bTheme->y = top + rowGap;
	bBiomes->x = colR; bBiomes->y = top + rowGap;

	bSeed->width = 2 * bw + 10;
	bSeed->x = colL; bSeed->y = top + 2 * rowGap;

	bMode->width = 2 * bw + 10;
	bMode->x = colL; bMode->y = top + 3 * rowGap;
	bCreate->width = bw;
	bCreate->x = width / 2 - bw / 2;
	bCreate->y = bMode->y + bMode->height + 14 + Mth::Max(2, height / 30);

	bBack->width = 80;
	bBack->x = width - bBack->width - 8;
	bBack->y = height - bBack->height - 6;
}

void SimpleChooseLevelScreen::render( int xm, int ym, float a )
{
#ifdef EMSCRIPTEN
	std::string typed;
	if (takeSeedFromPage(typed)) {
		if (typed.size() > 32) typed.resize(32);
		s_seedText = typed;
		updateLabels();
	}
#endif
	renderDirtBackground(0);
    glEnable2(GL_BLEND);

	drawCenteredString(minecraft->font, "Create World", width / 2, Mth::Max(2, bSize->y - 14), 0xffffffff);
	drawCenteredString(minecraft->font,
		s_creative ? "Unlimited resources and flying" : "Mobs, health and gathering resources",
		width / 2, bMode->y + bMode->height + 3, 0xffcccccc);

	Screen::render(xm, ym, a);
    glDisable2(GL_BLEND);
}

void SimpleChooseLevelScreen::buttonClicked( Button* button )
{
	if (button == bBack) {
		minecraft->screenChooser.setScreen(SCREEN_STARTMENU);
		return;
	}
	if (button == bSize) {
		const SizeChoice* list; int def;
		const int n = sizeChoices(phoneDevice(minecraft), &list, &def);
		int cur = def;
		for (int i = 0; i < n; ++i) if (list[i].chunks == s_options.size) cur = i;
		s_options.size = list[(cur + 1) % n].chunks;
		updateLabels();
		return;
	}
	if (button == bSeed) {
#ifdef EMSCRIPTEN
		EM_ASM({
			if (Module.mcAskText) Module.mcAskText('World seed',
				'Any text or number gives the same world every time. Leave it empty for a random one.',
				UTF8ToString($0), 32, 'mcSeedPending');
		}, s_seedText.c_str());
#endif
		return;
	}
	if (button == bType)   { s_options.type = (s_options.type + 1) % WorldType::COUNT; updateLabels(); return; }
	if (button == bTheme)  { s_options.theme = (s_options.theme + 1) % WorldTheme::COUNT; updateLabels(); return; }
	if (button == bBiomes) {
		s_options.biomes = s_options.biomes == WorldBiomes::MODERN ? WorldBiomes::LEGACY : WorldBiomes::MODERN;
		updateLabels();
		return;
	}
	if (button == bMode) { s_creative = !s_creative; updateLabels(); return; }
	if (button != bCreate) return;
	if (hasChosen)
		return;

	const int gameType = s_creative ? GameType::Creative : GameType::Survival;

	std::string levelId = getUniqueLevelName(levelName);
	LevelSettings settings(seedFromText(s_seedText), gameType);
	settings.gen = s_options;
#ifdef __EMSCRIPTEN__
	// Show ProgressScreen first, then defer level creation to next frame so it can render
	// before we block on generation. prepareLevel will yield to allow progress updates.
	minecraft->setScreen(new ProgressScreen());
	minecraft->scheduleLevelCreation(levelId, levelId, settings.getSeed(), gameType, s_options);
#else
	minecraft->selectLevel(levelId, levelId, settings);
	minecraft->hostMultiplayer();
	minecraft->setScreen(new ProgressScreen());
#endif
	hasChosen = true;
}

bool SimpleChooseLevelScreen::handleBackEvent(bool isDown) {
	if (!isDown)
		minecraft->screenChooser.setScreen(SCREEN_STARTMENU);
	return true;
}
