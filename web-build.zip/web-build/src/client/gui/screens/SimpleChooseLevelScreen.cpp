#include <cstdlib>
#include "SimpleChooseLevelScreen.h"
#include "ProgressScreen.h"
#include "ScreenChooser.h"
#include "../components/Button.h"
#include "../../Minecraft.h"
#include "../../../world/level/LevelSettings.h"
#include "../../../platform/time.h"
#include "../../../util/Mth.h"
#include "../../../world/ModBiomes.h"

static WorldGenOptions s_options;
static bool s_chosen = false;
static std::string s_seedText;
static int s_gameMode = 0;
int g_nextWorldHeight = 0;
static int s_skySize = 0;
static std::string s_installing;
static bool s_installFailed = false;
static bool s_modsOn = false;
static bool s_typePicked = false;
static void fitModType() {
	const std::vector<ModBiomes::WorldTypeDef>& t = ModBiomes::worldTypes();
	if (!s_options.modType.empty() && !ModBiomes::findType(s_options.modType)) s_options.modType.clear();
	if (!s_typePicked && s_options.modType.empty() && !t.empty() && s_options.type == WorldType::DEFAULT) s_options.modType = t.back().key;
}

#ifdef EMSCRIPTEN
#include <emscripten.h>
static bool takeSeedFromPage(std::string& out) {
	char buf[64];
	const int got = EM_ASM_INT({
		var s = Module.mcSeedPending;
		if (typeof s !== 'string') return 0;
		Module.mcSeedPending = null;
		stringToUTF8(s, $0, $1);
		return 1;
	}, buf, (int)sizeof buf);
	if (!got) return false;
	out = buf;
	return true;
}
#endif

long SimpleChooseLevelScreen::seedFromText(const std::string& text) {
	if (text.empty()) return getEpochTimeS();
	char* end = NULL;
	const long long v = strtoll(text.c_str(), &end, 10);
	if (end && *end == 0) return (long)(int)v;
	int h = 0;
	for (unsigned int i = 0; i < text.size(); ++i) h = 31 * h + (unsigned char)text[i];
	return (long)h;
}

#ifdef EMSCRIPTEN
extern "C" int mcIsPhoneDevice();
static bool phoneDevice(Minecraft*) { return mcIsPhoneDevice() != 0; }
#else
static bool phoneDevice(Minecraft* mc) { return mc->useTouchscreen(); }
#endif

static void skySizes(bool phone, int chunks[2], const char* names[2]) {
	chunks[0] = WorldSize::LARGE;  names[0] = "Large (1024)";
	chunks[1] = phone ? WorldSize::EXTREME : WorldSize::INFINITE_CHUNKS;
	names[1] = phone ? "Extreme (2048)" : "Infinite (no friends)";
}

static const char* const TYPE_NAMES[WorldType::COUNT] = { "Default", "Island", "Inland", "Floating", "Flat" };
static const char* const THEME_NAMES[WorldTheme::COUNT] = { "Normal", "Hell", "Paradise", "Woods" };

int SimpleChooseLevelScreen::sizeChoices(bool phone, const SizeChoice** out, int* defaultIndex) {
	static const SizeChoice pc[] = {
		{ WorldSize::TINY,    "Tiny (128)" },
		{ WorldSize::SMALL,   "Small (256)" },
		{ WorldSize::NORMAL,  "Normal (512)" },
		{ WorldSize::LARGE,   "Large (1024)" },
		{ WorldSize::EXTREME, "Extreme (2048)" },
		{ WorldSize::INFINITE_CHUNKS, "Infinite" },
	};
	static const SizeChoice mobile[] = {
		{ WorldSize::TINY,    "Small (128)" },
		{ WorldSize::SMALL,   "Normal (256)" },
		{ WorldSize::NORMAL,  "Large (512)" },
	};
	if (phone) { *out = mobile; *defaultIndex = 2; return 3; }
	*out = pc; *defaultIndex = 3;
	return 6;
}

SimpleChooseLevelScreen::SimpleChooseLevelScreen(const std::string& levelName)
:	bMode(0),
	bCreate(0),
	bBack(0),
	bSize(0), bType(0), bTheme(0), bBiomes(0), bSeed(0), bTall(0),
	levelName(levelName),
	hasChosen(false)
{
}

SimpleChooseLevelScreen::~SimpleChooseLevelScreen()
{
	delete bMode;
	delete bCreate;
	delete bBack;
	delete bSize;
	delete bType;
	delete bTheme;
	delete bBiomes;
	delete bSeed;
	delete bTall;
}

void SimpleChooseLevelScreen::init()
{
	const bool phone = phoneDevice(minecraft);
	if (!s_chosen) {
		const SizeChoice* list; int def;
		sizeChoices(phone, &list, &def);
		s_options = WorldGenOptions();
		s_options.size = list[def].chunks;
		s_options.biomes = WorldBiomes::MODERN;
		s_chosen = true;
	} else {
		const SizeChoice* list; int def;
		const int n = sizeChoices(phone, &list, &def);
		bool ok = false;
		for (int i = 0; i < n; ++i) ok = ok || list[i].chunks == s_options.size;
		if (!ok) s_options.size = list[def].chunks;
	}

	if (minecraft->useTouchscreen()) {
		bCreate   = new Touch::TButton(1, "Create World");
		bMode     = new Touch::TButton(2, "");
		bBack	  = new Touch::TButton(3, "Back");
		bSize     = new Touch::TButton(4, "");
		bType     = new Touch::TButton(5, "");
		bTheme    = new Touch::TButton(6, "");
		bBiomes   = new Touch::TButton(7, "");
		bSeed     = new Touch::TButton(8, "");
		bTall     = new Touch::TButton(9, "");
	} else {
		bCreate   = new Button(1, "Create World");
		bMode     = new Button(2, "");
		bBack	  = new Button(3, "Back");
		bSize     = new Button(4, "");
		bType     = new Button(5, "");
		bTheme    = new Button(6, "");
		bBiomes   = new Button(7, "");
		bSeed     = new Button(8, "");
		bTall     = new Button(9, "");
	}
	updateLabels();
	Button* all[] = { bSize, bType, bTheme, bBiomes, bSeed, bTall, bMode, bCreate, bBack };
	for (int i = 0; i < 9; ++i) {
		buttons.push_back(all[i]);
		tabButtons.push_back(all[i]);
	}
}

void SimpleChooseLevelScreen::updateLabels()
{
	const SizeChoice* list; int def;
	const int n = sizeChoices(phoneDevice(minecraft), &list, &def);
	const char* sizeName = list[def].name;
	for (int i = 0; i < n; ++i) if (list[i].chunks == s_options.size) sizeName = list[i].name;
	bSize->msg = std::string("Size: ") + sizeName;
	fitModType();
	const ModBiomes::WorldTypeDef* mt = s_options.modType.empty() ? NULL : ModBiomes::findType(s_options.modType);
	bType->msg = std::string("Type: ") + (mt ? mt->name.c_str() : TYPE_NAMES[s_options.type]);
	bTheme->msg = std::string("Theme: ") + THEME_NAMES[s_options.theme];
#ifdef EMSCRIPTEN
	s_modsOn = EM_ASM_INT({ return Module.mcMods && Module.mcMods.hasEnabled && Module.mcMods.hasEnabled() ? 1 : 0; }) != 0;
#endif
	bBiomes->msg = std::string("Biomes: ") + (s_options.biomes == WorldBiomes::MODERN ? "Rocket" : "Classic PE");
	if (s_gameMode == 2) s_seedText = "404";
	{
		std::string shown = s_seedText;
		if (shown.size() > 12) shown = shown.substr(0, 11) + "...";
		bSeed->msg = std::string("Seed: ") + (s_seedText.empty() ? "Random" : shown);
	}
	if (g_nextWorldHeight == 128 || g_nextWorldHeight == 256) { s_options.height = g_nextWorldHeight; g_nextWorldHeight = 0; }
	bTall->msg = std::string("Tall World: ") + (s_gameMode == 2 ? "Off" : s_options.height == 256 ? "On (256)" : "Off");
	bTall->active = s_gameMode != 2;
	bMode->msg = std::string("Game Mode: ") + (s_gameMode == 1 ? "Creative" : (s_gameMode == 2 ? "404 Challenge"
		: (s_gameMode == 3 ? "Skyblock" : "Survival")));
	bBiomes->active = s_options.type == WorldType::DEFAULT && s_gameMode != 2 && s_gameMode != 3 && !mt;
	if (mt) bBiomes->msg = "Biomes: Rocket";
	bType->active = s_gameMode != 2 && s_gameMode != 3;
	bTheme->active = s_gameMode != 2 && s_gameMode != 3;
	if (s_gameMode == 3) {
		int chunks[2]; const char* names[2];
		skySizes(phoneDevice(minecraft), chunks, names);
		bSize->msg = std::string("Size: ") + names[s_skySize & 1];
		bType->msg = "Type: Skyblock";
		bSize->active = true;
		bSeed->active = true;
	} else if (s_gameMode == 2) {
		bSize->active = false;
		bSeed->active = false;
		s_seedText = "404";
	} else {
		bSize->active = true;
		bSeed->active = true;
	}
}

void SimpleChooseLevelScreen::setupPositions()
{
	const int bw = Mth::Min(150, (width - 30) / 2);
	const int bh = bSize->height;
	const int colL = width / 2 - bw - 5, colR = width / 2 + 5;
	const int top = Mth::Max(18, height / 7);
	const int rowGap = Mth::Max(bh + 2, Mth::Min(bh + 6, height / 9));

	bSize->width = bType->width = bTheme->width = bBiomes->width = bw;
	bSize->x = colL;   bSize->y = top;
	bType->x = colR;   bType->y = top;
	bTheme->x = colL;  bTheme->y = top + rowGap;
	bBiomes->x = colR; bBiomes->y = top + rowGap;

	bSeed->width = bTall->width = bw;
	bSeed->x = colL; bSeed->y = top + 2 * rowGap;
	bTall->x = colR; bTall->y = top + 2 * rowGap;

	bMode->width = 2 * bw + 10;
	bMode->x = colL; bMode->y = top + 3 * rowGap;
	bCreate->width = bw;
	bCreate->x = width / 2 - bw / 2;
	bCreate->y = bMode->y + bMode->height + 24 + Mth::Max(2, height / 30);

	bBack->width = 80;
	bBack->x = width - bBack->width - 8;
	bBack->y = height - bBack->height - 6;
}

void SimpleChooseLevelScreen::render( int xm, int ym, float a )
{
#ifdef EMSCRIPTEN
	if (!s_installing.empty()) {
		const int st = EM_ASM_INT({ return Module.mcInstall404 | 0; });
		if (st == 1) {
			const std::string id = s_installing;
			s_installing.clear();
			minecraft->selectLevel(id, "404", LevelSettings::None());
			minecraft->hostMultiplayer();
			minecraft->setScreen(new ProgressScreen());
			return;
		}
		if (st == -1) {
			s_installing.clear();
			s_installFailed = true;
			hasChosen = false;
		}
	}
#endif
#ifdef EMSCRIPTEN
	std::string typed;
	if (takeSeedFromPage(typed)) {
		if (typed.size() > 32) typed.resize(32);
		s_seedText = typed;
		updateLabels();
	}
#endif
	renderDirtBackground(0);
    glEnable2(GL_BLEND);

	drawCenteredString(minecraft->font, "Create World", width / 2, Mth::Max(2, bSize->y - 14), 0xffffffff);
	if (!s_installing.empty())
		drawCenteredString(minecraft->font, "Loading the 404 world...", width / 2, bCreate->y + bCreate->height + 4, 0xffffff60);
	else if (s_installFailed)
		drawCenteredString(minecraft->font, "Couldn't load the 404 world (check your connection)", width / 2, bCreate->y + bCreate->height + 4, 0xffff6060);
	else if (s_modsOn && s_gameMode != 2 && s_gameMode != 3 && s_options.type == WorldType::DEFAULT && s_options.biomes != WorldBiomes::MODERN)
		drawCenteredString(minecraft->font, "Mods are on: Classic PE worlds may break them - Rocket is made for mods",
			width / 2, bCreate->y + bCreate->height + 4, 0xffffaa33);
	else if (s_gameMode != 2 && s_gameMode != 3 && s_options.biomes == WorldBiomes::MODERN) {
		const SizeChoice* list; int def;
		const int n = sizeChoices(phoneDevice(minecraft), &list, &def);
		int cur = -1, large = n;
		for (int i = 0; i < n; ++i) {
			if (list[i].chunks == s_options.size) cur = i;
			if (large == n && std::string(list[i].name).compare(0, 5, "Large") == 0) large = i;
		}
		if (cur >= 0 && cur < large)
			drawCenteredString(minecraft->font, "Rocket biomes are best experienced on a Large world or bigger",
				width / 2, bCreate->y + bCreate->height + 4, 0xffffdd55);
	}
	if (s_modsOn && s_installing.empty() && !s_installFailed && !minecraft->options.preloadChunks && s_options.size < WorldSize::INFINITE_CHUNKS)
		drawCenteredString(minecraft->font, "Mods run smoother with Pre-load Chunks on (Settings > Graphics)",
			width / 2, bCreate->y + bCreate->height + 14, 0xffffdd55);
	if (s_gameMode == 2) {
		drawCenteredString(minecraft->font, "Gather until nightfall, then dig down and never return!",
			width / 2, bMode->y + bMode->height + 3, 0xffcccccc);
		drawCenteredString(minecraft->font, "Hardcore: one life. Die and the world is deleted.",
			width / 2, bMode->y + bMode->height + 13, 0xffff5555);
	} else if (s_gameMode == 3) {
		drawCenteredString(minecraft->font, "Start on a tiny island over the void - bridge out to the others",
			width / 2, bMode->y + bMode->height + 3, 0xffcccccc);
		drawCenteredString(minecraft->font, "Every island is its own biome. No Nether or End.",
			width / 2, bMode->y + bMode->height + 13, 0xffcccccc);
	} else {
		drawCenteredString(minecraft->font,
			s_gameMode == 1 ? "Unlimited resources and flying" : "Mobs, health and gathering resources",
			width / 2, bMode->y + bMode->height + 3, 0xffcccccc);
	}

	Screen::render(xm, ym, a);
    glDisable2(GL_BLEND);
}

void SimpleChooseLevelScreen::buttonClicked( Button* button )
{
	if (button == bBack) {
		minecraft->screenChooser.setScreen(SCREEN_STARTMENU);
		return;
	}
	if (button == bSize && s_gameMode == 3) {
		s_skySize ^= 1;
		updateLabels();
		return;
	}
	if (button == bSize) {
		const SizeChoice* list; int def;
		const int n = sizeChoices(phoneDevice(minecraft), &list, &def);
		int cur = def;
		for (int i = 0; i < n; ++i) if (list[i].chunks == s_options.size) cur = i;
		s_options.size = list[(cur + 1) % n].chunks;
		if (s_gameMode == 2 && s_options.size == WorldSize::INFINITE_CHUNKS) {
			s_options.size = list[0].chunks;
		}
		updateLabels();
		return;
	}
	if (button == bSeed) {
#ifdef EMSCRIPTEN
		EM_ASM({
			if (Module.mcAskText) Module.mcAskText('World seed',
				'Any text or number gives the same world every time. Leave it empty for a random one.',
				UTF8ToString($0), 32, 'mcSeedPending');
		}, s_seedText.c_str());
#endif
		return;
	}
	if (button == bType) {
		s_typePicked = true;
		const std::vector<ModBiomes::WorldTypeDef>& t = ModBiomes::worldTypes();
		int at = -1;
		for (size_t i = 0; i < t.size(); ++i) if (t[i].key == s_options.modType) at = (int)i;
		if (at >= 0) {
			if (at + 1 < (int)t.size()) s_options.modType = t[at + 1].key;
			else { s_options.modType.clear(); s_options.type = WorldType::DEFAULT; }
		} else if (s_options.type + 1 < WorldType::COUNT) s_options.type = s_options.type + 1;
		else if (!t.empty()) { s_options.type = WorldType::DEFAULT; s_options.modType = t[0].key; }
		else s_options.type = WorldType::DEFAULT;
		updateLabels();
		return;
	}
	if (button == bTall) { s_options.height = s_options.height == 256 ? 128 : 256; updateLabels(); return; }
	if (button == bTheme)  { s_options.theme = (s_options.theme + 1) % WorldTheme::COUNT; updateLabels(); return; }
	if (button == bBiomes) {
		s_options.biomes = s_options.biomes == WorldBiomes::MODERN ? WorldBiomes::LEGACY : WorldBiomes::MODERN;
		updateLabels();
		return;
	}
	if (button == bMode) {
		s_gameMode = (s_gameMode + 1) % 4;
		if (s_gameMode == 3) s_seedText = "";
		updateLabels();
		return;
	}
	if (button != bCreate) return;
	if (hasChosen)
		return;

	const int gameType = s_gameMode == 3 ? GameType::Survival : s_gameMode;

#ifdef EMSCRIPTEN
	if (gameType == GameType::Challenge404) {
		ChooseLevelScreen::init();
		s_installing = getUniqueLevelName("404");
		s_installFailed = false;
		hasChosen = true;
		const std::string dst = minecraft->externalStoragePath + "/games/com.mojang/minecraftWorlds/" + s_installing;
		EM_ASM({ if (Module.mcInstallWorld) Module.mcInstallWorld('worlds/404/', UTF8ToString($0), 'mcInstall404'); else Module.mcInstall404 = -1; },
			dst.c_str());
		return;
	}
#endif


	std::string levelId = getUniqueLevelName(levelName);
	LevelSettings settings(seedFromText(s_seedText), gameType);
	s_options.revision = GenRevision::CURRENT;
	WorldGenOptions gen = s_options;
	if (!gen.modType.empty()) { gen.type = WorldType::DEFAULT; gen.biomes = WorldBiomes::MODERN; }
	if (s_gameMode == 2 || s_gameMode == 3) gen.modType.clear();
	if (g_nextWorldHeight == 128 || g_nextWorldHeight == 256) { gen.height = s_options.height = g_nextWorldHeight; g_nextWorldHeight = 0; }
	if (gen.height != 256 || s_gameMode == 2) gen.height = 128;
	if (s_gameMode == 3) {
		gen.type = WorldType::SKYBLOCK;
		int chunks[2]; const char* names[2];
		skySizes(phoneDevice(minecraft), chunks, names);
		gen.size = chunks[s_skySize & 1];
		gen.theme = WorldTheme::NORMAL;
		gen.biomes = WorldBiomes::MODERN;
	}
	settings.gen = gen;
#ifdef __EMSCRIPTEN__
	// Show ProgressScreen first, then defer level creation to next frame so it can render
	// before we block on generation. prepareLevel will yield to allow progress updates.
	minecraft->setScreen(new ProgressScreen());
	minecraft->scheduleLevelCreation(levelId, levelId, settings.getSeed(), gameType, gen);
#else
	minecraft->selectLevel(levelId, levelId, settings);
	minecraft->hostMultiplayer();
	minecraft->setScreen(new ProgressScreen());
#endif
	hasChosen = true;
}

bool SimpleChooseLevelScreen::handleBackEvent(bool isDown) {
	if (!isDown)
		minecraft->screenChooser.setScreen(SCREEN_STARTMENU);
	return true;
}
