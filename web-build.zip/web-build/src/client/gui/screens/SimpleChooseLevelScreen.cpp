#include "SimpleChooseLevelScreen.h"
#include "ProgressScreen.h"
#include "ScreenChooser.h"
#include "../components/Button.h"
#include "../../Minecraft.h"
#include "../../../world/level/LevelSettings.h"
#include "../../../platform/time.h"
#include "../../../util/Mth.h"

static WorldGenOptions s_options;
static bool s_chosen = false;

#ifdef EMSCRIPTEN
extern "C" int mcIsPhoneDevice();
static bool phoneDevice(Minecraft*) { return mcIsPhoneDevice() != 0; }
#else
static bool phoneDevice(Minecraft* mc) { return mc->useTouchscreen(); }
#endif

static const char* const TYPE_NAMES[WorldType::COUNT] = { "Default", "Island", "Inland", "Floating", "Flat" };
static const char* const THEME_NAMES[WorldTheme::COUNT] = { "Normal", "Hell", "Paradise", "Woods" };

int SimpleChooseLevelScreen::sizeChoices(bool phone, const SizeChoice** out, int* defaultIndex) {
	static const SizeChoice pc[] = {
		{ WorldSize::TINY,    "Tiny (128)" },
		{ WorldSize::SMALL,   "Small (256)" },
		{ WorldSize::NORMAL,  "Normal (512)" },
		{ WorldSize::LARGE,   "Large (1024)" },
		{ WorldSize::EXTREME, "Extreme (2048)" },
		{ WorldSize::INFINITE_CHUNKS, "Infinite" },
	};
	static const SizeChoice mobile[] = {
		{ WorldSize::TINY,    "Small (128)" },
		{ WorldSize::SMALL,   "Normal (256)" },
		{ WorldSize::NORMAL,  "Large (512)" },
	};
	if (phone) { *out = mobile; *defaultIndex = 1; return 3; }
	*out = pc; *defaultIndex = 2;
	return 6;
}

SimpleChooseLevelScreen::SimpleChooseLevelScreen(const std::string& levelName)
:	bCreative(0),
	bSurvival(0),
	bBack(0),
	bSize(0), bType(0), bTheme(0), bBiomes(0),
	levelName(levelName),
	hasChosen(false)
{
}

SimpleChooseLevelScreen::~SimpleChooseLevelScreen()
{
	delete bCreative;
	delete bSurvival;
	delete bBack;
	delete bSize;
	delete bType;
	delete bTheme;
	delete bBiomes;
}

void SimpleChooseLevelScreen::init()
{
	const bool phone = phoneDevice(minecraft);
	if (!s_chosen) {
		const SizeChoice* list; int def;
		sizeChoices(phone, &list, &def);
		s_options = WorldGenOptions();
		s_options.size = list[def].chunks;
		s_options.biomes = WorldBiomes::MODERN;
		s_chosen = true;
	} else {
		const SizeChoice* list; int def;
		const int n = sizeChoices(phone, &list, &def);
		bool ok = false;
		for (int i = 0; i < n; ++i) ok = ok || list[i].chunks == s_options.size;
		if (!ok) s_options.size = list[def].chunks;
	}

	if (minecraft->useTouchscreen()) {
		bCreative = new Touch::TButton(1, "Creative mode");
		bSurvival = new Touch::TButton(2, "Survival mode");
		bBack	  = new Touch::TButton(3, "Back");
		bSize     = new Touch::TButton(4, "");
		bType     = new Touch::TButton(5, "");
		bTheme    = new Touch::TButton(6, "");
		bBiomes   = new Touch::TButton(7, "");
	} else {
		bCreative = new Button(1, "Creative mode");
		bSurvival = new Button(2, "Survival mode");
		bBack	  = new Button(3, "Back");
		bSize     = new Button(4, "");
		bType     = new Button(5, "");
		bTheme    = new Button(6, "");
		bBiomes   = new Button(7, "");
	}
	updateLabels();
	Button* all[] = { bSize, bType, bTheme, bBiomes, bCreative, bSurvival, bBack };
	for (int i = 0; i < 7; ++i) {
		buttons.push_back(all[i]);
		tabButtons.push_back(all[i]);
	}
}

void SimpleChooseLevelScreen::updateLabels()
{
	const SizeChoice* list; int def;
	const int n = sizeChoices(phoneDevice(minecraft), &list, &def);
	const char* sizeName = list[def].name;
	for (int i = 0; i < n; ++i) if (list[i].chunks == s_options.size) sizeName = list[i].name;
	bSize->msg = std::string("Size: ") + sizeName;
	bType->msg = std::string("Type: ") + TYPE_NAMES[s_options.type];
	bTheme->msg = std::string("Theme: ") + THEME_NAMES[s_options.theme];
	bBiomes->msg = std::string("Biomes: ") + (s_options.biomes == WorldBiomes::MODERN ? "1.5" : "Classic PE");
	bBiomes->active = s_options.type == WorldType::DEFAULT;
}

void SimpleChooseLevelScreen::setupPositions()
{
	const int bw = Mth::Min(150, (width - 30) / 2);
	const int bh = bSize->height;
	const int colL = width / 2 - bw - 5, colR = width / 2 + 5;
	const int top = Mth::Max(18, height / 7);
	const int rowGap = Mth::Max(bh + 2, Mth::Min(bh + 6, height / 9));

	bSize->width = bType->width = bTheme->width = bBiomes->width = bw;
	bSize->x = colL;   bSize->y = top;
	bType->x = colR;   bType->y = top;
	bTheme->x = colL;  bTheme->y = top + rowGap;
	bBiomes->x = colR; bBiomes->y = top + rowGap;

	bCreative->width = bSurvival->width = bw;
	const int modeY = top + 2 * rowGap + Mth::Max(6, height / 14);
	bCreative->x = colL; bCreative->y = modeY;
	bSurvival->x = colR; bSurvival->y = modeY;

	bBack->width = 80;
	bBack->x = width - bBack->width - 8;
	bBack->y = height - bBack->height - 6;
}

void SimpleChooseLevelScreen::render( int xm, int ym, float a )
{
	renderDirtBackground(0);
    glEnable2(GL_BLEND);

	drawCenteredString(minecraft->font, "Create World", width / 2, Mth::Max(2, bSize->y - 14), 0xffffffff);
	const int ty = bSurvival->y + bSurvival->height + 4;
	drawCenteredString(minecraft->font, "Mobs, health and", bSurvival->x + bSurvival->width / 2, ty, 0xffcccccc);
	drawCenteredString(minecraft->font, "gathering resources", bSurvival->x + bSurvival->width / 2, ty + 10, 0xffcccccc);
	drawCenteredString(minecraft->font, "Unlimited resources", bCreative->x + bCreative->width / 2, ty, 0xffcccccc);
	drawCenteredString(minecraft->font, "and flying", bCreative->x + bCreative->width / 2, ty + 10, 0xffcccccc);

	Screen::render(xm, ym, a);
    glDisable2(GL_BLEND);
}

void SimpleChooseLevelScreen::buttonClicked( Button* button )
{
	if (button == bBack) {
		minecraft->screenChooser.setScreen(SCREEN_STARTMENU);
		return;
	}
	if (button == bSize) {
		const SizeChoice* list; int def;
		const int n = sizeChoices(phoneDevice(minecraft), &list, &def);
		int cur = def;
		for (int i = 0; i < n; ++i) if (list[i].chunks == s_options.size) cur = i;
		s_options.size = list[(cur + 1) % n].chunks;
		updateLabels();
		return;
	}
	if (button == bType)   { s_options.type = (s_options.type + 1) % WorldType::COUNT; updateLabels(); return; }
	if (button == bTheme)  { s_options.theme = (s_options.theme + 1) % WorldTheme::COUNT; updateLabels(); return; }
	if (button == bBiomes) {
		s_options.biomes = s_options.biomes == WorldBiomes::MODERN ? WorldBiomes::LEGACY : WorldBiomes::MODERN;
		updateLabels();
		return;
	}
	if (button != bCreative && button != bSurvival) return;
	if (hasChosen)
		return;

	int gameType;

	if (button == bCreative)
		gameType = GameType::Creative;

	if (button == bSurvival)
		gameType = GameType::Survival;

	std::string levelId = getUniqueLevelName(levelName);
	LevelSettings settings(getEpochTimeS(), gameType);
	settings.gen = s_options;
#ifdef __EMSCRIPTEN__
	// Show ProgressScreen first, then defer level creation to next frame so it can render
	// before we block on generation. prepareLevel will yield to allow progress updates.
	minecraft->setScreen(new ProgressScreen());
	minecraft->scheduleLevelCreation(levelId, levelId, settings.getSeed(), gameType, s_options);
#else
	minecraft->selectLevel(levelId, levelId, settings);
	minecraft->hostMultiplayer();
	minecraft->setScreen(new ProgressScreen());
#endif
	hasChosen = true;
}

bool SimpleChooseLevelScreen::handleBackEvent(bool isDown) {
	if (!isDown)
		minecraft->screenChooser.setScreen(SCREEN_STARTMENU);
	return true;
}
