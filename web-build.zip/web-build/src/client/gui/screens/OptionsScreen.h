#ifndef NET_MINECRAFT_CLIENT_GUI_SCREENS__OptionsScreen_H__
#define NET_MINECRAFT_CLIENT_GUI_SCREENS__OptionsScreen_H__

#include "../Screen.h"
#include "../components/Button.h"

class ImageButton;
class OptionsPane;

class OptionsScreen: public Screen
{
	typedef Screen super;
	void init();

	void generateOptionScreens();

public:
	bool closeButtonRect(int& x, int& y, int& w, int& h);
	OptionsScreen();
	~OptionsScreen();
	void setupPositions();
	void buttonClicked( Button* button );
	void render(int xm, int ym, float a);
	void removed();
	void selectCategory(int index);

	virtual void keyPressed(int eventKey);
	virtual void mouseClicked( int x, int y, int buttonNum );
	virtual void mouseReleased( int x, int y, int buttonNum );
	virtual void mouseWheel(int x, int y, int notches);
	virtual void tick();
private:
	void layoutPane();
	int viewTop() const;
	int viewBottom() const;
	bool pointOnSlider(int x, int y) const;
	int paneTop;
	int scrollY, maxScroll;
	bool dragging, dragScrolling, dragOnSlider;
	int dragStartY, dragStartScroll;
	Touch::THeader* bHeader;
	ImageButton* btnClose;
	Button* btnUsername;
	Button* btnKeys;
	std::vector<Button*> categoryButtons;
	bool javaLayout;
	Button* btnDone;
	std::vector<OptionsPane*> optionPanes;
	OptionsPane* currentOptionPane;
	int selectedCategory;
};

#endif /*NET_MINECRAFT_CLIENT_GUI_SCREENS__OptionsScreen_H__*/
