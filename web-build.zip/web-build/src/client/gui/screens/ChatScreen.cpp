#include "ChatScreen.h"
#include "../../../world/ModScripts.h"
#include "../Gui.h"
#include "../NewChat.h"
#include "../Font.h"
#include "../../Minecraft.h"
#include "../../../AppPlatform.h"
#include "../../../platform/log.h"
#include "../../../platform/input/Mouse.h"
#include "../../../platform/input/Keyboard.h"
#include "../../renderer/Tesselator.h"
#include "../../renderer/gles.h"
#include "../../sound/SoundEngine.h"
#include <cctype>

#ifdef EMSCRIPTEN
#include <emscripten.h>
#include "../../../network/RakNetInstance.h"
#include "../../../network/packet/MessagePacket.h"
#include "../../player/LocalPlayer.h"
#include "../../../world/level/Level.h"
extern Minecraft* webCurrentGame();
extern "C" int mcIsTouchMode();

EM_JS(int, cs_submit, (const char* text), {
	try { if (Module.mcCommands && Module.mcCommands.submit) { Module.mcCommands.submit(UTF8ToString(text)); return 1; } }
	catch (e) { console.warn('[chat] submit', e); return 1; }
	return 0;
});
EM_JS(void, cs_complete_start, (const char* before), {
	try { if (Module.mcCommands && Module.mcCommands.completeStart) Module.mcCommands.completeStart(UTF8ToString(before)); } catch (e) { console.warn('[chat] complete', e); }
});
EM_JS(int, cs_complete_take, (char* buf, int cap), {
	try {
		var C = Module.mcCommands;
		if (!C || !C.completeTake) return -1;
		var r = C.completeTake();
		if (r == null) return -1;
		stringToUTF8(r.join('\n'), buf, cap);
		return r.length;
	} catch (e) { return -1; }
});
EM_JS(int, cs_suggest, (const char* text, int cursor, char* buf, int cap), {
	try {
		var C = Module.mcCommands;
		if (!C || !C.suggest) return 0;
		stringToUTF8(String(C.suggest(UTF8ToString(text), cursor) || ''), buf, cap);
		return 1;
	} catch (e) { return 0; }
});
EM_JS(void, cs_chat_state, (int open, int touch), {
	try { Module.mcChatOpen = open ? (touch ? 2 : 1) : 0; if (!open && Module.mcCommands) Module.mcCommands.clipSel = ''; } catch (e) { }
});
EM_JS(int, cs_kb_inset, (), {
	try { return Module.mcTextIn ? Module.mcTextIn.inset() | 0 : 0; } catch (e) { return 0; }
});
EM_JS(void, cs_textin_open, (const char* v, int s, int e), {
	try { if (Module.mcTextIn) Module.mcTextIn.open(UTF8ToString(v), s, e); } catch (x) { }
});
EM_JS(void, cs_textin_close, (), {
	try { if (Module.mcTextIn) Module.mcTextIn.close(); } catch (x) { }
});
EM_JS(void, cs_textin_set, (const char* v, int s, int e), {
	try { if (Module.mcTextIn) Module.mcTextIn.set(UTF8ToString(v), s, e); } catch (x) { }
});
EM_JS(void, cs_textin_arm, (), {
	try { if (Module.mcTextIn) Module.mcTextIn.arm(); } catch (x) { }
});
EM_JS(int, cs_textin_state, (char* buf, int cap), {
	try {
		var T = Module.mcTextIn;
		if (!T || !T.el) return -1;
		var el = T.el;
		stringToUTF8((el.selectionStart | 0) + '\t' + (el.selectionEnd | 0) + '\t' + (T.enters | 0) + '\t' + (T.escapes | 0) + '\t' + el.value, buf, cap);
		return T.ver | 0;
	} catch (e) { return -1; }
});

void webOpenChat(const char* prefix) {
	Minecraft* mc = webCurrentGame();
	if (mc && mc->level && mc->player && !mc->screen) mc->setScreen(new ChatScreen(prefix ? prefix : ""));
}
extern "C" EMSCRIPTEN_KEEPALIVE void mcChatSend(const char* raw) {
	Minecraft* mc = webCurrentGame();
	if (!mc || !mc->level || !mc->player || !raw) return;
	std::string text(raw);
	while (!text.empty() && (text[text.size() - 1] == ' ' || text[text.size() - 1] == '\t')) text.erase(text.size() - 1);
	while (!text.empty() && text[0] == ' ') text.erase(0, 1);
	if (text.empty()) return;
	if (text.size() > 100) text.resize(100);
	if (text[0] == '/') {
		if (!ModScripts::command(mc, text)) mc->gui.addMessage("\xC2\xA7" "cUnknown command. Try /help for a list of commands");
		return;
	}
	if (ModPE::hook(ModPE::CHAT, "chatHook", "[" + ModScripts::quote(text) + "]")) return;
	const std::string line = "<" + mc->player->name + "> " + text;
	if (!mc->level->isClientSide) mc->gui.addMessage(line);
	if (mc->raknetInstance) { MessagePacket packet(line.c_str()); mc->raknetInstance->send(packet); }
	ModScripts::chatted(mc, text);
}
extern "C" EMSCRIPTEN_KEEPALIVE void mcChatPrint(const char* text, int id) {
	Minecraft* mc = webCurrentGame();
	if (mc && mc->font) NewChat::setFont(mc->font);
	NewChat::print(text ? text : "", id);
}
extern "C" EMSCRIPTEN_KEEPALIVE void mcChatBroadcast(const char* text) {
	Minecraft* mc = webCurrentGame();
	if (!mc || !mc->level || !text) return;
	mc->gui.addMessage(text);
	if (mc->raknetInstance && !mc->level->isClientSide) { MessagePacket packet(text); mc->raknetInstance->send(packet); }
}
extern "C" EMSCRIPTEN_KEEPALIVE const char* mcChatHistory(int n) {
	static std::string out;
	const std::vector<std::string>& m = NewChat::messages();
	out = "[";
	for (int i = 0; i < (int)m.size() && i < n; ++i) out += (i ? "," : "") + ModScripts::quote(m[i]);
	out += "]";
	return out.c_str();
}
extern "C" EMSCRIPTEN_KEEPALIVE int mcChatIsOpen() {
	Minecraft* mc = webCurrentGame();
	return mc && mc->screen && dynamic_cast<ChatScreen*>(mc->screen) ? 1 : 0;
}
#else
static int cs_submit(const char*) { return 0; }
static void cs_complete_start(const char*) {}
static int cs_complete_take(char*, int) { return -1; }
static int cs_suggest(const char*, int, char*, int) { return 0; }
static void cs_chat_state(int, int) {}
static int cs_kb_inset() { return 0; }
static void cs_textin_open(const char*, int, int) {}
static void cs_textin_close() {}
static void cs_textin_set(const char*, int, int) {}
static void cs_textin_arm() {}
static int cs_textin_state(char*, int) { return -1; }
static int mcIsTouchMode() { return 0; }
#endif

namespace {
std::vector<std::string> s_outbox;
std::string lower(const std::string& s) { std::string o(s); for (size_t i = 0; i < o.size(); ++i) o[i] = (char)tolower((unsigned char)o[i]); return o; }
std::string trim(const std::string& s) {
	size_t a = 0, b = s.size();
	while (a < b && s[a] == ' ') ++a;
	while (b > a && s[b - 1] == ' ') --b;
	return s.substr(a, b - a);
}
void splitLines(const std::string& s, char sep, std::vector<std::string>& out) {
	size_t a = 0;
	for (;;) {
		const size_t b = s.find(sep, a);
		out.push_back(s.substr(a, b == std::string::npos ? std::string::npos : b - a));
		if (b == std::string::npos) break;
		a = b + 1;
	}
}
enum { P_NONE, P_HIST, P_SUGG, P_FIELD, P_SLASH, P_SEND, P_CLOSE };
}

ChatScreen::ChatScreen(const std::string& prefix)
:	touch(false), defaultText(prefix), historyCursor(0), completing(false), waitingCompletions(false), completionIndex(0),
	pageVer(-1), pageEnters(0), kbInset(0), panelW(0), barY(0), barH(0), slashX(0), fieldX(0), fieldW(0), sendX(0), btnW(0),
	closeX(0), closeS(0), headH(0), suggTop(0), suggRowH(0), suggRows(0), suggScroll(0), usageH(0), histTop(0), histBottom(0),
	histScroll(0), pressX(0), pressY(0), pressScroll(0), pressWhat(P_NONE), dragging(false), msgSerial(-1) {}

ChatScreen::~ChatScreen() {
	TextKeys::active = false;
	TextKeys::clear();
	if (touch) cs_textin_close();
	cs_chat_state(0, 0);
	NewChat::resetScroll();
}

void ChatScreen::init() {
	touch = mcIsTouchMode() != 0;
	TextKeys::clear();
	TextKeys::active = true;
	historyCursor = (int)NewChat::sent().size();
	field.font = font;
	field.maxLen = 100;
	field.background = touch;
	field.focused = true;
	setupPositions();
	field.setText(defaultText);
	cs_chat_state(1, touch ? 1 : 0);
	if (touch) {
		cs_textin_open(field.text.c_str(), field.cursor, field.cursor);
		pageVer = -1;
		pageEnters = 0;
		char buf[64];
		if (cs_textin_state(buf, sizeof buf) >= 0) {
			std::vector<std::string> f;
			splitLines(buf, '\t', f);
			if (f.size() >= 4) pageEnters = atoi(f[2].c_str());
		}
		refreshSuggestions();
	}
}

void ChatScreen::setupPositions() {
	if (!touch) {
		field.x = 4; field.y = height - 12; field.w = width - 4; field.h = 12;
		return;
	}
	layoutTouch();
}

bool ChatScreen::javaOpen(Minecraft* mc) {
	ChatScreen* s = mc && mc->screen ? dynamic_cast<ChatScreen*>(mc->screen) : NULL;
	return s && !s->touch;
}
bool ChatScreen::touchOpen(Minecraft* mc) {
	ChatScreen* s = mc && mc->screen ? dynamic_cast<ChatScreen*>(mc->screen) : NULL;
	return s && s->touch;
}

void ChatScreen::queueSend(const std::string& text) { s_outbox.push_back(text); }

void ChatScreen::flushOutbox(Minecraft* mc) {
	if (s_outbox.empty()) return;
	std::vector<std::string> q;
	q.swap(s_outbox);
	for (size_t i = 0; i < q.size(); ++i) {
		if (cs_submit(q[i].c_str())) continue;
#ifdef EMSCRIPTEN
		mcChatSend(q[i].c_str());
#endif
	}
}

void ChatScreen::close() { minecraft->setScreen(NULL); }

void ChatScreen::send() {
	const std::string s = trim(field.text);
	if (!s.empty()) {
		NewChat::addSent(s);
		queueSend(s);
	}
	close();
}

bool ChatScreen::handleBackEvent(bool isDown) {
	if (!isDown) close();
	return true;
}

bool ChatScreen::closeButtonRect(int& x, int& y, int& w, int& h) {
	if (!touch) return false;
	x = closeX; y = 0; w = closeS; h = closeS;
	return true;
}

void ChatScreen::sentHistory(int dir) {
	const std::vector<std::string>& sent = NewChat::sent();
	int i = historyCursor + dir;
	const int n = (int)sent.size();
	if (i < 0) i = 0;
	if (i > n) i = n;
	if (i == historyCursor) return;
	if (i == n) {
		historyCursor = n;
		field.setText(historyStash);
	} else {
		if (historyCursor == n) historyStash = field.text;
		field.setText(sent[i]);
		historyCursor = i;
	}
	fieldChanged();
}

void ChatScreen::completeWord() {
	if (completing) {
		field.deleteFromCursor(field.nthWordFromPos(-1, field.cursor, false) - field.cursor);
		if (completionIndex >= (int)completions.size()) completionIndex = 0;
	} else {
		const int i = field.nthWordFromPos(-1, field.cursor, false);
		completions.clear();
		completionIndex = 0;
		const std::string before = field.text.substr(0, field.cursor);
		if (!before.empty()) { cs_complete_start(before.c_str()); waitingCompletions = true; }
		if (completions.empty()) return;
		completing = true;
		field.deleteFromCursor(i - field.cursor);
	}
	if (completions.size() > 1) {
		std::string all;
		for (size_t k = 0; k < completions.size(); ++k) all += (k ? ", " : "") + completions[k];
		NewChat::print(all, 1);
	}
	field.writeText(completions[completionIndex++]);
	fieldChanged();
}

void ChatScreen::takeCompletions() {
	if (!waitingCompletions) return;
	char buf[8192];
	const int n = cs_complete_take(buf, sizeof buf);
	if (n < 0) return;
	waitingCompletions = false;
	completions.clear();
	if (n > 0) {
		std::vector<std::string> l;
		splitLines(buf, '\n', l);
		for (size_t k = 0; k < l.size(); ++k) if (!l[k].empty()) completions.push_back(l[k]);
	}
	if (!completions.empty()) {
		completing = true;
		completeWord();
	}
}

void ChatScreen::onKey(const TextKeys::Ev& e) {
	using namespace TextKeys;
	waitingCompletions = false;
	if (e.kind == K_TAB) {
		if (touch && !sugg.empty() && !e.shift) {
			field.setText(sugg[0].insert);
			fieldChanged();
			return;
		}
		completeWord();
		return;
	}
	completing = false;
	if (e.kind == K_ESC) { close(); return; }
	if (e.kind == K_ENTER) { send(); return; }
	if (e.kind == K_UP) { sentHistory(-1); return; }
	if (e.kind == K_DOWN) { sentHistory(1); return; }
	if (e.kind == K_PGUP) {
		if (touch) histScroll += 5; else NewChat::scroll(NewChat::lineCount(true, height) - 1);
		return;
	}
	if (e.kind == K_PGDN) {
		if (touch) { histScroll -= 5; if (histScroll < 0) histScroll = 0; } else NewChat::scroll(-(NewChat::lineCount(true, height) - 1));
		return;
	}
	const std::string before = field.text;
	const int c0 = field.cursor, s0 = field.selEnd;
	field.key(e);
	if (field.text != before || field.cursor != c0 || field.selEnd != s0) fieldChanged();
}

void ChatScreen::updateEvents() {
	if (passEvents) return;
	while (Mouse::next()) mouseEvent();
	while (Keyboard::next()) { }
	while (Keyboard::nextTextChar()) { }
	TextKeys::Ev e;
	while (minecraft->screen == this && TextKeys::next(e)) onKey(e);
	std::string pasted;
	while (ChatTextField::pastedFromPage(pasted)) {
		completing = false;
		field.writeText(pasted);
		fieldChanged();
	}
}

void ChatScreen::tick() {
	field.tick();
	takeCompletions();
	if (touch) syncFromPage();
	ChatTextField::tellPageSelection(field.selectedText());
}

void ChatScreen::fieldChanged() {
	if (touch) {
		cs_textin_set(field.text.c_str(), field.selEnd < field.cursor ? field.selEnd : field.cursor, field.selEnd < field.cursor ? field.cursor : field.selEnd);
		char buf[16];
		pageVer = cs_textin_state(buf, sizeof buf);
		refreshSuggestions();
	}
	ChatTextField::tellPageSelection(field.selectedText());
}

void ChatScreen::syncFromPage() {
	char buf[512];
	const int ver = cs_textin_state(buf, sizeof buf);
	if (ver < 0) return;
	std::vector<std::string> f;
	splitLines(buf, '\t', f);
	if (f.size() < 5) return;
	size_t at = 0;
	for (int k = 0; k < 4; ++k) at = std::string(buf).find('\t', at) + 1;
	const std::string value = std::string(buf).substr(at);
	const int enters = atoi(f[2].c_str());
	if (ver != pageVer) {
		pageVer = ver;
		std::string clean;
		for (size_t k = 0; k < value.size() && (int)clean.size() < field.maxLen; ++k)
			if (ChatTextField::allowedChar(value[k])) clean += value[k];
		const bool changed = clean != field.text;
		field.text = clean;
		int s = atoi(f[0].c_str()), e = atoi(f[1].c_str());
		if (s > (int)clean.size()) s = (int)clean.size();
		if (e > (int)clean.size()) e = (int)clean.size();
		field.setCursor(e);
		if (s != e) field.setSelectionPos(s);
		if (changed) { completing = false; refreshSuggestions(); }
	}
	if (enters != pageEnters) { pageEnters = enters; send(); }
}


void ChatScreen::mouseWheel(int x, int y, int notches) {
	int i = notches > 1 ? 1 : notches < -1 ? -1 : notches;
	if (touch) { histScroll += i * 3; if (histScroll < 0) histScroll = 0; return; }
	if (!Keyboard::isKeyDown(Keyboard::KEY_LSHIFT)) i *= 7;
	NewChat::scroll(i);
}

#ifdef EMSCRIPTEN
#define CHAT_TRACE(tag, a, b, c) EM_ASM({ if (Module.mcChatDebug) console.log('[chat] ' + UTF8ToString($0) + ' ' + $1 + ' ' + $2 + ' ' + $3); }, tag, a, b, c)
#else
#define CHAT_TRACE(tag, a, b, c)
#endif
void ChatScreen::mouseClicked(int x, int y, int buttonNum) {
	CHAT_TRACE("down", x, y, buttonNum);
	if (!touch) {
		field.mouseClicked(x, y, buttonNum);
		ChatTextField::tellPageSelection(field.selectedText());
		return;
	}
	pressX = x; pressY = y; dragging = false;
	pressWhat = P_NONE;
	if (x >= closeX && y < closeS) pressWhat = P_CLOSE;
	else if (y >= barY && y < barY + barH && x < panelW) {
		if (x >= slashX && x < slashX + btnW) pressWhat = P_SLASH;
		else if (x >= sendX && x < sendX + btnW * 2) pressWhat = P_SEND;
		else if (x >= fieldX && x < fieldX + fieldW) pressWhat = P_FIELD;
	} else if (suggRows > 0 && y >= suggTop && y < barY && x < panelW) { pressWhat = P_SUGG; pressScroll = suggScroll; }
	else if (y >= histTop && y < histBottom && x < panelW) { pressWhat = P_HIST; pressScroll = histScroll; }
	if (pressWhat == P_FIELD) {
		field.setCursor(field.indexAt(x));
		fieldChanged();
		cs_textin_arm();
	}
	CHAT_TRACE("what", pressWhat, suggTop, barY);
}

void ChatScreen::mouseReleased(int x, int y, int buttonNum) {
	CHAT_TRACE("up", x, y, pressWhat * 10 + (dragging ? 1 : 0));
	if (!touch) return;
	const int what = pressWhat;
	pressWhat = P_NONE;
	if (dragging) { dragging = false; return; }
	if (what == P_CLOSE) { minecraft->soundEngine->playUI("random.click", 1, 1); close(); return; }
	if (what == P_SEND) { minecraft->soundEngine->playUI("random.click", 1, 1); send(); return; }
	if (what == P_SLASH) {
		minecraft->soundEngine->playUI("random.click", 1, 1);
		if (field.text.empty() || field.text[0] != '/') field.setText("/" + field.text);
		else field.setText("/");
		suggScroll = 0;
		fieldChanged();
		cs_textin_arm();
		return;
	}
	if (what == P_SUGG && y >= suggTop && y < barY) {
		const int row = (y - suggTop - usageH) / suggRowH;
		const int k = row + suggScroll;
		if (row >= 0 && k >= 0 && k < (int)sugg.size()) {
			minecraft->soundEngine->playUI("random.click", 1, 1);
			field.setText(sugg[k].insert);
			suggScroll = 0;
			fieldChanged();
			cs_textin_arm();
		}
	}
}


void ChatScreen::layoutTouch() {
	kbInset = cs_kb_inset() * height / 1000;
	if (kbInset > height / 2 + 20) kbInset = height / 2 + 20;
	const int usable = height - kbInset;
	panelW = width >= 480 ? width * 62 / 100 : width;
	headH = 22;
	closeS = 22;
	closeX = width - closeS;
	barH = 28;
	barY = usable - barH;
	btnW = 24;
	slashX = 3;
	sendX = panelW - 3 - btnW * 2;
	fieldX = slashX + btnW + 4;
	fieldW = sendX - 4 - fieldX;
	field.x = fieldX; field.y = barY + 4; field.w = fieldW; field.h = barH - 8;
	suggRowH = 16;
	usageH = usage.empty() ? 0 : 14;
	const int room = barY - headH - 24;
	suggRows = (int)sugg.size();
	const int maxRows = (room - usageH) / suggRowH;
	if (suggRows > maxRows) suggRows = maxRows < 0 ? 0 : maxRows;
	if (suggRows > 6) suggRows = 6;
	if (suggScroll > (int)sugg.size() - suggRows) suggScroll = (int)sugg.size() - suggRows;
	if (suggScroll < 0) suggScroll = 0;
	suggTop = barY - (suggRows > 0 || usageH ? suggRows * suggRowH + usageH : 0);
	histTop = headH + 2;
	histBottom = suggTop - 2;
}

void ChatScreen::refreshSuggestions() {
	const std::string key = field.text + "\n" + std::string(1, (char)('0' + field.cursor % 64));
	sugg.clear();
	usage.clear();
	if (field.text.empty() || field.text[0] != '/') { suggFor = key; layoutTouch(); return; }
	static char buf[16384];
	buf[0] = 0;
	cs_suggest(field.text.c_str(), field.cursor, buf, sizeof buf);
	std::vector<std::string> l;
	splitLines(buf, '\n', l);
	if (!l.empty()) usage = l[0];
	for (size_t k = 1; k < l.size(); ++k) {
		const size_t t = l[k].find('\t');
		if (t == std::string::npos) continue;
		Sugg s = { l[k].substr(0, t), l[k].substr(t + 1) };
		sugg.push_back(s);
	}
	suggFor = key;
	layoutTouch();
}

void ChatScreen::touchButton(int x, int y, int w, int h, const std::string& label, bool down, bool on) {
	fill(x, y, x + w, y + h, (int)0xff1e1e1f);
	fill(x + 1, y + 1, x + w - 1, y + h - 1, down ? (int)0xff6f6f70 : on ? (int)0xff8c8d90 : (int)0xff58585a);
	fill(x + 1, y + 1, x + w - 1, y + 2, down ? (int)0xff58585a : (int)0xffa0a0a2);
	fill(x + 1, y + h - 3, x + w - 1, y + h - 1, down ? (int)0xff6f6f70 : (int)0xff313233);
	const int tw = font->width(label);
	font->drawShadow(label, (float)(x + (w - tw) / 2), (float)(y + (h - 8) / 2 - (down ? 0 : 1)), (int)0xffffffff);
}

void ChatScreen::drawCross(int x, int y, int size, int col) {
	for (int k = 0; k < size; ++k) {
		fill(x + k, y + k, x + k + 2, y + k + 2, col);
		fill(x + size - 1 - k, y + k, x + size + 1 - k, y + k + 2, col);
	}
}

void ChatScreen::renderTouch(int xm, int ym, float a) {
	layoutTouch();
	if (pressWhat == P_HIST || pressWhat == P_SUGG) {
		const int my = Mouse::getY() * height / (minecraft->height > 0 ? minecraft->height : 1);
		const int dy = my - pressY;
		if (dy > 4 || dy < -4) dragging = true;
		if (dragging) {
			if (pressWhat == P_HIST) { histScroll = pressScroll + dy / 10; if (histScroll < 0) histScroll = 0; }
			else { suggScroll = pressScroll - dy / suggRowH; layoutTouch(); }
		}
	}
	glDisable(GL_DEPTH_TEST);
	fill(0, 0, panelW, height, (int)0xb4000000);
	fill(0, 0, panelW, headH, (int)0xe0262627);
	fill(0, headH - 1, panelW, headH, (int)0xff555556);
	const std::string title = "Chat";
	font->drawShadow(title, (float)((panelW - font->width(title)) / 2), (float)((headH - 8) / 2), (int)0xffffffff);
	if (msgSerial != NewChat::serial() || wrapped.empty()) {
		msgSerial = NewChat::serial();
		wrapped.clear();
		const std::vector<std::string>& m = NewChat::messages();
		for (size_t k = m.size(); k-- > 0; ) NewChat::wrap(font, m[k], panelW - 12, wrapped);
	}
	const int lineH = 10;
	const int fit = (histBottom - histTop) / lineH;
	if (histScroll > (int)wrapped.size() - fit) histScroll = (int)wrapped.size() - fit;
	if (histScroll < 0) histScroll = 0;
	int yy = histBottom - lineH;
	for (int k = (int)wrapped.size() - 1 - histScroll; k >= 0 && yy >= histTop; --k, yy -= lineH)
		NewChat::drawCoded(font, wrapped[k], 6.0f, (float)(yy + 1), 0xffffff, 255, true);
	if (wrapped.empty()) {
		const std::string hint = "No messages yet";
		font->drawShadow(hint, (float)((panelW - font->width(hint)) / 2), (float)((histTop + histBottom) / 2 - 4), (int)0xff9a9a9a);
	}
	if (usageH) {
		fill(0, suggTop, panelW, suggTop + usageH, (int)0xf0101011);
		NewChat::drawCoded(font, usage, 6.0f, (float)(suggTop + 3), 0xb0b0b0, 255, true);
	}
	for (int r = 0; r < suggRows; ++r) {
		const int k = r + suggScroll;
		if (k >= (int)sugg.size()) break;
		const int ry = suggTop + usageH + r * suggRowH;
		const bool down = pressWhat == P_SUGG && !dragging && pressY >= ry && pressY < ry + suggRowH;
		fill(0, ry, panelW, ry + suggRowH, down ? (int)0xf0505052 : (r % 2 ? (int)0xf0262627 : (int)0xf02e2e30));
		NewChat::drawCoded(font, sugg[k].display, 8.0f, (float)(ry + (suggRowH - 8) / 2), 0xffffff, 255, true);
	}
	if (suggRows > 0 && (int)sugg.size() > suggRows) {
		const int listH = suggRows * suggRowH, top = suggTop + usageH;
		const int len = listH * suggRows / (int)sugg.size(), off = (listH - len) * suggScroll / ((int)sugg.size() - suggRows);
		fill(panelW - 3, top + off, panelW - 1, top + off + len, (int)0xffc0c0c0);
	}
	fill(0, barY, panelW, barY + barH, (int)0xf0181819);
	touchButton(slashX, barY + 2, btnW, barH - 4, "/", pressWhat == P_SLASH, !field.text.empty() && field.text[0] == '/');
	touchButton(sendX, barY + 2, btnW * 2, barH - 4, "Send", pressWhat == P_SEND, false);
	fill(field.x - 1, field.y - 1, field.x + field.w + 1, field.y + field.h + 1, (int)0xffa0a0a0);
	fill(field.x, field.y, field.x + field.w, field.y + field.h, (int)0xff000000);
	if (field.text.empty()) {
		const std::string hint = "Tap here to chat";
		font->drawShadow(hint, (float)(field.x + 4), (float)(field.y + (field.h - 8) / 2), (int)0xff7a7a7a);
	}
	field.background = false;
	const int fx = field.x, fy = field.y, fw = field.w;
	field.x = fx + 4; field.y = fy + (field.h - 8) / 2; field.w = fw - 8;
	field.draw();
	field.x = fx; field.y = fy; field.w = fw;
	field.background = true;
	touchButton(closeX + 2, 2, closeS - 4, closeS - 4, "", pressWhat == P_CLOSE, false);
	drawCross(closeX + 7, 7, closeS - 15, (int)0xffffffff);
}

void ChatScreen::render(int xm, int ym, float a) {
	if (touch) { renderTouch(xm, ym, a); return; }
	glDisable(GL_DEPTH_TEST);
	fill(2, height - 14, width - 2, height - 2, (int)0x80000000);
	field.draw();
}
