#include "ChatScreen.h"
#include "../../../world/ModScripts.h"
#include "DialogDefinitions.h"
#include "../Gui.h"
#include "../../Minecraft.h"
#include "../../../AppPlatform.h"
#include "../../../platform/log.h"

#ifdef EMSCRIPTEN
#include <emscripten.h>
#include "../../../network/RakNetInstance.h"
#include "../../../network/packet/MessagePacket.h"
#include "../../player/LocalPlayer.h"
extern Minecraft* webCurrentGame();
void webOpenChat(const char* prefix) {
	EM_ASM({ if (Module.mcChat) Module.mcChat.open(UTF8ToString($0)); }, prefix ? prefix : "");
}
extern "C" EMSCRIPTEN_KEEPALIVE void mcChatSend(const char* raw) {
	Minecraft* mc = webCurrentGame();
	if (!mc || !mc->level || !mc->player || !raw) return;
	std::string text(raw);
	while (!text.empty() && (text[text.size() - 1] == ' ' || text[text.size() - 1] == '\t')) text.erase(text.size() - 1);
	while (!text.empty() && text[0] == ' ') text.erase(0, 1);
	if (text.empty()) return;
	if (text.size() > 100) text.resize(100);
	if (text[0] == '/') {
		if (!ModScripts::command(mc, text)) mc->gui.addMessage("Unknown command. Try /help for a list of commands");
		return;
	}
	if (ModPE::hook(ModPE::CHAT, "chatHook", "[" + ModScripts::quote(text) + "]")) return;
	const std::string line = "<" + mc->player->name + "> " + text;
	mc->gui.addMessage(line);
	if (mc->raknetInstance) { MessagePacket packet(line.c_str()); mc->raknetInstance->send(packet); }
	ModScripts::chatted(mc, text);
}
#endif

void ChatScreen::init() {
	minecraft->platform()->createUserInput(DialogDefinitions::DIALOG_NEW_CHAT_MESSAGE);
}

void ChatScreen::render(int xm, int ym, float a)
{
	int status = minecraft->platform()->getUserInputStatus();
	if (status > -1) {
		if (status == 1) {
			std::vector<std::string> v = minecraft->platform()->getUserInput();
			if (v.size() && v[0].length() > 0 && !(v[0][0] == '/' && ModScripts::command(minecraft, v[0]))
			    && !ModPE::hook(ModPE::CHAT, "chatHook", "[" + ModScripts::quote(v[0]) + "]")) {
				minecraft->gui.addMessage(v[0]);
				ModScripts::chatted(minecraft, v[0]);
			}
		}

		minecraft->setScreen(NULL);
	}
}
