#include <cstdio>
#include "ChooseLevelScreen.h"
#include <algorithm>
#include <set>
#include "../../Minecraft.h"

void ChooseLevelScreen::init() {
	loadLevelSource();
}

void ChooseLevelScreen::loadLevelSource()
{
	LevelStorageSource* levelSource = minecraft->getLevelSource();
	levelSource->getLevelList(levels);
	std::sort(levels.begin(), levels.end());
}

std::string ChooseLevelScreen::getUniqueLevelName( const std::string& level ) {
	std::set<std::string> Set;
	for (unsigned int i = 0; i < levels.size(); ++i)
		Set.insert(levels[i].id);

	std::string s = level;
	for (int n = 2; Set.find(s) != Set.end(); ++n) {
		char buf[16];
		sprintf(buf, " (%d)", n);
		s = level + buf;
	}
	return s;
}
