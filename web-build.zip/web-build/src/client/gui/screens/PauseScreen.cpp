#include "../../Options.h"
#include "../../Account.h"
#include "PauseScreen.h"
#include "StartMenuScreen.h"
#include "OptionsScreen.h"
#include "../components/ImageButton.h"
#include "../../Minecraft.h"
#include "../../../util/Mth.h"
#include "../../../network/RakNetInstance.h"
#include "../../../network/ServerSideNetworkHandler.h"

#include <algorithm>
#include "../ModMenuButtons.h"

#ifdef EMSCRIPTEN
#include <emscripten.h>
extern "C" int mcIsTouchMode();
#include "../../../network/WebNetInstance.h"
#include "../../../world/level/Level.h"
#endif

PauseScreen::PauseScreen(bool wasBackPaused)
:	saveStep(0),
	visibleTime(0),
	bContinue(0),
	bQuit(0),
	bQuitAndSaveLocally(0),
	bServerVisibility(0),
	bOptions(0),
//	bThirdPerson(0),
	wasBackPaused(wasBackPaused),
	bSound(&Options::Option::SOUND, 1, 0),
	bThirdPerson(&Options::Option::THIRD_PERSON),
    bHideGui(&Options::Option::HIDE_GUI)
{
	ImageDef def;
	def.setSrc(IntRectangle(160, 144, 39, 31));
	def.name = "gui/touchgui.png";
	IntRectangle& defSrc = *def.getSrc();

	def.width = defSrc.w * 0.666667f;
	def.height = defSrc.h * 0.666667f;

	bSound.setImageDef(def, true);
	defSrc.y += defSrc.h;
	bThirdPerson.setImageDef(def, true);
    bHideGui.setImageDef(def, true);
	//void setImageDef(ImageDef& imageDef, bool setButtonSize);
}

PauseScreen::~PauseScreen() {
#ifdef EMSCRIPTEN
	EM_ASM({ Module.mcResumeRect = null; });
#endif
	delete bContinue;
	delete bQuit;
	delete bQuitAndSaveLocally;
	delete bServerVisibility;
	delete bOptions;
//	delete bThirdPerson;
	for (unsigned int i = 0; i < modButtons.size(); ++i) delete modButtons[i];
}

void PauseScreen::syncModButtons() {
	for (unsigned int i = 0; i < modButtons.size(); ++i) {
		Button* b = modButtons[i];
		buttons.erase(std::remove(buttons.begin(), buttons.end(), b), buttons.end());
		tabButtons.erase(std::remove(tabButtons.begin(), tabButtons.end(), b), tabButtons.end());
		delete b;
	}
	modButtons.clear();
	const std::vector<std::string>& labels = ModMenuButtons::labels("pause");
	for (unsigned int i = 0; i < labels.size(); ++i) {
		Button* b = Options::pocketUi() ? (Button*)new Touch::TButton(ModMenuButtons::FIRST + i, labels[i]) : new Button(ModMenuButtons::FIRST + i, labels[i]);
		modButtons.push_back(b);
		buttons.push_back(b);
		tabButtons.push_back(b);
	}
	modVersion = ModMenuButtons::version();
}

void PauseScreen::init() {
	if (Options::pocketUi()) {
		bContinue = new Touch::TButton(1, "Back to game");
		bQuit = new Touch::TButton(2, "Quit to title");
		bQuitAndSaveLocally = new Touch::TButton(3, "Quit and copy map");
		bServerVisibility = new Touch::TButton(4, "");
		bOptions = new Touch::TButton(6, "Options");
//		bThirdPerson = new Touch::TButton(5, "Toggle 3:rd person view");
	} else {
		bContinue = new Button(1, "Back to game");
		bQuit = new Button(2, "Quit to title");
		bQuitAndSaveLocally = new Button(3, "Quit and copy map");
		bServerVisibility = new Button(4, "");
		bOptions = new Button(6, "Options");
//		bThirdPerson = new Button(5, "Toggle 3:rd person view");
	}

	buttons.push_back(bContinue);
	buttons.push_back(bOptions);
	buttons.push_back(bQuit);

	bSound.updateImage(&minecraft->options);
	bThirdPerson.updateImage(&minecraft->options);
	bHideGui.updateImage(&minecraft->options);
#ifdef EMSCRIPTEN
	if (mcIsTouchMode()) buttons.push_back(&bThirdPerson);
#endif
    //buttons.push_back(&bHideGui);

	// If Back wasn't pressed, set up additional items (more than Quit to menu
	// and Back to game) here
    
    #if !defined(APPLE_DEMO_PROMOTION) && !defined(RPI)
	if (true || !wasBackPaused) {
		if (minecraft->raknetInstance) {
			if (minecraft->raknetInstance->isServer()) {
				updateServerVisibilityText();
				buttons.push_back(bServerVisibility);
			}
			else {
                #if !defined(DEMO_MODE)
                buttons.push_back(bQuitAndSaveLocally);
				#endif
			}
		}
	}
    #endif
//	buttons.push_back(bThirdPerson);

	for (unsigned int i = 0; i < buttons.size(); ++i) {
		if (buttons[i] == &bSound) continue;
		if (buttons[i] == &bThirdPerson) continue;
		if (buttons[i] == &bHideGui) continue;
		tabButtons.push_back(buttons[i]);
	}
	syncModButtons();
}

void PauseScreen::setupPositions() {
    saveStep = 0;

#ifdef EMSCRIPTEN
	if (!mcIsTouchMode()) {
		std::vector<Button*> column;
		column.push_back(bContinue); column.push_back(bOptions);
		column.insert(column.end(), modButtons.begin(), modButtons.end());
		column.push_back(bQuit); column.push_back(bServerVisibility); column.push_back(bQuitAndSaveLocally);
		std::vector<Button*> shown;
		for (unsigned int i = 0; i < column.size(); ++i)
			if (std::find(buttons.begin(), buttons.end(), column[i]) != buttons.end())
				shown.push_back(column[i]);

		const int W = std::min(200, width - 16), H = 20, GAP = 4, TITLE = 24, SPLIT = 12;
		bQuit->textColor = 0xff5555;
		bQuit->textHoverColor = 0xff9090;
		int total = TITLE + (int)shown.size() * (H + GAP) - GAP;
		for (unsigned int i = 1; i < shown.size(); ++i)
			if (shown[i] == bServerVisibility || shown[i] == bQuitAndSaveLocally) { total += SPLIT; break; }
		int y = (height - total) / 2 + TITLE;
		bool split = false;
		for (unsigned int i = 0; i < shown.size(); ++i, y += H + GAP) {
			if (i > 0 && !split && (shown[i] == bServerVisibility || shown[i] == bQuitAndSaveLocally)) {
				y += SPLIT;
				split = true;
			}
			shown[i]->width = W;
			shown[i]->height = H;
			shown[i]->x = (width - W) / 2;
			shown[i]->y = y;
		}
		bQuitAndSaveLocally->width = bServerVisibility->width = W;
		bQuitAndSaveLocally->x = bServerVisibility->x = (width - W) / 2;

		bSound.y = bThirdPerson.y = 8;
		bSound.x = 4;
		bThirdPerson.x = bSound.x + 4 + bSound.width;
		bHideGui.x = bThirdPerson.x + 4 + bThirdPerson.width;

		const float sx = (float)minecraft->width / width, sy = (float)minecraft->height / height;
		EM_ASM({ Module.mcResumeRect = new Array($0, $1, $2, $3, $4, $5); },
		       (int)(bContinue->x * sx), (int)((bContinue->y + 1) * sy),
		       (int)(bContinue->width * sx), (int)(bContinue->height * sy),
		       minecraft->width, minecraft->height);
		return;
	}
#endif
	int yBase = 16;

	bContinue->width = bQuit->width = /*bThirdPerson->w =*/ 160;
	bQuitAndSaveLocally->width = bServerVisibility->width = 160;

	bContinue->x = (width - bContinue->width) / 2;
	bContinue->y = yBase + 32 * 1;

	bOptions->width = 160;
	bOptions->x = (width - bOptions->width) / 2;
	bOptions->y = yBase + 32 * 2;

	int mods = (int)modButtons.size();
	for (int i = 0; i < mods; ++i) {
		modButtons[i]->width = 160;
		modButtons[i]->x = (width - 160) / 2;
		modButtons[i]->y = yBase + 32 * (3 + i);
	}

	bQuit->x = (width - bQuit->width) / 2;
	bQuit->y = yBase + 32 * (3 + mods);

#if APPLE_DEMO_PROMOTION
    bQuit->y += 16;
#endif
    
	bQuitAndSaveLocally->x = bServerVisibility->x = (width - bQuitAndSaveLocally->width) / 2;
	bQuitAndSaveLocally->y = bServerVisibility->y = yBase + 32 * (4 + mods);

	bSound.y = bThirdPerson.y = 8;
	bSound.x = 4;
	bThirdPerson.x = bSound.x + 4 + bSound.width;
	bHideGui.x = bThirdPerson.x + 4 + bThirdPerson.width;

	//bThirdPerson->x = (width - bThirdPerson->w) / 2;
	//bThirdPerson->y = yBase + 32 * 4;
}

void PauseScreen::tick() {
	if (modVersion != ModMenuButtons::version()) { syncModButtons(); setupPositions(); }
#ifdef EMSCRIPTEN
	if (std::find(buttons.begin(), buttons.end(), bServerVisibility) != buttons.end()) updateServerVisibilityText();
#endif
	super::tick();
	visibleTime++;
}

void PauseScreen::render(int xm, int ym, float a) {
	renderBackground();

	//bool isSaving = !minecraft->level.pauseSave(saveStep++);
	//if (isSaving || visibleTime < 20) {
	//	float col = ((visibleTime % 10) + a) / 10.0f;
	//	col = Mth::sin(col * Mth::PI * 2) * 0.2f + 0.8f;
	//	int br = (int) (255 * col);

	//	drawString(font, "Saving level..", 8, height - 16, br << 16 | br << 8 | br);
	//}

	drawCenteredString(font, "Game menu", width / 2, bContinue->y - 24, 0xffffff);

	super::render(xm, ym, a);
}

void PauseScreen::buttonClicked(Button* button) {
	if (button->id >= ModMenuButtons::FIRST) { ModMenuButtons::press("pause", button->id - ModMenuButtons::FIRST); return; }
	if (button->id == bContinue->id) {
		minecraft->setScreen(NULL);
		//minecraft->grabMouse();
	}
	if (button->id == bOptions->id) {
		minecraft->setScreen(new OptionsScreen());
		return;
	}
    if (button->id == bQuit->id) {
		minecraft->leaveGame();
    }
	if (button->id == bQuitAndSaveLocally->id) {
		minecraft->leaveGame(true);
	}

	if (button->id == bServerVisibility->id) {
		if (!Account::gate("Multiplayer")) return;
#ifdef EMSCRIPTEN
		if (WebNetInstance* net = dynamic_cast<WebNetInstance*>(minecraft->raknetInstance)) {
			if (!net->isServer() || !minecraft->netCallback || !minecraft->level) return;
			ServerSideNetworkHandler* ss = (ServerSideNetworkHandler*) minecraft->netCallback;
			const int state = net->roomState();
			if (state == 0 || state == 3) {
				ss->allowIncomingConnections(true);
				net->openRoom();
				announced = false;
			} else if (state == 2) {
				const std::string code = net->roomCode();
				EM_ASM({ try { navigator.clipboard.writeText(UTF8ToString($0)); } catch (e) { } }, code.c_str());
				minecraft->gui.addMessage("Friends can join with code " + code + " (copied)");
			}
			updateServerVisibilityText();
			return;
		}
#endif
		if (minecraft->raknetInstance && minecraft->netCallback && minecraft->raknetInstance->isServer()) {
			ServerSideNetworkHandler* ss = (ServerSideNetworkHandler*) minecraft->netCallback;
			bool allows = !ss->allowsIncomingConnections();
			ss->allowIncomingConnections(allows);

			updateServerVisibilityText();
		}
	}

	if (button->id == OptionButton::ButtonId) {
		((OptionButton*)button)->toggle(&minecraft->options);
	}

	//if (button->id == bThirdPerson->id) {
	//	minecraft->options.thirdPersonView = !minecraft->options.thirdPersonView;
	//}
}

void PauseScreen::updateServerVisibilityText()
{
	if (!minecraft->raknetInstance || !minecraft->raknetInstance->isServer())
		return;

#ifdef EMSCRIPTEN
	if (WebNetInstance* net = dynamic_cast<WebNetInstance*>(minecraft->raknetInstance)) {
		bServerVisibility->active = true;
		switch (net->roomState()) {
		case 1: bServerVisibility->msg = "Opening..."; break;
		case 2: {
			const std::string code = net->roomCode();
			const int n = net->playerCount();
			char buf[64];
			if (n > 0) snprintf(buf, sizeof(buf), "Code: %s  (%d joined)", code.c_str(), n);
			else       snprintf(buf, sizeof(buf), "Code: %s  (tap to copy)", code.c_str());
			bServerVisibility->msg = buf;
			if (!announced) {
				announced = true;
				minecraft->gui.addMessage("Friends can join with code " + code + " - Join Game on the title screen");
			}
			break;
		}
		case 3: bServerVisibility->msg = "Couldn't open - try again"; break;
		default: bServerVisibility->msg = "Open to friends"; break;
		}
		return;
	}
#endif
	ServerSideNetworkHandler* ss = (ServerSideNetworkHandler*) minecraft->netCallback;
	bServerVisibility->msg = ss->allowsIncomingConnections()?
		"Server is visible"
	:   "Server is invisible";
}
