#include "../../../world/ModOverrides.h"
#include "OptionsScreen.h"

#include "StartMenuScreen.h"
#include "ControlsScreen.h"
#include "DialogDefinitions.h"
#include "../../Minecraft.h"
#include "../../../AppPlatform.h"

#include "../components/OptionsPane.h"
#include "../components/ImageButton.h"
#include "../components/OptionsGroup.h"
#include "../../renderer/gles.h"
#include "../Gui.h"
#include "../components/OptionsItem.h"
#include "../components/Slider.h"
#include "../../../platform/input/Mouse.h"
#include "../../../platform/input/Keyboard.h"
#ifdef EMSCRIPTEN
#include <emscripten.h>
extern "C" int mcIsPhoneDevice();
#endif
OptionsScreen::OptionsScreen()
: btnClose(NULL),
  btnUsername(NULL),
  btnKeys(NULL),
  bHeader(NULL),
  javaLayout(false),
  btnDone(NULL),
  selectedCategory(0),
  currentOptionPane(NULL),
  paneTop(0), scrollY(0), maxScroll(0),
  dragging(false), dragScrolling(false), dragOnSlider(false),
  dragStartY(0), dragStartScroll(0) {
}

OptionsScreen::~OptionsScreen() {
	if(btnClose != NULL) {
		delete btnClose;
		btnClose = NULL;
	}
	if(bHeader != NULL) {
		delete bHeader,
		bHeader = NULL;
	}
	delete btnUsername;
	btnUsername = NULL;
	delete btnKeys;
	btnKeys = NULL;
	delete btnDone;
	btnDone = NULL;
	for(std::vector<Button*>::iterator it = categoryButtons.begin(); it != categoryButtons.end(); ++it) {
		if(*it != NULL) {
			delete *it;
			*it = NULL;
		}
	}
	for(std::vector<OptionsPane*>::iterator it = optionPanes.begin(); it != optionPanes.end(); ++it) {
		if(*it != NULL) {
			delete *it;
			*it = NULL;
		}
	}
	categoryButtons.clear();
}

static Button* optionsButton(bool java, int id, const std::string& label) {
	if (java) return new Button(id, 0, 0, 100, 20, label);
	return new Touch::TButton(id, label);
}

void OptionsScreen::init() {
	javaLayout = !Options::pocketUi();
	OptionsItem::javaStyle = javaLayout;
	bHeader = new Touch::THeader(0, "Options");
	btnClose = new ImageButton(1, "");
	ImageDef def;
	def.name = "gui/touchgui.png";
	def.width = 34;
	def.height = 26;

	def.setSrc(IntRectangle(150, 0, (int)def.width, (int)def.height));
	btnClose->setImageDef(def, true);

	categoryButtons.push_back(optionsButton(javaLayout, 2, "Controls"));
	categoryButtons.push_back(optionsButton(javaLayout, 3, "Game"));
	categoryButtons.push_back(optionsButton(javaLayout, 4, javaLayout ? "Video" : "Graphics"));
	categoryButtons.push_back(optionsButton(javaLayout, 6, "Audio"));
#ifdef EMSCRIPTEN
	categoryButtons.push_back(optionsButton(javaLayout, 5, "Bot..."));
#endif
	if (javaLayout) {
		btnDone = new Button(1, 0, 0, 150, 20, "Done");
		buttons.push_back(btnDone);
	} else {
		buttons.push_back(bHeader);
		buttons.push_back(btnClose);
	}
#ifdef EMSCRIPTEN
	btnUsername = optionsButton(javaLayout, 9, "Username");
	buttons.push_back(btnUsername);
	btnKeys = optionsButton(javaLayout, 10, "Key Bindings...");
	buttons.push_back(btnKeys);
#endif
	for(std::vector<Button*>::iterator it = categoryButtons.begin(); it != categoryButtons.end(); ++it) {
		buttons.push_back(*it);
		tabButtons.push_back(*it);
	}
	generateOptionScreens();

}
void OptionsScreen::setupPositions() {
	if (javaLayout) {
		const int gw = width - 16 < 310 ? width - 16 : 310;
		const int gx = (width - gw) / 2;
		const int n = (int)categoryButtons.size();
		const int tw = (gw - (n - 1) * 4) / (n > 0 ? n : 1);
		for (int i = 0; i < n; ++i) {
			Button* b = categoryButtons[i];
			b->x = gx + i * (tw + 4); b->y = 22; b->width = tw; b->height = 20; b->selected = false;
		}
		const int by = height - 28;
		const int half = (gw - 10) / 2;
		btnDone->width = half; btnDone->height = 20;
		btnDone->x = gx + half + 10; btnDone->y = by;
		if (btnUsername) { btnUsername->width = half; btnUsername->height = 20; btnUsername->x = gx; btnUsername->y = by; }
		if (btnKeys) { btnKeys->width = half; btnKeys->height = 20; btnKeys->x = gx; btnKeys->y = by; }
		for (unsigned int i = 0; i < optionPanes.size(); ++i) {
			optionPanes[i]->x = gx;
			optionPanes[i]->y = paneTop = 50;
			optionPanes[i]->width = gw;
			optionPanes[i]->setupPositions();
		}
		selectCategory(0);
		return;
	}
	int buttonHeight = btnClose->height;
	btnClose->x = width - btnClose->width;
	btnClose->y = 0;
	int tabH = buttonHeight;
	{
		const int n = (int)categoryButtons.size();
		const int room = height - buttonHeight - 4;
		if (n > 0 && n * tabH > room) {
			tabH = room / n;
			if (tabH < 14) tabH = 14;
		}
	}
	int offsetNum = 0;
	for(std::vector<Button*>::iterator it = categoryButtons.begin(); it != categoryButtons.end(); ++it) {
		(*it)->x = 0;
		(*it)->y = buttonHeight + offsetNum * tabH;
		if (tabH < buttonHeight) (*it)->height = tabH;
		(*it)->selected = false;
		offsetNum++;
	}
	bHeader->x = 0;
	bHeader->y = 0;
	bHeader->width = width - btnClose->width;
	bHeader->height = btnClose->height;
	if (btnUsername && categoryButtons.size() > 0 && categoryButtons[0] != NULL) {
		const int tabW = categoryButtons[0]->width;
		const int avail = width - tabW;
		const int cw = avail - 16 < 280 ? avail - 16 : 280;
		btnUsername->width = cw < 200 ? cw : 200;
		btnUsername->height = buttonHeight;
		btnUsername->x = tabW + (avail - btnUsername->width) / 2;
		btnUsername->y = height - buttonHeight - 8;
		if (btnKeys) {
			btnKeys->width = btnUsername->width; btnKeys->height = buttonHeight;
			btnKeys->x = btnUsername->x; btnKeys->y = btnUsername->y;
		}
	}
	for(std::vector<OptionsPane*>::iterator it = optionPanes.begin(); it != optionPanes.end(); ++it) {
		if(categoryButtons.size() > 0 && categoryButtons[0] != NULL) {
			const int tabW = categoryButtons[0]->width;
			const int avail = width - tabW;
			const int cw = avail - 16 < 280 ? avail - 16 : 280;
			(*it)->x = tabW + (avail - cw) / 2;
			(*it)->y = paneTop = bHeader->height + 8;
			(*it)->width = cw;
			(*it)->setupPositions();
		}
	}
	selectCategory(0);
}

void OptionsScreen::render( int xm, int ym, float a ) {
	if (btnUsername)
		btnUsername->msg = minecraft->options.usernameSet
			? "Username: " + minecraft->options.username : std::string("Set username");
	renderBackground();
	super::render(xm, ym, a);
	if (javaLayout) drawCenteredString(minecraft->font, "Options", width / 2, 8, 0xffffffff);
	int xmm = xm;
	int ymm = ym - 1;
	if (dragging && currentOptionPane != NULL) {
		if (Mouse::getButtonState(MouseAction::ACTION_LEFT) != MouseAction::DATA_DOWN) {
			dragging = dragScrolling = false;
		} else {
			const int dy = ymm - dragStartY;
			if (!dragOnSlider && !dragScrolling && (dy > 4 || dy < -4)) dragScrolling = true;
			if (dragScrolling && scrollY != dragStartScroll - dy) {
				scrollY = dragStartScroll - dy;
				layoutPane();
			}
		}
	}
	const int top = viewTop(), bottom = viewBottom();
	if (minecraft->level && currentOptionPane != NULL) {
		const int y1 = currentOptionPane->height + 4 < bottom ? currentOptionPane->height + 4 : bottom;
		if (!javaLayout)
		fill(currentOptionPane->x - 10, top - 6,
		     currentOptionPane->x + currentOptionPane->width + 10, y1, 0xb0000000);
	}
	if(currentOptionPane != NULL) {
		glEnable2(GL_SCISSOR_TEST);
		const float s = Gui::GuiScale;
		const int sy0 = (int)(top * s) - (int)(6 * s), sy1 = (int)(bottom * s);
		glScissor(0, minecraft->height - sy1, minecraft->width, sy1 - sy0);
		currentOptionPane->render(minecraft, xmm, ymm);
		glDisable2(GL_SCISSOR_TEST);
		if (maxScroll > 0) {
			const int bx = currentOptionPane->x + currentOptionPane->width + 6;
			const int viewH = bottom - top;
			const int contentH = viewH + maxScroll;
			int barH = viewH * viewH / contentH;
			if (barH < 12) barH = 12;
			const int barY = top + (viewH - barH) * scrollY / maxScroll;
			fill(bx, top, bx + 3, bottom, 0x50000000);
			fill(bx, barY, bx + 3, barY + barH, 0xc0c0c0c0);
		}
	}
}

int OptionsScreen::viewTop() const {
	return paneTop;
}

int OptionsScreen::viewBottom() const {
	if (btnUsername && btnUsername->visible) return btnUsername->y - 6;
	if (btnKeys && btnKeys->visible) return btnKeys->y - 6;
	if (btnDone) return btnDone->y - 6;
	return height - 4;
}

void OptionsScreen::layoutPane() {
	if (currentOptionPane == NULL) return;
	currentOptionPane->y = paneTop;
	currentOptionPane->setupPositions();
	const int contentBottom = currentOptionPane->height;
	maxScroll = contentBottom + 6 - viewBottom();
	if (maxScroll < 0) maxScroll = 0;
	if (scrollY > maxScroll) scrollY = maxScroll;
	if (scrollY < 0) scrollY = 0;
	if (scrollY != 0) {
		currentOptionPane->y = paneTop - scrollY;
		currentOptionPane->setupPositions();
	}
}

bool OptionsScreen::pointOnSlider(int x, int y) const {
	if (currentOptionPane == NULL) return false;
	for (unsigned int g = 0; g < currentOptionPane->getChildren().size(); ++g) {
		GuiElementContainer* group = dynamic_cast<GuiElementContainer*>(currentOptionPane->getChildren()[g]);
		if (!group) continue;
		for (unsigned int i = 0; i < group->getChildren().size(); ++i) {
			GuiElementContainer* item = dynamic_cast<GuiElementContainer*>(group->getChildren()[i]);
			if (!item || item->getChildren().empty()) continue;
			if (y < item->y || y >= item->y + item->height) continue;
			Slider* sl = dynamic_cast<Slider*>(item->getChildren()[0]);
			if (!sl) continue;
			if (x >= sl->x && x < sl->x + sl->width) return true;
		}
	}
	return false;
}

void OptionsScreen::mouseWheel(int x, int y, int notches) {
	if (maxScroll <= 0) return;
	scrollY -= notches * 24;
	layoutPane();
}

void OptionsScreen::removed()
{
}
void OptionsScreen::buttonClicked( Button* button ) {
	if(button == btnClose || (btnDone && button == btnDone)) {
		if (minecraft->level) {
			minecraft->options.save();
			minecraft->screenChooser.setScreen(SCREEN_PAUSE);
			return;
		}
		minecraft->options.save();
		minecraft->reloadOptions();
		minecraft->screenChooser.setScreen(SCREEN_STARTMENU);
	} else if (btnKeys && button == btnKeys) {
		minecraft->options.save();
		minecraft->setScreen(new ControlsScreen());
	} else if (btnUsername && button == btnUsername) {
#ifdef EMSCRIPTEN
		EM_ASM({ if (Module.mcAskUsername) Module.mcAskUsername(); });
#endif
	} else if (button->id == 5) {
		if (!button->active) return;
#ifdef EMSCRIPTEN
		EM_ASM({ try { if (Module.mcBotSettings) Module.mcBotSettings(); } catch (e) { } });
#endif
	} else if(button->id > 1 && button->id < 7) {
		for (unsigned int i = 0; i < categoryButtons.size(); ++i)
			if (categoryButtons[i] == button) { selectCategory((int)i); break; }
	}
}

void OptionsScreen::selectCategory( int index ) {
	int currentIndex = 0;
	for(std::vector<Button*>::iterator it = categoryButtons.begin(); it != categoryButtons.end(); ++it) {
		if(index == currentIndex) {
			(*it)->selected = true;
		} else {
			(*it)->selected = false;
		}
		currentIndex++;
	}
	if(index < (int)optionPanes.size())
		currentOptionPane = optionPanes[index];
	if (btnUsername) btnUsername->visible = btnUsername->active = (index == 1);
	if (btnKeys) btnKeys->visible = btnKeys->active = (index == 0);
	scrollY = 0;
	dragging = dragScrolling = false;
	layoutPane();
}

void OptionsScreen::generateOptionScreens() {
	optionPanes.push_back(new OptionsPane());
	optionPanes.push_back(new OptionsPane());
	optionPanes.push_back(new OptionsPane());
	optionPanes.push_back(new OptionsPane());

	OptionsGroup& controls = optionPanes[0]->createOptionsGroup(
		mcIsPhoneDevice() ? "options.group.controls" : "options.group.controls.pc");
	controls.addOptionItem(&Options::Option::SENSITIVITY, minecraft)
		.addOptionItem(&Options::Option::INVERT_MOUSE, minecraft);
	if (mcIsPhoneDevice())
		controls.addOptionItem(&Options::Option::LEFT_HANDED, minecraft)
			.addOptionItem(&Options::Option::TOUCH_CONTROLS, minecraft);
	if (mcIsPhoneDevice()) controls.addOptionItem(&Options::Option::MINE_ASSIST, minecraft);
	controls.addOptionItem(&Options::Option::EASY_BRIDGE, minecraft);
	if (!mcIsPhoneDevice()) controls.addOptionItem(&Options::Option::SPRINT_TOGGLE, minecraft);
	if (mcIsPhoneDevice())
		controls.addOptionItem(&Options::Option::EDGE_ASSIST, minecraft)
			.addOptionItem(&Options::Option::TOUCH_CROSSHAIR, minecraft);
	controls
		.addOptionItem(&Options::Option::AUTO_TOOL, minecraft)
		.addOptionItem(&Options::Option::TOOL_REFILL, minecraft);
	if (mcIsPhoneDevice()) controls.addOptionItem(&Options::Option::THIRD_PERSON, minecraft);
#ifndef EMSCRIPTEN
	controls.addOptionItem(&Options::Option::USE_TOUCHSCREEN, minecraft)
		.addOptionItem(&Options::Option::USE_TOUCH_JOYPAD, minecraft);
	optionPanes[0]->createOptionsGroup("Feedback")
		.addOptionItem(&Options::Option::DESTROY_VIBRATION, minecraft);
#endif

	OptionsGroup& gameGroup = optionPanes[1]->createOptionsGroup("options.group.game");
	gameGroup
		.addOptionItem(&Options::Option::DIFFICULTY_SLIDER, minecraft)
		.addOptionItem(&Options::Option::SERVER_VISIBLE, minecraft)
		.addOptionItem(&Options::Option::HUNGER, minecraft)
		.addOptionItem(&Options::Option::SPRINTING, minecraft)
		.addOptionItem(&Options::Option::VIEW_BOBBING, minecraft);
	if (ModOverrides::survival().autoHarvestAvailable)
		gameGroup.addOptionItem(&Options::Option::AUTO_HARVEST, minecraft);
	if (ModOverrides::survival().herobrineAllowed)
		gameGroup.addOptionItem(&Options::Option::HEROBRINE, minecraft);

	OptionsGroup& audio = optionPanes[3]->createOptionsGroup("options.group.audio");
	audio.addOptionItem(&Options::Option::SOUND, minecraft)
		.addOptionItem(&Options::Option::MUSIC, minecraft)
		.addOptionItem(&Options::Option::SOUND_STYLE, minecraft);
	if (mcIsPhoneDevice()) audio.addOptionItem(&Options::Option::KEEP_MY_MUSIC, minecraft);

	if (OptionsItem::javaStyle) optionPanes[2]->createOptionsGroup("").setWide(true).addOptionItem(&Options::Option::OPTIMIZE, minecraft);
	OptionsGroup& graphics = optionPanes[2]->createOptionsGroup("options.group.graphics");
	if (!OptionsItem::javaStyle) graphics.addOptionItem(&Options::Option::OPTIMIZE, minecraft);
	graphics
		.addOptionItem(&Options::Option::UI_STYLE, minecraft)
		.addOptionItem(&Options::Option::GUI_SCALE, minecraft)
		.addOptionItem(&Options::Option::FOV, minecraft)
		.addOptionItem(&Options::Option::LEAVES, minecraft)
		.addOptionItem(&Options::Option::RENDER_SCALE, minecraft)
		.addOptionItem(&Options::Option::BIOME_BLEND, minecraft)
		.addOptionItem(&Options::Option::BIOME_SKY, minecraft)
		.addOptionItem(&Options::Option::LIGHTING_STYLE, minecraft)
		.addOptionItem(&Options::Option::ENTITY_LIGHTING, minecraft)
		.addOptionItem(&Options::Option::ANTIALIAS, minecraft)
		.addOptionItem(&Options::Option::STEREO_3D, minecraft)
		.addOptionItem(&Options::Option::SHOW_FPS, minecraft);
	if (!mcIsPhoneDevice())
		graphics.addOptionItem(&Options::Option::STEREO_3D, minecraft);
	optionPanes[2]->createOptionsGroup("options.group.fog")
		.addOptionItem(&Options::Option::VIEW_DISTANCE, minecraft)
		.addOptionItem(&Options::Option::DISTANT_DETAIL, minecraft)
		.addOptionItem(&Options::Option::LAZY_CHUNKS, minecraft)
		.addOptionItem(&Options::Option::PRELOAD_CHUNKS, minecraft)
		.addOptionItem(&Options::Option::FOG, minecraft)
		.addOptionItem(&Options::Option::FOG_START, minecraft);
	optionPanes[2]->createOptionsGroup("options.group.graphicsExperimental")
		.addOptionItem(&Options::Option::AMBIENT_OCCLUSION, minecraft)
		.addOptionItem(&Options::Option::FANCY_CLOUDS, minecraft);
}

void OptionsScreen::keyPressed(int eventKey) {
	if (eventKey == Keyboard::KEY_ESCAPE) {
		buttonClicked(btnClose);
		return;
	}
	super::keyPressed(eventKey);
}

void OptionsScreen::mouseClicked( int x, int y, int buttonNum ) {
	if(currentOptionPane != NULL && y >= viewTop() - 6 && y < viewBottom()) {
		currentOptionPane->mouseClicked(minecraft, x, y, buttonNum);
		dragging = true;
		dragScrolling = false;
		dragOnSlider = pointOnSlider(x, y);
		dragStartY = y;
		dragStartScroll = scrollY;
	}
	super::mouseClicked(x, y, buttonNum);
}

void OptionsScreen::mouseReleased( int x, int y, int buttonNum ) {
	dragging = dragScrolling = false;
	if(currentOptionPane != NULL)
		currentOptionPane->mouseReleased(minecraft, x, y, buttonNum);
	super::mouseReleased(x, y, buttonNum);
}

void OptionsScreen::tick() {
	if(currentOptionPane != NULL)
		currentOptionPane->tick(minecraft);
	super::tick();
}

bool OptionsScreen::closeButtonRect(int& x, int& y, int& w, int& h) {
	if (!btnClose || !btnClose->visible) return false;
	x = btnClose->x; y = btnClose->y; w = btnClose->width; h = btnClose->height;
	return w > 0 && h > 0;
}
