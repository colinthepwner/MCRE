#include "OptionsScreen.h"

#include "StartMenuScreen.h"
#include "DialogDefinitions.h"
#include "../../Minecraft.h"
#include "../../../AppPlatform.h"

#include "../components/OptionsPane.h"
#include "../components/ImageButton.h"
#include "../components/OptionsGroup.h"
#include "../../../platform/input/Keyboard.h"
#ifdef EMSCRIPTEN
#include <emscripten.h>
#endif
OptionsScreen::OptionsScreen()
: btnClose(NULL),
  btnUsername(NULL),
  bHeader(NULL),
  selectedCategory(0) {
}

OptionsScreen::~OptionsScreen() {
	if(btnClose != NULL) {
		delete btnClose;
		btnClose = NULL;
	}
	if(bHeader != NULL) {
		delete bHeader,
		bHeader = NULL;
	}
	delete btnUsername;
	btnUsername = NULL;
	for(std::vector<Touch::TButton*>::iterator it = categoryButtons.begin(); it != categoryButtons.end(); ++it) {
		if(*it != NULL) {
			delete *it;
			*it = NULL;
		}
	}
	for(std::vector<OptionsPane*>::iterator it = optionPanes.begin(); it != optionPanes.end(); ++it) {
		if(*it != NULL) {
			delete *it;
			*it = NULL;
		}
	}
	categoryButtons.clear();
}

void OptionsScreen::init() {
	bHeader = new Touch::THeader(0, "Options");
	btnClose = new ImageButton(1, "");
	ImageDef def;
	def.name = "gui/touchgui.png";
	def.width = 34;
	def.height = 26;

	def.setSrc(IntRectangle(150, 0, (int)def.width, (int)def.height));
	btnClose->setImageDef(def, true);

	categoryButtons.push_back(new Touch::TButton(2, "Controls"));
	categoryButtons.push_back(new Touch::TButton(3, "Game"));
	categoryButtons.push_back(new Touch::TButton(4, "Graphics"));
	buttons.push_back(bHeader);
	buttons.push_back(btnClose);
#ifdef EMSCRIPTEN
	btnUsername = new Touch::TButton(9, "Username");
	buttons.push_back(btnUsername);
#endif
	for(std::vector<Touch::TButton*>::iterator it = categoryButtons.begin(); it != categoryButtons.end(); ++it) {
		buttons.push_back(*it);
		tabButtons.push_back(*it);
	}
	generateOptionScreens();

}
void OptionsScreen::setupPositions() {
	int buttonHeight = btnClose->height;
	btnClose->x = width - btnClose->width;
	btnClose->y = 0;
	int offsetNum = 1;
	for(std::vector<Touch::TButton*>::iterator it = categoryButtons.begin(); it != categoryButtons.end(); ++it) {
		(*it)->x = 0;
		(*it)->y = offsetNum * buttonHeight;
		(*it)->selected = false;
		offsetNum++;
	}
	bHeader->x = 0;
	bHeader->y = 0;
	bHeader->width = width - btnClose->width;
	bHeader->height = btnClose->height;
	if (btnUsername && categoryButtons.size() > 0 && categoryButtons[0] != NULL) {
		const int tabW = categoryButtons[0]->width;
		const int avail = width - tabW;
		const int cw = avail - 16 < 280 ? avail - 16 : 280;
		btnUsername->width = cw < 200 ? cw : 200;
		btnUsername->height = buttonHeight;
		btnUsername->x = tabW + (avail - btnUsername->width) / 2;
		btnUsername->y = height - buttonHeight - 8;
	}
	for(std::vector<OptionsPane*>::iterator it = optionPanes.begin(); it != optionPanes.end(); ++it) {
		if(categoryButtons.size() > 0 && categoryButtons[0] != NULL) {
			const int tabW = categoryButtons[0]->width;
			const int avail = width - tabW;
			const int cw = avail - 16 < 280 ? avail - 16 : 280;
			(*it)->x = tabW + (avail - cw) / 2;
			(*it)->y = bHeader->height + 8;
			(*it)->width = cw;
			(*it)->setupPositions();
		}
	}
	selectCategory(0);
}

void OptionsScreen::render( int xm, int ym, float a ) {
	if (btnUsername)
		btnUsername->msg = minecraft->options.usernameSet
			? "Username: " + minecraft->options.username : std::string("Set username");
	renderBackground();
	super::render(xm, ym, a);
	int xmm = xm * width / minecraft->width;
	int ymm = ym * height / minecraft->height - 1;
	if (minecraft->level && currentOptionPane != NULL) {
		fill(currentOptionPane->x - 10, currentOptionPane->y - 6,
		     currentOptionPane->x + currentOptionPane->width + 10, currentOptionPane->height + 4, 0xb0000000);
	}
	if(currentOptionPane != NULL)
		currentOptionPane->render(minecraft, xmm, ymm);
}

void OptionsScreen::removed()
{
}
void OptionsScreen::buttonClicked( Button* button ) {
	if(button == btnClose) {
		if (minecraft->level) {
			minecraft->options.save();
			minecraft->screenChooser.setScreen(SCREEN_PAUSE);
			return;
		}
		minecraft->reloadOptions();
		minecraft->screenChooser.setScreen(SCREEN_STARTMENU);
	} else if (btnUsername && button == btnUsername) {
#ifdef EMSCRIPTEN
		EM_ASM({ if (Module.mcAskUsername) Module.mcAskUsername(); });
#endif
	} else if(button->id > 1 && button->id < 7) {
		// This is a category button
		int categoryButton = button->id - categoryButtons[0]->id;
		selectCategory(categoryButton);
	}
}

void OptionsScreen::selectCategory( int index ) {
	int currentIndex = 0;
	for(std::vector<Touch::TButton*>::iterator it = categoryButtons.begin(); it != categoryButtons.end(); ++it) {
		if(index == currentIndex) {
			(*it)->selected = true;
		} else {
			(*it)->selected = false;
		}
		currentIndex++;
	}
	if(index < (int)optionPanes.size())
		currentOptionPane = optionPanes[index];
	if (btnUsername) btnUsername->visible = btnUsername->active = (index == 1);
}

void OptionsScreen::generateOptionScreens() {
	optionPanes.push_back(new OptionsPane());
	optionPanes.push_back(new OptionsPane());
	optionPanes.push_back(new OptionsPane());

	OptionsGroup& controls = optionPanes[0]->createOptionsGroup("options.group.controls");
	controls.addOptionItem(&Options::Option::SENSITIVITY, minecraft)
		.addOptionItem(&Options::Option::INVERT_MOUSE, minecraft)
		.addOptionItem(&Options::Option::LEFT_HANDED, minecraft);
#ifndef EMSCRIPTEN
	controls.addOptionItem(&Options::Option::USE_TOUCHSCREEN, minecraft)
		.addOptionItem(&Options::Option::USE_TOUCH_JOYPAD, minecraft);
	optionPanes[0]->createOptionsGroup("Feedback")
		.addOptionItem(&Options::Option::DESTROY_VIBRATION, minecraft);
#endif

	optionPanes[1]->createOptionsGroup("options.group.game")
		.addOptionItem(&Options::Option::DIFFICULTY_SLIDER, minecraft)
		.addOptionItem(&Options::Option::SERVER_VISIBLE, minecraft)
		.addOptionItem(&Options::Option::HUNGER, minecraft)
		.addOptionItem(&Options::Option::SPRINTING, minecraft);

	optionPanes[1]->createOptionsGroup("options.group.audio")
		.addOptionItem(&Options::Option::SOUND, minecraft)
		.addOptionItem(&Options::Option::MUSIC, minecraft);

	optionPanes[2]->createOptionsGroup("options.group.graphics")
		.addOptionItem(&Options::Option::FOV, minecraft)
		.addOptionItem(&Options::Option::GRAPHICS, minecraft)
		.addOptionItem(&Options::Option::BIOME_BLEND, minecraft)
		.addOptionItem(&Options::Option::BIOME_SKY, minecraft)
		.addOptionItem(&Options::Option::SHOW_FPS, minecraft);
	optionPanes[2]->createOptionsGroup("options.group.fog")
		.addOptionItem(&Options::Option::VIEW_DISTANCE, minecraft)
		.addOptionItem(&Options::Option::FOG, minecraft)
		.addOptionItem(&Options::Option::FOG_START, minecraft);
	optionPanes[2]->createOptionsGroup("options.group.graphicsExperimental")
		.addOptionItem(&Options::Option::AMBIENT_OCCLUSION, minecraft)
		.addOptionItem(&Options::Option::FANCY_CLOUDS, minecraft);
}

void OptionsScreen::keyPressed(int eventKey) {
	if (eventKey == Keyboard::KEY_ESCAPE) {
		buttonClicked(btnClose);
		return;
	}
	super::keyPressed(eventKey);
}

void OptionsScreen::mouseClicked( int x, int y, int buttonNum ) {
	if(currentOptionPane != NULL)
		currentOptionPane->mouseClicked(minecraft, x, y, buttonNum);
	super::mouseClicked(x, y, buttonNum);
}

void OptionsScreen::mouseReleased( int x, int y, int buttonNum ) {
	if(currentOptionPane != NULL)
		currentOptionPane->mouseReleased(minecraft, x, y, buttonNum);
	super::mouseReleased(x, y, buttonNum);
}

void OptionsScreen::tick() {
	if(currentOptionPane != NULL)
		currentOptionPane->tick(minecraft);
	super::tick();
}
