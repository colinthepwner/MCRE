#ifndef NET_MINECRAFT_CLIENT_GUI_SCREENS__DemoChooseLevelScreen_H__
#define NET_MINECRAFT_CLIENT_GUI_SCREENS__DemoChooseLevelScreen_H__

#include "ChooseLevelScreen.h"
#include "../../../world/level/levelgen/WorldGenOptions.h"
class Button;

class SimpleChooseLevelScreen: public ChooseLevelScreen
{
public:
	SimpleChooseLevelScreen(const std::string& levelName);

	virtual ~SimpleChooseLevelScreen();

	void init();

	void setupPositions();

	void render(int xm, int ym, float a);

	void buttonClicked(Button* button);
	bool handleBackEvent(bool isDown);

private:
	struct SizeChoice { int chunks; const char* name; };
	static int sizeChoices(bool phone, const SizeChoice** out, int* defaultIndex);
	void updateLabels();

	Button* bCreative;
	Button* bSurvival;
	Button* bBack;
	Button* bSize;
	Button* bType;
	Button* bTheme;
	Button* bBiomes;
	bool hasChosen;

	std::string levelName;
};

#endif /*NET_MINECRAFT_CLIENT_GUI_SCREENS__DemoChooseLevelScreen_H__*/
