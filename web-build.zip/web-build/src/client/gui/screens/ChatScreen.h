#ifndef NET_MINECRAFT_CLIENT_GUI_SCREENS__ChatScreen_H__
#define NET_MINECRAFT_CLIENT_GUI_SCREENS__ChatScreen_H__


#include "../Screen.h"
#include "../components/ChatTextField.h"
#include <string>
#include <vector>

class ChatScreen: public Screen
{
public:
	ChatScreen(const std::string& prefix = "");
	virtual ~ChatScreen();

	void init();
	void setupPositions();
	void render(int xm, int ym, float a);
	void tick();
	void updateEvents();
	bool handleBackEvent(bool isDown);
	bool isPauseScreen() { return false; }
	bool renderGameBehind() { return true; }
	bool closeButtonRect(int& x, int& y, int& w, int& h);

	void buttonClicked(Button* button) {}

	static bool javaOpen(Minecraft* mc);
	static bool touchOpen(Minecraft* mc);
	static void flushOutbox(Minecraft* mc);
	static void queueSend(const std::string& text);

protected:
	void keyPressed(int eventKey) {}
	void mouseClicked(int x, int y, int buttonNum);
	void mouseReleased(int x, int y, int buttonNum);
	void mouseWheel(int x, int y, int notches);

private:
	void onKey(const TextKeys::Ev& e);
	void send();
	void close();
	void sentHistory(int dir);
	void completeWord();
	void takeCompletions();
	void fieldChanged();
	void syncFromPage();
	void refreshSuggestions();
	void layoutTouch();
	void renderTouch(int xm, int ym, float a);
	void touchButton(int x, int y, int w, int h, const std::string& label, bool down, bool on);
	void drawCross(int x, int y, int size, int col);

	bool touch;
	std::string defaultText;
	std::string historyStash;
	int historyCursor;
	bool completing;
	bool waitingCompletions;
	std::vector<std::string> completions;
	int completionIndex;
	ChatTextField field;

	struct Sugg { std::string display, insert; };
	std::vector<Sugg> sugg;
	std::string usage;
	std::string suggFor;
	int pageVer, pageEnters;
	int kbInset;
	int panelW, barY, barH, slashX, fieldX, fieldW, sendX, btnW, closeX, closeS, headH;
	int suggTop, suggRowH, suggRows, suggScroll, usageH;
	int histTop, histBottom, histScroll;
	int pressX, pressY, pressScroll, pressWhat;
	bool dragging;
	int msgSerial;
	std::vector<std::string> wrapped;
};

#endif /*NET_MINECRAFT_CLIENT_GUI_SCREENS__ChatScreen_H__*/
