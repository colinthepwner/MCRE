#include "DeathScreen.h"
#include "ScreenChooser.h"
#include "../components/Button.h"
#include "../../Minecraft.h"
#include "../../player/LocalPlayer.h"
#include "../../../platform/time.h"

static const int WAIT_TICKS = 30;

#ifdef EMSCRIPTEN
extern "C" int mcIsTouchMode();
static bool pcLayout() { return !mcIsTouchMode(); }
#else
static bool pcLayout() { return false; }
#endif
static const int PC_TITLE_H = 36;

DeathScreen::DeathScreen()
:	bRespawn(0),
	bTitle(0),
	_hasChosen(false),
	_tick(0)
{
}

DeathScreen::~DeathScreen()
{
	delete bRespawn;
	delete bTitle;
}

void DeathScreen::init()
{
	if (minecraft->useTouchscreen()) {
		bRespawn = new Touch::TButton(1, "Respawn!");
		bTitle = new Touch::TButton(2, "Main menu");
	} else {
		bRespawn = new Button(1, "Respawn!");
		bTitle = new Button(2, "Main menu");
	}
	buttons.push_back(bRespawn);
	buttons.push_back(bTitle);

	tabButtons.push_back(bRespawn);
	tabButtons.push_back(bTitle);
}

void DeathScreen::setupPositions()
{
	if (pcLayout()) {
		const int W = width - 16 < 200 ? width - 16 : 200, H = 20, GAP = 4;
		const int total = PC_TITLE_H + 2 * H + GAP;
		const int y = (height - total) / 2 + PC_TITLE_H;
		bRespawn->width = bTitle->width = W;
		bRespawn->height = bTitle->height = H;
		bRespawn->x = bTitle->x = (width - W) / 2;
		bRespawn->y = y;
		bTitle->y = y + H + GAP;
		return;
	}
	bRespawn->width = bTitle->width = width / 4;

	bRespawn->y = bTitle->y = height / 2;
	bRespawn->x = width/2 - bRespawn->width - 10;
	bTitle->x = width/2 + 10;

	LOGI("xyz: %d, %d (%d, %d)\n", bTitle->x, bTitle->y, width, height);
}

void DeathScreen::tick() {
	++_tick;
}

void DeathScreen::render( int xm, int ym, float a )
{
	fillGradient(0, 0, width, height, 0x60500000, 0xa0803030);

	glPushMatrix2();
	glScalef2(2, 2, 2);
	const int titleY = pcLayout() ? (bRespawn->y - PC_TITLE_H) / 2 : height / 8;
	drawCenteredString(font, "You died!", width / 2 / 2, titleY, 0xffffff);
	glPopMatrix2();

	if (_tick >= WAIT_TICKS)
		Screen::render(xm, ym, a);
}

void DeathScreen::buttonClicked( Button* button )
{
	if (_tick < WAIT_TICKS) return;

	if (button == bRespawn) {
		//RespawnPacket packet();
		//minecraft->raknetInstance->send(packet);

		minecraft->player->respawn();
		//minecraft->raknetInstance->send();
		minecraft->setScreen(NULL);
	}

	if (button == bTitle)
		minecraft->leaveGame();
}
