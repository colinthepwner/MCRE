#include "../../Options.h"
#include "DeathScreen.h"
#include "../../../world/ModContent.h"
#include <emscripten.h>
#include <string>


#include "ScreenChooser.h"
#include "../components/Button.h"
#include "../../Minecraft.h"
#include "../../player/LocalPlayer.h"
#include "../../../platform/time.h"
#include "../../NetherTravel.h"
#include "../../../world/level/Level.h"
#include "../../../world/level/LevelSettings.h"
#include "../../../world/level/storage/LevelStorageSource.h"

static std::string s_modeLine;
static bool s_shared = false;
static std::string hardcoreLine(Minecraft* mc) {
	std::string name;
	if (mc->getGameType() == GameType::Challenge404) name = "the 404 Challenge";
	else if (!ModContent::worldMode().empty()) {
		char* n = (char*)EM_ASM_PTR({
			var s = '';
			try { var o = Module.mcMods && Module.mcMods.modeMods ? Module.mcMods.modeMods() : {}; var m = o[UTF8ToString($0)]; if (m && m.name) s = String(m.name); } catch (e) { }
			return stringToNewUTF8(s);
		}, ModContent::worldMode().c_str());
		if (n) { name = n; free(n); }
	}
	return name.empty() ? "You cannot respawn in hardcore mode!" : "You cannot respawn in " + name + "!";
}

static const int WAIT_TICKS = 30;

#ifdef EMSCRIPTEN
extern "C" int mcIsTouchMode();
static bool pcLayout() { return !mcIsTouchMode(); }
#else
static bool pcLayout() { return false; }
#endif
static const int PC_TITLE_H = 36;

DeathScreen::DeathScreen()
:	bRespawn(0),
	bTitle(0),
	_hasChosen(false),
	_hardcore(false),
	_tick(0)
{
}

DeathScreen::~DeathScreen()
{
	delete bRespawn;
	delete bTitle;
}

void DeathScreen::init()
{
	_hardcore = minecraft->getGameType() == GameType::Challenge404 || ModContent::worldHardcore();
	s_shared = _hardcore && ModContent::othersConnected(minecraft->level);
	if (s_shared) _hardcore = false;
	if (_hardcore) s_modeLine = hardcoreLine(minecraft);
	if (_hardcore && minecraft->level && !minecraft->level->isClientSide)
		minecraft->level->saveLevelData();

	const char* titleText = _hardcore ? "Delete world" : "Main menu";
	if (Options::pocketUi()) {
		bRespawn = new Touch::TButton(1, "Respawn!");
		bTitle = new Touch::TButton(2, titleText);
	} else {
		bRespawn = new Button(1, "Respawn!");
		bTitle = new Button(2, titleText);
	}
	if (_hardcore) bRespawn->visible = bRespawn->active = false;
	else {
		buttons.push_back(bRespawn);
		tabButtons.push_back(bRespawn);
	}
	buttons.push_back(bTitle);
	tabButtons.push_back(bTitle);
}

void DeathScreen::setupPositions()
{
	if (_hardcore) {
		const int W = pcLayout() ? (width - 16 < 200 ? width - 16 : 200) : width / 3;
		bTitle->width = W;
		if (pcLayout()) bTitle->height = 20;
		bTitle->x = (width - W) / 2;
		bTitle->y = pcLayout() ? (height - PC_TITLE_H - 20) / 2 + PC_TITLE_H + 12 : height / 2 + 8;
		bRespawn->x = bRespawn->y = -1000;
		return;
	}
	if (pcLayout()) {
		const int W = width - 16 < 200 ? width - 16 : 200, H = 20, GAP = 4;
		const int total = PC_TITLE_H + 2 * H + GAP;
		const int y = (height - total) / 2 + PC_TITLE_H;
		bRespawn->width = bTitle->width = W;
		bRespawn->height = bTitle->height = H;
		bRespawn->x = bTitle->x = (width - W) / 2;
		bRespawn->y = y;
		bTitle->y = y + H + GAP;
		return;
	}
	bRespawn->width = bTitle->width = width / 4;

	bRespawn->y = bTitle->y = height / 2;
	bRespawn->x = width/2 - bRespawn->width - 10;
	bTitle->x = width/2 + 10;

	LOGI("xyz: %d, %d (%d, %d)\n", bTitle->x, bTitle->y, width, height);
}

void DeathScreen::tick() {
	++_tick;
}

void DeathScreen::render( int xm, int ym, float a )
{
	fillGradient(0, 0, width, height, 0x60500000, 0xa0803030);

	glPushMatrix2();
	glScalef2(2, 2, 2);
	const int titleY = _hardcore ? (bTitle->y - PC_TITLE_H - 12) / 2
	                 : pcLayout() ? (bRespawn->y - PC_TITLE_H) / 2 : height / 8;
	drawCenteredString(font, _hardcore ? "Game over!" : "You died!", width / 2 / 2, titleY, 0xffffff);
	glPopMatrix2();
	if (_hardcore)
		drawCenteredString(font, s_modeLine, width / 2, bTitle->y - 16, 0xffffff);
	else if (s_shared)
		drawCenteredString(font, "Hardcore: everything you carried is gone.", width / 2, bTitle->y + bTitle->height + 8, 0xff8080);

	if (_tick >= WAIT_TICKS)
		Screen::render(xm, ym, a);
}

void DeathScreen::buttonClicked( Button* button )
{
	if (_tick < WAIT_TICKS) return;

	if (button == bRespawn) {
		//RespawnPacket packet();
		//minecraft->raknetInstance->send(packet);

		minecraft->player->respawn();
		//minecraft->raknetInstance->send();
		minecraft->setScreen(NULL);
	}

	if (button == bTitle) {
		if (_hardcore) {
			const std::string id = NetherTravel::currentLevelId();
			minecraft->leaveGame();
			if (!id.empty() && minecraft->getLevelSource())
				minecraft->getLevelSource()->deleteLevel(id);
			return;
		}
		minecraft->leaveGame();
	}
}
