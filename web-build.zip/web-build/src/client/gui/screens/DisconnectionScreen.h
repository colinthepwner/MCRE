#ifndef NET_MINECRAFT_CLIENT_GUI_SCREENS__DisconnectionScreen_H__
#define NET_MINECRAFT_CLIENT_GUI_SCREENS__DisconnectionScreen_H__

#include "../Screen.h"
#include "../Font.h"
#include "../components/Button.h"
#include "../../Minecraft.h"
#include "../../Options.h"
#include <string>
#include <vector>

class DisconnectionScreen: public Screen
{
	typedef Screen super;
public:
	DisconnectionScreen(const std::string& msg)
	:	_msg(msg),
		_back(NULL),
		_textY(0)
	{}

	~DisconnectionScreen() {
		delete _back;
	}

	void init() {
		if (Options::pocketUi())
			_back = new Touch::TButton(1, "Ok");
		else
			_back = new Button(1, "Ok");

		buttons.push_back(_back);
		tabButtons.push_back(_back);
	}

	void setupPositions() {
		_lines.clear();
		std::string line, word;
		const std::string& m = _msg;
		for (size_t i = 0; i <= m.size(); ++i) {
			const char c = i < m.size() ? m[i] : ' ';
			if (c != ' ' && c != '\n') { word += c; continue; }
			if (!word.empty()) {
				const std::string tryLine = line.empty() ? word : line + " " + word;
				if (!line.empty() && minecraft->font->width(tryLine) > width - 50) { _lines.push_back(line); line = word; }
				else line = tryLine;
				word.clear();
			}
			if (c == '\n') { _lines.push_back(line); line.clear(); }
		}
		if (!line.empty() || _lines.empty()) _lines.push_back(line);

		if (Options::pocketUi()) _back->width = 128;
		else { _back->width = width - 16 < 200 ? width - 16 : 200; _back->height = 20; }
		const int textH = (int)_lines.size() * LINE_H;
		int top = (height - (textH + GAP + _back->height)) / 2;
		if (top < 8) top = 8;
		_textY = top;
		_back->x = (width - _back->width) / 2;
		_back->y = top + textH + GAP;
	}

	void render( int xm, int ym, float a ) {
		renderBackground();
		super::render(xm, ym, a);

		for (size_t i = 0; i < _lines.size(); ++i) {
			const int x = (width - minecraft->font->width(_lines[i])) / 2;
			minecraft->font->drawShadow(_lines[i], (float)x, (float)(_textY + (int)i * LINE_H), 0xffffffff);
		}
	}

	void buttonClicked(Button* button) {
		if (button->id == _back->id) {
			minecraft->leaveGame();
		}
	}
	bool isInGameScreen() { return false; }

private:
	static const int LINE_H = 10;
	static const int GAP = 20;
	std::string _msg;
	Button* _back;
	std::vector<std::string> _lines;
	int _textY;
};

#endif /*NET_MINECRAFT_CLIENT_GUI_SCREENS__DisconnectionScreen_H__*/
