#include "../../Options.h"
#include "InBedScreen.h"
#include "ScreenChooser.h"
#include "../components/Button.h"
#include "../../Minecraft.h"
#include "../../player/LocalPlayer.h"
#include "../../../platform/time.h"

static const int WAIT_TICKS = 30;

InBedScreen::InBedScreen()
	: bWakeUp(0)
{
}

InBedScreen::~InBedScreen() {
	delete bWakeUp;
}

void InBedScreen::init() {
	if (Options::pocketUi()) {
		bWakeUp = new Touch::TButton(1, "Leave Bed");
	} else {
		bWakeUp = new Button(1, "Leave Bed");
	}
	buttons.push_back(bWakeUp);

	tabButtons.push_back(bWakeUp);
}

#ifdef EMSCRIPTEN
extern "C" int mcIsTouchMode();
static bool pcLayout() { return !mcIsTouchMode(); }
#else
static bool pcLayout() { return false; }
#endif

void InBedScreen::setupPositions() {
	int hx = 0, hy = 0;
	minecraft->gui.getSlotPos(0, hx, hy);
	const int hotbarTop = height - ((int)(minecraft->height * Gui::InvGuiScale) - hy);
	if (pcLayout()) {
		bWakeUp->width = width - 16 < 200 ? width - 16 : 200;
		bWakeUp->height = 20;
		bWakeUp->y = hotbarTop - 18;
	} else {
		bWakeUp->width = width - 16 < 160 ? width - 16 : 160;
		bWakeUp->y = hotbarTop - 6 - bWakeUp->height;
	}
	bWakeUp->x = (width - bWakeUp->width) / 2;
}

void InBedScreen::render( int xm, int ym, float a ) {
	glEnable(GL_BLEND);
	glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
	Screen::render(xm, ym, a);
	glDisable(GL_BLEND);
}

void InBedScreen::buttonClicked( Button* button ) {
	if (button == bWakeUp) {
		minecraft->player->stopSleepInBed(true, true, true);
		minecraft->setScreen(NULL);
	}
}
