#include "../../../Account.h"
#include "TouchStartMenuScreen.h"
#ifdef EMSCRIPTEN
#include <emscripten.h>
#include "../WebJoinScreen.h"
EM_JS(int, startmenu_take_rejoin, (char* out, int size), {
	try {
		var c = Module.mcRejoin;
		if (!c) return 0;
		Module.mcRejoin = null;
		stringToUTF8(String(c), out, size);
		return 1;
	} catch (e) { return 0; }
});
#endif
#include "../ProgressScreen.h"
#include "../OptionsScreen.h"
#include "../PauseScreen.h"
#include "../InvalidLicenseScreen.h"
//#include "BuyGameScreen.h"

#include "../../Font.h"
#include "../../Gui.h"
#include "../../components/SmallButton.h"
#include "../../components/ScrolledSelectionList.h"
#include "../../components/GuiElement.h"

#include "../../../Minecraft.h"
#include "../../ModMenuButtons.h"
#include <algorithm>
#ifdef EMSCRIPTEN
extern "C" void glGenerateMipmap(GLenum target);
#endif
#include "../../../renderer/Tesselator.h"
#include "../../../renderer/Textures.h"
#include "../../../renderer/TextureData.h"
#include "../../../../SharedConstants.h"
#include "../../../../AppPlatform.h"
#include "../../../../LicenseCodes.h"
#include "../../../../util/Mth.h"
#include "../../../Options.h"
#include "../../../../platform/time.h"
#include <cstdio>
#include <cstdlib>

#include "../DialogDefinitions.h"
#include "../ModsScreen.h"
#include "../SimpleChooseLevelScreen.h"
#include "../../../../world/level/LevelSettings.h"
#include "../../../../world/level/storage/ExternalFileLevelStorageSource.h"
#include "../../../../world/level/storage/LevelStorageSource.h"
#include <set>

//
// Buy Button implementation
//
BuyButton::BuyButton(int id)
:	super(id, "")
{
	ImageDef def;
	// Setup the source rectangle
	def.setSrc(IntRectangle(64, 182, 190, 55));
	def.width = 75;//rc.w / 3;
	def.height = 75 * (55.0f / 190.0f);//rc.h / 3;
	def.name = "gui/gui.png";

	setImageDef(def, true);
}

void BuyButton::render(Minecraft* minecraft, int xm, int ym) {
	glColor4f2(1, 1, 1, 1);
	bool hovered = active && (minecraft->useTouchscreen()? (xm >= x && ym >= y && xm < x + width && ym < y + height) : false);
	renderBg(minecraft, xm, ym);
	TextureId texId = (_imageDef.name.length() > 0)? minecraft->textures->loadAndBindTexture(_imageDef.name) : Textures::InvalidId;
	if ( Textures::isTextureIdValid(texId) ) {
		const ImageDef& d = _imageDef;
		Tesselator& t = Tesselator::instance;
		
		t.begin();
			if (!active)				t.color(0xff808080);
			else if (hovered||selected) t.color(0xffcccccc);
			//else						t.color(0xffe0e0e0);
			else t.color(0xffffffff);

			float hx = ((float) d.width) * 0.5f;
			float hy = ((float) d.height) * 0.5f;
			const float cx = ((float)x+d.x) + hx;
			const float cy = ((float)y+d.y) + hy;
			if (hovered) {
				hx *= 0.95f;
				hy *= 0.95f;
			}

			const TextureData* td = minecraft->textures->getTemporaryTextureData(texId);
			const IntRectangle* src = _imageDef.getSrc();
			if (td != NULL && src != NULL) {
				float u0 = (src->x) / (float)td->w;
				float u1 = (src->x+src->w) / (float)td->w;
				float v0 = (src->y) / (float)td->h;
				float v1 = (src->y+src->h) / (float)td->h;
				t.vertexUV(cx-hx, cy-hy, blitOffset, u0, v0);
				t.vertexUV(cx-hx, cy+hy, blitOffset, u0, v1);
				t.vertexUV(cx+hx, cy+hy, blitOffset, u1, v1);
				t.vertexUV(cx+hx, cy-hy, blitOffset, u1, v0);
			}
		t.draw();
	}
}

static std::string pickSplash() {
	std::vector<std::string> lines;
	if (FILE* f = fopen("/data/images/title/splashes.txt", "rb")) {
		char buf[256];
		while (fgets(buf, sizeof buf, f)) {
			std::string s(buf);
			while (!s.empty() && (s[s.size()-1] == '\n' || s[s.size()-1] == '\r')) s.erase(s.size()-1);
			bool ascii = !s.empty();
			for (unsigned int i = 0; i < s.size(); ++i) if ((unsigned char)s[i] >= 0x80) { ascii = false; break; }
			if (ascii) lines.push_back(s);
		}
		fclose(f);
	}
	if (lines.empty()) return "";
	return lines[(unsigned int)(getTimeMs() ^ rand()) % lines.size()];
}

//
//
static bool renderPanorama(Minecraft* mc) {
	static int state = 0;
	TextureId ids[6];
	if (state == 0) {
		FILE* f = fopen("/data/images/title/bg/ready", "rb");
		if (!f) return false;
		fclose(f);
		state = 1;
	}
	for (int i = 0; i < 6; ++i) {
		char name[64];
		sprintf(name, "title/bg/panorama%d.png", i);
		ids[i] = mc->textures->loadTexture(name);
		if (!Textures::isTextureIdValid(ids[i])) return false;
	}

	const float ms = (float)(getTimeMs() % 3600000);
	const float yaw = ms * 0.0025f;
	const float pitch = 2.0f + Mth::sin(ms / 23000.0f) * 5.0f;

	glMatrixMode(GL_PROJECTION);
	glPushMatrix2();
	glLoadIdentity2();
	gluPerspective(80.0f, (float)mc->width / (float)(mc->height > 0 ? mc->height : 1), 0.05f, 10.0f);
	glMatrixMode(GL_MODELVIEW);
	glPushMatrix2();
	glLoadIdentity2();
	glRotatef2(pitch, 1.0f, 0.0f, 0.0f);
	glRotatef2(yaw + 180.0f, 0.0f, 1.0f, 0.0f);

	const GLboolean depthWas = glIsEnabled(GL_DEPTH_TEST);
	const GLboolean cullWas = glIsEnabled(GL_CULL_FACE);
	glDisable2(GL_DEPTH_TEST);
	glDisable2(GL_CULL_FACE);
	glDisable2(GL_BLEND);
	glEnable2(GL_TEXTURE_2D);
	glColor4f2(1, 1, 1, 1);

	static const float F[6][3][3] = {
		{ { 0, 0, 1 }, { -1, 0, 0 }, { 0, 1, 0 } },
		{ { -1, 0, 0 }, { 0, 0, -1 }, { 0, 1, 0 } },
		{ { 0, 0, -1 }, { 1, 0, 0 }, { 0, 1, 0 } },
		{ { 1, 0, 0 }, { 0, 0, 1 }, { 0, 1, 0 } },
		{ { 0, 1, 0 }, { -1, 0, 0 }, { 0, 0, -1 } },
		{ { 0, -1, 0 }, { -1, 0, 0 }, { 0, 0, 1 } },
	};
	Tesselator& t = Tesselator::instance;
	for (int i = 0; i < 6; ++i) {
		mc->textures->bind(ids[i]);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_CLAMP_TO_EDGE);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_CLAMP_TO_EDGE);
		const float* f = F[i][0]; const float* r = F[i][1]; const float* u = F[i][2];
		t.begin();
		t.vertexUV(f[0] - r[0] + u[0], f[1] - r[1] + u[1], f[2] - r[2] + u[2], 0, 0);
		t.vertexUV(f[0] - r[0] - u[0], f[1] - r[1] - u[1], f[2] - r[2] - u[2], 0, 1);
		t.vertexUV(f[0] + r[0] - u[0], f[1] + r[1] - u[1], f[2] + r[2] - u[2], 1, 1);
		t.vertexUV(f[0] + r[0] + u[0], f[1] + r[1] + u[1], f[2] + r[2] + u[2], 1, 0);
		t.draw();
	}

	glMatrixMode(GL_PROJECTION);
	glPopMatrix2();
	glMatrixMode(GL_MODELVIEW);
	glPopMatrix2();
	if (depthWas) glEnable2(GL_DEPTH_TEST);
	if (cullWas) glEnable2(GL_CULL_FACE);
	return true;
}

namespace Touch {

//
// Start menu screen implementation
//

// Some kind of default settings, might be overridden in ::init
StartMenuScreen::StartMenuScreen()
:	bHost(    2, "Start Game"),
	bJoin(    3, "Join Game"),
	bOptions( 4, "Options"),
	bMods(    6, "Mods"),
	bTutorial(7, "Tutorial"),
	bBuy(     5),
	bTest(    9, "Create"),
	jSingle(  2, 0, 0, 200, 20, "Singleplayer"),
	jMulti(   3, 0, 0, 200, 20, "Multiplayer"),
	jTutorial(7, 0, 0, 200, 20, "Play Tutorial"),
	jMods(    6, 0, 0,  98, 20, "Mods"),
	jOptions( 4, 0, 0,  98, 20, "Options...")
{
	ImageDef def;
	bJoin.width = 75;
	def.width = def.height = (float) bJoin.width;

	def.setSrc(IntRectangle(0, 26, (int)def.width, (int)def.width));
	def.name = "gui/touchgui.png";
	IntRectangle& defSrc = *def.getSrc();

	bOptions.setImageDef(def, true);

	defSrc.y += defSrc.h;
	bHost.setImageDef(def, true);

	defSrc.y += defSrc.h;
	bJoin.setImageDef(def, true);

	ImageDef mods = def;
	mods.name = "gui/mods_button.png";
	mods.setSrc(IntRectangle(0, 0, (int)def.width, (int)def.width));
	bMods.setImageDef(mods, true);

	ImageDef tut = def;
	tut.name = "gui/tutorial_button.png";
	tut.setSrc(IntRectangle(0, 0, (int)def.width, (int)def.width));
	bTutorial.setImageDef(tut, true);
}

StartMenuScreen::~StartMenuScreen()
{
	for (unsigned int i = 0; i < modButtons.size(); ++i) delete modButtons[i];
}

void StartMenuScreen::syncModButtons() {
	for (unsigned int i = 0; i < modButtons.size(); ++i) {
		::Button* b = modButtons[i];
		buttons.erase(std::remove(buttons.begin(), buttons.end(), b), buttons.end());
		tabButtons.erase(std::remove(tabButtons.begin(), tabButtons.end(), b), tabButtons.end());
		delete b;
	}
	modButtons.clear();
	const std::vector<std::string>& labels = ModMenuButtons::labels("title");
	for (unsigned int i = 0; i < labels.size(); ++i) {
		::Button* b = new TButton(ModMenuButtons::FIRST + i, labels[i]);
		modButtons.push_back(b);
		buttons.push_back(b);
		tabButtons.push_back(b);
	}
	modVersion = ModMenuButtons::version();
}

void StartMenuScreen::useButtonSet(bool pc) {
	::Button* all[10] = { &bHost, &bJoin, &bTutorial, &bMods, &bOptions, &jSingle, &jMulti, &jTutorial, &jMods, &jOptions };
	for (int i = 0; i < 10; ++i) {
		buttons.erase(std::remove(buttons.begin(), buttons.end(), all[i]), buttons.end());
		tabButtons.erase(std::remove(tabButtons.begin(), tabButtons.end(), all[i]), tabButtons.end());
	}
	::Button** set = pc ? all + 5 : all;
	buttons.insert(buttons.begin(), set, set + 5);
	tabButtons.insert(tabButtons.begin(), set, set + 5);
	pcLayout = pc ? 1 : 0;
}

void StartMenuScreen::init()
{
    //buttons.push_back(&bTest);
	splash = pickSplash();

	#ifdef DEMO_MODE
		buttons.push_back(&bBuy);
		tabButtons.push_back(&bBuy);
	#endif

	copyright = "Unofficial fan project - not affiliated with Mojang";

	#ifdef PRE_ANDROID23
		std::string versionString = Common::getGameVersionString("j");
	#else
		std::string versionString = Common::getGameVersionString();
	#endif

	#ifdef DEMO_MODE
        #ifdef __APPLE__
            version = versionString + " (Lite)";
        #else
            version = versionString + " (Demo)";
        #endif
	#else
		version = versionString;
	#endif
	gameVersion = "Minecraft RE";
	#ifdef EMSCRIPTEN
		gameVersion += std::string(" ") + emscripten_run_script_string("String(Module.mcBuild || 'dev')");
	#endif
	#ifdef EMSCRIPTEN
		version = "@colinthepwner";
	#endif
    
    #ifdef APPLE_DEMO_PROMOTION
        version = versionString + " (Demo)";
    #endif

	bJoin.active = bHost.active = bOptions.active = bMods.active = bTutorial.active = false;
	jSingle.active = jMulti.active = jTutorial.active = jMods.active = jOptions.active = false;
	syncModButtons();
}

struct TitleArt {
	float w, h;
	float u1, v1;
	bool pixel;
};
static TitleArt titleArt(int texW, int texH) {
	TitleArt a;
	if (texW <= 0 || texH <= 0) texW = 512, texH = 128;
	a.pixel = texW == 512 && texH == 128;
	a.w = a.pixel ? 274.0f : (float)texW;
	a.h = a.pixel ? 68.0f : (texW == 1024 && texH == 512) ? 264.0f : (float)texH;
	a.u1 = a.w / (float)texW;
	a.v1 = a.h / (float)texH;
	return a;
}
static TitleArt titleArt(Minecraft* mc) {
	const TextureData* d = mc->textures->getTemporaryTextureData(mc->textures->loadTexture("gui/title.png"));
	return d ? titleArt(d->w, d->h) : titleArt(0, 0);
}

static int logoBox(int width, int height, bool pc, const TitleArt& a, float px, float py, float& w, float& h, float& y) {
	const float aspect = a.h / a.w;
	float maxW;
	if (pc) {
		w = a.pixel ? a.w : 300.0f;
		maxW = (float)width - 20.0f;
	} else {
		w = 0.36f * (float)width;
		maxW = ((float)height / 3.0f - 18.0f) / aspect;
	}
	maxW = Mth::Max(maxW, 16.0f);
	if (w > maxW) w = maxW;
	int k = 0;
	if (a.pixel) {
		k = (int)(w * px / a.w + 0.5f);
		while (k > 0 && (float)k * a.w / px > maxW) --k;
	}
	if (k > 0) {
		w = (float)k * a.w / px;
		h = (float)k * a.h / py;
	} else {
		h = w * aspect;
	}
	y = pc ? (height < 260 ? 6.0f : 18.0f) : Mth::Max(4.0f, ((float)height / 3.0f - (h + 12.0f)) * 0.5f);
	if (k > 0) y = Mth::floor(y * py + 0.5f) / py;
	return k;
}
static void guiPx(Minecraft* mc, int width, int height, float& px, float& py) {
	const float gs = Gui::GuiScale > 0 ? Gui::GuiScale : 1.0f;
	px = width > 0 && mc->width > 0 ? (float)mc->width / (float)width : gs;
	py = height > 0 && mc->height > 0 ? (float)mc->height / (float)height : gs;
}

void StartMenuScreen::setupPositions() {
	const bool pc = !Options::pocketUi();
	if ((pc ? 1 : 0) != pcLayout) useButtonSet(pc);
	copyrightPosX = width - minecraft->font->width(copyright) - 1;
	versionPosX = (width - minecraft->font->width(version)) / 2;
	if (pc) {
		float lw, lh, ly, lpx, lpy;
		guiPx(minecraft, width, height, lpx, lpy);
		logoBox(width, height, true, titleArt(minecraft), lpx, lpy, lw, lh, ly);
		int y = Mth::Max(height / 4 + 48, (int)(ly + lh) + 62);
		const int rows = 3 + (int)modButtons.size();
		const int need = rows * 24 + 12 + 20;
		if (y + need > height - 12) y = Mth::Max((int)(ly + lh) + 62, height - 12 - need);
		const int x = (width - 200) / 2;
		jSingle.x = x; jSingle.y = y;
		jMulti.x = x;  jMulti.y = y + 24;
		jTutorial.x = x; jTutorial.y = y + 48;
		for (unsigned int i = 0; i < modButtons.size(); ++i) {
			modButtons[i]->x = x; modButtons[i]->y = y + 72 + 24 * i;
			modButtons[i]->width = 200; modButtons[i]->height = 20;
		}
		jMods.x = x;            jMods.y = y + rows * 24 + 12;
		jOptions.x = x + 102;   jOptions.y = jMods.y;
		bBuy.y = bTest.y = height + 100;
		return;
	}
	int yBase = 2 + height / 3;
	static const int TILE_MAX = 75, TILE_MIN = 40, TILE_GAP = 4;
	int buttonWidth = (width - 6 * TILE_GAP) / 5;
	if (buttonWidth > TILE_MAX) buttonWidth = TILE_MAX;
	if (buttonWidth < TILE_MIN) buttonWidth = TILE_MIN;
	{
		LargeImageButton* tiles[5] = { &bJoin, &bHost, &bTutorial, &bMods, &bOptions };
		for (int i = 0; i < 5; ++i) {
			tiles[i]->setImageSize((float)buttonWidth, (float)buttonWidth);
			tiles[i]->labelScale = (float)buttonWidth / (float)TILE_MAX;
		}
	}
	float spacing = (width - (5.0f * buttonWidth)) / 6;
	if (spacing < 0) spacing = 0;

	//#ifdef ANDROID
	bHost.y =	 yBase;
	bJoin.y =	 yBase;
	bOptions.y = yBase;
	bMods.y =	 yBase;
	bTutorial.y = yBase;
	//#endif

	//bTest.x = 0; //width - bTest.w;
	//bTest.y = height - bTest.h;

	// Center buttons
	bJoin.x		= 0*buttonWidth + (int)(1*spacing);
	bHost.x		= 1*buttonWidth + (int)(2*spacing);
	bTutorial.x	= 2*buttonWidth + (int)(3*spacing);
	bMods.x		= 3*buttonWidth + (int)(4*spacing);
	bOptions.x	= 4*buttonWidth + (int)(5*spacing);
	//bBuy.y = bOptions.y - bBuy.h - 6;
	//bBuy.x = bOptions.x + bOptions.w - bBuy.w;

	if (!modButtons.empty()) {
		const int GAP = 6, H = 20;
		int total = -GAP;
		for (unsigned int i = 0; i < modButtons.size(); ++i) {
			modButtons[i]->width = std::max(60, minecraft->font->width(modButtons[i]->msg) + 16);
			modButtons[i]->height = H;
			total += modButtons[i]->width + GAP;
		}
		int x = (width - total) / 2, y = bHost.y + bHost.height + 10;
		for (unsigned int i = 0; i < modButtons.size(); ++i) {
			modButtons[i]->x = x;
			modButtons[i]->y = y;
			x += modButtons[i]->width + GAP;
		}
	}

	bBuy.y = height - bBuy.height - 3;
	bBuy.x = (width - bBuy.width) / 2;
    
    bTest.x = 4;
    bTest.y = height - bTest.height - 4;

	copyrightPosX = width - minecraft->font->width(copyright) - 1;
	versionPosX = (width - minecraft->font->width(version)) / 2;// - minecraft->font->width(version) - 2;
}

void StartMenuScreen::tick() {
	_updateLicense();
#ifdef EMSCRIPTEN
	char rejoin[16];
	if (startmenu_take_rejoin(rejoin, sizeof(rejoin)) && Account::gate("Multiplayer")) {
		minecraft->locateMultiplayer();
		minecraft->setScreen(new WebJoinScreen(rejoin));
		return;
	}
#endif
	if (modVersion != ModMenuButtons::version()) { syncModButtons(); setupPositions(); }
	else if ((Options::pocketUi() ? 0 : 1) != pcLayout) setupPositions();
}

void StartMenuScreen::buttonClicked(::Button* button) {
	if (ModMenuButtons::isMod(button->id)) { ModMenuButtons::press("title", button->id - ModMenuButtons::FIRST); return; }

	//if (button->id == bTest.id) {
	//	minecraft->selectLevel("Broken", "Broken", 1317199248);
	//	minecraft->hostMultiplayer();
	//	minecraft->setScreen(new ProgressScreen());
	//}
	if (button->id == bHost.id)
	{
		#if defined(DEMO_MODE) || defined(APPLE_DEMO_PROMOTION)
			minecraft->setScreen( new SimpleChooseLevelScreen("_DemoLevel") );
		#else
			minecraft->screenChooser.setScreen(SCREEN_SELECTWORLD);
		#endif
	}
	if (button->id == bJoin.id)
	{
		if (!Account::gate("Multiplayer")) return;
        #ifdef APPLE_DEMO_PROMOTION
            minecraft->platform()->createUserInput(DialogDefinitions::DIALOG_DEMO_FEATURE_DISABLED);
        #else
            minecraft->locateMultiplayer();
            minecraft->screenChooser.setScreen(SCREEN_JOINGAME);
        #endif
	}
	if (button->id == bOptions.id)
	{
		minecraft->setScreen(new OptionsScreen());
	}
	if (button->id == bMods.id)
	{
		if (!Account::gate("Mods")) return;
		minecraft->setScreen(new ModsScreen());
	}
	if (button->id == bTutorial.id)
	{
		startTutorial();
	}
	if (button->id == bBuy.id)
	{
		minecraft->platform()->buyGame();
		//minecraft->setScreen(new BuyGameScreen());
	}
}

bool StartMenuScreen::isInGameScreen() { return false; }

void StartMenuScreen::mouseClicked(int x, int y, int buttonNum) {
#ifdef EMSCRIPTEN
	if (linkW > 0 && x >= linkX - 2 && x < linkX + linkW + 2 && y >= linkY - 2 && y < linkY + 11) {
		EM_ASM({ try { window.open("https://github.com/colinthepwner/MCRE", "_blank", "noopener"); } catch (e) { } });
		return;
	}
#endif
	Screen::mouseClicked(x, y, buttonNum);
}

void StartMenuScreen::startTutorial() {
#ifdef EMSCRIPTEN
	if (!tutInstalling.empty()) return;
	const std::string id = ExternalFileLevelStorageSource::TutorialScratchId;
	tutInstalling = id;
	tutFailed = false;
	const std::string dst = minecraft->externalStoragePath + "/games/com.mojang/minecraftWorlds/" + id;
	EM_ASM({ if (Module.mcInstallWorld) Module.mcInstallWorld('worlds/tutorial/', UTF8ToString($0), 'mcInstallTutorial', true); else Module.mcInstallTutorial = -1; },
		dst.c_str());
#endif
}

void StartMenuScreen::render( int xm, int ym, float a )
{
#ifdef EMSCRIPTEN
	static bool told = false;
	if (!told) { told = true; EM_ASM({ if (Module.mcTitleShown) Module.mcTitleShown(); }); }
#endif
#ifdef EMSCRIPTEN
	if (!tutInstalling.empty()) {
		const int st = EM_ASM_INT({ return Module.mcInstallTutorial | 0; });
		if (st == 1) {
			const std::string id = tutInstalling;
			tutInstalling.clear();
			minecraft->selectLevel(id, "Tutorial", LevelSettings::None());
			minecraft->hostMultiplayer();
			minecraft->setScreen(new ProgressScreen());
			return;
		}
		if (st == -1) { tutInstalling.clear(); tutFailed = true; }
	}
#endif
	if (renderPanorama(minecraft)) {
		fillGradient(0, 0, width, height, 0x30000000, 0x70000000);
	} else {
		renderBackground();
	}

    glEnable2(GL_BLEND);

#if defined(RPI)
	TextureId id = minecraft->textures->loadTexture("gui/pi_title.png");
#else
	TextureId id = minecraft->textures->loadTexture("gui/title.png");
#endif
	const TextureData* data = minecraft->textures->getTemporaryTextureData(id);

	if (data) {
		minecraft->textures->bind(id);

		const float x = (float)width / 2;
		float y = 4;
#ifdef EMSCRIPTEN
		const TitleArt art = titleArt(data->w, data->h);
		const bool pc = !Options::pocketUi();
		float w, h, px, py;
		guiPx(minecraft, width, height, px, py);
		const int k = logoBox(width, height, pc, art, px, py, w, h, y);
		const float wh = 0.5f * w;
		const float u1 = art.u1, v1 = art.v1;
		const float lx = k > 0 ? Mth::floor((x - wh) * px + 0.5f) / px : x - wh;

		static TextureId mipmappedId = (TextureId)-1;
		if (mipmappedId != id) {
			glGenerateMipmap(GL_TEXTURE_2D);
			mipmappedId = id;
		}
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, k > 0 ? GL_NEAREST : GL_LINEAR_MIPMAP_LINEAR);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, k > 0 ? GL_NEAREST : GL_LINEAR);
#else
		const float wh = 0.5f * Mth::Min((float)width/2.0f, (float)data->w / 2);
		const float scale = 2.0f * wh / (float)data->w;
		const float h = scale * (float)data->h;
		const float u1 = 1.0f, v1 = 1.0f;
		const float lx = x - wh;
#endif

		// Render title text
		Tesselator& t = Tesselator::instance;
		glColor4f2(1, 1, 1, 1);
		t.begin();
			t.vertexUV(lx, y+h, blitOffset, 0, v1);
			t.vertexUV(lx + 2*wh, y+h, blitOffset, u1, v1);
			t.vertexUV(lx + 2*wh, y+0, blitOffset, u1, 0);
			t.vertexUV(lx, y+0, blitOffset, 0, 0);
		t.draw();

#ifdef EMSCRIPTEN
		{
			const int vy = (int)(y + h) + (pc ? 46 : 2);
			linkX = versionPosX; linkY = vy; linkW = font->width(version);
			const bool over = xm >= linkX - 2 && xm < linkX + linkW + 2 && ym >= linkY - 2 && ym < linkY + 11;
			drawString(font, version, linkX, linkY, over ? 0xffffffaa : 0xffffff55);
			if (over) fill(linkX, linkY + 9, linkX + linkW, linkY + 10, 0xffffffaa);
		}
		if (pc) drawString(font, gameVersion, 2, height - 10, 0xffffff);

		if (!splash.empty()) {
			float s = 1.8f - Mth::abs(Mth::sin((float)(getTimeMs() % 1000) / 1000.0f * 6.2831855f) * 0.1f);
			s = s * 100.0f / (float)(font->width(splash) + 32);
			s = Mth::Min(s, 160.0f / (float)font->width(splash));
			float sx = x + wh * 0.55f, sy = y + h + 12.0f;
			float tilt = -20.0f;
			if (!pc) {
				int below = bHost.y + bHost.height;
				for (unsigned int i = 0; i < modButtons.size(); ++i)
					if (modButtons[i]->y + modButtons[i]->height > below) below = modButtons[i]->y + modButtons[i]->height;
				const float bottom = (float)(height - 12);
				sx = (float)width / 2;
				sy = ((float)below + bottom) / 2.0f + 4.0f;
				tilt = 0.0f;
				s = Mth::Min(1.8f - Mth::abs(Mth::sin((float)(getTimeMs() % 1000) / 1000.0f * 6.2831855f) * 0.1f),
				             (float)(width - 24) / (float)font->width(splash));
				const float room = (bottom - (float)below) / 10.0f;
				if (s > room) s = room;
			}
			if (tilt != 0.0f && art.pixel) {
				const float th = tilt * 0.017453292f, sn = Mth::sin(th), cs = Mth::cos(th), tn = sn / cs;
				const float half = 0.5f * (float)font->width(splash) * s;
				const float dMin = -half * cs + 8.0f * s * sn, dMax = half * cs + 8.0f * s * sn;
				const float slabR = lx + w * 216.0f / 274.0f;
				const float part[2][3] = { { lx, slabR, y + h }, { slabR, lx + w, y + h * 44.0f / 68.0f } };
				for (int i = 0; i < 2; ++i) {
					const float d = Mth::Min(part[i][1] - sx, dMax);
					if (d < Mth::Max(part[i][0] - sx, dMin)) continue;
					const float top = sy + (d - 8.0f * s * sn) * tn - 8.0f * s * cs;
					if (top < part[i][2] + 1.0f) sy += part[i][2] + 1.0f - top;
				}
			}
			glPushMatrix2();
			glTranslatef2(sx, sy, 0.0f);
			if (tilt != 0.0f) glRotatef2(tilt, 0.0f, 0.0f, 1.0f);
			glScalef2(s, s, s);
			drawCenteredString(font, splash, 0, -8, 0xffffff00);
			glPopMatrix2();
		}
#else
		drawString(font, version, versionPosX, (int)(y+h)+2, /*50,*/ 0xffcccccc);//0x666666);
#endif
		drawString(font, copyright, copyrightPosX, height - 10, 0xffffff);
		//patch->draw(t, 0, 20);
#ifdef EMSCRIPTEN
		if (!tutInstalling.empty() || tutFailed) {
			const ::Button& tb = pc ? (const ::Button&)jTutorial : (const ::Button&)bTutorial;
			drawCenteredString(font, tutFailed ? "Couldn't load the tutorial world (check your connection)" : "Loading the tutorial...",
				width / 2, tb.y + tb.height + 4, tutFailed ? 0xffff6060 : 0xffffff60);
		}
#endif
	}
	Screen::render(xm, ym, a);
    glDisable2(GL_BLEND);
}

void StartMenuScreen::_updateLicense()
{
	int id = minecraft->getLicenseId();
	if (LicenseCodes::isReady(id))
	{
		if (LicenseCodes::isOk(id))
			jSingle.active = jMulti.active = jTutorial.active = jMods.active = jOptions.active =
			bJoin.active = bHost.active = bOptions.active = bMods.active = bTutorial.active = true;
		else
		{
			bool hasBuyButton = minecraft->platform()->hasBuyButtonWhenInvalidLicense();
			minecraft->setScreen(new InvalidLicenseScreen(id, hasBuyButton));
		}
	} else {
		jSingle.active = jMulti.active = jTutorial.active = jMods.active = jOptions.active =
		bJoin.active = bHost.active = bOptions.active = bMods.active = bTutorial.active = false;
	}
}

bool StartMenuScreen::handleBackEvent( bool isDown ) {
	minecraft->quit();
	return true;
}

};
