#ifndef NET_MINECRAFT_CLIENT_GUI_SCREENS_TOUCH__TouchStartMenuScreen_H__
#define NET_MINECRAFT_CLIENT_GUI_SCREENS_TOUCH__TouchStartMenuScreen_H__

#include "../../Screen.h"
#include "../../components/LargeImageButton.h"


class BuyButton: public ImageButton {
	typedef ImageButton super;
public:
	BuyButton(int id);
	void render(Minecraft* minecraft, int xm, int ym);
};


namespace Touch {

class StartMenuScreen: public Screen
{
public:
	StartMenuScreen();
	virtual ~StartMenuScreen();
	
	void init();
	void setupPositions();
	
	void tick();
	void render(int xm, int ym, float a);

	void buttonClicked(Button* button);
	bool handleBackEvent(bool isDown);
	void mouseClicked(int x, int y, int buttonNum);
	bool isInGameScreen();
private:
	void _updateLicense();
	
	void syncModButtons();
	std::vector< ::Button*> modButtons;
	int modVersion = -1;

	LargeImageButton bHost;
	LargeImageButton bJoin;
	LargeImageButton bOptions;
	LargeImageButton bMods;
	LargeImageButton bTutorial;
	TButton bTest;
	BuyButton bBuy;

	::Button jSingle, jMulti, jTutorial, jMods, jOptions;
	int pcLayout = -1;
	std::string splash;
	std::string gameVersion;
	void useButtonSet(bool pc);
	void startTutorial();
	std::string tutInstalling;
	bool tutFailed = false;

	std::string copyright;
	int copyrightPosX;

	std::string version;
	int versionPosX;
	int linkX = 0, linkY = -100, linkW = 0;
};
};

#endif /*NET_MINECRAFT_CLIENT_GUI_SCREENS_TOUCH__TouchStartMenuScreen_H__*/
