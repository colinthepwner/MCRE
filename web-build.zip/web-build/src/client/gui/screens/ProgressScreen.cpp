#include "ProgressScreen.h"
#ifdef __EMSCRIPTEN__
#include <emscripten.h>
#endif
#include "DisconnectionScreen.h"
#include "../Gui.h"
#include "../Font.h"
#include "../../Minecraft.h"
#include "../../renderer/Tesselator.h"
#include "../../../SharedConstants.h"
#include "../../renderer/Textures.h"
#include "../../../network/ClientSideNetworkHandler.h"
#include "../../../world/level/Level.h"
#include <cstdio>

ProgressScreen::ProgressScreen()
:	ticks(0)
{
}

void ProgressScreen::render( int xm, int ym, float a )
{
	// Require minimum display time so progress UI is visible during sync gen (EMSCRIPTEN)
	const int MinDisplayTicks = 20; // ~1 second
	ClientSideNetworkHandler* joiner = NULL;
#ifdef __EMSCRIPTEN__
	joiner = dynamic_cast<ClientSideNetworkHandler*>(minecraft->netCallback);
#endif
	const bool downloading = joiner && minecraft->level && !joiner->isSettled() && ticks < 60 * 20;
	if (minecraft->isLevelGenerated() && ticks >= MinDisplayTicks && !downloading) {
		minecraft->setScreen(NULL);
		return;
	}
	std::string title, status;
	int pct = minecraft->progressStagePercentage;
	if (joiner && !joiner->tripTitle().empty()) title = joiner->tripTitle();
	else if (!minecraft->progressTitle.empty()) title = minecraft->progressTitle;
	else if (minecraft->level && !minecraft->level->isClientSide) title = minecraft->level->isNew() ? "Generating world" : "Loading world";
	else title = joiner ? "Joining world" : "Generating world";
	const int sid = minecraft->getProgressStatusId();
	if (downloading || (joiner && !joiner->tripTitle().empty() && !minecraft->level)) {
		status = "Downloading terrain";
		pct = downloading ? joiner->settleProgress() : -1;
	} else if (sid == 1 && pct >= 0) {
		char b[64];
		sprintf(b, "Preparing spawn area: %d%%", pct);
		status = b;
	} else status = minecraft->getProgressMessage();

	Tesselator& t = Tesselator::instance;
	renderBackground();

	minecraft->textures->loadAndBindTexture("gui/background.png");

	const float s = 32;
	t.begin();
	t.color(0x404040);
	t.vertexUV(0, (float)height, 0, 0, height / s);
	t.vertexUV((float)width, (float)height, 0, width / s, height / s);
	t.vertexUV((float)width, 0, 0, width / s, 0);
	t.vertexUV(0, 0, 0, 0, 0);
	t.draw();

	int i = pct;

	if (i >= 0) {
		int w = 100;
		int h = 2;
		int x = width / 2 - w / 2;
		int y = height / 2 + 16;

		//printf("%d, %d - %d, %d\n", x, y, x + w, y + h);

		glDisable2(GL_TEXTURE_2D);
		t.begin();
		t.color(0x808080);
		t.vertex((float)x, (float)y, 0);
		t.vertex((float)x, (float)(y + h), 0);
		t.vertex((float)(x + w), (float)(y + h), 0);
		t.vertex((float)(x + w), (float)y, 0);

		t.color(0x80ff80);
		t.vertex((float)x, (float)y, 0);
		t.vertex((float)x, (float)(y + h), 0);
		t.vertex((float)(x + i), (float)(y + h), 0);
		t.vertex((float)(x + i), (float)y, 0);
		t.draw();
		glEnable2(GL_TEXTURE_2D);
	}

    glEnable2(GL_BLEND);

	minecraft->font->drawShadow(title, (float)((width - minecraft->font->width(title)) / 2), (float)(height / 2 - 4 - 16), 0xffffff);

	const int progressWidth = minecraft->font->width(status);
	const int progressLeft  = (width - progressWidth) / 2;
	const int progressY = height / 2 - 4 + 8;
	minecraft->font->drawShadow(status, (float)progressLeft, (float)progressY, 0xffffff);

#if APPLE_DEMO_PROMOTION
	drawCenteredString(minecraft->font, "This demonstration version", width/2, progressY + 36, 0xffffff);
    drawCenteredString(minecraft->font, "does not allow saving games", width/2, progressY + 46, 0xffffff);
#endif
    
	// If we're locating the server, show our famous spinner!
	bool isLocating = (sid == 0 && status == minecraft->getProgressMessage());
	if (isLocating) {
		const int spinnerX = progressLeft + progressWidth + 6;
		static const char* spinnerTexts[] = {"-", "\\", "|", "/"};
		int n = ((int)(5.5f * getTimeS()) % 4);
		drawCenteredString(minecraft->font, spinnerTexts[n], spinnerX, progressY, 0xffffffff);
	}

    glDisable2(GL_BLEND);
#ifndef __EMSCRIPTEN__
	sleepMs(50);
#else
#endif
}

bool ProgressScreen::isInGameScreen() { return false; }

void ProgressScreen::tick() {
#ifdef __EMSCRIPTEN__
	if (EM_ASM_INT({ var n = Module.mcNet; return n && (n.state === 'joining' || n.state === 'mods') ? 1 : 0; })) ticks = 0;
	if (ClientSideNetworkHandler* c = dynamic_cast<ClientSideNetworkHandler*>(minecraft->netCallback))
		if (!c->tripTitle().empty() && !minecraft->level) ticks = 0;
#endif
	// After 10 seconds of not connecting -> write an error message and go back
	if (++ticks == 10 * SharedConstants::TicksPerSecond && minecraft->getProgressStatusId() == 0) {
		minecraft->setScreen( new DisconnectionScreen("Could not connect to server. Try again.") );
	}
}
