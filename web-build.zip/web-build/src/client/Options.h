#ifndef NET_MINECRAFT_CLIENT__Options_H__
#define NET_MINECRAFT_CLIENT__Options_H__

//package net.minecraft.client;

//#include "locale/Language.h"

#include <string>
#include <cstdio>
#include "KeyMapping.h"
#include "../platform/input/Keyboard.h"
#include "../util/StringUtils.h"
#include "OptionsFile.h"

class Minecraft;
typedef std::vector<std::string> StringVector;

class Options
{
public:
    class Option
	{
        const bool _isProgress;
        const bool _isBoolean;
        const std::string _captionId;
		const int _ordinal;

	public:
		static const Option MUSIC;
		static const Option SOUND;
		static const Option INVERT_MOUSE;
		static const Option SENSITIVITY;
		static const Option RENDER_DISTANCE;
		static const Option VIEW_BOBBING;
		static const Option ANAGLYPH;
		static const Option LIMIT_FRAMERATE;
		static const Option DIFFICULTY;
		static const Option GRAPHICS;
		static const Option AMBIENT_OCCLUSION;
		static const Option GUI_SCALE;
        
		static const Option THIRD_PERSON;
		static const Option HIDE_GUI;
		static const Option SERVER_VISIBLE;
		static const Option LEFT_HANDED;
		static const Option USE_TOUCHSCREEN;
		static const Option USE_TOUCH_JOYPAD;
		static const Option DESTROY_VIBRATION;
		static const Option FANCY_CLOUDS;
		static const Option SPRINTING;
		static const Option FOV;
		static const Option VIEW_DISTANCE;
		static const Option FOG;
		static const Option FOG_START;
		static const Option DIFFICULTY_SLIDER;
		static const Option SHOW_FPS;
		static const Option BIOME_BLEND;
		static const Option HUNGER;
		static const Option BIOME_SKY;
		static const Option TOUCH_CONTROLS;
		static const Option RENDER_SCALE;
		static const Option DISTANT_DETAIL;

		static const Option PIXELS_PER_MILLIMETER;

		/*
        static Option* getItem(int id) {
            for (Option item : Option.values()) {
                if (item.getId() == id) {
                    return item;
                }
            }
            return NULL;
        }
		*/

        Option(int ordinal, const std::string& captionId, bool hasProgress, bool isBoolean)
		:	_captionId(captionId),
			_isProgress(hasProgress),
			_isBoolean(isBoolean),
			_ordinal(ordinal)
		{}

        bool isProgress() const {
            return _isProgress;
        }

        bool isBoolean() const {
            return _isBoolean;
        }

		bool isInt() const {
			return (!_isBoolean && !_isProgress);
		}

        int getId() {
            return _ordinal;
        }

        std::string getCaptionId() const {
            return _captionId;
        }
    };

private:
	static const float SOUND_MIN_VALUE;
	static const float SOUND_MAX_VALUE;
	static const float MUSIC_MIN_VALUE;
	static const float MUSIC_MAX_VALUE;
	static const float SENSITIVITY_MIN_VALUE;
	static const float SENSITIVITY_MAX_VALUE;
	static const float PIXELS_PER_MILLIMETER_MIN_VALUE;
	static const float PIXELS_PER_MILLIMETER_MAX_VALUE;
    static const char* RENDER_DISTANCE_NAMES[];
    static const char* DIFFICULTY_NAMES[];
    static const char* GUI_SCALE[];
	static const int DIFFICULY_LEVELS[];
public:
	static bool debugGl;

	float music;
    float sound;
    float sensitivity;
    float fov;
    bool fogEnabled;
    float fogStart;
    bool showFps;
    int biomeBlend;
    bool hungerEnabled;
    bool biomeSky;
    bool invertYMouse;
    int viewDistance;
    bool bobView;
    bool anaglyph3d;
    bool limitFramerate;
    bool fancyGraphics;
    bool ambientOcclusion;
    bool fancyClouds;
	bool useMouseForDigging;
	bool isLeftHanded;
	int touchControls;
	static int renderScale;
	static int distantDetail;
	bool destroyVibration;
    //std::string skin;

    KeyMapping keyUp;
    KeyMapping keyLeft;
    KeyMapping keyDown;
    KeyMapping keyRight;
    KeyMapping keyJump;
    KeyMapping keyBuild;
    KeyMapping keyDrop;
    KeyMapping keyChat;
    KeyMapping keyFog;
    KeyMapping keySneak;
	KeyMapping keyCraft;
	KeyMapping keyDestroy;
	KeyMapping keyUse;

	KeyMapping keyMenuNext;
	KeyMapping keyMenuPrevious;
	KeyMapping keyMenuOk;
	KeyMapping keyMenuCancel;

    KeyMapping* keyMappings[16];

	/*protected*/ Minecraft* minecraft;
    ///*private*/ File optionsFile;

    int difficulty;
    bool hideGui;
    bool thirdPersonView;
    bool renderDebug;

    bool isFlying;
    bool smoothCamera;
    bool fixedCamera;
    float flySpeed;
    float cameraSpeed;
    int guiScale;
	std::string username;
	bool usernameSet;

	bool serverVisible;
	bool isJoyTouchArea;
	bool useTouchScreen;
	bool sprintingEnabled;
	float pixelsPerMillimeter;

	bool sprintAllowed() const { return hungerEnabled || sprintingEnabled; }
    Options(Minecraft* minecraft, const std::string& workingDirectory)
	:	minecraft(minecraft)
	{
        //optionsFile = /*new*/ File(workingDirectory, "options.txt");
        initDefaultValues();

		load();
    }

	Options()
	:	minecraft(NULL)
	{
		
	}

	void initDefaultValues();

    std::string getKeyDescription(int i) {
        //Language language = Language.getInstance();
        //return language.getElement(keyMappings[i].name);
		return "Options::getKeyDescription not implemented";
    }

    std::string getKeyMessage(int i) {
        //return Keyboard.getKeyName(keyMappings[i].key);
		return "Options::getKeyMessage not implemented";
    }

    void setKey(int i, int key) {
        keyMappings[i]->key = key;
        save();
    }

    void set(const Option* item, float value) {
        if (item == &Option::MUSIC) {
            music = value;
            //minecraft.soundEngine.updateOptions();
        } else if (item == &Option::SOUND) {
            sound = value;
            //minecraft.soundEngine.updateOptions();
        } else if (item == &Option::SENSITIVITY) {
            sensitivity = value;
		} else if (item == &Option::FOV) {
			fov = value;
		} else if (item == &Option::VIEW_DISTANCE) {
			int v = (int)(value + 0.5f);
			if (v < 0) v = 0;
			if (v > 3) v = 3;
			viewDistance = 3 - v;
		} else if (item == &Option::FOG_START) {
			fogStart = value;
		} else if (item == &Option::DIFFICULTY_SLIDER) {
			int v = (int)(value + 0.5f);
			difficulty = v < 0 ? 0 : v > 3 ? 3 : v;
		} else if (item == &Option::TOUCH_CONTROLS) {
			int v = (int)(value + 0.5f);
			touchControls = v < 0 ? 0 : v > 2 ? 2 : v;
		} else if (item == &Option::BIOME_BLEND) {
			int v = (int)(value + 0.5f);
			biomeBlend = v < 0 ? 0 : v > 3 ? 3 : v;
		} else if (item == &Option::RENDER_SCALE) {
			int v = (int)(value + 0.5f);
			renderScale = v < 0 ? 0 : v > 4 ? 4 : v;
		} else if (item == &Option::DISTANT_DETAIL) {
			int v = (int)(value + 0.5f);
			distantDetail = v < 0 ? 0 : v > 1 ? 1 : v;
		} else if (item == &Option::PIXELS_PER_MILLIMETER) {
			 pixelsPerMillimeter = value;
		}
		notifyOptionUpdate(item, value);
		save();
    }
	void set(const Option* item, int value) {
		if(item == &Option::DIFFICULTY) {
			difficulty = value;
		}
		notifyOptionUpdate(item, value);
	}

    void toggle(const Option* option, int dir);

	int getIntValue(const Option* item) {
		if(item == &Option::DIFFICULTY) return difficulty;
		return 0;
	}

    float getProgressValue(const Option* item) {
        if (item == &Option::MUSIC) return music;
        if (item == &Option::SOUND) return sound;
        if (item == &Option::SENSITIVITY) return sensitivity;
		if (item == &Option::FOV) return fov;
		if (item == &Option::VIEW_DISTANCE) return (float)(3 - viewDistance);
		if (item == &Option::FOG_START) return fogStart;
		if (item == &Option::DIFFICULTY_SLIDER) return (float)difficulty;
		if (item == &Option::BIOME_BLEND) return (float)biomeBlend;
		if (item == &Option::TOUCH_CONTROLS) return (float)touchControls;
		if (item == &Option::RENDER_SCALE) return (float)renderScale;
		if (item == &Option::DISTANT_DETAIL) return (float)distantDetail;
		if (item == &Option::PIXELS_PER_MILLIMETER) return pixelsPerMillimeter;
        return 0;
    }

    bool getBooleanValue(const Option* item) {
        if (item == &Option::INVERT_MOUSE)
            return invertYMouse;
        if (item == &Option::VIEW_BOBBING)
            return bobView;
        if (item == &Option::ANAGLYPH)
            return anaglyph3d;
        if (item == &Option::LIMIT_FRAMERATE)
            return limitFramerate;
        if (item == &Option::AMBIENT_OCCLUSION)
            return ambientOcclusion;
        if (item == &Option::GRAPHICS)
            return fancyGraphics;
        if (item == &Option::THIRD_PERSON)
            return thirdPersonView;
        if (item == &Option::HIDE_GUI)
            return hideGui;
		if (item == &Option::THIRD_PERSON)
			return thirdPersonView;
		if (item == &Option::SERVER_VISIBLE)
			return serverVisible;
		if (item == &Option::LEFT_HANDED)
			return isLeftHanded;
		if (item == &Option::USE_TOUCHSCREEN)
			return useTouchScreen;
		if (item == &Option::USE_TOUCH_JOYPAD)
			return isJoyTouchArea;
		if (item == &Option::DESTROY_VIBRATION)
			return destroyVibration;
		if (item == &Option::FANCY_CLOUDS)
			return fancyClouds;
		if (item == &Option::SPRINTING)
			return sprintAllowed();
		if (item == &Option::HUNGER)
			return hungerEnabled;
		if (item == &Option::BIOME_SKY)
			return biomeSky;
		if (item == &Option::FOG)
			return fogEnabled;
		if (item == &Option::SHOW_FPS)
			return showFps;
		return false;
	}

	float getProgrssMin(const Option* item) {
		if (item == &Option::MUSIC) return MUSIC_MIN_VALUE;
		if (item == &Option::SOUND) return SOUND_MIN_VALUE;
		if (item == &Option::SENSITIVITY) return SENSITIVITY_MIN_VALUE;
		if (item == &Option::FOV) return 30.0f;
		if (item == &Option::VIEW_DISTANCE) return 0.0f;
		if (item == &Option::FOG_START) return 0.1f;
		if (item == &Option::DIFFICULTY_SLIDER) return 0.0f;
		if (item == &Option::BIOME_BLEND) return 0.0f;
		if (item == &Option::TOUCH_CONTROLS) return 0.0f;
		if (item == &Option::RENDER_SCALE) return 0.0f;
		if (item == &Option::DISTANT_DETAIL) return 0.0f;
		if (item == &Option::PIXELS_PER_MILLIMETER) return PIXELS_PER_MILLIMETER_MIN_VALUE;
		return 0;
	}

	float getProgrssMax(const Option* item) {
		if (item == &Option::MUSIC) return MUSIC_MAX_VALUE;
		if (item == &Option::SOUND) return SOUND_MAX_VALUE;
		if (item == &Option::SENSITIVITY) return SENSITIVITY_MAX_VALUE;
		if (item == &Option::FOV) return 110.0f;
		if (item == &Option::VIEW_DISTANCE) return 3.0f;
		if (item == &Option::FOG_START) return 1.0f;
		if (item == &Option::DIFFICULTY_SLIDER) return 3.0f;
		if (item == &Option::BIOME_BLEND) return 3.0f;
		if (item == &Option::TOUCH_CONTROLS) return 2.0f;
		if (item == &Option::RENDER_SCALE) return 4.0f;
		if (item == &Option::DISTANT_DETAIL) return 1.0f;
		if (item == &Option::PIXELS_PER_MILLIMETER) return PIXELS_PER_MILLIMETER_MAX_VALUE;
		return 1.0f;
	} 

	std::string getMessage(const Option* item);

	void update();
    void load();
    void save();
	void addOptionToSaveOutput(StringVector& stringVector, std::string name, bool boolValue);
	void addOptionToSaveOutput(StringVector& stringVector, std::string name, float floatValue);
	void addOptionToSaveOutput(StringVector& stringVector, std::string name, int intValue);
	void notifyOptionUpdate(const Option* option, bool value);
	void notifyOptionUpdate(const Option* option, float value);
	void notifyOptionUpdate(const Option* option, int value);
private:
    static bool readFloat(const std::string& string, float& value);
    static bool readInt(const std::string& string, int& value);
	static bool readBool(const std::string& string, bool& value);

private:
	OptionsFile optionsFile;
	
};

#endif /*NET_MINECRAFT_CLIENT__Options_H__*/
