#include "GameMode.h"
#include "../../world/ModRules.h"
#include "../../world/ModScripts.h"
#include <sstream>
#include "../Challenge404Rules.h"
#include "../../world/ExtrasHooks.h"
#include "../Minecraft.h"
#include "../../network/packet/UseItemPacket.h"
#include "../../network/packet/PlayerActionPacket.h"
#include "../../world/level/Level.h"
#include "../../world/item/ItemInstance.h"
#include "../player/LocalPlayer.h"
#ifndef STANDALONE_SERVER
#include "../sound/SoundEngine.h"
#include "../particle/ParticleEngine.h"
#endif
#include "../../network/RakNetInstance.h"
#include "../../network/packet/RemoveBlockPacket.h"
#ifndef STANDALONE_SERVER
#include "../renderer/LevelRenderer.h"
#endif
#include "../../world/level/material/Material.h"

GameMode::GameMode( Minecraft* minecraft)
:	minecraft(minecraft),
	destroyProgress(0),
	oDestroyProgress(0),
	destroyTicks(0),
	destroyDelay(0)
{
}

/*virtual*/
Player* GameMode::createPlayer(Level* level) {
    return new LocalPlayer(minecraft, level, minecraft->user, level->dimension->id, isCreativeType());
}

/*virtual*/
void GameMode::interact(Player* player, Entity* entity) {
	ModScripts::interacted(player, entity);
    player->interact(entity);
}

/*virtual*/
void GameMode::attack(Player* player, Entity* entity) {
	if (minecraft->level->adventureSettings.noPvP && entity->isPlayer())
		return;
	if (minecraft->level->adventureSettings.noPvM && entity->isMob())
		return;
	ModScripts::attacked(player, entity);
	if (ModPE::wants(ModPE::ATTACK)) {
		std::stringstream a;
		a << "[" << player->entityId << "," << entity->entityId << "]";
		if (ModPE::hook(ModPE::ATTACK, "attackHook", a.str())) return;
	}
    player->attack(entity);
}

/* virtual */
void GameMode::startDestroyBlock( int x, int y, int z, int face ) {
	if(minecraft->player->getCarriedItem() != NULL && minecraft->player->getCarriedItem()->id == Item::bow->id)
		return;
	destroyBlock(x, y, z, face);
}

/*virtual*/
bool GameMode::destroyBlock(int x, int y, int z, int face) {
    Level* level = minecraft->level;
    Tile* oldTile = Tile::tiles[level->getTile(x, y, z)];
	if (!oldTile)
		return false;
	if (ModPE::wants(ModPE::DESTROY_BLOCK)) {
		std::stringstream a;
		a << "[" << x << "," << y << "," << z << "," << face << "]";
		if (ModPE::hook(ModPE::DESTROY_BLOCK, "destroyBlock", a.str())) return false;
	}

    if (level->adventureSettings.immutableWorld) {
        if (oldTile != (Tile*)Tile::leaves
         && oldTile->material != Material::plant) {
             return false;
        }
    }
	if (!ModRules::allowBreak(level, x, y, z, minecraft->player)) return false;
#ifndef STANDALONE_SERVER
	minecraft->particleEngine->destroy(x, y, z);
#endif
	ExtrasHooks::beforePlayerBreak(level, minecraft->player, x, y, z);
	int data = level->getData(x, y, z);
	const int oldId = level->getTile(x, y, z);
    bool changed = level->setTile(x, y, z, 0);
    if (changed) {
		ModScripts::blockBroken(level, x, y, z, oldId, data, minecraft->player);
#ifndef STANDALONE_SERVER
        minecraft->soundEngine->play(oldTile->soundType->getBreakSound(), x + 0.5f, y + 0.5f, z + 0.5f, (oldTile->soundType->getVolume() + 1) / 2, oldTile->soundType->getPitch() * 0.8f);
#endif
        oldTile->destroy(level, x, y, z, data);
		if (minecraft->options.destroyVibration) minecraft->platform()->vibrate(24);

		if (minecraft->isOnline()) {
			RemoveBlockPacket packet(minecraft->player, x, y, z);
			minecraft->raknetInstance->send(packet);
		}
	}
    return changed;
}
/*virtual*/
bool GameMode::useItemOn(Player* player, Level* level, ItemInstance* item, int x, int y, int z, int face, const Vec3& hit) {
	float clickX = hit.x - x;
	float clickY = hit.y - y;
	float clickZ = hit.z - z;
	item = player->inventory->getSelected();
	if(level->isClientSide) {
		UseItemPacket packet(x, y, z, face, item, player->entityId, clickX, clickY, clickZ);
		minecraft->raknetInstance->send(packet);
	}

	if (minecraft->getGameType() == 2 && item && item->id == Tile::torch->id) {
		return false;
	}

    int t = level->getTile(x, y, z);
	if (t == Tile::invisible_bedrock->id) return false;
	if (player == minecraft->player && ModPE::wants(ModPE::USE_ITEM)) {
		std::stringstream a;
		a << "[" << x << "," << y << "," << z << "," << ModScripts::quote(ModScripts::itemRef(item)) << ","
		  << ModScripts::quote(ModScripts::blockRef(t, level->getData(x, y, z))) << "," << face << ","
		  << (item ? item->getAuxValue() : 0) << "," << ModScripts::blockData(t, level->getData(x, y, z)) << "]";
		if (ModPE::hook(ModPE::USE_ITEM, "useItem", a.str())) return true;
	}
	if (t > 0 && player == minecraft->player) ModScripts::blockUsed(level, x, y, z, player);
	if (t > 0 && !ModRules::allowUse(level, x, y, z, player)) return true;
    if (t > 0 && Tile::tiles[t]->use(level, x, y, z, player))
		return true;

	if (item == NULL) return false;
	ModScripts::itemUsedOn(level, item, x, y, z, face, player);
	const int fx = x + (face == 4 ? -1 : face == 5 ? 1 : 0), fy = y + (face == 0 ? -1 : face == 1 ? 1 : 0), fz = z + (face == 2 ? -1 : face == 3 ? 1 : 0);
	const int before = level->getTile(x, y, z), beforeF = level->getTile(fx, fy, fz);
	if (item->id < 256 && (!ModRules::allowPlace(level, fx, fy, fz, item->id, item->getAuxValue(), player)
	                       || !ModRules::allowPlace(level, x, y, z, item->id, item->getAuxValue(), player))) return false;
	bool success;
	if(isCreativeType()) {
		int aux = item->getAuxValue();
		int count = item->count;
		success = item->useOn(player, level, x, y, z, face, clickX, clickY, clickZ);
		item->setAuxValue(aux);
		item->count = count;
	} else {
		Challenge404Rules::PlaceGuard guard;
		Challenge404Rules::beforePlace(minecraft, guard, x, y, z, face);
		success = item->useOn(player, level, x, y, z, face, clickX, clickY, clickZ);
		success = Challenge404Rules::afterPlace(minecraft, guard, success);
	}
	if (success) {
		if (level->getTile(x, y, z) != before && level->getTile(x, y, z) != 0) ModScripts::blockPlaced(level, x, y, z, player, face);
		else if (level->getTile(fx, fy, fz) != beforeF && level->getTile(fx, fy, fz) != 0) ModScripts::blockPlaced(level, fx, fy, fz, player, face);
	}
	return success;
}

bool GameMode::useItem( Player* player, Level* level, ItemInstance* item ) {
	int oldCount = item->count;
	ModScripts::itemUsed(level, item, player);

	const ItemInstance before = *item;
	ItemInstance* itemInstance = item->use(level, player);
	if(level->isClientSide) {
		UseItemPacket packet(&before, player->entityId, player->aimDirection);
		minecraft->raknetInstance->send(packet);
	}
	if (itemInstance != item || (itemInstance != NULL && itemInstance->count != oldCount)) {
	    //player.inventory.items[player.inventory.selected] = itemInstance;
	    //if (itemInstance.count == 0) {
	    //    player.inventory.items[player.inventory.selected] = NULL;
	    //}
	    return true;
	}
	return false;
}

ItemInstance* GameMode::handleInventoryMouseClick( int containerId, int slotNum, int buttonNum, Player* player ) {
	//return player.containerMenu.clicked(slotNum, buttonNum, player);
	return NULL;
}

void GameMode::handleCloseInventory( int containerId, Player* player ) {
	//player.containerMenu.removed(player);
	//player.containerMenu = player.inventoryMenu;
}

float GameMode::getPickRange() {
	return 5.0f;
}

void GameMode::initPlayer( Player* player ) {
	initAbilities(player->abilities);
}

void GameMode::releaseUsingItem(Player* player){
	if(minecraft->level->isClientSide) {
		PlayerActionPacket packet(PlayerActionPacket::RELEASE_USE_ITEM,  0, 0, 0, 0, player->entityId);
		minecraft->raknetInstance->send(packet);
	}
	player->releaseUsingItem();
}

void GameMode::tick() {
	oDestroyProgress = destroyProgress;
}

void GameMode::render( float a ) {
#ifndef STANDALONE_SERVER
	if (destroyProgress <= 0) {
		minecraft->gui.progress = 0;
		minecraft->levelRenderer->destroyProgress = 0;
	} else {
		float dp = oDestroyProgress + (destroyProgress - oDestroyProgress) * a;
		minecraft->gui.progress = dp;
		minecraft->levelRenderer->destroyProgress = dp;
	}
#endif
}
