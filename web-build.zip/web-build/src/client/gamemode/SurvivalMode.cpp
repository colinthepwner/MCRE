#include "SurvivalMode.h"
#include "../../world/ModScripts.h"
#include <sstream>
#include "../Challenge404Rules.h"
#include "../Minecraft.h"
#include "../player/LocalPlayer.h"
#ifndef STANDALONE_SERVER
#include "../particle/ParticleEngine.h"
#include "../sound/SoundEngine.h"
#endif
#include "../../world/level/Level.h"
#include "../../world/EnchantBrewHooks.h"
#include "../../world/ModMech.h"
#include "../../world/ModOverrides.h"
#include "../../world/entity/player/Abilities.h"
#include "../tutorial/ConsoleTutorial.h"

SurvivalMode::SurvivalMode( Minecraft* minecraft )
:	super(minecraft),
	xDestroyBlock(-1),
	yDestroyBlock(-1),
	zDestroyBlock(-1)
{
}

static float digProgress(Minecraft* mc, Tile* tile, int data) {
	const float own = tile->destroyProgressFor(mc->player, data);
	const float java = ModScripts::javaDigProgress(mc->player, tile->id, data, tile->destroySpeed);
	return java >= 0 ? java : own;
}

void SurvivalMode::continueDestroyBlock( int x, int y, int z, int face ) {
	if (destroyDelay > 0) {
		destroyDelay--;
		return;
	}

	if (x == xDestroyBlock && y == yDestroyBlock && z == zDestroyBlock) {
		int t = minecraft->level->getTile(x, y, z);
		if (t == 0) return;
		Tile* tile = Tile::tiles[t];

		destroyProgress += digProgress(minecraft, tile, minecraft->level->getData(x, y, z));
		ModMech::hungerOwn(minecraft->player, ModOverrides::survival().hungerDigTick, true);

		if ((++destroyTicks & 3) == 1) {
#ifndef STANDALONE_SERVER
			if (tile != NULL) {
				minecraft->soundEngine->play(tile->soundType->getStepSound(), x + 0.5f, y + 0.5f, z + 0.5f, (tile->soundType->getVolume() + 1) / 8, tile->soundType->getPitch() * 0.5f);
			}
#endif
		}

		if (destroyProgress >= 1) {
			destroyBlock(x, y, z, face);
			destroyProgress = 0;
			oDestroyProgress = 0;
			destroyTicks = 0;
			destroyDelay = 5;
		}
	} else {
		destroyProgress = 0;
		oDestroyProgress = 0;
		destroyTicks = 0;
		xDestroyBlock = x;
		yDestroyBlock = y;
		zDestroyBlock = z;
	}
}

bool SurvivalMode::destroyBlock( int x, int y, int z, int face ) {
	Challenge404Rules::beforeBreak(minecraft, x, y, z);
	int t = minecraft->level->getTile(x, y, z);
	int data = minecraft->level->getData(x, y, z);
	ConsoleTutorial::destroyBlock(Tile::tiles[t]);
	bool changed = GameMode::destroyBlock(x, y, z, face);
	bool couldDestroy = minecraft->player->canHarvest(Tile::tiles[t], data);

	ItemInstance* item = minecraft->player->inventory->getSelected();
	if (item != NULL && !item->isNull()) {
		const int tutDamage = item->getDamageValue();
		item->mineBlock(t, x, y, z);
		if (item->count > 0 && item->isDamageableItem() && item->getDamageValue() > tutDamage && item->getDamageValue() > item->getMaxDamage() / 2)
			ConsoleTutorial::itemDamaged(item);
		if (item->count == 0) {
			//item->snap(minecraft->player);
			minecraft->player->inventory->clearSlot(minecraft->player->inventory->selected);
		}
	}
	if (changed && couldDestroy) {
		ItemInstance instance(t, 1, data);
		EnchantBrewHooks::playerDestroy(minecraft->level, minecraft->player, Tile::tiles[t], x, y, z, data);
		ModMech::hungerOwn(minecraft->player, ModOverrides::survival().hungerBreak, true);
	}
	if (changed) Challenge404Rules::afterBreak(minecraft, x, y, z, t);
	return changed;
}

void SurvivalMode::stopDestroyBlock() {
	destroyProgress = 0;
	destroyDelay = 0;
}

void SurvivalMode::initAbilities( Abilities& abilities ) {
	abilities.flying = false;
	abilities.mayfly = false;
	abilities.instabuild = false;
	abilities.invulnerable = false;
}

void SurvivalMode::startDestroyBlock( int x, int y, int z, int face ) {
	if(minecraft->player->getCarriedItem() != NULL && minecraft->player->getCarriedItem()->id == Item::bow->id)
		return;

	if (ModPE::wants(ModPE::START_DESTROY)) {
		std::stringstream mpa;
		mpa << "[" << x << "," << y << "," << z << "," << face << "]";
		if (ModPE::hook(ModPE::START_DESTROY, "startDestroyBlock", mpa.str())) return;
	}
	int t = minecraft->level->getTile(x, y, z);
	if (t > 0) ConsoleTutorial::startDestroyBlock(minecraft->player->inventory->getSelected(), Tile::tiles[t]);
	if (t > 0 && destroyProgress == 0) Tile::tiles[t]->attack(minecraft->level, x, y, z, minecraft->player);
	if (t > 0 && digProgress(minecraft, Tile::tiles[t], minecraft->level->getData(x, y, z)) >= 1) {
		destroyBlock(x, y, z, face);
		ModMech::hungerOwn(minecraft->player, ModOverrides::survival().hungerDigTick, true);
	}
}
