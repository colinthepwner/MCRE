#ifndef NET_MINECRAFT_CLIENT__OptionStrings_H__
#define NET_MINECRAFT_CLIENT__OptionStrings_H__

class OptionStrings {
public:
    static const char* Multiplayer_Username;
    static const char* Multiplayer_ServerVisible;
    
    static const char* Graphics_Fancy;
    static const char* Graphics_LowQuality;
    static const char* Graphics_AmbientOcclusion;
    static const char* Graphics_FancyClouds;
    static const char* Graphics_Fov;
    static const char* Graphics_ViewDistance;
    static const char* Graphics_Fog;
    static const char* Graphics_FogStart;
    static const char* Audio_Sound;
    static const char* Audio_Music;
    static const char* Graphics_ShowFps;
    static const char* Graphics_BiomeBlend;
    static const char* Graphics_BiomeSky;
    static const char* Graphics_RenderScale;
    
    static const char* Controls_Sensitivity;
    static const char* Controls_InvertMouse;
    static const char* Controls_UseTouchScreen;
	static const char* Controls_UseTouchJoypad;
    static const char* Controls_IsLefthanded;
    static const char* Controls_TouchControls;
    static const char* Controls_FeedbackVibration;

	static const char* Game_DifficultyLevel;
	static const char* Game_SprintingEnabled;
	static const char* Game_HungerEnabled;
};

#endif /*NET_MINECRAFT_CLIENT__OptionsStrings_H__*/
