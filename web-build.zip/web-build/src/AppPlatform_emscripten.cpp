#include "AppPlatform_emscripten.h"
#include "util/Mth.h"

// Query the actual browser window / canvas size at call time so the game
// always knows the real render resolution instead of using a fixed value.
int AppPlatform_emscripten::getScreenWidth() {
    int w = EM_ASM_INT({ return window.innerWidth; });
    return (w > 0) ? w : 854;
}
int AppPlatform_emscripten::getScreenHeight() {
    int h = EM_ASM_INT({ return window.innerHeight; });
    return (h > 0) ? h : 480;
}

float AppPlatform_emscripten::getPixelsPerMillimeter() {
    double ratio = EM_ASM_DOUBLE({ return Module.mcPixelRatio ? Module.mcPixelRatio() : (window.devicePixelRatio || 1.0); });
    return (float)(3.7795 * ratio);
}

