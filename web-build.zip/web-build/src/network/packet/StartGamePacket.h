#ifndef NET_MINECRAFT_NETWORK_PACKET__StartGamePacket_H__
#define NET_MINECRAFT_NETWORK_PACKET__StartGamePacket_H__

#include "../Packet.h"

class StartGamePacket : public Packet
{
public:
	long levelSeed;
	int levelGeneratorVersion;
	int gameType;

	int entityId;
	float x, y, z;
	bool hasGen;
	int genSize, genType, genTheme, genBiomes, genRevision;
	bool hasDim;
	int dimension;
	RakNet::RakString modType;

	StartGamePacket()
	:	hasGen(false), genSize(0), genType(0), genTheme(0), genBiomes(0), genRevision(0),
		hasDim(false), dimension(0)
	{
	}

	StartGamePacket(long seed, int levelGeneratorVersion, int gameType, int entityId, float x, float y, float z)
	:	levelSeed(seed),
		levelGeneratorVersion(levelGeneratorVersion),
		gameType(gameType),
		entityId(entityId),
		x(x),
		y(y),
		z(z),
		hasGen(false), genSize(0), genType(0), genTheme(0), genBiomes(0), genRevision(0),
		hasDim(false), dimension(0)
	{
	}

	void setGen(int size, int type, int theme, int biomes, int revision) {
		hasGen = true;
		genSize = size; genType = type; genTheme = theme; genBiomes = biomes; genRevision = revision;
	}

	void write(RakNet::BitStream* bitStream)
	{
		bitStream->Write((RakNet::MessageID)(ID_USER_PACKET_ENUM + PACKET_STARTGAME));

		bitStream->Write(levelSeed);
		bitStream->Write(levelGeneratorVersion);
		bitStream->Write(gameType);
		bitStream->Write(entityId);
		bitStream->Write(x);
		bitStream->Write(y);
		bitStream->Write(z);
		if (hasGen) {
			bitStream->Write(genSize);
			bitStream->Write(genType);
			bitStream->Write(genTheme);
			bitStream->Write(genBiomes);
			bitStream->Write(genRevision);
			bitStream->Write(dimension);
			bitStream->Write(modType);
		}
	}

	void read(RakNet::BitStream* bitStream)
	{
		bitStream->Read(levelSeed);
		bitStream->Read(levelGeneratorVersion);
		bitStream->Read(gameType);
		bitStream->Read(entityId);
		bitStream->Read(x);
		bitStream->Read(y);
		bitStream->Read(z);
		hasGen = bitStream->Read(genSize) && bitStream->Read(genType) && bitStream->Read(genTheme)
			&& bitStream->Read(genBiomes) && bitStream->Read(genRevision);
		hasDim = hasGen && bitStream->Read(dimension);
		if (!hasDim) dimension = 0;
		if (!hasDim || !bitStream->Read(modType)) modType = "";
	}

	void handle(const RakNet::RakNetGUID& source, NetEventCallback* callback)
	{
		callback->handle(source, (StartGamePacket*)this);
	}
};

#endif /*NET_MINECRAFT_NETWORK_PACKET__StartGamePacket_H__*/
