#ifndef _MINECRAFT_NETWORK_SERVERSIDENETWORKHANDLER_H_
#define _MINECRAFT_NETWORK_SERVERSIDENETWORKHANDLER_H_


#include "NetEventCallback.h"
#include "../raknet/RakNetTypes.h"
#include "../world/level/LevelListener.h"
#include <vector>
#include <string>
#include <unordered_set>

class Minecraft;
class Level;
class IRakNetInstance;
class Packet;
class Player;

class ServerSideNetworkHandler : public NetEventCallback, public LevelListener
{
public:
	ServerSideNetworkHandler(Minecraft* minecraft, IRakNetInstance* raknetInstance);
	virtual ~ServerSideNetworkHandler();

	virtual void levelGenerated(Level* level);

	virtual void tileChanged(int x, int y, int z);
	virtual void tileChangedQuietly(int x, int y, int z);
	virtual void tileBrightnessChanged(int x, int y, int z) { /* do nothing */ }
	virtual Packet* getAddPacketFromEntity(Entity* entity);
	virtual void entityAdded(Entity* e);
	virtual void entityRemoved(Entity* e);
	virtual void levelEvent(Player* source, int type, int x, int y, int z, int data);
	virtual void tileEvent(int x, int y, int z, int b0, int b1);

	virtual void onNewClient(const RakNet::RakNetGUID& clientGuid);
	virtual void onDisconnect(const RakNet::RakNetGUID& guid);

	void onReady_ClientGeneration(const RakNet::RakNetGUID& source);
	void tickWeather();
	int _sentRaining = -1, _sentThundering = -1;
	void onReady_RequestedChunks(const RakNet::RakNetGUID& source);

	virtual void handle(const RakNet::RakNetGUID& source, LoginPacket* packet);
	virtual void handle(const RakNet::RakNetGUID& source, ReadyPacket* packet);
	virtual void handle(const RakNet::RakNetGUID& source, MovePlayerPacket* packet);
	//virtual void handle(const RakNet::RakNetGUID& source, PlaceBlockPacket* packet);
	virtual void handle(const RakNet::RakNetGUID& source, RemoveBlockPacket* packet);
	//virtual void handle(const RakNet::RakNetGUID& source, ExplodePacket* packet);
	virtual void handle(const RakNet::RakNetGUID& source, RequestChunkPacket* packet);
	virtual void handle(const RakNet::RakNetGUID& source, PlayerEquipmentPacket* packet);
	virtual void handle(const RakNet::RakNetGUID& source, PlayerArmorEquipmentPacket* packet);
	virtual void handle(const RakNet::RakNetGUID& source, SetHealthPacket* packet);
	//virtual void handle(const RakNet::RakNetGUID& source, TeleportEntityPacket* packet);
	virtual void handle(const RakNet::RakNetGUID& source, InteractPacket* packet);
	virtual void handle(const RakNet::RakNetGUID& source, AnimatePacket* packet);
	virtual void handle(const RakNet::RakNetGUID& source, UseItemPacket* packet);
	virtual void handle(const RakNet::RakNetGUID& source, EntityEventPacket* packet);
	virtual void handle(const RakNet::RakNetGUID& source, PlayerActionPacket* packet);
	virtual void handle(const RakNet::RakNetGUID& source, RespawnPacket* packet);
	virtual void handle(const RakNet::RakNetGUID& source, SendInventoryPacket* packet);
	virtual void handle(const RakNet::RakNetGUID& source, DropItemPacket* packet);
	virtual void handle(const RakNet::RakNetGUID& source, ContainerSetSlotPacket* packet);
	virtual void handle(const RakNet::RakNetGUID& source, ContainerClosePacket* packet);
	virtual void handle(const RakNet::RakNetGUID& source, SignUpdatePacket* packet);

	bool allowsIncomingConnections() { return _allowIncoming; }
	void allowIncomingConnections(bool doAllow);

	Player* popPendingPlayer(const RakNet::RakNetGUID& source);

	void carryPlayersOver(int toDimension);
	virtual void handle(const RakNet::RakNetGUID& source, ChangeDimensionPacket* packet);
	virtual void handle(const RakNet::RakNetGUID& source, PlayerDataPacket* packet);
	virtual void handle(const RakNet::RakNetGUID& source, RidePacket* packet);
	virtual void handle(const RakNet::RakNetGUID& source, MessagePacket* packet);
private:
	struct Carried {
		RakNet::RakNetGUID guid;
		std::string name;
		int health;
		int xpLevel, xpTotal;
		float xpProgress;
	};
	static std::vector<Carried> s_carried;
	void admit(const RakNet::RakNetGUID& source, const std::string& name, const Carried* carried);

	void redistributePacket(Packet* packet, const RakNet::RakNetGUID& fromPlayer);
	void displayGameMessage(const std::string& message);

	Player* getPlayer(const RakNet::RakNetGUID& source);

public:
	void tickChunks();
	std::string netDebug();
private:
	bool chunkFinished(int x, int z);
	void sendChunk(const RakNet::RakNetGUID& to, int x, int z);
	struct ChunkAsk { RakNet::RakNetGUID who; int x, z; float since; };
	std::vector<ChunkAsk> _chunkAsks;
	std::unordered_set<long long> _sentChunks;
	std::unordered_set<long long> _quietWrites;
	static long long chunkKey(int x, int z) { return ((long long)x << 32) | (unsigned int)z; }
	static long long posKey(int x, int y, int z) { return ((long long)(x & 0xfffff) << 29) | ((long long)(z & 0xfffff) << 9) | (y & 511); }

	Minecraft*					minecraft;
	Level*						level;
	IRakNetInstance*			raknetInstance;
	RakNet::RakPeerInterface*	rakPeer;

	std::vector<Player*> _pendingPlayers;
	bool _allowIncoming;
};

#endif
