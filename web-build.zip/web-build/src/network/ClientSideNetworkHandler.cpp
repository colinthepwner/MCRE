
#include "ClientSideNetworkHandler.h"
#ifdef EMSCRIPTEN
#include <emscripten.h>
#endif
#include "../world/ModThrown.h"
#include "../world/ModContent.h"
#include "../world/level/Weather.h"
#include "packet/PacketInclude.h"
#include "RideSync.h"
#include "RakNetInstance.h"
#include "../world/level/chunk/ChunkSource.h"
#include "../world/level/Level.h"
#include "../world/level/storage/LevelStorageSource.h"
#include "../world/entity/player/Player.h"
#include "../world/entity/player/Inventory.h"
#include "../client/Minecraft.h"
#include "../client/gamemode/GameMode.h"
#ifndef STANDALONE_SERVER
#include "../client/gui/screens/DisconnectionScreen.h"
#endif
#include "../client/player/LocalPlayer.h"
#include "../client/multiplayer/MultiPlayerLevel.h"
#include "../client/player/input/KeyboardInput.h"
#include "../client/sound/SoundEngine.h"
#include "../world/entity/MobFactory.h"
#include "../raknet/RakPeerInterface.h"
#include "../world/level/Explosion.h"
#include "../world/level/tile/entity/FurnaceTileEntity.h"
#include "../world/inventory/BaseContainerMenu.h"
#ifndef STANDALONE_SERVER
#include "../client/particle/TakeAnimationParticle.h"
#endif
#include "../world/entity/EntityFactory.h"
#include "../world/entity/item/PrimedTnt.h"
#include "../world/entity/projectile/Arrow.h"
#include "../world/level/tile/entity/ChestTileEntity.h"
#include "../client/player/RemotePlayer.h"
#include "../world/level/tile/LevelEvent.h"
#include "../world/entity/item/FallingTile.h"
#include "../world/entity/item/Minecart.h"
#include "../world/entity/ItemFrame.h"
#include "../world/level/tile/RedstoneUpdate.h"
#include "../world/level/dimension/NetherDimension.h"
#include "../world/level/dimension/EndDimension.h"
#include "../world/level/storage/LevelData.h"
#include "../world/phys/HitResult.h"
#include "../nbt/CompoundTag.h"
#include "../nbt/NbtIo.h"
#include "../util/RakDataIO.h"
#include "../platform/time.h"
#include "../client/NetherTravel.h"
#include "../util/Mth.h"
#ifndef STANDALONE_SERVER
#include "../client/gui/screens/ProgressScreen.h"
#include "../client/renderer/LevelRenderer.h"
#include "../client/particle/ParticleEngine.h"
#include "../world/ModDimensions.h"
#endif

static MultiPlayerLevel* mpcast(Level* l) { return (MultiPlayerLevel*) l; }

ClientSideNetworkHandler::ClientSideNetworkHandler(Minecraft* minecraft, IRakNetInstance* raknetInstance)
:	minecraft(minecraft),
	raknetInstance(raknetInstance),
	level(NULL),
	requestNextChunkPosition(0),
    requestNextChunkIndex(0)
#ifdef EMSCRIPTEN
	, sentReady(false), settleStart(-1), worldChunks(CHUNK_CACHE_WIDTH)
	, carriedPlayer(NULL), arrivingFrom(0), dropPending(false), deferredStart(NULL)
	, restoredPlayer(NULL), lastSaveTime(0)
#endif
{
	rakPeer = raknetInstance->getPeer();
}

ClientSideNetworkHandler::~ClientSideNetworkHandler()
{
#ifdef EMSCRIPTEN
	if (carriedPlayer) { carriedPlayer->deleteChildren(); delete carriedPlayer; }
	if (restoredPlayer) { restoredPlayer->deleteChildren(); delete restoredPlayer; }
	delete deferredStart;
#endif
}

void ClientSideNetworkHandler::requestNextChunk()
{
	if (requestNextChunkIndex < NumRequestChunks)
	{
        IntPair& chunk = requestNextChunkIndexList[requestNextChunkIndex];
		RequestChunkPacket packet(chunk.x, chunk.y);
        raknetInstance->send(packet);

        //LOGI("requesting chunks @ (%d, %d)\n", chunk.x, chunk.y);
        
		//raknetInstance->send(new RequestChunkPacket(requestNextChunkPosition % CHUNK_CACHE_WIDTH, requestNextChunkPosition / CHUNK_CACHE_WIDTH));
		requestNextChunkIndex++;
        requestNextChunkPosition++;
	}
}

bool ClientSideNetworkHandler::areAllChunksLoaded()
{
	return (requestNextChunkPosition >= (CHUNK_CACHE_WIDTH * CHUNK_CACHE_WIDTH));
}

bool ClientSideNetworkHandler::isChunkLoaded(int x, int z)
{
#ifdef EMSCRIPTEN
	return true;
#endif
	if (x < 0 || x >= CHUNK_CACHE_WIDTH || z < 0 || z >= CHUNK_CACHE_WIDTH) {
		LOGE("Error: Tried to request chunk (%d, %d)\n", x, z);
		return true;
	}
	return chunksLoaded[x * CHUNK_CACHE_WIDTH + z];
	//return areAllChunksLoaded();
}

void ClientSideNetworkHandler::onConnect(const RakNet::RakNetGUID& hostGuid)
{
	LOGI("onConnect, server guid: %s, local guid: %s\n", hostGuid.ToString(), raknetInstance->myGuid().ToString());
	serverGuid = hostGuid;

	clearChunksLoaded();
	LoginPacket packet(minecraft->user->name.c_str(), SharedConstants::NetworkProtocolVersion);
	raknetInstance->send(packet);
}

void ClientSideNetworkHandler::onUnableToConnect()
{
	LOGI("onUnableToConnect\n");
}

void ClientSideNetworkHandler::onDisconnect(const RakNet::RakNetGUID& guid)
{
#if defined(EMSCRIPTEN) && !defined(STANDALONE_SERVER)
	if (minecraft->level == NULL && (carriedPlayer || dropPending)) {
		minecraft->setScreen(new DisconnectionScreen("The host left the game"));
		return;
	}
#endif
	LOGI("onDisconnect\n");
#if defined(EMSCRIPTEN) && !defined(STANDALONE_SERVER)
	{
		char why[160] = { 0 };
		EM_ASM({
			var r = (Module.mcNet && Module.mcNet.kickReason) || '';
			if (Module.mcNet) Module.mcNet.kickReason = '';
			stringToUTF8(String(r).slice(0, 150), $0, 160);
		}, why);
		if (why[0]) {
			minecraft->setScreen(new DisconnectionScreen(why));
			return;
		}
	}
#endif
	if (level)
	{
		level->isClientSide = false;
		for (int i = (int)level->players.size()-1; i >= 0; --i ) {
			Player* p = level->players[i];
			if (p != minecraft->player) {
				p->reallyRemoveIfPlayer = true;
				level->removeEntity(p);
			}
		}
	}
#ifndef STANDALONE_SERVER
	minecraft->gui.addMessage("Disconnected from server");
#endif
}

void ClientSideNetworkHandler::handle(const RakNet::RakNetGUID& source, LoginStatusPacket* packet) {
	if (packet->status == LoginStatus::Success) {
		raknetInstance->setIsLoggedIn(true);
		return;
	}

	if (packet->status == LoginStatus::Failed_ClientOld) {
		LOGI("Disconnect! Client is outdated!\n");
#ifndef STANDALONE_SERVER
		minecraft->setScreen(new DisconnectionScreen("Could not connect: Outdated client!"));
#endif
	}
	if (packet->status == LoginStatus::Failed_ServerOld) {
		LOGI("Disconnect! Server is outdated!\n");
#ifndef STANDALONE_SERVER
		minecraft->setScreen(new DisconnectionScreen("Could not connect: Outdated server!"));
#endif
	}
}


void ClientSideNetworkHandler::handle(const RakNet::RakNetGUID& source, StartGamePacket* packet)
{
	LOGI("StartGamePacket\n");

#ifdef RPI
	if (packet->gameType != GameType::Creative) {
		minecraft->setScreen(new DisconnectionScreen("Could not connect: Incompatible server!"));
		return;
	}
#endif

#ifdef EMSCRIPTEN
	LOGI("StartGamePacket: dimension %d, level %s, carried player %s\n", packet->dimension,
	     !minecraft->level ? "none" : minecraft->isLevelGenerated() ? "ready" : "loading", carriedPlayer ? "yes" : "no");
	if (minecraft->level != NULL) {
		if (!minecraft->isLevelGenerated()) {
			delete deferredStart;
			deferredStart = new StartGamePacket(*packet);
			dropPending = true;
			return;
		}
		dropLevel();
	}
#endif
	const std::string& levelId = LevelStorageSource::TempLevelId;
	LevelStorageSource* storageSource = minecraft->getLevelSource();
	storageSource->deleteLevel(levelId);
#ifdef EMSCRIPTEN
	ModContent::bindFromFile("/data/web_mods/joined_map.txt");
#endif
	//level = new Level(storageSource->selectLevel(levelId, true), "temp", packet->levelSeed, SharedConstants::StorageVersion);
	LevelSettings settings(packet->levelSeed, LevelSettings::validateGameType(packet->gameType));
#ifdef EMSCRIPTEN
	if (packet->hasGen) {
		settings.gen.size = packet->genSize;
		settings.gen.type = packet->genType;
		settings.gen.theme = packet->genTheme;
		settings.gen.biomes = packet->genBiomes;
		settings.gen.revision = packet->genRevision;
		settings.gen.modType = packet->modType.C_String();
	}
	worldChunks = packet->hasGen ? packet->genSize : CHUNK_CACHE_WIDTH;
	spawnX = packet->x; spawnY = packet->y; spawnZ = packet->z;
	syncedChunks.clear();
	requestedChunks.clear();
	sentReady = false;
	settleStart = -1;
#endif
	Dimension* dimension = NULL;
	std::string message = "ClientSideNetworkHandler -> setLevel";
#ifdef EMSCRIPTEN
	if (packet->hasDim && packet->dimension == NetherDimension::ID) dimension = new NetherDimension();
	if (packet->hasDim && packet->dimension == EndDimension::ID) dimension = new EndDimension();
	if (packet->hasDim && ModDimensions::isModDim(packet->dimension)) dimension = ModDimensions::create(packet->dimension);
	if (carriedPlayer)
		message = packet->dimension == NetherDimension::ID ? "Entering the Nether"
		        : packet->dimension == EndDimension::ID ? "Entering the End"
		        : ModDimensions::isModDim(packet->dimension) ? ModDimensions::byId(packet->dimension)->enterMsg
		        : ModDimensions::isModDim(arrivingFrom) ? ModDimensions::byId(arrivingFrom)->leaveMsg
		        : arrivingFrom == EndDimension::ID ? "Leaving the End" : "Leaving the Nether";
#endif
	MultiPlayerLevel* level = new MultiPlayerLevel(
		storageSource->selectLevel(levelId, true),
		"temp",
		settings,
		SharedConstants::StorageVersion,
		dimension);
	level->isClientSide = true;

	bool isCreative = (packet->gameType == GameType::Creative);
	LocalPlayer* player = new LocalPlayer(minecraft, level, minecraft->user, level->dimension->id, isCreative);
#ifdef EMSCRIPTEN
	if (carriedPlayer) {
		player->owner = raknetInstance->myGuid();
		player->entityId = packet->entityId;
		Level* wasLevel = minecraft->level;
		minecraft->level = level;
		player->load(carriedPlayer);
		minecraft->level = wasLevel;
#ifndef STANDALONE_SERVER
		minecraft->setScreen(new ProgressScreen());
#endif
		carriedPlayer->deleteChildren();
		delete carriedPlayer;
		carriedPlayer = NULL;
		player->dimension = level->dimension->id;
		player->xd = player->yd = player->zd = 0;
		player->fallDistance = 0;
		NetherTravel::arrived(minecraft);
	} else if (restoredPlayer) {
		player->owner = raknetInstance->myGuid();
		player->entityId = packet->entityId;
		Level* wasLevel = minecraft->level;
		minecraft->level = level;
		player->load(restoredPlayer);
		minecraft->level = wasLevel;
#ifndef STANDALONE_SERVER
		minecraft->setScreen(new ProgressScreen());
#endif
		player->dimension = level->dimension->id;
		player->xd = player->yd = player->zd = 0;
		player->fallDistance = 0;
	}
	if (restoredPlayer) { restoredPlayer->deleteChildren(); delete restoredPlayer; restoredPlayer = NULL; }
	lastSave.clear();
#endif
	player->owner = raknetInstance->myGuid();
	player->entityId = packet->entityId;
	player->moveTo(packet->x, packet->y, packet->z, player->yRot, player->xRot);

	LOGI("new pos: %f, %f [%f - %f]\n", player->x, player->z, player->bb.y0, player->bb.y1);

	minecraft->setLevel(level, message, player);
	minecraft->setGameType(packet->gameType);
}

void ClientSideNetworkHandler::handle(const RakNet::RakNetGUID& source, MessagePacket* packet)
{
	LOGI("MessagePacket\n");
#ifndef STANDALONE_SERVER
	minecraft->gui.addMessage(packet->message.C_String());
#endif
}

void ClientSideNetworkHandler::handle(const RakNet::RakNetGUID& source, SetTimePacket* packet)
{
	if (!level)
		return;

	LOGI("SetTimePacket\n");
	const long diff = (long)packet->time - (long)level->getTime();
	if (diff > 1200 || diff < -1200) {
		level->setTime(packet->time);
		mpcast(level)->timeDrift = 0;
	} else {
		mpcast(level)->timeDrift = (int)diff;
	}
}

void ClientSideNetworkHandler::handle(const RakNet::RakNetGUID& source, AddEntityPacket* packet)
{
	if (!level)
		return;

	if (packet->type == RedstoneUpdate::ENTITY_ITEM_FRAME) {
		ItemFrame* frame = ItemFrame::createFromNet(level, packet->x, packet->y, packet->z, packet->data());
		frame->entityId = packet->entityId;
		mpcast(level)->putEntity(packet->entityId, frame);
		return;
	}

	Entity* e = EntityFactory::CreateEntity(packet->type, level);
	if (!e)
		return;

	e->entityId = packet->entityId;
	e->setPos(packet->x, packet->y, packet->z);

	// Entity Specific stuff here
	switch (packet->type)
	{
		case EntityTypes::IdFallingTile: {
			int data = -packet->data();
            FallingTile* ft = (FallingTile*) e;
            ft->tile = data & 0xff;
            ft->data = data >> 16;
		}
			break;
		case EntityTypes::IdMinecart:
			((Minecart*) e)->setType(packet->data());
			break;
		case EntityTypes::IdArrow: {
			Entity* owner = level->getEntity(packet->data());
			if (owner && owner->isMob())
				((Arrow*)e)->ownerId = owner->entityId;
			break;
		}
		case ModThrown::MOD_THROWN:
			((ModThrown*) e)->itemId = packet->data();
			break;
		default:
			break;
	}

    if (packet->hasMovementData()) {
		/*
		e->xd = packet->xd;
		e->yd = packet->yd;
		e->zd = packet->zd;
		*/
		e->lerpMotion(packet->xd, packet->yd, packet->zd);
		//LOGI("Client: reading entity with %f, %f, %f\n", e->xd, e->yd, e->zd);
	}

	mpcast(level)->putEntity(packet->entityId, e);
}
void ClientSideNetworkHandler::handle( const RakNet::RakNetGUID& source, AddPaintingPacket* packet ) {
	if (!level)
		return;

	Painting* painting = new Painting(level, packet->xTile, packet->yTile, packet->zTile, packet->dir, packet->motive);
	mpcast(level)->putEntity(packet->entityId, painting);
}
void ClientSideNetworkHandler::handle(const RakNet::RakNetGUID& source, AddMobPacket* packet)
{
	LOGI("AddMobPacket (%p)\n", level);

	if (!level) {
		LOGW("Trying to add a mob with no level!\n");
		//we skip this since we will get this player anyway when we request level
		return;
	}
	if (!packet->type) {
		LOGE("Trying to add a mob without a type id\n");
		return;
	}

	Mob* mob = MobFactory::CreateMob(packet->type, level);
	if (!mob) {
		LOGE("Server tried to add an unknown mob type! :%d\n", packet->type);
		return;
	}

	mob->entityId = packet->entityId;
	mob->moveTo(packet->x, packet->y, packet->z, packet->yRot, packet->xRot);
	mob->getEntityData()->assignValues(&packet->unpack);
	level->addEntity(mob);
}

void ClientSideNetworkHandler::handle(const RakNet::RakNetGUID& source, AddPlayerPacket* packet)
{
	if (!level) {
		//we skip this since we will get this player anyway when we request level
		return;
	}
	LOGI("AddPlayerPacket\n");

	Player* player = new RemotePlayer(level, minecraft->isCreativeMode());
	minecraft->gameMode->initAbilities(player->abilities);
	player->entityId = packet->entityId;
	level->addEntity(player);

	player->moveTo(packet->x, packet->y, packet->z, packet->yRot, packet->xRot);
	player->name = packet->name.C_String();
	player->owner = packet->owner;
	player->getEntityData()->assignValues(&packet->unpack);
    int slot = Inventory::MAX_SELECTION_SIZE;
    if (packet->carriedItemId == 0) {
        player->inventory->clearSlot(slot);
    } else {
        ItemInstance newItem(packet->carriedItemId, 1, packet->carriedItemAuxValue);
        player->inventory->replaceSlot(slot, &newItem);
    }
    player->inventory->moveToSelectedSlot(slot, true);
	//player->resetPos();

	std::string message = packet->name.C_String();
	message += " joined the game";
#ifndef STANDALONE_SERVER
	minecraft->gui.addMessage(message);
#endif
}

void ClientSideNetworkHandler::handle(const RakNet::RakNetGUID& source, RemovePlayerPacket* packet) {
	if (!level || source == minecraft->player->owner) return;

	if (Player* player = findPlayer(level, packet->entityId, &packet->owner)) {
		player->reallyRemoveIfPlayer = true;
		level->removeEntity(player);
	}

	//for (int i = (int)level->players.size()-1; i >= 0; --i) {
	//	if (level->players[i]->owner == source) {
	//		level->players[i]->reallyRemoveIfPlayer = true;
	//		level->players.erase(level->players.begin() + i);
	//		break;
	//	}
	//}

	//if (!player) return;

	//std::string message = packet->name.C_String();
	//message += " joined the game";
	//minecraft->gui.addMessage(message);
}

void ClientSideNetworkHandler::handle(const RakNet::RakNetGUID& source, RemoveEntityPacket* packet)
{
	if (!level) return;

	Entity* entity = level->getEntity(packet->entityId);
	LOGI("RemoveEntityPacket %p %p, %d\n", entity, minecraft->player, entity?(int)(entity->isPlayer()): -1);
	if (!entity) return;

	level->removeEntity(entity);
}

void ClientSideNetworkHandler::handle(const RakNet::RakNetGUID& source, AddItemEntityPacket* packet)
{
	if (!level) return;

	ItemEntity* entity = new ItemEntity(level, packet->x, packet->y, packet->z, ItemInstance(packet->itemId, packet->itemCount, packet->auxValue));
	entity->xd = packet->xa();
	entity->yd = packet->ya();
	entity->zd = packet->za();
	//LOGI("item-entity @ client: %f, %f, %f\n", entity->xd, entity->yd, entity->zd);

	mpcast(level)->putEntity(packet->id, entity);
}

void ClientSideNetworkHandler::handle(const RakNet::RakNetGUID& source, TakeItemEntityPacket* packet) {
	if (!level) return;

	Entity* e = level->getEntity(packet->itemId);
	if (!e)
		return;
	
	ItemInstance item;
	if (e->isItemEntity()) {
		item = ((ItemEntity*) e)->item;
#ifndef STANDALONE_SERVER
		if (Entity* to = level->getEntity(packet->playerId))
			minecraft->particleEngine->add(new TakeAnimationParticle(level, (ItemEntity*)e, to, -0.5f));
#endif
	}
	else if (e->getEntityTypeId() == EntityTypes::IdArrow)
		item = ItemInstance(Item::arrow);

	if (item.isNull())
		return;

	// try take it and if we don't have space; re-throw it
	if (minecraft->player->entityId == packet->playerId
	&& !minecraft->player->inventory->add(&item)) {
		DropItemPacket dropPacket(packet->playerId, item);
		minecraft->raknetInstance->send(dropPacket);
	}
	level->playSound(e, "random.pop", 0.2f, 1.0f * 2.f);
}

void ClientSideNetworkHandler::handle(const RakNet::RakNetGUID& source, MovePlayerPacket* packet)
{
	if (!level)
		return;

	//printf("MovePlayerPacket\n");
	Entity* entity = level->getEntity(packet->entityId);
	if (entity && entity != minecraft->player)
	{
		entity->lerpTo(packet->x, packet->y, packet->z, packet->yRot, packet->xRot, 3);
	}
}

void ClientSideNetworkHandler::handle(const RakNet::RakNetGUID& source, MoveEntityPacket* packet)
{
	if (!level)
		return;

	//printf("MovePlayerPacket\n");
	Entity* entity = level->getEntity(packet->entityId);
	if (entity && entity != minecraft->player)
	{
		float xRot = packet->hasRot? packet->xRot : entity->xRot;
		float yRot = packet->hasRot? packet->yRot : entity->yRot;
		entity->lerpTo(packet->x, packet->y, packet->z, yRot, xRot, 3);
	}
}

void ClientSideNetworkHandler::handle(const RakNet::RakNetGUID& source, UpdateBlockPacket* packet)
{
	if (!level) return;

	//LOGI("UpdateBlockPacket @ %d, %d, %d\n", packet->x, packet->y, packet->z);

	int x = packet->x, z = packet->z;

	if (isChunkLoaded(x >> 4, z >> 4))
	{
		//LOGI("chunk is loaded - UPDATE @ %d, %d, %d -- %d, %d\n", x, packet->y, z, packet->blockId, packet->blockData);

		int y = packet->y;
		int tileId = Tile::transformToValidBlockId(packet->blockId, x, y, z);
#ifdef EMSCRIPTEN
		prepareChunk(x >> 4, z >> 4);
#endif
		level->setTileAndData(x, y, z, tileId, packet->blockData);
	} else {
		SBufferedBlockUpdate update;
		update.blockId = packet->blockId;
		update.blockData = packet->blockData;
		update.setData = true;
		update.x = packet->x;
		update.y = packet->y;
		update.z = packet->z;
		bufferedBlockUpdates.push_back(update);
	}
}

void ClientSideNetworkHandler::handle(const RakNet::RakNetGUID& source, ExplodePacket* packet) {
	if (!level) return;
	Explosion explosion(level, NULL, packet->x, packet->y, packet->z, packet->r);
	explosion.toBlow.insert(packet->toBlow.begin(), packet->toBlow.end());
	explosion.finalizeExplosion();
}

void ClientSideNetworkHandler::handle(const RakNet::RakNetGUID& source, LevelEventPacket* packet) {
	if (!level) return;
	if(packet->eventId == LevelEvent::ALL_PLAYERS_SLEEPING) {
		minecraft->player->setAllPlayersSleeping();
	}
	else {
		minecraft->level->levelEvent(NULL, packet->eventId, packet->x, packet->y, packet->z, packet->data);
	}
}

void ClientSideNetworkHandler::handle(const RakNet::RakNetGUID& source, TileEventPacket* packet) {
	if (!level) return;
	minecraft->level->tileEvent(packet->x, packet->y, packet->z, packet->b0, packet->b1);
}

void ClientSideNetworkHandler::handle(const RakNet::RakNetGUID& source, EntityEventPacket* packet) {
	if (!level) return;

	Entity* e = level->getEntity(packet->entityId);
	if (e) e->handleEntityEvent(packet->eventId);
}

void ClientSideNetworkHandler::handle(const RakNet::RakNetGUID& source, ChunkDataPacket* packet)
{
	if (!level) {
		LOGI("level @ handle ChunkDataPacket is 0\n");
		return;
	}
	//LOGI("ChunkDataPacket\n");

#ifdef EMSCRIPTEN
	requestedChunks.erase(packet->x * 65536 + packet->z);
	prepareChunk(packet->x, packet->z);
#endif
	LevelChunk* chunk = level->getChunkSource()->create(packet->x, packet->z);
	if (!chunk || chunk->isEmpty())
	{
		LOGI("Failed to find write-able chunk\n");
		return;
	}

	//unsigned char* blockIds = chunk->getBlockData();
	DataLayer& blockData = chunk->data;

	const int setSize = LEVEL_HEIGHT / 8;
	const int setShift = 4; // power of LEVEL_HEIGHT / 8

	bool recalcHeight = false;

	int x0 = 16, x1 = 0, z0 = 16, z1 = 0, y0 = LEVEL_HEIGHT, y1 = 0;
	int rx = packet->x << 4;
	int rz = packet->z << 4;

	unsigned char readBlockBuffer[setSize];
	unsigned char readDataBuffer[setSize / 2];

	for (int i = 0; i < CHUNK_COLUMNS; i++)
	{
		unsigned char updateBits = 0;
		packet->chunkData.Read(updateBits);

		if (updateBits > 0)
		{
			recalcHeight = true;

			int colX = (i % CHUNK_WIDTH);
			int colZ = (i / CHUNK_WIDTH);
			int colDataPosition = colX << 11 | colZ << 7;

			for (int set = 0; set < 8; set++)
			{
				if ((updateBits & (1 << set)) != 0) 
				{
					packet->chunkData.Read((char*)readBlockBuffer, setSize);
					packet->chunkData.Read((char*)readDataBuffer, setSize / 2);

					for (int part = 0; part < setSize; part++)
					{
						//if (readBlockBuffer[part] == ((Tile*)Tile::grass)->id)
						//	readBlockBuffer[part] = 255;
						int x = rx + colX;
						int y = (set << setShift) + part;
						int z = rz + colZ;

						int tileId = Tile::transformToValidBlockId(readBlockBuffer[part], x, y, z);
						level->setTileNoUpdate(x, y, z, tileId);
					}
					// ((part & 1) == 0) ? readDataBuffer[part >> 1] & 0xf : (readDataBuffer[part >> 1] & 0xf0) >> 4

					//packet->chunkData.Read((char*)(&blockIds[colDataPosition + (set << setShift)]), setSize);
					// block data is only 4 bits per block
					//packet->chunkData.Read((char*)(&blockData.data[(colDataPosition + (set << setShift)) >> 1]), setSize >> 1);

					memcpy(&blockData.data[(colDataPosition + (set << setShift)) >> 1], readDataBuffer, setSize >> 1);
				}

				if (((1 << set) << setShift) < y0)
				{
					y0 = ((1 << set) << setShift);
				}
				if (((1 << set) << setShift) + (LEVEL_HEIGHT / 8) - 1 > y1)
				{
					y1 = ((1 << set) << setShift) + (LEVEL_HEIGHT / 8) - 1;
				}
			}
			if ((i % CHUNK_WIDTH) < x0)
			{
				x0 = (i % CHUNK_WIDTH);
			}
			if ((i % CHUNK_WIDTH) > x1)
			{
				x1 = (i % CHUNK_WIDTH);
			}
			if ((i / CHUNK_WIDTH) < z0)
			{
				z0 = (i / CHUNK_WIDTH);
			}
			if ((i / CHUNK_WIDTH) > z1)
			{
				z1 = (i / CHUNK_WIDTH);
			}
		}
	}

 	if (recalcHeight)
 	{
// 		chunk->recalcHeightmap();
// 		//chunk->recalcBlockLights();
 		level->setTilesDirty((packet->x << 4) + x0, y0, (packet->z << 4) + z0, (packet->x << 4) + x1, y1, (packet->z << 4) + z1);
// 		int rx = packet->x << 4;
// 		int rz = packet->z << 4;
// 		level->updateLight(LightLayer::Block, x0 + rx - 1, y0, z0 + rz - 1, x1 + rx + 1, y1, z1 + rz + 1);
// 		//for (int cx = x0; cx < x1; cx++)
// 		//{
// 		//	for (int cz = z0; cz < z1; cz++)
// 		//	{
// 		//		for (int cy = y0; cy < y1; cy++)
// 		//		{
// 					//level->updateLight(LightLayer::Sky, cx + rx, cy, cz + rz, cx + rx, cy, cz + rz);
// 		//			level->updateLight(LightLayer::Block, cx + rx - 1, cy, cz + rz - 1, cx + rx + 1, cy, cz + rz + 1);
// 		//		}
// 		//	}
// 		//}
// 
 	}
	//chunk->terrainPopulated = true;
	chunk->unsaved = false;
#ifdef EMSCRIPTEN
	chunk->unsaved = true;
	syncedChunks.insert(packet->x * 65536 + packet->z);
	return;
#endif

	chunksLoaded[packet->x * CHUNK_CACHE_WIDTH + packet->z] = true;

	if (areAllChunksLoaded())
	{
		ReadyPacket packet(ReadyPacket::READY_REQUESTEDCHUNKS);
		raknetInstance->send(packet);

		for (unsigned int i = 0; i < bufferedBlockUpdates.size(); i++)
		{
			const SBufferedBlockUpdate& update = bufferedBlockUpdates[i];
			int tileId = Tile::transformToValidBlockId( update.blockId, update.x, update.y, update.z );
			if (update.setData)
				level->setTileAndData(update.x, update.y, update.z, tileId, update.blockData);
			else
				level->setTile(update.x, update.y, update.z, tileId);
		}
		bufferedBlockUpdates.clear();
	}
	else
	{
		requestNextChunk();
	}
}

class _ChunkSorter
{
public:
    _ChunkSorter(int x, int z)
    :   x(x),
        y(z)
    {
    }
    
    bool operator() (const IntPair& a, const IntPair& b) {
        const int ax = a.x - x, ay = a.y - y;
        const int bx = b.x - x, by = b.y - y;
        return (ax*ax + ay*ay) < (bx*bx + by*by);
    }
private:
    int x;
    int y;
};


void ClientSideNetworkHandler::arrangeRequestChunkOrder() {
	clearChunksLoaded();

    // Default sort is around center of the world
    int cx = CHUNK_CACHE_WIDTH / 2;
    int cz = CHUNK_CACHE_WIDTH / 2;

    // If player exists, let's sort around him
    Player* p = minecraft? minecraft->player : NULL;
    if (p) {
        cx = Mth::floor(p->x / (float)CHUNK_WIDTH);
        cz = Mth::floor(p->z / (float)CHUNK_DEPTH);
    }

    _ChunkSorter sorter(cx, cz);
    std::sort(requestNextChunkIndexList, requestNextChunkIndexList + NumRequestChunks, sorter);
}

void ClientSideNetworkHandler::levelGenerated(Level* level)
{
	this->level = level;
	ReadyPacket packet(ReadyPacket::READY_CLIENTGENERATION);
	raknetInstance->send(packet);
#ifdef EMSCRIPTEN
	return;
#endif

    arrangeRequestChunkOrder();
	requestNextChunk();
}

void ClientSideNetworkHandler::handle(const RakNet::RakNetGUID& source, PlayerEquipmentPacket* packet)
{
	if (!level)
		return;

	Entity* entity = level->getEntity(packet->entityId);
	if (!entity || !entity->isPlayer())
		return;

	Player* player = (Player*)entity;
	// make sure it's not our local player
	if (player->owner == raknetInstance->myGuid())
	{
		printf("Attempted to modify local player's inventory\n");
		return;
	}
	// override the player's inventory
	//int slot = player->inventory->getSlot(packet->itemId, packet->itemAuxValue);
	//if (slot >= 0) {
	//	player->inventory->moveToSelectedSlot(slot, true);
		//item->id = packet->itemId;
		//item->setAuxValue(packet->itemAuxValue);
		//item->count = 63;
	int slot = Inventory::MAX_SELECTION_SIZE;
	if (slot >= 0) {
		if (packet->itemId == 0) {
			player->inventory->clearSlot(slot);
		} else {
			ItemInstance newItem(packet->itemId, 63, packet->itemAuxValue);
			player->inventory->replaceSlot(slot, &newItem);
		}
		player->inventory->moveToSelectedSlot(slot, true);
	} else {
		LOGW("Warning: Remote player doesn't have his thing, Odd!\n");
	}
}

void ClientSideNetworkHandler::handle(const RakNet::RakNetGUID& source, PlayerArmorEquipmentPacket* packet) {
	if (!level)
		return;

	Entity* entity = level->getEntity(packet->entityId);
	if (!entity || !entity->isPlayer())
		return;

	Player* player = (Player*)entity;
	// make sure it's not our local player, since that should be UpdateArmorPacket
	if (player->owner == raknetInstance->myGuid()) {
		printf("Attempted to modify local player's armor visually\n");
		return;
	}

	packet->fillIn(player);
}

void ClientSideNetworkHandler::handle(const RakNet::RakNetGUID& source, InteractPacket* packet)
{
	if (!level)
		return;

	Entity* src = level->getEntity(packet->sourceId);
	Entity* entity = level->getEntity(packet->targetId);
	if (src && entity && src->isPlayer())
	{
		Player* player = (Player*) src;
		if (InteractPacket::Attack == packet->action)
			minecraft->gameMode->attack(player, entity);
		if (InteractPacket::Interact == packet->action)
			minecraft->gameMode->interact(player, entity);
	}
}

void ClientSideNetworkHandler::handle(const RakNet::RakNetGUID& source, SetEntityDataPacket* packet)
{
	if (!level)
		return;

	LOGI("SetEntityDataPacket\n");

	Entity* e = level->getEntity(packet->id);
	if (e) {
		SynchedEntityData* data = e->getEntityData();
		if (data)
			data->assignValues(&packet->getUnpackedData());
	}
}

void ClientSideNetworkHandler::handle( const RakNet::RakNetGUID& source, SetEntityMotionPacket* packet )
{
	if (!level)
		return;

	if (Entity* e = level->getEntity(packet->id)) {
		/*
		e->xd = packet->xd;
		e->yd = packet->yd;
		e->zd = packet->zd;
		*/
		e->lerpMotion(packet->xd, packet->yd, packet->zd);
	}
}

void ClientSideNetworkHandler::handle(const RakNet::RakNetGUID& source, AnimatePacket* packet)
{
	if (!level)
		return;

    // Own player - Then don't play... :
    if (minecraft->player->entityId == packet->entityId) {
        if (packet->action == AnimatePacket::Swing) return;
    }

	Entity* entity = level->getEntity(packet->entityId);
	if (!entity || !entity->isPlayer())
        return;
    
	Player* player = (Player*) entity;

    switch (packet->action) {
	case AnimatePacket::Swing:
		player->swing();
		break;
	case AnimatePacket::WAKE_UP:
		player->stopSleepInBed(false, false, false);
		break;
	default:
		LOGW("Unknown Animate action: %d\n", packet->action);
		break;
	}
}

void ClientSideNetworkHandler::handle(const RakNet::RakNetGUID& source, UseItemPacket* packet)
{
}

void ClientSideNetworkHandler::handle(const RakNet::RakNetGUID& source, SetHealthPacket* packet)
{
	if (!level || !minecraft->player)
		return;

	minecraft->player->hurtTo(packet->health);
}

void ClientSideNetworkHandler::handle(const RakNet::RakNetGUID& source, SetSpawnPositionPacket* packet) {
	if (!level || !minecraft || !minecraft->player) return;
	if (!level->inRange(packet->x, packet->y, packet->z)) return;

	minecraft->player->setRespawnPosition(Pos(packet->x, packet->y, packet->z));
	level->getLevelData()->setSpawn(packet->x, packet->y, packet->z);
}

void ClientSideNetworkHandler::handle(const RakNet::RakNetGUID& source, HurtArmorPacket* packet) {
    if (!level || !minecraft->player) {
        return;
    }

    minecraft->player->hurtArmor(packet->dmg);
}

void ClientSideNetworkHandler::handle(const RakNet::RakNetGUID& source, RespawnPacket* packet)
{
	if (level) {
		//LOGI("RespawnPacket! %d\n", findPlayer(level, packet->entityId, NULL));
		NetEventCallback::handle(level, source, packet );
	}
}

void ClientSideNetworkHandler::handle(const RakNet::RakNetGUID& source, ContainerOpenPacket* packet)
{
	if (!level || !minecraft || !minecraft->player)
		return;

	if (packet->type == ContainerType::FURNACE) {
		FurnaceTileEntity* te = new FurnaceTileEntity();
		te->clientSideOnly = true;
		minecraft->player->openFurnace(te);
		if (minecraft->player->containerMenu)
			minecraft->player->containerMenu->containerId = packet->containerId;
	}
	if (packet->type == ContainerType::CONTAINER) {
		ChestTileEntity* te = new ChestTileEntity();
		te->clientSideOnly = true;
		minecraft->player->openContainer(te);
		if (minecraft->player->containerMenu)
			minecraft->player->containerMenu->containerId = packet->containerId;
	}
}

void ClientSideNetworkHandler::handle(const RakNet::RakNetGUID& source, ContainerClosePacket* packet)
{
	if (minecraft && minecraft->player && minecraft->player->containerMenu)
		minecraft->player->closeContainer();
}

void ClientSideNetworkHandler::handle(const RakNet::RakNetGUID& source, ContainerSetContentPacket* packet)
{
	if (!minecraft || !minecraft->player)
		return;

    if (packet->containerId == 0) {
        for (unsigned int i = 0; i < packet->items.size(); ++i) {
            minecraft->player->inventory->setItem(Inventory::MAX_SELECTION_SIZE + i, &packet->items[i]);
        }
    } else if (minecraft->player->containerMenu && minecraft->player->containerMenu->containerId == packet->containerId) {
        for (unsigned int i = 0; i < packet->items.size(); ++i) {
            minecraft->player->containerMenu->setSlot(i, &packet->items[i]);
        }
    }
}

void ClientSideNetworkHandler::handle(const RakNet::RakNetGUID& source, ContainerSetSlotPacket* packet)
{
	//LOGI("ContainerSetSlot\n");

	if (!minecraft->player
	  || !minecraft->player->containerMenu
	  || minecraft->player->containerMenu->containerId != packet->containerId)
	  return;

	//minecraft->player->containerMenu->setSlot(packet->slot, packet->item.isNull()? NULL : &packet->item);
	minecraft->player->containerMenu->setSlot(packet->slot, &packet->item);
}

void ClientSideNetworkHandler::handle(const RakNet::RakNetGUID& source, ContainerSetDataPacket* packet)
{
	//LOGI("ContainerSetData\n");
	if (minecraft->player && minecraft->player->containerMenu && minecraft->player->containerMenu->containerId == packet->containerId) {
		//LOGI("client: SetData2 %d, %d\n", packet->id, packet->value);
		minecraft->player->containerMenu->setData(packet->id, packet->value);
	}
}

void ClientSideNetworkHandler::handle( const RakNet::RakNetGUID& source, ChatPacket* packet )
{
#ifndef STANDALONE_SERVER
	minecraft->gui.displayClientMessage(packet->message);
#endif
}

void ClientSideNetworkHandler::handle(const RakNet::RakNetGUID& source, SignUpdatePacket* packet)
{
	if (!level)
		return;

	TileEntity* te = level->getTileEntity(packet->x, packet->y, packet->z);
	if (TileEntity::isType(te, TileEntityType::Sign)) {
		SignTileEntity* ste = (SignTileEntity*) te;
		if (ste->isEditable()) {
			for (int i = 0; i < SignTileEntity::NUM_LINES; i++) {
				ste->messages[i] = packet->lines[i];
			}
			//ste->setChanged();
		}
	}
}

void ClientSideNetworkHandler::handle(const RakNet::RakNetGUID& source, AdventureSettingsPacket* packet) {
    if (!level)
		return;
	//assert(level != NULL && "level is NULL @ handle(AdventureSettingsPacket*)");

    packet->fillIn(level->adventureSettings);
}

void ClientSideNetworkHandler::clearChunksLoaded()
{
	// Init the chunk positions
	for (int i = 0; i < NumRequestChunks; ++i) {
		requestNextChunkIndexList[i].x = i/CHUNK_WIDTH;
		requestNextChunkIndexList[i].y = i%CHUNK_WIDTH;
		chunksLoaded[i] = false;
	}
}

#ifdef EMSCRIPTEN
void ClientSideNetworkHandler::prepareChunk(int cx, int cz)
{
	if (!level) return;
	ChunkSource* cs = level->getChunkSource();
	for (int dx = -1; dx <= 0; ++dx)
	for (int dz = -1; dz <= 0; ++dz) {
		const int px = cx + dx, pz = cz + dz;
		if (px < 0 || pz < 0 || px >= worldChunks || pz >= worldChunks) continue;
		LevelChunk* c = cs->getChunk(px, pz);
		if (c && !c->terrainPopulated) cs->postProcess(cs, px, pz);
	}
}

void ClientSideNetworkHandler::handle(const RakNet::RakNetGUID& source, PlayerDataPacket* packet)
{
	if (packet->kind != PlayerDataPacket::RESTORE || packet->data.empty()) return;
	if (restoredPlayer) { restoredPlayer->deleteChildren(); delete restoredPlayer; }
	RakNet::BitStream stream(&packet->data[0], (unsigned int)packet->data.size(), false);
	RakDataInput dis(stream);
	restoredPlayer = NbtIo::read(&dis);
}

void ClientSideNetworkHandler::sendPlayerSave(bool force)
{
	LocalPlayer* p = minecraft ? minecraft->player : NULL;
	if (!level || !p || !sentReady || p->health <= 0 || p->removed || !raknetInstance) return;
	CompoundTag tag;
	p->saveWithoutId(&tag);
	RakNet::BitStream stream;
	RakDataOutput dos(stream);
	NbtIo::write(&tag, &dos);
	tag.deleteChildren();
	const unsigned char* d = stream.GetData();
	const int n = stream.GetNumberOfBytesUsed();
	if (n <= 0) return;
	lastSaveTime = getTimeS();
	if (!force && (int)lastSave.size() == n && memcmp(&lastSave[0], d, n) == 0) return;
	lastSave.assign(d, d + n);
	PlayerDataPacket packet(PlayerDataPacket::SAVE);
	packet.data = lastSave;
	raknetInstance->send(packet);
}

void ClientSideNetworkHandler::sendPlayerDied()
{
	if (!raknetInstance) return;
	lastSave.clear();
	PlayerDataPacket packet(PlayerDataPacket::DIED);
	raknetInstance->send(packet);
}

void ClientSideNetworkHandler::tickChunkRequests()
{
	if (dropPending && minecraft->level && minecraft->isLevelGenerated()) {
		dropLevel();
		if (deferredStart) {
			StartGamePacket* start = deferredStart;
			deferredStart = NULL;
			handle(serverGuid, start);
			delete start;
		}
		return;
	}
	if (!level || !minecraft || !minecraft->player) return;
	if (sentReady && getTimeS() - lastSaveTime > 5.0) sendPlayerSave(false);
	static const int MAX_IN_FLIGHT = 6;
	static const int RADIUS = 8;
	static const int READY_RADIUS = 2;
	static const int SETTLE_IN_FLIGHT = (2 * READY_RADIUS + 1) * (2 * READY_RADIUS + 1);
	static const double REASK_SECONDS = 8.0;
	static const double SETTLE_GIVE_UP = 30.0;
	const double now = getTimeS();
	for (std::map<int, double>::iterator it = requestedChunks.begin(); it != requestedChunks.end();) {
		if (now - it->second > REASK_SECONDS) requestedChunks.erase(it++);
		else ++it;
	}
	const int pcx = Mth::floor(minecraft->player->x) >> 4;
	const int pcz = Mth::floor(minecraft->player->z) >> 4;

	if (!sentReady) {
		LocalPlayer* p = minecraft->player;
		p->moveTo(spawnX, spawnY, spawnZ, p->yRot, p->xRot);
		p->xd = p->yd = p->zd = 0;
		p->fallDistance = 0;
		if (settleStart < 0) settleStart = now;
		const bool gaveUp = now - settleStart > SETTLE_GIVE_UP;
		bool all = true;
		for (int dx = -READY_RADIUS; dx <= READY_RADIUS && all && !gaveUp; ++dx)
		for (int dz = -READY_RADIUS; dz <= READY_RADIUS && all; ++dz) {
			const int x = pcx + dx, z = pcz + dz;
			if (x < 0 || z < 0 || x >= worldChunks || z >= worldChunks) continue;
			if (!syncedChunks.count(x * 65536 + z)) all = false;
		}
		if (all) {
			sentReady = true;
			trip.clear();
			ReadyPacket ready(ReadyPacket::READY_REQUESTEDCHUNKS);
			raknetInstance->send(ready);
		}
	}

	const int inFlight = sentReady ? MAX_IN_FLIGHT : SETTLE_IN_FLIGHT;
	for (int r = 0; r <= RADIUS && (int)requestedChunks.size() < inFlight; ++r)
	for (int dx = -r; dx <= r && (int)requestedChunks.size() < inFlight; ++dx)
	for (int dz = -r; dz <= r && (int)requestedChunks.size() < inFlight; ++dz) {
		if (dx != -r && dx != r && dz != -r && dz != r) continue;
		const int x = pcx + dx, z = pcz + dz;
		if (x < 0 || z < 0 || x >= worldChunks || z >= worldChunks) continue;
		const int key = x * 65536 + z;
		if (syncedChunks.count(key) || requestedChunks.count(key)) continue;
		requestedChunks[key] = now;
		RequestChunkPacket packet(x, z);
		raknetInstance->send(packet);
	}
}
#endif

void ClientSideNetworkHandler::handle(const RakNet::RakNetGUID& source, RidePacket* packet)
{
	if (!level || packet->kind != RidePacket::STATE) return;
	Entity* rider = level->getEntity(packet->riderId);
	if (!rider) return;
	Entity* mount = packet->mountId >= 0 ? level->getEntity(packet->mountId) : NULL;
	if (mount && mount->removed) mount = NULL;
	if (mount) { if (rider->riding != mount) rider->ride(mount); }
	else if (rider->riding) rider->ride(NULL);
	if (minecraft && rider == (Entity*)minecraft->player) RideSync::hostSaid() = RideSync::mountOf(rider);
}

void ClientSideNetworkHandler::handle(const RakNet::RakNetGUID& source, SetExperiencePacket* packet)
{
	if (!minecraft || !minecraft->player) return;
	minecraft->player->experience.progress = packet->progress;
	minecraft->player->experience.level = packet->level;
	minecraft->player->experience.total = packet->total;
}

void ClientSideNetworkHandler::handle(const RakNet::RakNetGUID& source, SetWeatherPacket* packet)
{
	if (level && level->weather) level->weather->setRemote(packet->raining != 0, packet->thundering != 0);
}

int ClientSideNetworkHandler::settleProgress() const
{
	if (!level || !minecraft->player) return -1;
	if (sentReady) return 100;
	static const int R = 2;
	const int pcx = Mth::floor(spawnX) >> 4, pcz = Mth::floor(spawnZ) >> 4;
	int have = 0, all = 0;
	for (int dx = -R; dx <= R; ++dx)
		for (int dz = -R; dz <= R; ++dz) {
			const int x = pcx + dx, z = pcz + dz;
			if (x < 0 || z < 0 || x >= worldChunks || z >= worldChunks) continue;
			++all;
			if (syncedChunks.count(x * 65536 + z)) ++have;
		}
	return all ? 100 * have / all : 100;
}

void ClientSideNetworkHandler::handle(const RakNet::RakNetGUID& source, ChangeDimensionPacket* packet)
{
#ifdef EMSCRIPTEN
	LOGI("Portals: switch to dimension %d (level %s)\n", packet->dimension,
	     !minecraft->level ? "none" : minecraft->isLevelGenerated() ? "ready" : "loading");
	if (packet->kind != ChangeDimensionPacket::SWITCHING || !minecraft->level) return;
	{
		const int from = minecraft->level->dimension ? minecraft->level->dimension->id : 0, to = packet->dimension;
		trip = to == NetherDimension::ID ? "Entering the Nether" : to == EndDimension::ID ? "Entering the End"
		     : ModDimensions::isModDim(to) ? ModDimensions::byId(to)->enterMsg
		     : ModDimensions::isModDim(from) ? ModDimensions::byId(from)->leaveMsg
		     : from == EndDimension::ID ? "Leaving the End" : "Leaving the Nether";
	}
	if (minecraft->isLevelGenerated()) dropLevel();
	else dropPending = true;
#endif
}

#ifdef EMSCRIPTEN
void ClientSideNetworkHandler::dropLevel()
{
	dropPending = false;
	Level* old = minecraft->level;
	if (!old) return;
	LocalPlayer* p = minecraft->player;
	if (carriedPlayer) { carriedPlayer->deleteChildren(); delete carriedPlayer; carriedPlayer = NULL; }
	if (p) {
		if (p->health <= 0) {
			p->reset();
			p->resetPos(true);
		}
		carriedPlayer = new CompoundTag();
		p->saveWithoutId(carriedPlayer);
	}
	arrivingFrom = old->dimension ? old->dimension->id : 0;

#ifndef STANDALONE_SERVER
	minecraft->setScreen(new ProgressScreen());
	if (minecraft->levelRenderer) minecraft->levelRenderer->setLevel(NULL);
	if (minecraft->particleEngine) minecraft->particleEngine->setLevel(NULL);
#endif
	minecraft->cameraTargetPlayer = NULL;
	minecraft->hitResult = HitResult();
	MobFactory::clearStaticTestMobs();
	minecraft->level = NULL;
	minecraft->player = NULL;
	level = NULL;
	delete old->getLevelStorage();
	delete old;

	syncedChunks.clear();
	requestedChunks.clear();
	sentReady = false;
	settleStart = -1;
}
#endif
