Example Biome Features
======================
What grows and gets built where - by biome:
worldgen/frost_spruce.json   a tree ("type": "tree") in taiga and tundra, with this mod's Frost Leaves.
worldgen/bluebells.json      flowers ("type": "plant") scattered in plains and forests.
worldgen/desert_well.json    a structure written out in layers, only on desert sand.
worldgen/swamp_clay.json     clay deposits ("type": "ore") under swamps.
"biomes" takes: rainforest, swampland, seasonal_forest, forest, savanna, shrubland, taiga, desert,
plains, ice_desert, tundra (Java names like "jungle" or "swamp" work too).
Mods can't add new biomes yet - these decorate the existing ones.
Only chunks generated from now on get them: explore somewhere new.

The modding guide: https://colinthepwner.github.io/MCRE/modding.html
