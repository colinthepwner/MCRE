Example Shaders
===============
Shader packs are mods here: drop an OptiFine / Iris pack .zip on the game and switch it on. Its
own options are in that mod's Settings (Mods tab -> the pack -> Settings).

scripts/main.js   /shaders      every installed pack, the live one marked (client.shaders.list)
                  /useshader    switch one on by its mod id, or off (client.shaders.use) - the
                                answer comes when the pack is running or has failed
                  /shaderopts   what the live pack's options are set to (client.shaders.options)
                  /shadows      sets the pack's own "Shadows" option and rebuilds it
                                (client.shaders.setOption)
                  the "shaders" event fires whenever the live pack changes, a failure included.

Each command asks the player's own device to do the work (mod.send -> client.on("message")),
because a shader pack belongs to a device and commands run where the world is.

Game rules:  shaderPack ("") - the live pack's mod id; setting it switches pack.
             shadersAllowed (on) - off: no pack runs at all, whatever is installed. It lasts the
             session, so the player's pack comes back when the scripts stop.

The modding guide: https://colinthepwner.github.io/MCRE/modding.html
