// Example Shaders - scripts/main.js
// Rube loads OptiFine / Iris shader packs: a pack is installed as a mod (drop the .zip on the
// game), and its options are that mod's Settings. A script can do the same from the outside.
//
// A pack is each device's own look at the world, so client.shaders only ever means THIS device.
// Commands run where the world is, so each one here just asks the player's own device to do the
// work (mod.send -> client.on("message")), which is what makes it right for a joined player too.

mod.command('shaders', function (c) { mod.send(c.player, { shaders: 'list' }); },
  { description: 'the shader packs on this device' });

mod.command('useshader', function (c) { mod.send(c.player, { shaders: 'use', pack: c.args[0] || 'off' }); },
  { usage: '<pack id|off>', description: 'switch a shader pack on' });

mod.command('shaderopts', function (c) { mod.send(c.player, { shaders: 'opts' }); },
  { description: 'what the live pack options are set to' });

mod.command('shadows', function (c) { mod.send(c.player, { shaders: 'shadows', on: (c.args[0] || 'on') !== 'off' }); },
  { usage: '<on|off>', description: 'the shadows of the live pack' });

// --- this device -----------------------------------------------------------------------------

client.on('message', function (e) {
  var d = e.data || {};
  if (!d.shaders) return;

  // Every installed pack, with the live one marked.
  if (d.shaders === 'list') return client.shaders.list().then(function (packs) {
    if (!packs.length) return client.message('No shader packs installed - drop an OptiFine pack .zip on the game.');
    packs.forEach(function (p) {
      client.message((p.on ? '* ' : '  ') + p.name + '  (' + p.id + ', ' + p.programs + ' programs)');
    });
    client.message('/useshader <id>  or  /useshader off');
  });

  // Switch one on. The promise answers when the pack is really running - the first load compiles
  // the whole pack, which takes a moment - or says why it could not be used.
  if (d.shaders === 'use') {
    var want = String(d.pack).toLowerCase();
    client.message(want === 'off' ? 'Shaders off.' : 'Loading ' + want + '...');
    return client.shaders.use(want === 'off' ? false : want).then(function (err) {
      if (err) client.message('Could not use it: ' + err);
    });
  }

  // A pack option, by the pack own names: setting one rebuilds the pack with it, exactly as
  // changing it in the mod Settings does. Which names a pack has is up to the pack.
  if (d.shaders === 'opts') return client.shaders.current().then(function (p) {
    if (!p) return client.message('No shader pack is on.');
    return client.shaders.options(p.id).then(function (o) {
      var keys = Object.keys(o);
      client.message(p.name + ': ' + (keys.length ? keys.length + ' options set' : 'every option at the pack own default'));
      keys.slice(0, 12).forEach(function (k) { client.message('  ' + k + ' = ' + o[k]); });
    });
  });

  if (d.shaders === 'shadows') return client.shaders.current().then(function (p) {
    if (!p) return client.message('No shader pack is on.');
    return client.shaders.setOption(p.id, 'Shadows', !!d.on).then(function (ok) {
      client.message(ok ? 'Rebuilding ' + p.name + '...' : 'That pack has no "Shadows" option.');
    });
  });
});

// The live pack changed - switched on or off, rebuilt with new options, or it failed. This is the
// only way to hear about a pack that will not compile.
client.on('shaders', function (e) {
  if (e.error) client.message('Shaders stopped: ' + e.error);
  else if (e.on) client.message('Shaders: ' + e.name);
  else client.message('Shaders off.');
  client.hud('shaders', e.on ? 'Shaders: ' + e.name : null);
});

// A world with a look of its own can switch packs off while it is open, and the player pack comes
// back when the scripts stop. Left commented out: it would surprise anyone trying this preset
// while using a pack.
// mod.on('start', function () { world.setGameRule('shadersAllowed', false); });
