Example Texture Pack
====================
lang/en_US.lang   lines of key=value replacing the game's text (here: Dirt is now "Soil").
To change pictures, add 16x16 .png files with the game's names:
  textures/blocks/dirt.png     replaces dirt
  textures/items/apple.png     replaces the apple
(the names are in texture_names.txt of the game's Example Pack - Download it in the Mods tab).
Sounds: sounds/random/click.ogg replaces "random.click" (the menu buttons).
A Java Edition resource pack .zip works as it is, too.

The modding guide: https://colinthepwner.github.io/MCRE/modding.html
