Example Scripting
=================
scripts/main.js   everything is here, in sections:
  commands        /hello for everyone, /day for operators (permission "op")
  a menu          buttons and an item picker (client.gui.open, client.on("gui"))
  keys            the "key" settings in manifest.json show up in Options > Controls > Key Bindings;
                  client.on("keybind") hears them - G opens the menu, K shows coordinates
  world data      storage.get / set keep a count with the world
  game rules, AFK a longer AFK time (world.setGameRule), "is AFK / is back" messages (the "afk"
                  event) and /afk (players.presence / setAfk)
types/mcre.d.ts + jsconfig.json   autocomplete for the scripting API in VS Code and similar.
/console in a world shows your log() lines and errors, and runs lines of script.

The modding guide: https://colinthepwner.github.io/MCRE/modding.html
