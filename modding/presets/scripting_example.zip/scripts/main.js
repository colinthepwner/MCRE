// Example Scripting - scripts/main.js
// One script runs on every device: mod.on / players / world reach where the world is, client.*
// is this device. See the modding guide for every function.

// --- commands -----------------------------------------------------------------------------------
mod.command('hello', function (c) {
  players.message(c.player, 'Hello, ' + c.player.name + '!');
}, { description: 'say hello' });

mod.command('day', function () {
  world.setTimeOfDay('noon');
}, { permission: 'op', description: 'make it noon (operators)' });

// --- a menu -------------------------------------------------------------------------------------
function openMenu() {
  client.items().then(function (all) {
    client.gui.open({
      id: 'menu', title: 'Example Menu',
      elements: [
        { type: 'text', text: 'Opened ' + (client.storage.get('opened') || 0) + ' times on this device.' },
        { type: 'row', elements: [
          { type: 'button', id: 'heal', text: 'Heal me' },
          { type: 'button', id: 'controls', text: 'Controls...' } ] },
        { type: 'text', text: 'Pick a block for a stack of it:', color: '#aaaaaa' },
        { type: 'items', id: 'pick', items: all.filter(function (s) { return s.item.indexOf('minecraft:') === 0; }).slice(0, 90), rows: 4 }
      ]
    });
  });
}

client.on('gui', function (e) {
  if (e.gui !== 'menu') return;
  client.player().then(function (me) {
    if (e.id === 'heal') players.heal(me, 20);
    if (e.id === 'controls') client.openControls();   // the game's Controls screen, on this mod's keys
    if (e.id === 'pick' && e.item) players.give(me, e.item, 64);
  });
});

// --- keys the player can rebind (manifest "settings" of type "key": Options > Controls) ---------
var showCoords = false;
client.on('keybind', function (e) {
  if (!e.down) return;
  if (e.id === 'menu_key') {
    client.storage.set('opened', (client.storage.get('opened') || 0) + 1);
    openMenu();
  }
  if (e.id === 'coords_key') {
    showCoords = !showCoords;
    if (!showCoords) client.hud('coords', null);
  }
});
client.on('tick', function (e) {
  if (showCoords && e.player) client.hud('coords', Math.floor(e.player.x) + ', ' + Math.floor(e.player.y) + ', ' + Math.floor(e.player.z));
});

// --- world events, and data kept with the world -------------------------------------------------
mod.on('break', function (e) {
  if (e.block !== 'minecraft:diamond_ore' || !e.player) return;
  var found = storage.get('diamonds') || 0;
  storage.set('diamonds', found + 1);
  players.message(e.player, 'Diamond ore broken in this world: ' + (found + 1));
});

// --- game rules and AFK -------------------------------------------------------------------------
// Game rules are the game's own features' settings (world.gameRules() lists them). Set them on
// "start": they last the session.
mod.on('start', function () {
  world.setGameRule('afkKickSeconds', 300);   // 5 minutes before an AFK player is disconnected
});
mod.on('afk', function (e) {
  players.message('all', e.player.name + (e.afk ? ' is AFK' : ' is back') + ' (' + e.device + ')');
});
mod.command('afk', function (c) {
  players.presence(c.player).then(function (p) { players.setAfk(c.player, !(p && p.afk)); });
}, { description: 'go AFK / come back' });
