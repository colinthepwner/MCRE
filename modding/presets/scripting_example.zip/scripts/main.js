// Example Scripting - scripts/main.js
// One script runs on every device: mod.on / players / world reach where the world is, client.*
// is this device. See the modding guide for every function.

// --- commands -----------------------------------------------------------------------------------
mod.command('hello', function (c) {
  players.message(c.player, 'Hello, ' + c.player.name + '!');
  // (an achievement: shown the first time only - every later /hello in this world is quiet)
  players.award(c.player, 'first_hello', { name: 'Hello there', description: 'Use /hello', icon: 'minecraft:torch' });
}, { description: 'say hello' });

mod.command('day', function () {
  world.setTimeOfDay('noon');
}, { permission: 'op', description: 'make it noon (operators)' });

// the game's own commands from a script (as the server), and command blocks running theirs
mod.command('nightvision', function (c) {
  world.runCommand('/effect give ' + c.player.name + ' night_vision 60').then(function (r) {
    players.message(c.player, r.output);
  });
}, { permission: 'op', description: 'see in the dark for a minute (operators)' });

mod.on('commandblock', function (e) {
  if (!e.success) log('the command block at ' + e.x + ' ' + e.y + ' ' + e.z + ' failed: ' + e.output);
});

// a device's own options: /sounds flips Options > Game > Sounds (old / new) on the player's device
mod.command('sounds', function (c) {
  mod.send(c.player, { flipSounds: true });
}, { description: 'switch between the old and the new (1.7) sounds' });

client.on('message', function (e) {
  if (!e.data || !e.data.flipSounds) return;
  client.soundStyle().then(function (s) { client.setSoundStyle(s === 'old' ? 'new' : 'old'); });
});

client.on('soundStyle', function (e) {
  client.message('Sounds: ' + (e.style === 'new' ? 'New (1.7)' : 'Old'));
});

// --- a menu -------------------------------------------------------------------------------------
function openMenu() {
  client.items().then(function (all) {
    client.gui.open({
      id: 'menu', title: 'Example Menu',
      elements: [
        { type: 'text', text: 'Opened ' + (client.storage.get('opened') || 0) + ' times on this device.' },
        { type: 'row', elements: [
          { type: 'button', id: 'heal', text: 'Heal me' },
          { type: 'button', id: 'controls', text: 'Controls...' } ] },
        { type: 'text', text: 'Pick a block for a stack of it:', color: '#aaaaaa' },
        { type: 'items', id: 'pick', items: all.filter(function (s) { return s.item.indexOf('minecraft:') === 0; }).slice(0, 90), rows: 4 }
      ]
    });
  });
}

client.on('gui', function (e) {
  if (e.gui !== 'menu') return;
  client.player().then(function (me) {
    if (e.id === 'heal') players.heal(me, 20);
    if (e.id === 'controls') client.openControls();   // the game's Controls screen, on this mod's keys
    if (e.id === 'pick' && e.item) players.give(me, e.item, 64);
  });
});

// --- keys the player can rebind (manifest "settings" of type "key": Options > Controls) ---------
var showCoords = false;
client.on('keybind', function (e) {
  if (!e.down) return;
  if (e.id === 'menu_key') {
    client.storage.set('opened', (client.storage.get('opened') || 0) + 1);
    openMenu();
  }
  if (e.id === 'coords_key') {
    showCoords = !showCoords;
    if (!showCoords) client.hud('coords', null);
  }
});
client.on('tick', function (e) {
  if (showCoords && e.player) client.hud('coords', Math.floor(e.player.x) + ', ' + Math.floor(e.player.y) + ', ' + Math.floor(e.player.z));
});

// --- world events, and data kept with the world -------------------------------------------------
// (a flower with "neighbor_updates": true - Example Biome Features' bluebell: its support gone, it
// pops off, as the game's own flowers do)
mod.on('neighbor', async function (e) {
  if (!/:bluebell$/.test(e.block)) return;
  var below = await world.getBlock(e.x, e.y - 1, e.z);
  if (below.block === 'air') world.setBlock(e.x, e.y, e.z, 'air');
});
mod.on('break', function (e) {
  if (e.block !== 'minecraft:diamond_ore' || !e.player) return;
  var found = storage.get('diamonds') || 0;
  storage.set('diamonds', found + 1);
  players.message(e.player, 'Diamond ore broken in this world: ' + (found + 1));
});

// --- game rules and AFK -------------------------------------------------------------------------
// Game rules are the game's own features' settings (world.gameRules() lists them). Set them on
// "start": they last the session.
mod.on('start', function () {
  world.setGameRule('afkKickSeconds', 300);   // 5 minutes before an AFK player is disconnected
  // (some rules are the world's own settings and stay with it - generateStructures)
  world.gameRule('generateStructures').then(function (on) {
    if (!on) console.log('This world makes no villages or other structures.');
  });
});
mod.on('afk', function (e) {
  players.message('all', e.player.name + (e.afk ? ' is AFK' : ' is back') + ' (' + e.device + ')');
});

// --- the sky ------------------------------------------------------------------------------------
// world.setSkyColor tints the whole sky for everyone (night and weather still darken it); null
// gives it back. Biomes can have their own instead: "sky_color" in biomes/<name>.json.
mod.command('redsky', function (c) {
  world.skyColor().then(function (now) {
    world.setSkyColor(now === '#ff4020' ? null : '#ff4020');
  });
}, { description: 'turn the sky red / back' });
mod.on('sky', function (e) {
  players.message('all', e.color ? 'The sky turns ' + e.color : 'The sky is back to normal');
});
mod.command('afk', function (c) {
  players.presence(c.player).then(function (p) { players.setAfk(c.player, !(p && p.afk)); });
}, { description: 'go AFK / come back' });
// Edge Assist (touch): a word when it lets someone go over an edge.
mod.on('edge', function (e) {
  if (e.state === 'through') players.message(e.player, 'Careful!');
});
// The world's bot (/bot spawn): cheer when it finishes a job; /botwood sends it for logs.
mod.on('bot', function (e) {
  if (e.action === 'done') players.message('all', e.bot + ' finished: ' + e.task);
});
mod.command('botwood', function (c) {
  world.bot().then(function (b) {
    if (!b) { players.message(c.player, 'No bot here - /bot spawn first'); return; }
    world.botCommand('get 16 logs').then(function (r) { players.message(c.player, r.msg); });
  });
}, { description: 'send the bot for 16 logs', permission: 'op' });
