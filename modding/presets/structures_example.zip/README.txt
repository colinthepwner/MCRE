Example Structures
==================
worldgen/ruin.json   a structure in layers, bottom first: each row a line of blocks north to south,
                     each character a block from "key" ("." air, " " leaves what's there). "C" is a
                     chest filled from a loot table. "chance" per chunk, "on" what it stands on.
                     A schematic (.schematic, .schem, .nbt) can be used instead of "layers": "file".
loot_tables/chests/ruin.json   Java's loot table format.
scripts/main.js      the "structure" event, and /ruin to build one (operators only).
Only chunks generated from now on get them: explore somewhere new.

The modding guide: https://colinthepwner.github.io/MCRE/modding.html
