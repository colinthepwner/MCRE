// Minecraft RE - mod scripting API, for editors (VS Code and others read this file and complete
// the API as you type). Keep it next to your scripts: this mod's jsconfig.json points the editor
// at types/*.d.ts and scripts/*.js. Nothing here runs - it only describes what the game gives
// every script: mod, world, players, gui, storage, client and log.

/** A block or item: "<mod id>:<name>", "minecraft:<java name>" (e.g. "minecraft:stone"),
 *  "air", or just "<name>" for your own mod's. Add ":<data>" for a variant ("minecraft:wool:14").
 *  Java 1.7's blocks go by their 1.7 names ("minecraft:stained_glass:14", "minecraft:log2:1",
 *  "minecraft:double_plant:0", "minecraft:red_flower:9" - see the README's Names). */
type Name = string;

/** A player. Pass it (or its id) wherever a player goes. */
interface Player {
  id: number;
  name: string;
  /** Feet position. */
  x: number; y: number; z: number;
  health: number;
}

/** A creature (or other entity) in an event. */
interface Creature {
  id: number;
  /** "minecraft:zombie", "<mod id>:<name>" for a mod's own creature, ... */
  type: string;
  x: number; y: number; z: number;
  health?: number;
  /** Set when the creature is a player. */
  name?: string;
}

/** world.entity(): a creature in detail. */
interface CreatureDetail extends Creature {
  yaw: number; pitch: number;
  motion: [number, number, number];
  onGround: boolean;
  /** Ticks of fire left. */
  fire: number;
  maxHealth?: number;
  /** The creature it's going for (0: none). */
  target?: number;
  effects?: { effect: string; seconds: number; level: number }[];
  /** A mod creature's model parts hidden on it now (world.setPartVisible). */
  hiddenParts?: string[];
  /** A mod creature's picture: 0 its "texture", n its n-th "textures" one (world.setMobTexture). */
  texture?: number;
}

/** Everything an event can carry. Which fields are set depends on the event (see mod.on). */
interface GameEvent {
  /** The event's name. */
  t: string;
  /** A block: its name, data value and position. */
  block?: Name; data?: number; x?: number; y?: number; z?: number;
  /** An item: its name and how many. */
  item?: Name; count?: number;
  /** The face of a block an item was used on, or ("place") the face clicked to place it
   *  (0 down, 1 up, 2 north, 3 south, 4 west, 5 east). */
  face?: number;
  /** Whoever did it. */
  player?: Player;
  /** The creature it happened to, and (hurt / death) what did it. */
  entity?: Creature; source?: Creature | null;
  damage?: number;
  /** "chat" */
  text?: string;
  /** "explode" */
  power?: number;
  /** "weather" */
  raining?: number; thundering?: number;
  /** "dispense": the slot it came from, which way the dispenser faces (as face), and whether a
   *  Java mod dispensed it its own way (1) rather than the game (0). */
  slot?: number; facing?: number; handled?: number;
  /** "enchant" */
  enchantment?: string; level?: number;
  /** "jukebox": the disc's music (its item's "record"); e.action is "insert" or "eject". */
  sound?: string;
  /** "dimension": 0 overworld, -1 Nether, 1 End. */
  dimension?: number;
  /** "sky": a script set the sky's colour (world.setSkyColor) - null: given back. */
  sky?: { color: string | null; mod: string };
  /** "afk": gone AFK (true) or back (false), and what they play on. */
  afk?: boolean; device?: Device;
  /** "bot": what the world's bot did - spawn / despawn / done / fail / died / rename; its name,
   *  the job (done / fail), its owner (spawn), its old name (rename). */
  action?: 'spawn' | 'despawn' | 'done' | 'fail' | 'died' | 'rename' | 'asked' | 'chore'; bot?: string; task?: string; owner?: string; was?: string;
  /** action "chore": the bot put an errand of its own in front of the job it was given, because
   *  something ordinary was missing - fuel for the furnace it was at, blocks to stack out of a
   *  hole. `task` is the errand. The job underneath is untouched and carries on when the errand
   *  ends, so no "done" follows for the job itself until it really finishes. Game rule
   *  botSelfHelp turns this off, and the bot reports the shortage and stops instead. */
  /** action "asked": somebody put a question about the surroundings to the bot - who asked (by),
   *  which question (query: "sense" | "find" | "look" | "progress") and what about. */
  by?: string; query?: string; about?: string;
  /** "edge": Edge Assist started holding the player at a drop ("hold"), they pushed on and went
   *  over ("through"), or they stopped / walked away ("free"). "tutorial": the walkthrough's section
   *  ("gameplay", "inventory", "crafting", "crafting_table", "furnace", "minecart", "boat", "fishing",
   *  "bed", "container", "dispenser", "redstone_and_piston", "portal"). */
  state?: 'hold' | 'through' | 'free' | string;
  /** "tutorial": what happened - it started, moved on a step, went into a section, or its main part
   *  ended (time runs again, monsters come, the spawn area opens); the main track's current text id
   *  ("IDS_TUTORIAL_TASK_CHOP_WOOD"...); whether the main part is over. */
  what?: 'start' | 'step' | 'state' | 'complete'; step?: string; complete?: boolean;
  /** "gametick": the world's time. */
  time?: number;
  /** "structure": which one, how it was turned (0-3, a quarter each) and its size [x, y, z]. */
  name?: string; rotation?: number; size?: [number, number, number];
  /** "gui": the menu's id, the button's id, what happened, the text boxes' values. */
  gui?: string; id?: string; action?: 'click' | 'submit' | 'input' | 'close' | 'slot' | 'message';
  values?: { [inputId: string]: string };
  /** "gui", action "message": what an html menu sent (mcre.send). */
  data?: any;
  /** "gui": what's in the menu's item slots now (see SlotsElement); action "slot": which slot changed. */
  slots?: { [slotsId: string]: (ItemStack | null)[] }; index?: number;
  /** "gui" / "message": the mod it's for. ("message" carries what was sent as e.data.) */
  mod?: string;
}

/** A stack of items. */
interface ItemStack { item: Name; count: number; data?: number; }

/** A monster spawner (world.spawner): what it makes and how often. Times are in ticks (20 a second). */
interface SpawnerInfo {
  /** "Zombie", "CaveSpider"... (Java's names), or a mod creature "<mod>:<name>". */
  mob: string;
  /** Ticks until its next try. */
  delay: number;
  /** After a try that spawned something, the next comes minDelay..maxDelay ticks later (200..800). */
  minDelay: number; maxDelay: number;
  /** Tries per round (4). */
  count: number;
  /** It waits while this many of its mob are near it (6). */
  maxNearby: number;
  /** It only works with a player this close (16 blocks). */
  playerRange: number;
  /** How far from it creatures appear (4 blocks). */
  range: number;
}

/** A world event's handler. Return a Promise if you like; errors are listed with the mod. */
type Handler = (e: GameEvent & { [k: string]: any }) => void | Promise<void>;

type WorldEventName =
  | 'start' | 'stop' | 'dimension' | 'join' | 'leave' | 'respawn'
  | 'use' | 'place' | 'break' | 'step' | 'tick' | 'useItem' | 'useItemOn'
  /** a block next to one of the mod's blocks with "neighbor_updates": true changed: e.block / e.data /
   *  e.x/y/z are the mod's block, e.neighbor the block now there (air when one was removed) */
  | 'neighbor'
  /** something is inside one of the mod's blocks with "entity_inside": true - every tick while it
   *  is: e.block / e.data / e.x/y/z, e.entity (and e.player for a player), e.vx/vy/vz its motion */
  | 'inside'
  /** one of the mod's liquids ("liquid": {"mix": [...]}) hardened next to its mix partner: e.liquid
   *  ("mod:<key>"), e.with ("water" / "lava" / a block), e.block (what it became), e.x/y/z */
  | 'liquidmix'
  | 'eat' | 'craft' | 'smelt' | 'attack' | 'interact' | 'hurt' | 'death' | 'spawn'
  | 'chat' | 'explode' | 'weather' | 'gametick' | 'gui' | 'message' | 'structure'
  /** a "throwable" mod item landed: e.item, e.x/y/z, e.entity (what it hit, if anything), e.player */
  | 'hit'
  /** an accessory slot's item changed (accessories.json / an item's "accessory"): e.slot, e.type,
   *  e.item / e.data / e.count (now - "id:0" when emptied), e.before / e.beforeData /
   *  e.beforeCount (what was there), e.player */
  | 'accessory'
  /** a dispenser fired one item: e.x/y/z, e.item, e.count, e.data, e.slot, e.facing, e.handled */
  | 'dispense'
  /** a mod's enchantment (enchantments/<name>.json) took effect on a hit: e.enchantment
   *  ("<mod>:<name>"), e.level, e.entity (what was hit), e.player */
  | 'enchant'
  /** a player earned an achievement (any mod's - scripts' players.award, Java mods'): e.player,
   *  e.id ("<mod>:<id>"), e.name, e.description, e.mod */
  | 'achievement'
  /** a catch was reeled in: e.player, e.item */
  | 'fish'
  /** the day's moon changed (moons.json): e.moon ("" an ordinary one), e.old, e.day */
  | 'moon'
  /** a player learned a skill (players.learnSkill): e.skill, e.player */
  | 'skill'
  /** a sleeper was woken: e.player, e.cause ("hunger" / "mob"), e.entity (the monster) */
  | 'sleepInterrupted'
  /** a creature's goal started / stopped: e.entity, e.goal, e.handle, e.priority, e.target (1: a
   *  target goal) */
  | 'goalStart' | 'goalStop'
  /** a player went AFK or came back (multiplayer, and single player): e.player, e.afk, e.device -
   *  see players.presence and the afk* game rules */
  | 'afk'
  /** the world's bot (/bot) spawned, finished or failed a job, set itself an errand mid-job
   *  ("chore"), died, was renamed or left: e.action, e.bot, e.task - see world.bot /
   *  world.botCommand and the bot* game rules */
  | 'bot'
  /** a tutorial world's walkthrough (Play Tutorial - the Xbox 360 Edition's TU3 tutorial): e.what,
   *  e.state, e.step, e.complete - see world.tutorial / world.tutorialSkip and the tutorial* game rules */
  | 'tutorial'
  /** Edge Assist (touch players walking with the stick are softly held at drops): e.player,
   *  e.state ("hold" / "through" / "free"), e.x/y/z - see the edgeAssist* game rules. The player's
   *  own game only (like "eat"). */
  | 'edge'
  /** a disc went into (e.action "insert") or came out of ("eject") a jukebox: e.x/y/z, e.item /
   *  e.data (the disc), e.sound (its music), e.player (none when a script did it) */
  | 'jukebox'
  /** a command block ran its command: e.x/y/z, e.command, e.success, e.output */
  | 'commandblock'
  /** a creature broke a block (on Brutal the game's monsters dig to players they hunt; a mod's
   *  "digs" trait too): e.mob, e.block / e.data, e.x/y/z */
  | 'mobdig'
  /** the world's difficulty changed: e.level (0 peaceful .. 4 brutal), e.name */
  | 'difficulty'
  /** Pre-load Chunks finished making the rest of a limited world in the background while it was played:
   *  e.made (chunks in its list). Its share of the time: the preloadShare game rule */
  | 'preload'
  /** a sponge soaked up water and is now a Wet Sponge: e.x/y/z (the sponge), e.count (water blocks taken).
   *  How far and how much: the spongeRange / spongeLimit game rules */
  | 'sponge'
  /** a game rule was changed with /gamerule: e.name, e.value */
  | 'gamerule'
  /** this mod's settings changed (e.values: all of them) */
  | 'settings';

interface CommandContext {
  player: Player;
  /** The words after the command's name. */
  args: string[];
  /** Everything typed, "/name ..." */
  text: string;
  /** Typed by the player whose world it is (single player: always). */
  isHost: boolean;
  /** Typed by an operator (the host always is). */
  isOp: boolean;
}

interface CommandOptions {
  /** "host": only the player whose world it is may use it; "op": operators. Default "everyone". */
  permission?: 'everyone' | 'host' | 'op';
  /** Shown by /help. */
  description?: string;
  /** What follows the name, for /help: "<player> <amount>". */
  usage?: string;
}

interface ModApi {
  /** This mod's id (manifest.json). */
  readonly id: string;
  /** A world event - fires once, where the world is (single player or the host). */
  on(event: WorldEventName, fn: Handler): void;
  /** "/name ..." typed in chat. */
  command(name: string, fn: (c: CommandContext) => void | Promise<void>, options?: CommandOptions): void;
  /** Data to client.on("message") on that player's device ("all": everyone's). */
  send(player: Player | number | 'all', data: any): void;
  /** This device's values of the settings in manifest.json ("settings"). Where the world is,
   *  they're the host's; in client code, that player's own. Changes: on("settings"), e.values. */
  readonly settings: {
    get(id: string): any;
    all(): { [id: string]: any };
    /** Change one (kept, like a change in the Settings dialog; the value is fitted to the setting). */
    set(id: string, value: any): void;
  };
}

interface WorldApi {
  setBlock(x: number, y: number, z: number, block: Name, data?: number): void;
  setData(x: number, y: number, z: number, data: number): void;
  /** built: a player put this block here by hand (the game records every placement) - see isBuilt. */
  getBlock(x: number, y: number, z: number): Promise<{ block: Name; data: number; built: boolean }>;
  /** Did somebody put this block here by hand? Bots never mine a block that is marked, so this is
   *  how a mod asks whether a cell is part of anyone's building. */
  isBuilt(x: number, y: number, z: number): Promise<boolean>;
  /** Mark (or unmark) a cell as somebody's handiwork. What world.setBlock writes is NOT marked -
   *  a mod growing ore or laying out terrain is not building - so a mod that puts a structure down
   *  marks it here and bots leave it standing. */
  setBuilt(x: number, y: number, z: number, on?: boolean): void;
  /** The light at a block: light (as growth reads it, night counted), full (the time of day not counted), the two
   *  layers, whether it sees the sky / is outdoors, and its biome. */
  light(x: number, y: number, z: number): Promise<{ light: number; full: number; sky: number; block: number; seesSky: boolean;
    outdoors: boolean; biome: string; temperature: number | null; rains: boolean }>;
  /** A "tick" event for a scripted block, this many game ticks (20 a second) from now. */
  scheduleTick(x: number, y: number, z: number, ticks: number): void;
  spawnItem(x: number, y: number, z: number, item: Name, count?: number): void;
  explode(x: number, y: number, z: number, power?: number, fire?: boolean): void;
  /** The world's time in ticks (a day is 19200; 0 is sunrise). */
  time(): Promise<number>;
  setTime(t: number): void;
  /** Is it raining / thundering? */
  weather(): Promise<{ raining: boolean; thundering: boolean }>;
  /** Clear skies, rain (snow where it's cold) or a thunderstorm - for this many seconds, or (none
   *  given) as long as the game's own weather would last. */
  setWeather(kind: 'clear' | 'rain' | 'thunder', seconds?: number): void;
  /** Ticks in a day: 19200 (Java's is 24000). */
  readonly DAY: number;
  /** The time of day: which day, ticks into it, the hour (Java's: 0 is sunrise, 6 noon), "HH:MM",
   *  and whether it's night. */
  timeOfDay(): Promise<{ day: number; ticks: number; hour: number; clock: string; night: boolean }>;
  /** "sunrise", "day", "noon", "sunset", "night", "midnight" or a Java time (0-23999): that time
   *  today - next: true, the next one. */
  setTimeOfDay(when: 'sunrise' | 'day' | 'noon' | 'sunset' | 'night' | 'midnight' | number, next?: boolean): void;
  /** 0 peaceful, 1 easy, 2 normal, 3 hard, 4 brutal - the host's own setting. Brutal: Hard and more
   *  (the brutal* game rules - monsters dig, skeletons back off, short creeper fuses...). Fires "difficulty". */
  difficulty(): Promise<number>;
  setDifficulty(level: number | 'peaceful' | 'easy' | 'normal' | 'hard' | 'brutal'): void;
  /** A game rule's value (see GameRules); undefined for a name there's no rule for. */
  gameRule<K extends keyof GameRules>(name: K): Promise<GameRules[K]>;
  gameRule(name: string): Promise<any>;
  /** Every game rule: its value, default and what it does. */
  gameRules(): Promise<{ [name: string]: { value: any; default: any; description: string } }>;
  /** Change a game rule (fitted to it: a number kept in its range); null puts the default back.
   *  For this session - set it on "start". A joined device's scripts may only as an operator. */
  setGameRule<K extends keyof GameRules>(name: K, value: GameRules[K] | null): void;
  setGameRule(name: string, value: any): void;
  /** The world's bot (one per world, /bot spawn), or null: its name, who it works for, where it
   *  is, health / food, the job it's on ("" idle) and how many more are queued. */
  bot(): Promise<BotInfo | null>;
  /** A /bot command as the server (the part after "/bot": "get 64 planks", "come", "stop"...).
   *  As the server it has no player to come to / deliver to - it serves its last owner. A joined
   *  device's scripts may only as an operator. */
  botCommand(line: string): Promise<{ ok: boolean; msg: string }>;
  /** What the bot knows about where it is - the same questions its chat brain asks, so a mod can
   *  read the world through the bot's eyes, or write a brain of its own. Every answer carries
   *  both fields AND ready-made English in `words`, because an answer about where you are is
   *  worth nothing as a row of coordinates. `of` is the player the directions are worked out
   *  from - their position and which way they are looking - and defaults to whoever the bot
   *  works for. Game rule botSense off, or no bot in the world: {ok: false, msg}.
   *  botSense: the whole scene (radius 4..48 blocks, 20 by default). */
  botSense(of?: string, radius?: number): Promise<BotSense>;
  /** The nearest <what>, a route the bot could really walk to it, and whether `of` is facing it.
   *  <what> is said in plain words: "village", "water", "lava", "a cave", "the way out", "back"
   *  (the way it came), "spawn", "my mine", "diamonds", "iron", "a chest", "a bed", "a monster",
   *  "an animal", a player's name, or any block by its name - a mod's blocks included. */
  botFind(what: string, of?: string, range?: number): Promise<BotFind>;
  /** What it can see from where it stands: a ray every 30 degrees round, as a horizon. */
  botLook(of?: string): Promise<BotLook>;
  /** How far along a player is - what they carry, what they have made, how long the world has
   *  been going - the reading the brain uses to tell a fair ask from one that hands them the
   *  game. */
  botProgress(of?: string): Promise<BotProgress>;
  /** A tutorial world's walkthrough (a world made by Play Tutorial), or null in any other world. */
  tutorial(): Promise<TutorialInfo | null>;
  /** Skip the tutorial's main part, as answering "ready to play on your own" does: the spawn area
   *  opens, time runs, monsters come. false: no main part running. A joined device's scripts may
   *  only as an operator. */
  tutorialSkip(): Promise<boolean>;
  /** The sky's colour where the world is now, "#rrggbb" - its daytime colour (the biome's,
   *  a mod biome's own "sky_color", or setSkyColor's), before night and weather darken it. */
  skyColor(): Promise<string>;
  /** The whole sky this colour - every biome and dimension, for everyone in the world (night and
   *  weather still darken it); null gives the sky back. Fires "sky". Lasts the session (set it on
   *  "start"). A joined player's scripts need op. */
  setSkyColor(color: string | number | null): void;
  /** A sound everyone nearby hears, e.g. "random.pop". */
  sound(name: string, x: number, y: number, z: number, volume?: number, pitch?: number): void;
  /** What's in a container (chest, furnace, dispenser, hopper...), slot by slot; null if there's none. */
  container(x: number, y: number, z: number): Promise<(ItemStack | null)[] | null>;
  /** Put items in one slot of a container (item null: empty it). */
  setSlot(x: number, y: number, z: number, slot: number, item: Name | ItemStack | null, count?: number, data?: number): void;
  /** Fill a container from a loot table ("chests/hut" for your own loot_tables/chests/hut.json,
   *  "<mod>:<path>", or the game's: "minecraft:chests/simple_dungeon"...). */
  fillLoot(x: number, y: number, z: number, table: string): void;
  /** Drop a loot table's items there. */
  dropLoot(x: number, y: number, z: number, table: string): void;
  /** Roll a loot table without placing anything. */
  rollLoot(table: string): Promise<ItemStack[]>;
  /** Build one of the mods' worldgen structures with its lowest north-west corner here
   *  ("<name>" for your own worldgen/<name>.json); rotation 0-3 quarters (default: random if it turns). */
  placeStructure(name: string, x: number, y: number, z: number, rotation?: number): void;
  /** A creature: "<name>" (your mod's mobs/<name>.json, or the game's: "pig"), "<mod>:<name>"
   *  or "minecraft:pig". A Promise of its entity id (0 if it couldn't be made). */
  spawnEntity(type: string, x: number, y: number, z: number): Promise<number>;

  // --- creatures (a player, or any creature's id, works in all of these) ---
  /** Every creature, those of one type ("zombie", "minecraft:zombie", "<mod>:<name>"), or
   *  those near a point (radius 16 unless given). */
  entities(filter?: string | { type?: string; x?: number; y?: number; z?: number; radius?: number; limit?: number }): Promise<Creature[]>;
  /** One creature in detail; null if it's gone. */
  entity(id: number | Player | Creature): Promise<CreatureDetail | null>;
  /** Put it there (yaw / pitch in degrees, optional). */
  moveEntity(id: number | Player | Creature, x: number, y: number, z: number, yaw?: number, pitch?: number): void;
  /** Add to its motion (blocks per tick; 0.4 up is about a jump). */
  pushEntity(id: number | Player | Creature, dx: number, dy: number, dz: number): void;
  damageEntity(id: number | Player | Creature, amount: number, source?: number | Player | Creature): void;
  healEntity(id: number | Player | Creature, amount: number): void;
  /** Effects: speed, slowness, haste, mining_fatigue, strength, instant_health, instant_damage,
   *  jump_boost, nausea, regeneration, resistance, fire_resistance, water_breathing,
   *  invisibility, blindness, night_vision, hunger, weakness, poison, wither. */
  addEffect(id: number | Player | Creature, effect: string, seconds?: number, level?: number): void;
  /** One effect, or (none given) all of them. */
  removeEffect(id: number | Player | Creature, effect?: string): void;
  /** Seconds (default 8); 0 puts it out. */
  setOnFire(id: number | Player | Creature, seconds?: number): void;
  /** A mod creature's model part(s) shown / hidden on this one creature (its mobs/<name>.json
   *  "hidden_parts" start hidden). Kept with the creature, seen by every player. */
  setPartVisible(id: number | Creature, part: string | string[], visible: boolean): void;
  /** A mod creature's picture on this one creature: n (1..) of its mobs/<name>.json "textures",
   *  0 its "texture". Kept with the creature (saved), seen by every player. */
  setMobTexture(id: number | Creature, n: number): void;
  /** Who a creature goes for (null: nobody). */
  setTarget(id: number | Creature, target: number | Player | Creature | null): void;
  /** Walk there, if it can find a way (up to 32 blocks). */
  walkTo(id: number | Creature, x: number, y: number, z: number): void;
  /** Everyone goes to a dimension - a mod's (dimensions/<name>.json: "<name>" or
   *  "<mod>:<name>") or "overworld" - as through a portal. Game rule modDimensionTravel. */
  travel(dimension: string): void;
  /** Every dimension: the game's (overworld 0, nether -1, end 1) and mods' (ids 2-98) - the
   *  numbers events and players' "dim" use. */
  dimensions(): { id: number; key: string; name: string }[];
  /** The world's type: "default", or a mod's own ("<mod>:<name>" - worldtypes/<name>.json; a
   *  Java mod's WorldType, like Biomes O' Plenty's "biomesoplenty:biomesop"). */
  worldType(): Promise<string>;
  /** The world height: 128, or 256 in a tall world ("Tall World" on the create screen) and in a
   *  dimension that asks for it (dimensions/<name>.json "height", a 1.5.2 / 1.6.4 Java mod's).
   *  Blocks are y 0 .. height - 1. Dimensions of one world can differ: ask again after "dimension". */
  height(): Promise<number>;
  /** Gone, without drops (never a player). */
  removeEntity(id: number | Creature): void;
  /** Today's moon (moons.json; "" an ordinary one), the moon up right now (its night), whether
   *  it's night, whether monsters are frenzied, and the day. */
  moon(): Promise<{ moon: string; up: string; night: boolean; frenzied: boolean; day: number }>;
  /** Farmland there fertile (crops grow faster) - false: not any more. */
  setFertilized(x: number, y: number, z: number, on?: boolean): void;

  // --- the goal AI (creature JSON "goals" / "targets") ---
  /** Add a goal ("wander", "melee", "tempt"... Java's "EntityAIWander", or a defineGoal one) to a
   *  creature. A Promise of its handle (0: refused - the log says why). */
  addGoal(id: number | Creature, priority: number, goal: string, params?: GoalParams): Promise<number>;
  /** The same in its target list ("hurt_by", "nearest"...). */
  addTarget(id: number | Creature, priority: number, goal: string, params?: GoalParams): Promise<number>;
  /** Take one off: its handle, or the goal's name. */
  removeGoal(id: number | Creature, which: number | string): void;
  removeTarget(id: number | Creature, which: number | string): void;
  /** Its goals and targets; null if it's gone. */
  goals(id: number | Creature): Promise<GoalInfo[] | null>;
  /** A kind's own lists from now on ("zombie", "<mod>:<name>"), as its JSON "goals" would - a list
   *  left out stays as it is. */
  setCreatureGoals(type: string, spec: { goals?: GoalSpec[]; targets?: GoalSpec[] }): void;
  /** A goal of this mod ("<mod id>:<name>", returned) - give it with addGoal or a creature's
   *  "goals". g is that goal on that creature (keep state in it; g.params: what it was added with).
   *  canUse is asked only when it could start; the callbacks run a tick behind the game. One that
   *  throws 3 times is removed. */
  defineGoal(name: string, spec: GoalDefinition): string;
  /** Walk there (speed: a factor, 1 its own). */
  mobMoveTo(id: number | Creature, x: number, y: number, z: number, speed?: number): void;
  mobMoveToEntity(id: number | Creature, target: number | Player | Creature, speed?: number): void;
  /** Stop walking. */
  mobStop(id: number | Creature): void;
  /** Look at a spot, or at a creature / player. */
  mobLookAt(id: number | Creature, x: number, y: number, z: number, yawSpeed?: number, pitchSpeed?: number): void;
  mobLookAt(id: number | Creature, target: number | Player | Creature, yawSpeed?: number, pitchSpeed?: number): void;
  mobJump(id: number | Creature): void;
  /** Where it stays near (move_towards_restriction); radius left out: its own. */
  setHome(id: number | Creature, x: number, y: number, z: number, radius?: number): void;
  setMoveSpeed(id: number | Creature, speed: number): void;
  /** How far (blocks) it notices things. */
  setFollowRange(id: number | Creature, blocks: number): void;
  /** How it finds its way; what's left out stays. */
  setNavigation(id: number | Creature, nav: { avoidWater?: boolean; breakDoors?: boolean; enterDoors?: boolean; swim?: boolean }): void;

  /** Particles everyone nearby sees: flame, smoke, large_smoke, heart, crit, enchanted_hit,
   *  portal, explosion, large_explosion, huge_explosion, lava, splash, bubble, dust, effect,
   *  entity_effect, enchant, angry_villager, happy_villager, snowball, slime, item, block. */
  particle(name: string, x: number, y: number, z: number, options?: {
    count?: number; spread?: number | [number, number, number]; speed?: number;
    /** dust / effect / entity_effect: "#ff8800", 0xff8800 or [r, g, b] */
    color?: string | number | [number, number, number];
    /** "item" / "block" particles: which */
    item?: Name; block?: Name;
  }): void;

  // --- commands and command blocks ---
  /** A chat command run as the server (an operator, no player): the game's, Java mods' and scripts'. */
  runCommand(text: string): Promise<{ ok: boolean; output: string }>;
  /** The command block there: null when there is none. */
  commandBlock(x: number, y: number, z: number): Promise<{ command: string; output: string; success: number } | null>;
  /** Its command. */
  setCommandBlock(x: number, y: number, z: number, command: string): void;
  /** Run it now, as if powered. */
  runCommandBlock(x: number, y: number, z: number): void;

  // --- jukeboxes (the game's block 84; a disc is an item with "record") ---
  /** The disc in the jukebox there: null when it's empty, false when there's no jukebox. */
  jukebox(x: number, y: number, z: number): Promise<(ItemStack & { sound: string }) | null | false>;
  /** Put a disc in (it plays for everyone nearby; a disc already in is replaced, not dropped), or
   *  null: take it out (gone). */
  setJukebox(x: number, y: number, z: number, disc: Name | ItemStack | null, data?: number): void;
  /** A disc's music at a spot, no jukebox needed (Java's world.playRecord); stopRecord ends it. */
  playRecord(x: number, y: number, z: number, disc: Name | ItemStack): void;
  stopRecord(x: number, y: number, z: number): void;

  // --- monster spawners (the game's block 52) ---
  /** The spawner there: its mob ("Zombie", a mod creature "<mod>:<name>") and timing; null if there's no spawner. */
  spawner(x: number, y: number, z: number): Promise<SpawnerInfo | null>;
  /** Set a spawner's mob ("zombie", "minecraft:cave_spider", Java's "CaveSpider", a mod creature
   *  "<mod>:<name>"; null keeps it) and any of its numbers. Saved with the world. */
  setSpawner(x: number, y: number, z: number, mob: string | null, opts?: Partial<Omit<SpawnerInfo, 'mob' | 'delay'>>): void;

  // --- signs, and data kept on a block ---
  /** A sign's 4 lines; null if there's no sign there. */
  signText(x: number, y: number, z: number): Promise<string[] | null>;
  /** Up to 4 lines of up to 15 letters (an array, or one string with \n). */
  setSignText(x: number, y: number, z: number, lines: string[] | string): void;
  /** What your mod kept on the block there (undefined: nothing, or the block changed). */
  getBlockData(x: number, y: number, z: number): Promise<any>;
  /** Keep a value (anything JSON) on the block there, saved with the world and dropped when
   *  the block is broken or replaced; null removes it. A Promise of whether it was kept
   *  (false: there's no block there). Where the world is only. */
  setBlockData(x: number, y: number, z: number, value: any): Promise<boolean>;
  /** Rules the game itself enforces from now on (scripts can't stop things in time; rules can).
   *  The same id replaces a set; null removes it. Gone when the scripts stop. */
  setRules(id: string, rules: Rules | null): void;
  /** Change an EXISTING item - the game's own or another mod's - with the keys of
   *  overrides/items/*.json (durability, stack, damage, tool, harvest_level, speed, tier, food,
   *  saturation, wear). null undoes this mod's changes to it. Gone when the scripts stop. */
  setItemProps(name: Name, props: ItemProps | null): void;
  /** Change an existing block (hardness, resistance, tool, harvest_level, hand, drops, loot). */
  setBlockProps(name: Name, props: BlockProps | null): void;
  /** Change an existing kind of creature ("minecraft:zombie", "<mod>:<name>"): health, damage, speed. */
  setMobProps(name: string, props: MobProps | null): void;
}

/** overrides/items/*.json, world.setItemProps. Only what's given changes. */
interface ItemProps {
  durability?: number; stack?: number;
  /** Attack damage. */
  damage?: number;
  /** What kind of tool it is: "none" makes a tool an ordinary item. */
  tool?: 'pickaxe' | 'axe' | 'shovel' | 'hoe' | 'sword' | 'shears' | 'none';
  /** The blocks' "harvest_level" it can harvest (wood / gold 0, stone 1, iron 2, diamond 3). */
  harvest_level?: number;
  /** How fast it mines what it's for. */
  speed?: number;
  /** A tier's level, speed and durability: wood, stone, iron, diamond, gold or a tiers/*.json one. */
  tier?: string;
  food?: number; saturation?: number;
  /** Durability a mined block / a hit costs, plus per_hardness x the block's hardness per block. */
  wear?: { mine?: number; hit?: number; per_hardness?: number };
  /** Its name ("minecraft:red_flower:5" as the name: just that variant). */
  name?: string;
  /** What it leaves when used up (a bowl, a bottle); crafting with it leaves craft_returns in the grid. */
  returns?: Name; craft_returns?: Name;
  /** Used looking at water, it becomes fills.water. */
  fills?: { water: Name };
  /** "water": wets farmland and puts out fire, then becomes its "returns". */
  liquid?: 'water';
  /** Drunk, not eaten; "clears_effects": and ends every effect. */
  drink?: boolean | 'clears_effects';
  /** Turns into that item in water. */
  in_water?: Name;
  /** Puts that block in front of the face it's used on (a spark). */
  places?: Name;
  /** Right-click blocks hits as a sword does; block_wear: durability per damage blocked. */
  blocks?: boolean; block_wear?: number;
  /** Lying in fire it turns into this. */
  cooks_in_fire?: Name;
  /** Experience for each one taken out of a furnace. */
  smelt_xp?: number;
  /** Extra reach while held (on the blocks it's made for and creatures; applies_to "all": every block). */
  reach?: number | { bonus: number; applies_to?: 'all' | 'effective' };
  /** How sugary it is (an apple 1000) - the eat event's e.sugar, a player's sugarPenalty. */
  sugar?: number;
  /** Right-clicking soil tills it like a hoe. */
  tills?: boolean;
  /** Blocks it's made for: breaking them costs cut_wear instead of its usual wear. */
  cuts?: Name | Name[]; cut_wear?: number;
  /** In the anvil with an enchanted item, takes the enchantments off. */
  strips_enchantments?: boolean;
  /** Armour: the share (0-1) of screen dimming it keeps off. */
  dim_resist?: number;
  /** Skills crafting it needs: "masonry", "a+b" (both), or a list (any one). */
  craft_skills?: string | Array<string | string[]>;
  /** Damage / corrosion tags ("silver", "acid_proof"...). */
  tags?: string[];
  throwable?: boolean | { damage?: number; speed?: number; gravity?: number };
  ranged?: { ammo?: Name | 'arrows'; power?: number; durability?: number };
  pull?: Name[] | { [arrow: string]: Name[] };
  /** The saturation eating it adds, as an amount (in place of food x saturation x 2); with food 0 it only fills the buffer. */
  satiation?: number;
  /** A game item that isn't food is eaten with its food / satiation (seeds, sugar); always_edible: on a full bar too. */
  edible?: boolean; always_edible?: boolean;
  /** Eaten on a plain click; its own use only while sneaking (an egg). */
  eat_first?: boolean;
  /** Rolled on eating it, in place of the game's own food effect ([]: none). */
  eat_effects?: Array<string | { effect: string; seconds?: number; level?: number; chance?: number }>;
  /** An empty bucket: the chance it melts when filled with lava. */
  lava_melt_chance?: number;
  /** What it smelts into by the fire's heat (the hottest entry not above it). */
  smelt_by_heat?: Array<{ heat: number; result: Name; count?: number }>;
}
/** overrides/blocks/*.json, world.setBlockProps. */
interface BlockProps {
  hardness?: number; resistance?: number;
  /** The tool that's fast on it (and, with harvest_level / hand, the one needed). */
  tool?: 'pickaxe' | 'axe' | 'shovel' | 'hoe' | 'sword' | 'shears' | 'none' | string | string[];
  /** The tool's level needed for it to drop anything. */
  harvest_level?: number;
  /** Without the right tool: "drop" (drops anyway), "nodrop" (breaks, drops nothing), "never" (can't be broken). */
  hand?: 'drop' | 'nodrop' | 'never';
  /** Same as hand: "nodrop". */
  requires_tool?: boolean;
  /** "none", "self", an item, or a list of {item, count, chance}: chances roll in order and the first
   *  that comes up drops (later ones are what's left - "10% flint, else gravel"). */
  drops?: 'none' | 'self' | Name | DropEntry[];
  /** What an explosion leaves of it instead (same form as drops). */
  explosion_drops?: 'none' | 'self' | Name | DropEntry[];
  /** A loot table (loot_tables/) it drops from instead. */
  loot?: string;
  /** A crop: blights now and then into a block per growth stage, which spreads and dies; bone meal cures it. */
  blight?: { chance?: number; blighted: Name | Name[]; dead?: Name | Name[] } | false;
  /** 0-1: landing on it softens a fall. */
  cushion?: number;
  /** A hard landing breaks it ("over_air": only with air under it). */
  breaks_on_landing?: boolean | 'over_air';
  /** Breaks quickly with anything and always drops (true: speed 4). */
  portable?: boolean | number;
  /** Growth ticks really grow it this often; only with this light / in a rainy biome / these biomes. */
  grow_chance?: number; grow_light?: number; grow_needs_rain?: boolean; grow_biomes?: string[];
  /** Outside these biomes it pops off. */
  biomes?: string[];
  /** On dry farmland: no growth, and this chance to die - into dies_to (or it pops off). */
  dry_death?: number; dies_to?: Name;
  light?: number; gravity?: boolean;
  /** Falls when the ground under it goes (game rule groundCollapse). */
  collapses?: boolean;
  /** Now and then a creature comes out on it. */
  spawns?: { creature: string; chance?: number; max?: number; radius?: number; air?: number };
  /** Now and then it drops these by itself. */
  windfall?: { chance: number; drops: DropEntry[] };
  /** Grows only as often as the biome's temperature x this / only under the open sky. */
  grow_warmth?: number; grow_sky?: boolean;
  /** Where it can stay and be placed (it pops off when it can't stay); decoration places it only where it may be placed. */
  plant?: PlantRules;
  /** A block put into its cell shows its break particles. */
  replace_particles?: boolean;
  /** Ticks a "dissolves" creature of each damage type ("pepsin", "acid", your own) takes to eat it -
   *  "instant" / 0, "never" / -1. Not listed: never. */
  dissolve?: { [damageType: string]: number | 'instant' | 'never' };
  /** A block of data `from` with one of `near` within h / v takes data `to` (its joined run too) when it
   *  breaks and, with random_tick, now and then with a player within `player` blocks. */
  data_near?: DataNear | DataNear[];
}
interface DataNear { near: Name | Name[]; h?: number; v?: number; from?: number; to: number; random_tick?: boolean; player?: number; not_dims?: string[]; }
interface PlantRules {
  /** The block under it must be one of these. */
  on?: Name | Name[];
  /** Sky or block light at it, whichever is more (the time of day not counted): [min, max], 0-15. */
  light?: [number, number];
  /** Under the open sky the light doesn't matter. */
  sky_light_ok?: boolean;
  /** false: never under the open sky (a world with a ceiling has none); true: only under it. */
  sky?: boolean;
  /** Biomes it can stay and be placed in / not in (decoration keys: "forest_hills", "<mod>:<biome>"). */
  biomes?: string[]; not_biomes?: string[];
  /** Biomes it can only be placed in (it stays if they change). */
  place_biomes?: string[];
  /** Only placed under the open sky. */
  place_sky?: boolean;
  /** Only placed outdoors (true) / indoors (false). */
  outdoors?: boolean;
  /** Only placed with no air or plant cell round it (3 x 3) open to the sky. */
  no_open_sides?: boolean;
  /** When it can't stay and nobody is within 16 blocks it goes without a drop. */
  vanish?: boolean;
}
/** One drop: entries roll in order and the first whose chance comes up drops; an entry whose
 *  conditions don't hold is skipped. */
type DropEntry = Name | {
  /** "none": a roll that drops nothing. */
  item: Name | 'none' | 'self';
  count?: number | [number, number]; chance?: number;
  /** true: only when a player broke it; false: only when not. */
  player_only?: boolean;
  exploded?: boolean; raining?: boolean;
  /** Only when the block's data has all of these bits / none of them. */
  data_bits?: number; not_data_bits?: number;
  biomes?: string[]; not_biomes?: string[];
};
/** overrides/mobs/*.json, world.setMobProps. */
interface MobProps {
  health?: number;
  /** Melee damage. */
  damage?: number;
  /** A factor on how fast it walks (1.5 = half as fast again). */
  speed?: number;
  /** How far (blocks) a monster notices a player - the game's 16. */
  follow?: number;
  /** Natural armour points, 0-24 (as a player's armour). */
  armor?: number;
  /** Experience it drops. */
  xp?: number;
  /** 0-1: the chance a bare-handed punch at it while it's after you hurts you. */
  back_damage?: number;
}

/** A goal's settings (world.addGoal, creature JSON "goals"); unknown ones are ignored. */
interface GoalParams {
  speed?: number;
  /** Who: "player", "monster", "animal", "zombie", "<mod>:<name>" (or a list). */
  entity?: string | string[];
  distance?: number; range?: number; chance?: number;
  /** tempt: the items it follows. */
  item?: Name; items?: Name[];
  scared?: boolean; longMemory?: boolean;
  /** ranged: ticks between shots, "20,60". */
  /** ranged: "arrow:<item>" shoots that arrow. */
  interval?: string; projectile?: string;
  /** Any goal: runs only while it holds (doesn't hold) one of these - items, or "ranged" / "none" / "any". */
  holding?: Name | Name[]; not_holding?: Name | Name[];
  yd?: number; nearSpeed?: number; minDist?: number; maxDist?: number;
  sight?: boolean; nearbyOnly?: boolean; callHelp?: boolean; closeAfter?: boolean; nocturnal?: boolean;
  /** What it can't share with other running goals: "move,look,jump" or a number. */
  mutex?: string | string[] | number;
  interruptible?: boolean;
  /** avoid_fire / avoid_predators: may swim when there's no dry way (default true). */
  swim?: boolean;
  /** avoid_predators: players count as predators too. */
  players?: boolean;
  [k: string]: any;
}
interface GoalSpec extends GoalParams { goal: string; priority?: number; }
interface GoalInfo { handle: number; id: string; priority: number; running: boolean; target: boolean; mutex: number; origin: number; }
/** The creature a defineGoal callback is about, with its legs and head. */
interface GoalMob extends Creature {
  moveTo(x: number, y: number, z: number, speed?: number): void;
  moveToEntity(e: number | Player | Creature, speed?: number): void;
  stop(): void;
  lookAt(x: number | Player | Creature, y?: number, z?: number): void;
  jump(): void;
  setTarget(e: number | Player | Creature | null): void;
}
interface GoalDefinition {
  mutex?: Array<'move' | 'look' | 'jump'> | 'move' | 'look' | 'jump' | number;
  interruptible?: boolean;
  canUse?(mob: GoalMob, g: { params: { [k: string]: string }; [k: string]: any }): boolean;
  canContinue?(mob: GoalMob, g: { params: { [k: string]: string }; [k: string]: any }): boolean;
  start?(mob: GoalMob, g: { params: { [k: string]: string }; [k: string]: any }): void;
  tick?(mob: GoalMob, g: { params: { [k: string]: string }; [k: string]: any }): void;
  stop?(mob: GoalMob, g: { params: { [k: string]: string }; [k: string]: any }): void;
}
/** players.stats */
interface PlayerStats {
  health: number; maxHealth: number;
  food: number; maxFood: number; saturation: number; exhaustion: number;
  xpLevel: number; xpTotal: number; xpProgress: number;
  /** Food points lost on sugary food, per 1000 of its "sugar". */
  sugarPenalty: number;
  /** Their skills: a bit per skill, in skills.json order. */
  skills: number;
}

/** The game's own features' settings that mods may change (world.gameRule / setGameRule) - Java's
 *  gamerules. New features add theirs here; world.gameRules() lists what this game has. */
interface GameRules {
  /** The day-night cycle runs (off: the time of day stands still). Default true. */
  doDaylightCycle: boolean;
  /** Command blocks run their commands when powered. Default true. */
  commandBlocks: boolean;
  /** Command blocks tell operators what their commands did. Default true. */
  commandBlockOutput: boolean;
  /** A command's result shows in the chat of whoever ran it. Default true. */
  sendCommandFeedback: boolean;
  /** Other operators see an operator's commands, greyed. Default true. */
  logAdminCommands: boolean;
  /** A computer player with no key, mouse or touch input for this long (seconds) is AFK; 0: idling
   *  never counts. Default 60. (Tabbing away, a phone's game in the background and the pause menu
   *  always count.) */
  afkIdleSeconds: number;
  /** A joined player AFK this long (seconds) is disconnected; 0: never. They fade out over this
   *  time (2 minutes when never). Default 120. */
  afkKickSeconds: number;
  /** AFK players fade out. Default true. */
  afkFade: boolean;
  /** Mobs leave AFK players alone (don't target them, give up chasing, slimes don't bite). Default true. */
  afkMobsIgnore: boolean;
  /** Health comes back from a full food bar. Default true. */
  naturalRegeneration: boolean;
  /** Food level needed for health to come back. Default 18. */
  regenFoodLevel: number;
  /** Ticks per point of health that comes back. Default 80. */
  regenTicks: number;
  /** Exhaustion each healed point costs (Java 1.6+: 3). Default 0. */
  regenExhaustion: number;
  /** Every hunger cost (walking, mining, jumping...) multiplied by this. Default 1. */
  hungerScale: number;
  /** Exhaustion every tick, even standing still. Default 0. */
  hungerPerTick: number;
  /** Ticks per starvation hit at an empty food bar. Default 80. */
  starveTicks: number;
  /** The top of every food bar, 1..20 (players.setStats maxFood caps one player lower). Default 20. */
  maxFood: number;
  /** How fast blocks break (0.5 = twice as slow). Default 1. */
  digSpeedScale: number;
  /** Experience points the first level takes; 0 (default): the game's own curve. */
  xpLevelCost: number;
  /** With xpLevelCost: extra points each further level takes (level n costs cost + step x n). Default 0. */
  xpLevelStep: number;
  /** Recipes with a "time" craft this much faster per experience level (0.02 = 2%). Default 0. */
  craftSpeedPerLevel: number;
  /** ...and this much faster per workbench level above the recipe's "station". Default 0. */
  craftSpeedPerStation: number;
  /** Things with a "quality" come out one quality better per this many levels (0: off). Default 0. */
  craftQualityLevels: number;
  /** Right-clicking the crafting result aims a quality higher: experience per tick of crafting time it
   *  costs, doubling each step (0: off). Default 0. */
  craftQualityXp: number;
  /** Fishing: a bite 1 in this many ticks while the hook is in water. Default 500. */
  fishBiteChance: number;
  /** Fishing: fish must live in water nearby and bite best at dawn and dusk. Default false. */
  fishDawnDusk: boolean;
  /** Darkness is pitch black: no light at all where there is none. Default false. */
  trueDarkness: boolean;
  /** Villages only in land made on this day of the world or later (0: always). Default 0. */
  villageMinDay: number;
  /** New villages can appear. Default true. */
  villagesAllowed: boolean;
  /** Desert and jungle temples only this many blocks or more from the world spawn. Default 0. */
  templeMinSpawnDistance: number;
  /** Mineshafts made before this day of the world have no torches. Default 0. */
  mineshaftTorchMinDay: number;
  /** Beds can be lain in at any time (the night is still only skipped in the sleep window). Default false. */
  sleepAnyTime: boolean;
  /** A bed under the open sky can't be slept in. Default false. */
  sleepNeedsRoof: boolean;
  /** The night can only be skipped from this Java time (0-23999; -1: the game's night). Default -1. */
  sleepWindowStart: number;
  /** ...until this one (-1: the game's night). Default -1. */
  sleepWindowEnd: number;
  /** A skipped night runs its hunger and healing tick by tick - the hungry wake up. Default false. */
  sleepSimulate: boolean;
  /** While the night is skipped, 1 in this many ticks a monster near a bed wakes its sleeper (0: never). Default 0. */
  sleepMobWakeChance: number;
  /** Healing from food runs this many times faster in bed. Default 1. */
  bedRegenMultiplier: number;
  /** A skipped night at least this many ticks long ends the sleepers' effects (0: never). Default 0. */
  sleepClearsEffects: number;
  /** How far blocks can be reached (0: the game's 5); held items add their "reach". Default 0. */
  blockReach: number;
  /** How far creatures can be hit (0: the game's); held items add their "reach". Default 0. */
  attackReach: number;
  /** How far creatures can be used (0: the game's). Default 0. */
  interactReach: number;
  /** Reach for everything in creative (0: the game's). Default 0. */
  creativeReach: number;
  /** Crafting that takes time stops with an empty food bar. Default false. */
  craftNeedsFood: boolean;
  /** Crafting that takes time stops while caught in cobweb. Default false. */
  craftBlockedInWeb: boolean;
  /** Mods' skills (skills.json) count: recipes that need one only for players who learned it. Default false. */
  skillsEnabled: boolean;
  /** Learning a skill costs this many levels x (skills already known + 1). Default 5. */
  skillCostLevels: number;
  /** Skills that can be learned a day (0: any number). Default 1. */
  skillsPerDay: number;
  /** Blocks that "collapse" fall when the ground under them goes. Default true. */
  groundCollapse: boolean;
  /** Screen dimming fades this much a tick. Default 0.01. */
  screenDimDecay: number;
  /** The darkest screen dimming gets (0-1). Default 0.9. */
  screenDimMax: number;
  /** Mods' moons (moons.json) take effect. Default true. */
  moons: boolean;
  /** Creatures may change blocks: dig, break doors, put out torches. Default true. */
  mobGriefing: boolean;
  /** Stack size of items / blocks that don't choose one (0: 64). Default 0. */
  defaultItemStack: number; defaultBlockStack: number;
  /** Blocks you can fall without getting hurt. Default 3. */
  fallSafeDistance: number;
  /** Fall damage per block fallen past that. Default 1. */
  fallDamageScale: number;
  /** Bone meal grows plants at once. Default true. */
  boneMealGrows: boolean;
  /** Bone meal on grass grows tall grass and flowers. Default true. */
  boneMealSpreadsGrass: boolean;
  /** Walking / mining speed with an empty food bar and no saturation. Default 1. */
  noFoodWalkScale: number; noFoodDigScale: number;
  /** Extra mining speed / melee damage per experience level (0.02 = 2%). Default 0. */
  digSpeedPerLevel: number; meleePerLevel: number;
  /** The block id lava flowing down onto water makes (0: none). Default 0. */
  lavaOverWaterBlock: number;
  /** Ores give experience when mined. Default true. */
  oreXp: boolean;
  /** A pile of food that cooks in fire ("cooks_in_fire") can put the fire out. Default false. */
  foodSmothersFire: boolean;
  /** The chance a bare-handed punch at a creature after you hurts you. Default 0. */
  bareHandBackDamage: number;
  /** Melee damage with an empty food bar and no saturation, players included (0: none). Default 1. */
  noFoodMeleeScale: number;
  /** Block reach is measured from this far below the eye (0: the eye). Default 0. */ blockReachDrop: number;
  /** ... or from this far below it, whichever is nearer (-1: one point only). Default -1. */ blockReachDrop2: number;
  /** Block reach is measured to the block's centre instead of the point looked at. Default false. */ blockReachToCenter: boolean;
  /** How creatures see: 0 the game's own, 1 through glass and fences, plants half block the view. Default 0. */ mobVision: number;
  /** How creatures find their way: 0 the game's own, 1 longer drops while chasing, no cactus, open gates. Default 0. */ mobPathfinding: number;
  /** "always" or "modifier" (only while sneaking): filling a bucket takes the source. Default "always". */ bucketFillTakesSource: string;
  /** "always" or "modifier" (sneaking with bucketPourSourceXp): emptying a bucket makes a source. Default "always". */ bucketPourSource: string;
  /** Total experience points a source pour needs ("modifier"). Default 0. */ bucketPourSourceXp: number;
  /** Experience points each source pour costs ("modifier"). Default 0. */ bucketPourSourceXpCost: number;
  /** Ticks a non-source pour flows before it drains. Default 16. */ bucketPourFlowTicks: number;
  /** Pouring a bucket into the liquid it holds only empties it (not in creative). Default false. */ bucketPourIntoSame: boolean;
  /** In creative, filling a bucket takes the liquid and leaves the bucket empty. Default false. */ bucketCreativeKeepsEmpty: boolean;
  /** Exhaustion a jump / a sprinting jump costs (4 = one food point). Defaults 0.2 / 0.8. */ hungerJump: number; hungerSprintJump: number;
  /** Exhaustion per block walked / sprinted / swum / climbed up. Defaults 0.01 / 0.1 / 0.015 / 0. */ hungerWalk: number; hungerSprint: number; hungerSwim: number; hungerClimb: number;
  /** Exhaustion per tick holding jump in water or lava / rowing a boat. Defaults 0. */ hungerSwimUp: number; hungerRow: number;
  /** Exhaustion a block broken / per tick of digging (actions). Defaults 0.025 / 0. */ hungerBreak: number; hungerDigTick: number;
  /** Placing / tilling costs the block's hardness (up to hungerHardnessCap, 20) times this (actions). Defaults 0. */ hungerPlaceHardness: number; hungerTillHardness: number; hungerHardnessCap: number;
  /** Exhaustion a landed melee hit (action) / damage taken costs. Defaults 0.3 / 0.3. */ hungerAttack: number; hungerHurt: number;
  /** Exhaustion throwing a "throwable" item / per tick drawing a bow (actions). Defaults 0. */ hungerThrow: number; hungerDrawTick: number;
  /** Creatures (not players, not the undead) heal by themselves every this many ticks (0: never). Default 0. */ mobRegenTicks: number;
  /** The share of its health a creature gets back each time. Default 0.1. */ mobRegenFraction: number;
  /** A heart shows over a creature whenever it heals (sparks over an iron golem). Default false. */ healParticles: boolean;
  /** Sprinting needs more food than this (-1: any food energy at all). Default 6. */ sprintMinFood: number;
  /** The crafting grid shows faded items where the rest of a recipe goes. Default true. */ craftGhosts: boolean;
  /** No monster spawns near a player with more than this many within 32 blocks (0: off). Default 0. */ hostileNearCap: number;
  /** That cap grows by this many times itself per 32 blocks below y 64. Default 0. */ hostileNearCapDeep: number;
  /** x this at night under a frenzy moon. Default 1. */ hostileNearCapMoon: number;
  /** At night under a full moon at least the cap x this. Default 1. */ hostileNearCapFullMoon: number;
  /** An item burnt up in lava puffs smoke and hisses. Default false. */ itemLavaSmoke: boolean;
  /** Offers Settings > Auto Harvest (hands-free mining / eating; a long press on touch). Default false. */ autoHarvestAvailable: boolean;
  /** Saturation can fill up to the food limit, not just the food level. Default false. */ saturationToMaxFood: boolean;
  /** This share of hungerPerTick builds up apart; at a food unit the next point comes off the bar. Default 0. */ nutritionOnlyHunger: number;
  /** Eating follows the two pools: with saturation room a food giving saturation is eaten on a full bar. Default false. */ eatByFoodPools: boolean;
  /** Spots a grass block tries each random tick to spread onto dirt or let trampled grass recover (MITE 4). Default 1. */ grassSpreadTries: number;
  /** Tutorial worlds show the console tutorial's walkthrough and hints (false: just the world). Default true. */
  tutorialHints: boolean;
  /** In a tutorial world the walled spawn area can't be left before the main tutorial is done or skipped. Default true. */
  tutorialAreaGate: boolean;
  /** Tutorial worlds have hunger and sprinting, and the walkthrough teaches them (sprint, food bar, eat the steak); false: the original TU3 rules, neither. Default true. */
  tutorialHunger: boolean;
  /** On Brutal, monsters hunting a player break the blocks in their way a bare hand can break (dirt, sand, gravel, wood, leaves...). Default true. */
  brutalDigging: boolean;
  /** On Brutal, ticks a monster takes per point of a block's hardness to break it - three spaced hits (a player's bare hand: 30). Default 60. */
  brutalDigTime: number;
  /** On Brutal, a skeleton backs away from a player closer than this many blocks, still shooting (0: never). Default 10. */
  brutalSkeletonRetreat: number;
  /** On Brutal, a skeleton with its bow out walks at this multiple of its usual pace - backing off and closing in
   *  alike. Default 1.4. */
  brutalSkeletonSpeed: number;
  /** On Brutal, a skeleton backing away from a player keeps facing them and treads backwards, bow still on them;
   *  false: it turns and runs. Default true. */
  brutalSkeletonFace: boolean;
  /** On Brutal, ticks a lit creeper takes to explode (other difficulties: 30). Default 20. */
  brutalCreeperFuse: number;
  /** On Brutal, creatures' damage to players is multiplied by this (Hard: 1.5). Default 2. */
  brutalDamage: number;
  /** On Brutal, how far a skeleton's arrows stray (Hard 2, Normal 6, Easy 10). Default 0. */
  brutalArrowSpread: number;
  /** On Brutal, the hits from a player (melee or their arrows) that kill a creeper - also a mod's creeper, and any
   *  creature with "brutal_hits": "creeper" (0: its usual health). Default 2. */
  brutalCreeperHits: number;
  /** On Brutal, the hits from a player that kill a skeleton - also a mod's skeleton, and any creature with
   *  "brutal_hits": "skeleton" (0: its usual health). Default 2. */
  brutalSkeletonHits: number;
  /** On Brutal, how much of the player's armour counts against damage (1: all of it, as other difficulties;
   *  0.6: full diamond stops 48% of a hit instead of 80%). Default 0.6. */
  brutalArmor: number;
  /** On Brutal, everything the player does - walking, fighting, mining, taking a hit - costs this many times the
   *  hunger. Default 1.5. */
  brutalHunger: number;
  /** On Brutal, a food's hidden saturation (how long it holds the bar up) is worth this much of itself. Default 0.5. */
  brutalSaturation: number;
  /** On Brutal, health only comes back with a food bar at least this full (other difficulties: the regenFoodLevel
   *  rule, 18). Default 20. */
  brutalRegenFood: number;
  /** On Brutal, health comes back this many times slower. Default 1.5. */
  brutalRegenSlow: number;
  /** On Brutal, starving on an empty bar bites this many times as often. Default 2. */
  brutalStarveFast: number;
  /** On Brutal, a zombie (and a zombie pigman) walks at this multiple of its usual pace. Default 1.2. */
  brutalZombieSpeed: number;
  /** On Brutal, monsters climb ladders and vines after a player above them (the "climbs" creature trait,
   *  which a mod can give anything). Default true. */
  brutalClimbing: boolean;
  /** On Brutal, ticks a zombie takes to break a door, trapdoor or fence gate down (0: it can't). Default 180. */
  brutalDoorTicks: number;
  /** On Brutal, raw flesh - chicken, beef, pork, fish, rotten flesh - always gives the Hunger effect;
   *  poisonous foods keep their own chances. Default true. */
  brutalRawHunger: boolean;
  /** On Brutal, the percent chance a block of dirt, sand or stone a player mines had a silverfish in it.
   *  Default 0.3. */
  brutalSilverfish: number;
  /** On Brutal, monsters spawn with gear, friends and effects scaled to the players' own armour and best
   *  weapon - a "threat" of 0 (wooden gear) to 1 (full diamond). Default true. */
  brutalScaling: boolean;
  /** On Brutal, the threat below which nothing scales at all, so early gear meets plain Brutal. Default 0.2. */
  brutalScaleStart: number;
  /** On Brutal, the most armour POINTS a monster may spawn wearing - 15 is a full iron set, and diamond is
   *  never given. Default 15. */
  brutalScaleArmor: number;
  /** On Brutal, what a monster's pace reaches at the top of the scaling. Default 1.12. */
  brutalScaleSpeed: number;
  /** On Brutal, what a monster's hit on a player reaches at the top of the scaling, on top of brutalDamage.
   *  Default 1.25. */
  brutalScaleDamage: number;
  /** On Brutal, the chance a piece of a monster's scaled gear drops when a player kills it. Default 0.05. */
  brutalGearDrop: number;
  /** On Brutal, the percent chance at the top of the scaling that a zombie spawns holding a sword or a
   *  pickaxe (a pickaxe lets its digging through stone). Default 60. */
  brutalZombieTools: number;
  /** On Brutal, the percent chance at the top of the scaling that a creeper spawns charged - twice the
   *  blast, and the crackling shell. Default 10. */
  brutalChargedCreepers: number;
  /** On Brutal, the percent chance at the top of the scaling that a zombie a player hits calls one more
   *  zombie in (once each). Default 10. */
  brutalReinforce: number;
  /** On Brutal, spiders can spawn with a potion effect as the scaling climbs, as Java's hard mode. Default true. */
  brutalSpiderEffects: boolean;
  /** On Brutal, extra skeletons that spawn alongside one at the top of the scaling. Default 2. */
  brutalPackSize: number;
  /** On Brutal, a blunt floor under a player's hit: the hits that kill any monster with no count of its own.
   *  Default 0 (off) - a monster's own armour is meant to cost swings, and at 4 a bare fist killed an iron-clad
   *  zombie in four. brutalCreeperHits / brutalSkeletonHits are separate: they are counts for the creature
   *  itself, and whatever it wears then takes its own cut on top. */
  brutalMobHits: number;
  /** With Pre-load Chunks on, the share of time (percent, 0-90) making the rest of a limited world may use while it's
   *  played - it opens with the area round the player and the rest comes in the background (0: paused). Default 30.
   *  Fires "preload" when done. */
  preloadShare: number;
  /** How far, in steps through water, a sponge soaks up water when placed or when water reaches it (0: sponges soak
   *  nothing, as before Java 1.8). Default 6. Fires "sponge". */
  spongeRange: number;
  /** The most water blocks one sponge soaks up. Default 65. */
  spongeLimit: number;
  /** Bots may be used in this world; false turns /bot off (default true). */
  botsAllowed: boolean;
  /** Only operators may command the bot. Default false. */
  botOpsOnly: boolean;
  /** The bot teleports to whoever it follows over long distances. Default true. */
  botTeleport: boolean;
  /** The bot may dig through blocks on its way (off: it walks and bridges only). Default true. */
  botBreakBlocks: boolean;
  /** The bot fights monsters that come at it or at whoever it defends. Default true. */
  botFight: boolean;
  /** The bot picks up items lying near it. Default true. */
  botPickup: boolean;
  /** The bot answers chat lines that name it. Default true. */
  botChat: boolean;
  /** The bot knows its surroundings and can be asked about them (world.botSense and friends,
   *  /bot find, and the material its chat brain is handed). Off, it still takes orders - it just
   *  has nothing to say about where it is. Default true. */
  botSense: boolean;
  /** The bot hands over whatever is asked for without a word. Off (the default) it offers the
   *  least cheaty route to it first - "I'll dig you a shaft to diamond level" rather than a
   *  diamond set - and still does exactly as it is told if you insist. Nothing is ever refused
   *  either way; this only changes what it suggests. Default false. */
  botSpoonfeed: boolean;
  /** Chat tells everyone when a player earns an achievement. Default true. */
  announceAchievements: boolean;
  /** Mods' biomes show their own sky colour ("sky_color", a Java biome's getSkyColorByTemp);
   *  off: the usual sky there. Default true. */
  modSkyColors: boolean;
  /** Mods' liquids (blocks with "liquid") flow and spread; off: they stay as they are. Default true. */
  modLiquidFlow: boolean;
  /** Mods' lava-like liquids with "sets_fire" set flammable blocks around them alight. Default true. */
  modLiquidFire: boolean;
  /** Touch players walking with the stick are softly held at drops - they slide along the rim and
   *  go over if they keep pushing (walking at an edge they're looking at: almost at once). Each
   *  player can also turn it off in Controls > Edge Assist. Default true. */
  edgeAssist: boolean;
  /** How deep (blocks) a drop has to be for Edge Assist; smaller steps are just terrain. Default 3. */
  edgeAssistDrop: number;
  /** How long (seconds) a touch player backing or strafing off an edge is held before they go
   *  over. Default 1. */
  edgeAssistHoldSeconds: number;
  /** The world keeps joined players' inventory, armour, food, experience and spot, and gives them
   *  back when they join again (by their Minecraft account, whatever name they play under). Off:
   *  everyone who joins starts fresh. Default true. */
  keepJoinedPlayers: boolean;
  /** Signed-in players may play under the in-game name they picked on the account screen. A name
   *  that belongs to someone this world knows is never given anyway (they play under their account's
   *  name). Off: everyone plays under their account's name. Default true. */
  allowNicknames: boolean;
  /** A joined player who hears nothing from the host for this long (seconds) leaves with "Lost
   *  connection to the host" (a host whose tab closed or whose phone froze the page). Default 30. */
  hostLostSeconds: number;
  /** How far (blocks) a jukebox's record can be heard; it fades out linearly to there. Read on
   *  each device as the record plays. Default 64 (Java's). */
  jukeboxRange: number;
  /** "Now playing: <disc>" shows above the hotbar when a record starts. Default true. */
  jukeboxNowPlaying: boolean;
  /** Villages, mineshafts, strongholds and temples appear in newly explored parts of the world.
   *  A setting of the world itself: saved with it, kept when scripts stop. Default true. */
  generateStructures: boolean;
  /** How many monsters can be around the players: the cap per 256 chunks of the area round each
   *  player (Java's 70). Java mods that change Java's limits set this world's default. */
  mobCapMonster: number;
  /** The same for animals (Java's 10). */
  mobCapAnimal: number;
  /** The same for squid and other water creatures (Java's 5). */
  mobCapWater: number;
  /** How often each vanilla mob spawns naturally - its share of the spawn picks. The number shown
   *  is normal; 0: it never spawns by itself; each biome's own weight for it scales the same way.
   *  Java mods that change Java's biome spawn weights set this world's defaults. */
  spawnWeightSheep: number; spawnWeightPig: number; spawnWeightChicken: number; spawnWeightCow: number;
  spawnWeightSquid: number; spawnWeightZombie: number; spawnWeightSkeleton: number;
  spawnWeightSpider: number; spawnWeightCreeper: number;
}

/** What a player plays on. */
type Device = 'computer' | 'phone' | 'unknown';

/** What the game refuses (a mod's rules/<name>.json has the same form). */
interface Rules {
  no_break?: Name | Name[]; no_place?: Name | Name[]; no_use?: Name | Name[];
  /** Creatures ("minecraft:player", "<mod>:<name>", "*") a kind of damage doesn't hurt. A plain
   *  string: that cause, for players. */
  no_damage?: string | Array<string | { entity?: string | string[]; cause?: DamageCause }>;
  /** false: players can't hurt players; explosions break nothing; fire doesn't spread. */
  pvp?: boolean; explosions_break_blocks?: boolean; fire_spreads?: boolean;
  explosion_proof?: Name | Name[];
  no_spawn?: string | string[];
  /** What players can't eat / wear (items; "*" any armour - it comes off); no sprinting, no sleeping. */
  no_eat?: Name | Name[]; no_wear?: Name | Name[]; no_sprint?: boolean; no_sleep?: boolean;
  /** Crafting quality judged as if their level were this much higher (negative: lower). */
  craft_levels?: number;
  /** Foods they may eat whenever eating is allowed at all, a full bar or not. */
  always_eat?: Name | Name[];
  /** Only for these players (names). */
  players?: string | string[];
  /** Only inside this box of blocks [x1, y1, z1, x2, y2, z2], and / or this dimension. */
  area?: [number, number, number, number, number, number];
  dimension?: 'overworld' | 'nether' | 'end' | 'any';
  /** Block rules apply to creative players too. */
  creative?: boolean;
  rules?: Rules[];
}
type DamageCause = 'any' | 'fall' | 'fire' | 'lava' | 'drown' | 'explosion' | 'attack' | 'projectile' | 'magic' | 'void' | 'suffocation' | 'other';

interface PlayersApi {
  all(): Promise<Player[]>;
  message(player: Player | number | 'all', text: string): void;
  /** item: a name ("minecraft:wool:14" for a variant) or a stack ({item, data}, e.g. from client.items()). */
  give(player: Player | number, item: Name | ItemStack, count?: number): void;
  /** Negative amounts hurt. */
  heal(player: Player | number, amount: number): void;
  /** Health, food and experience. Where the world is (it holds every player's). */
  stats(player: Player | number): Promise<PlayerStats | null>;
  /** Set any of them: maxHealth / maxFood are this player's own caps (0: the game's), xp is points
   *  added (negative: taken), xpLevel sets the level. */
  setStats(player: Player | number, stats: { health?: number; maxHealth?: number; food?: number; maxFood?: number;
    saturation?: number; exhaustion?: number; xpLevel?: number; xp?: number;
    /** Food points lost on sugary food, per 1000 of its "sugar" (0: none). */
    sugarPenalty?: number;
    /** Screen dimming added (it fades: screenDimDecay, screenDimMax; armour's dim_resist keeps some off). */
    dim?: number;
    /** All their skills at once: a bit per skill, in skills.json order. */
    skills?: number }): void;
  /** Whether skills count (the skillsEnabled rule), the skills they have, and every skill. */
  skills(player: Player | number): Promise<{ on: boolean; skills: string[]; all: { id: string; name: string }[] }>;
  /** Learn one the game's way: it costs levels (skillCostLevels), so many a day (skillsPerDay).
   *  Fires "skill". */
  learnSkill(player: Player | number, id: string): Promise<{ ok: boolean; message: string }>;
  /** A box in the list left of their inventory, above the potion effects; null removes it. Shown on
   *  their own device; saved with that player and shown again when the world or a joined game loads. */
  setStatus(player: Player | number, id: string, status: {
    title: string; text?: string;
    /** On hover: a string ("\n" between lines) or lines. */
    tooltip?: string | string[];
    /** An item name, or an 18 x 18 cell of a 256 x 256 picture in the mod. */
    icon?: Name | { texture: string; u: number; v: number } } | null): void;
  /** Give / take a skill, no cost. */
  addSkill(player: Player | number, id: string): void;
  removeSkill(player: Player | number, id: string): void;
  /** y null: onto the ground there. Never into blocks or off the world. */
  teleport(player: Player | number, x: number, y: number | null, z: number): void;
  /** Everything a player carries: slots 0-8 the hotbar, 9-35 the rest; armour head, chest, legs, feet. */
  inventory(player: Player | number): Promise<{ slots: (ItemStack | null)[]; armor: (ItemStack | null)[]; selected: number } | null>;
  /** Put items in one of a player's slots (0-35, or "head" / "chest" / "legs" / "feet"); item null empties it. */
  setSlot(player: Player | number, slot: number | 'head' | 'chest' | 'legs' | 'feet', item: Name | ItemStack | null, count?: number, data?: number): void;
  /** Take up to count of an item from a player (data: only that variant); how many were taken. */
  take(player: Player | number, item: Name, count?: number, data?: number): Promise<number>;
  /** Empty a player's inventory (armorToo: the armour as well). */
  clear(player: Player | number, armorToo?: boolean): void;
  /** "survival", "creative" or "challenge" (a 404 Challenge world: it stays). */
  gameMode(player: Player | number): Promise<'survival' | 'creative' | 'challenge' | null>;
  /** Their items come along. */
  setGameMode(player: Player | number, mode: 'survival' | 'creative'): void;
  /** An operator? The host always is; the host makes others ones with /op <name> (kept with the world). */
  isOp(player: Player | number): Promise<boolean>;
  /** The same from a script (the host's own scripts, or an operator's). */
  setOp(player: Player | number, on: boolean): void;
  /** What they play on and whether they're AFK (and for how long, in ms). */
  presence(player: Player | number): Promise<{ device: Device; afk: boolean; afkMs: number } | null>;
  /** Mark them AFK (until they're active again) or back (an "/afk" command...). The host's own
   *  scripts, or an operator's. */
  setAfk(player: Player | number, on: boolean): void;
  /** Give them an achievement - the first time only (kept with the world): the "Achievement get!"
   *  popup on their screen, a chat line for everyone (game rule announceAchievements) and the
   *  "achievement" event. The id is this mod's own ("<mod>:<id>" in achievements()); icon: an item. */
  award(player: Player | number, id: string, opts?: { name?: string; description?: string; icon?: Name }): void;
  /** Their achievements in this world, every mod's: {"<mod>:<id>": time earned (ms)}. */
  achievements(player: Player | number): Promise<{ [id: string]: number }>;
}

interface TextElement { type: 'text'; text: string; color?: string; size?: number; align?: 'left' | 'center' | 'right'; bold?: boolean; }
interface ButtonElement {
  type: 'button'; id: string; text: string; color?: string; textColor?: string;
  /** An item ("minecraft:diamond") or a picture in the mod ("textures/gui/coin.png"). */
  icon?: string;
}
/** A picture in the mod, or an item's icon. */
interface ImageElement { type: 'image'; src?: string; item?: Name; width?: number; height?: number; align?: 'left' | 'center' | 'right'; }
/** Elements in columns: up to "columns", fewer when the screen is narrow. */
interface GridElement { type: 'grid'; columns?: number; elements: Element[]; }
/** live: true - a "gui" event with action "input" for every change (a search as you type). */
interface InputElement { type: 'input'; id: string; placeholder?: string; value?: string; live?: boolean; }
interface RowElement { type: 'row'; elements: Element[]; }
interface DividerElement { type: 'divider'; }
/** Item slots the player can move items in and out of. Every change is a "gui" event with
 *  action "slot"; every gui event carries e.slots (what's in each slots element). */
interface SlotsElement {
  type: 'slots'; id: string;
  /** How many slots (default: as many as items), and per row (up to 9). */
  count?: number; columns?: number;
  /** What's in them. Leave it out when updating an open menu to keep what's there. */
  items?: (ItemStack | Name | null)[];
  /** May the player put items in / take them out (default true). put: false = an output slot. */
  put?: boolean; take?: boolean;
  /** Only these items may go in. */
  accept?: Name[];
  /** true: the script looks after what's left when the menu closes. Otherwise it goes back to
   *  the player (from slots they can put into). */
  keep?: boolean;
}
/** The player's own inventory, to move items to and from. */
interface InventoryElement { type: 'inventory'; title?: string; }
type Element = TextElement | ButtonElement | InputElement | RowElement | DividerElement | SlotsElement | InventoryElement | ImageElement | GridElement;

/** How a drawn menu looks (all optional; it still adapts to phones and computers). */
interface MenuStyle {
  /** "#203040", or a picture in the mod ("textures/gui/bg.png"). */
  background?: string;
  backgroundSize?: 'cover' | 'tile';
  border?: string; color?: string; title?: string; accent?: string;
  /** Rounded corners, 0-24. */
  radius?: number;
  font?: 'pixel' | 'sans' | 'serif';
}

interface Menu {
  /** Open a menu again with the same id to update it. */
  id: string;
  /** false: a panel - beside the game instead of over it. No dimmed backdrop, the game keeps the
   *  mouse and keys everywhere else, several can be open at once (one per id). Place it with
   *  position and width / height in CSS pixels - client.on("screen") says where the game's
   *  inventory window is, to dock one beside it. No Close button unless closeButton: true. */
  modal?: boolean;
  /** A panel's place: {left | right, top | bottom} in CSS pixels. */
  position?: { left?: number; right?: number; top?: number; bottom?: number };
  /** A panel kept but out of sight (an html one keeps running); open it again without to show it. */
  hidden?: boolean;
  title?: string;
  /** In pixels, 200-720 (default 380). For an html menu: pixels or "80%". */
  width?: number | string;
  height?: number | string;
  elements?: Element[];
  style?: MenuStyle;
  /** Your own page instead of elements: "gui/shop.html" in the mod. It gets window.mcre and nothing
   *  else - no internet, no game page: data, send(x), on(fn), close(), touch, and
   *    icons(items) -> Promise [{item, data, id, name, max, icon}] (icon: a 32 x 32 picture URL),
   *    asset(path) -> Promise URL of one of the game's pictures ("font/default8.png"),
   *    panel (true for a panel), area(rects | null): only these parts [{x, y, width, height}] of a
   *    panel show and take the mouse - the game gets the rest. A panel hands the game the keys it
   *    doesn't type with (or preventDefault) and the mouse's movement. */
  html?: string;
  /** For an html menu: mcre.data; opening it again with the same id passes new data to mcre.on. */
  data?: any;
  /** false: no Close button (Esc still closes it). */
  closeButton?: boolean;
}

interface GuiApi {
  open(player: Player | number, menu: Menu): void;
  close(player: Player | number): void;
}

interface StorageApi {
  /** Kept with the world, where the world is (a joined device's storage is empty). */
  get(key: string): any;
  set(key: string, value: any): void;
  all(): { [key: string]: any };
}

type ClientEventName = 'start' | 'stop' | 'tick' | 'key' | 'message' | 'gui' | 'dimension' | 'settings'
  /** the game's open screen changed (see ScreenInfo) - also when it moves, or the held stack changes */
  | 'screen'
  /** one of this mod's "key" settings went down / up: e.id, e.down, e.code (Options > Controls lists them) */
  | 'keybind'
  /** a click on a slot of the game's inventory screens: e.area, e.index, e.item, e.button, e.shift */
  | 'slotClick'
  /** Options > Game > Sounds changed on this device: e.style, "old" or "new" */
  | 'soundStyle'
  /** a window shown on one of this mod's displays (client.displayCapture) started / ended: e.id, e.on */
  | 'displayCapture';

/** Where a display's picture lies (client.display). */
interface DisplaySpec {
  /** The block whose face it's on. */
  x: number; y: number; z: number;
  /** Which face: "north", "south", "east", "west", "up", "down" (or the game's side 0-5 in that order). */
  face: string | number;
  /** Blocks to the viewer's right, and up (on a floor / ceiling: towards "top"), from that block. Default 1. */
  width?: number; height?: number;
  /** Blocks left off round the edge, or [sides, top and bottom]. Default 0. */
  margin?: number | [number, number];
  /** A floor or ceiling picture's top: the compass side it points to. Default "north". */
  top?: 'north' | 'south' | 'east' | 'west';
  /** How far in front of the face (blocks; negative: into the block). Default 0.003. */
  offset?: number;
}

/** The game's own screen on this device (client.screen(), client.on("screen")). */
interface ScreenInfo {
  /** "none" (playing), "inventory", "crafting", "chest", "furnace", "container" (dispenser, dropper,
   *  hopper), "creative", "station" (enchanting / anvil / brewing), "trading", "pause", "chat",
   *  "death", "sign", "bed", "menu" (no world), "other". */
  screen: string;
  /** Where an inventory screen draws its window, in CSS pixels; null for other screens. */
  rect: { x: number; y: number; width: number; height: number } | null;
  /** The stack on the cursor of an inventory screen. */
  held: ItemStack | null;
  /** The window's size in CSS pixels, and CSS pixels per GUI pixel (a slot is 18 GUI pixels). */
  width: number; height: number; scale: number;
  /** The screen's close X, in CSS pixels (null: it has none). It is always on top: the game cuts
   *  it out of every mod panel, so lay a panel out round it rather than under it. */
  close?: { x: number; y: number; width: number; height: number } | null;
}

interface KeyEvent extends GameEvent { key: string; code: string; down: boolean; }

interface ClientApi {
  /** This device's own events: "key" {key, code, down}, "tick" {player}, "message" {data}... */
  on(event: ClientEventName, fn: Handler): void;
  /** True where the world is (single player or the host). */
  readonly isHost: boolean;
  /** This device's player. */
  player(): Promise<Player>;
  /** To mod.on("message") where the world is. */
  send(data: any): void;
  /** close(id): that menu or panel; close(): the menu and this mod's panels. */
  gui: { open(menu: Menu): void; close(id?: string): void; };
  /** A sound only this device hears. */
  sound(name: string, volume?: number, pitch?: number): void;
  /** A line in this device's chat. */
  message(text: string): void;
  /** A line of text at the top right; null removes it. */
  hud(id: string, text: string | null): void;
  /** What's open in the game on this device, and where. */
  screen(): Promise<ScreenInfo>;
  /** The game's Controls screen (Options > Controls > Key Bindings), on this mod's keys. */
  openControls(): void;
  /** Options > Game > Sounds on this device: "old" (Better Than Adventure's sounds) or "new" (1.7.10's). */
  soundStyle(): Promise<'old' | 'new'>;
  /** Changes that option itself (saved; the Options screen shows it). "soundStyle" fires. */
  setSoundStyle(style: 'old' | 'new'): void;
  /** The open inventory screen's slots by area, and changing one. */
  screenSlots(): Promise<{ [area: string]: (ItemStack | null)[] } | null>;
  setScreenSlot(area: string, index: number, item: Name | ItemStack | null, count?: number, data?: number): Promise<boolean>;
  /** true: clicks on the game's inventory slots are this mod's ("slotClick" decides). */
  captureSlots(on: boolean): void;
  /** A picture on a block face, drawn in the world on this device; the same id again moves it, null removes it. */
  display(id: string, spec: DisplaySpec | null): void;
  /** Its picture: width x height RGBA bytes, top row first (or an ImageData). False when refused (size 1-2048). */
  displayFrame(id: string, pixels: Uint8Array | Uint8ClampedArray | number[] | ImageData, width?: number, height?: number): boolean;
  /** true: a window / tab / screen the player picks shown live on that display, letterboxed; false: stop.
   *  "displayCapture" fires when it starts or ends. */
  displayCapture(id: string, on?: boolean): void;
  /** A web page (http / https) in a big window of its own, after the player says yes. */
  openUrl(url: string): Promise<boolean>;
  /** A file the player picks from this device (null: none). From a menu button the picker opens at once. */
  pickFile(options?: { title?: string; accept?: string; maxBytes?: number }): Promise<{ name: string; size: number; data: Uint8Array } | null>;
  /** true: this device's keys are this mod's while playing ("key" hears them, the player doesn't move);
   *  Esc always hands them back. */
  captureKeys(on: boolean): void;
  /** What the game knows about an item. */
  itemInfo(item: Name | ItemStack): Promise<{ name: string; max: number; block: boolean; category: string; rarity: string; durability?: number; food?: number; armor?: string; id: number | null } | null>;
  /** The stack on the cursor of an open inventory screen (null: nothing). */
  held(): Promise<ItemStack | null>;
  /** Put a stack on that cursor (null: take it away). False when no inventory screen is open. */
  setHeld(item: Name | ItemStack | null, count?: number, data?: number): Promise<boolean>;
  /** Every block and item the game has - variants and mods' included - in the creative
   *  inventory's order, each a full stack. */
  items(): Promise<ItemStack[]>;
  /** Kept on this device for this mod, in every world (settings a player chose, their favourites...). */
  storage: { get(key: string): any; set(key: string, value: any): void; all(): { [key: string]: any } };
}

declare const mod: ModApi;
declare const world: WorldApi;
declare const players: PlayersApi;
declare const gui: GuiApi;
declare const storage: StorageApi;
declare const client: ClientApi;
/** To the browser console (F12). */
declare function log(...args: any[]): void;

/** world.tutorial(): a tutorial world's walkthrough. active: anything of it still to come (its
 *  sections - the boat, the pistons... - wait for you after the main part); main: the main part
 *  is still running; state: the section it is in (see the "tutorial" event); step: the main track's
 *  current text id ("" when it's done); complete: the main part is over; hunger: the world has
 *  hunger and sprinting (the tutorialHunger game rule). */
interface TutorialInfo {
  active: boolean; main: boolean; state: string; step: string; complete: boolean; hunger: boolean;
}

/** A direction, every way of saying it at once (world.botSense and friends). `relative`,
 *  `clock` and `bearing` are worked out from where the player is standing and which way they
 *  are looking, and are missing when there is nobody to be relative to. */
interface BotDir {
  /** Blocks east, up and south of the thing being described (negative: west, down, north). */
  dx: number; dy: number; dz: number;
  /** Straight-line distance, and the same ignoring height. */
  dist: number; flat: number;
  /** "north-west", "south"... The one thing never to answer a question with on its own. */
  compass: string;
  /** "40 blocks off", "a step or two away". */
  far: string;
  /** "about 15 seconds' walk" - at a walking 4.3 blocks a second. */
  walk: string;
  /** "six blocks below you", "about level with you". */
  height: string;
  /** Degrees off the player's own heading: 0 straight ahead, + to their right. */
  bearing?: number;
  /** "behind you, over your left shoulder". */
  relative?: string;
  /** "your 4 o'clock". */
  clock?: string;
  /** All of the above in one phrase, ready to say. */
  words: string;
}

/** world.botSense(): the whole scene round the bot. */
interface BotSense {
  ok: boolean; msg?: string;
  bot: { name: string; x: number; y: number; z: number; yaw: number; health: number; food: number; carrying: number; task: string };
  /** Whoever the answer is relative to, and where they are from the bot's point of view. */
  asker: { name: string; x: number; y: number; z: number; facing: string; health: number; fromMe: BotDir } | null;
  place: {
    biome: string; y: number; surfaceY: number; depth: number;
    outdoors: boolean; light: number; dark: boolean;
    day: number; night: boolean; raining: boolean;
    /** "the dead of night", "the middle of the day". */
    time: string;
    dimension: string;
    /** "in a narrow passage", "in a big open cavern", "out in the open". */
    room: string;
  };
  /** Every kind of block round it, landmarks and dangers first: how much of it, the nearest one,
   *  and where the bulk of it lies. `key` is the kind ("water", "logs", "diamond"), or a mod
   *  block's own name. */
  around: { what: string; key: string; n: number; nearest: [number, number, number]; dist: number; dir: BotDir }[];
  mobs: { what: string; n: number; hostile: boolean; dir: BotDir }[];
  mine: { has: boolean; x?: number; y?: number; z?: number; floorY?: number; kind?: string; dir?: BotDir };
  /** Where it set out from, if it has walked far enough to have a trail. */
  cameFrom: { x: number; y: number; z: number; dir: BotDir; words: string } | null;
  /** The whole scene in sentences. */
  words: string;
}

/** world.botFind(): the nearest something, and the way there. */
interface BotFind {
  ok: boolean; msg?: string;
  /** What was asked for, and what it settled on ("the nearest village", "the way out into the open"). */
  what: string; label: string;
  found: boolean;
  x?: number; y?: number; z?: number;
  /** From the bot, and from the player the answer is for. */
  fromMe?: BotDir; fromYou?: BotDir;
  /** Is the player pointed at it? "Not quite - swing right about 80 degrees." */
  facing?: { right: boolean; turn: string; degrees: number; words: string } | null;
  /** A village the generator knows from the seed, which the bot has never actually seen. */
  guessedFromTheSeed?: boolean;
  /** The route, in legs the bot could really walk - the bot's own path search, so it digs and
   *  bridges only where the game rules let it. `blocks` is the route's length in cells. */
  route?: {
    reachable: boolean; blocks: number; walk?: string;
    legs: { blocks: number; rise: number; how: string; dir: BotDir; words: string }[];
    words: string;
  };
  /** The answer in sentences - where it is from the player, how far, how long, and what is there. */
  words: string;
}

/** world.botLook(): what the bot can see from where it stands. */
interface BotLook {
  ok: boolean; msg?: string;
  /** One ray every 30 degrees: what it hits, how far off, and whether the sky is that way. */
  rays: { compass: string; relative: string; dist: number; what: string; sky: boolean }[];
  words: string;
}

/** world.botProgress(): how far along a player is. */
interface BotProgress {
  ok: boolean; msg?: string;
  player: string;
  /** Day of the world (its time, not wall-clock), and where the player is. */
  day: number; y: number; health: number; dimension: string;
  slotsUsed: number; armourPieces: number;
  /** 0 nothing, 1 wood or stone, 2 iron or gold, 3 diamond. */
  toolTier: number; armourTier: number;
  hasPickaxe: boolean; hasSword: boolean; hasFurnace: boolean; hasBed: boolean; hasBoat: boolean;
  diamonds: number; iron: number; gold: number; coal: number; logs: number;
  obsidian: number; enderPearls: number; blazeRods: number;
  /** "only just started - a bit of wood and not much else", "well into the diamond age". */
  stage: string;
  words: string;
}

/** world.bot(): the world's bot. */
interface BotInfo {
  name: string; id: number; owner: string;
  x: number; y: number; z: number; dimension: number;
  health: number; food: number;
  task: string; queued: number; carrying: number; creative: number;
}
