// Example Structures - scripts/main.js

// "scripted": true in worldgen/ruin.json: the script hears where each one went.
mod.on('structure', function (e) {
  if (e.name === 'structures_example:ruin') log('A ruin at ' + e.x + ', ' + e.y + ', ' + e.z);
});

// /ruin - build one where you stand.
mod.command('ruin', function (c) {
  world.placeStructure('ruin', Math.floor(c.player.x) - 2, Math.floor(c.player.y) - 1, Math.floor(c.player.z) - 2);
}, { permission: 'op', description: 'build a ruin here' });
