// Example Structures - scripts/main.js

// "scripted": true in worldgen/ruin.json: the script hears where each one went.
mod.on('structure', function (e) {
  if (e.name === 'structures_example:ruin') log('A ruin at ' + e.x + ', ' + e.y + ', ' + e.z);
});

// /ruin - build one where you stand.
mod.command('ruin', function (c) {
  // world.height(): 128, or 256 in a Tall World - kept under the top so the ruin fits.
  world.height().then(function (h) {
    var y = Math.min(Math.floor(c.player.y) - 1, h - 8);
    world.placeStructure('ruin', Math.floor(c.player.x) - 2, y, Math.floor(c.player.z) - 2);
  });
}, { permission: 'op', description: 'build a ruin here' });
