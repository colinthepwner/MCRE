Example Items
=============
items/cheese.json       food ("food": hunger points, or {"hunger", "saturation"}).
items/energy_bar.json   food with an effect, edible even when not hungry.
items/pebble.json       "throwable": thrown like a snowball, it hurts what it hits.
items/slingshot.json    "ranged": drawn like a bow, fires pebbles.
items/wand.json         "scripted": its script (scripts/main.js) decides what it does.
items/lucky_ring.json   "accessory": worn in a ring slot - accessories.json adds two beside the
                        armour; the script greets it going on and off ("accessory" event).
recipes/                how to make them.

The modding guide: https://colinthepwner.github.io/MCRE/modding.html
