// Example Items - scripts/main.js

// The wand ("scripted": true) does nothing by itself: its script decides.
mod.on('useItemOn', function (e) {
  if (e.item !== 'items_example:wand') return;
  world.getBlock(e.x, e.y, e.z).then(function (b) {
    players.message(e.player, b.block + (b.data ? ' (data ' + b.data + ')' : '') + ' at ' + e.x + ', ' + e.y + ', ' + e.z);
  });
});

// A thrown or fired pebble landed.
mod.on('hit', function (e) {
  if (e.item !== 'items_example:pebble') return;
  world.particle('item', e.x, e.y, e.z, { count: 6, item: 'minecraft:cobblestone' });
});
