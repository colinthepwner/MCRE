// Example Items - scripts/main.js

// The wand ("scripted": true) does nothing by itself: its script decides.
mod.on('useItemOn', function (e) {
  if (e.item !== 'items_example:wand') return;
  world.getBlock(e.x, e.y, e.z).then(function (b) {
    players.message(e.player, b.block + (b.data ? ' (data ' + b.data + ')' : '') + ' at ' + e.x + ', ' + e.y + ', ' + e.z);
  });
});

// The lucky ring went on or came off (it sits in one of the two ring slots accessories.json adds).
mod.on('accessory', function (e) {
  if (e.item === 'items_example:lucky_ring') players.message(e.player, 'You feel lucky.');
  else if (e.before === 'items_example:lucky_ring') players.message(e.player, 'Your luck fades.');
});

// A disc went into a jukebox, or came out (world.jukebox / setJukebox / playRecord do it from scripts).
mod.on('jukebox', function (e) {
  if (e.action === 'insert' && e.player) players.message(e.player, 'Spinning ' + e.item + '.');
});

// A thrown or fired pebble landed.
mod.on('hit', function (e) {
  if (e.item !== 'items_example:pebble') return;
  world.particle('item', e.x, e.y, e.z, { count: 6, item: 'minecraft:cobblestone' });
});
