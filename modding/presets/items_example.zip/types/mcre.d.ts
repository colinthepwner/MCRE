// Minecraft RE - mod scripting API, for editors (VS Code and others read this file and complete
// the API as you type). Keep it next to your scripts: this mod's jsconfig.json points the editor
// at types/*.d.ts and scripts/*.js. Nothing here runs - it only describes what the game gives
// every script: mod, world, players, gui, storage, client and log.

/** A block or item: "<mod id>:<name>", "minecraft:<java name>" (e.g. "minecraft:stone"),
 *  "air", or just "<name>" for your own mod's. Add ":<data>" for a variant ("minecraft:wool:14"). */
type Name = string;

/** A player. Pass it (or its id) wherever a player goes. */
interface Player {
  id: number;
  name: string;
  /** Feet position. */
  x: number; y: number; z: number;
  health: number;
}

/** A creature (or other entity) in an event. */
interface Creature {
  id: number;
  /** "minecraft:zombie", "<mod id>:<name>" for a mod's own creature, ... */
  type: string;
  x: number; y: number; z: number;
  health?: number;
  /** Set when the creature is a player. */
  name?: string;
}

/** world.entity(): a creature in detail. */
interface CreatureDetail extends Creature {
  yaw: number; pitch: number;
  motion: [number, number, number];
  onGround: boolean;
  /** Ticks of fire left. */
  fire: number;
  maxHealth?: number;
  /** The creature it's going for (0: none). */
  target?: number;
  effects?: { effect: string; seconds: number; level: number }[];
}

/** Everything an event can carry. Which fields are set depends on the event (see mod.on). */
interface GameEvent {
  /** The event's name. */
  t: string;
  /** A block: its name, data value and position. */
  block?: Name; data?: number; x?: number; y?: number; z?: number;
  /** An item: its name and how many. */
  item?: Name; count?: number;
  /** The face of a block an item was used on (0 down, 1 up, 2 north, 3 south, 4 west, 5 east). */
  face?: number;
  /** Whoever did it. */
  player?: Player;
  /** The creature it happened to, and (hurt / death) what did it. */
  entity?: Creature; source?: Creature | null;
  damage?: number;
  /** "chat" */
  text?: string;
  /** "explode" */
  power?: number;
  /** "weather" */
  raining?: number; thundering?: number;
  /** "dimension": 0 overworld, -1 Nether, 1 End. */
  dimension?: number;
  /** "gametick": the world's time. */
  time?: number;
  /** "structure": which one, how it was turned (0-3, a quarter each) and its size [x, y, z]. */
  name?: string; rotation?: number; size?: [number, number, number];
  /** "gui": the menu's id, the button's id, what happened, the text boxes' values. */
  gui?: string; id?: string; action?: 'click' | 'submit' | 'input' | 'close' | 'slot' | 'message';
  values?: { [inputId: string]: string };
  /** "gui", action "message": what an html menu sent (mcre.send). */
  data?: any;
  /** "gui": what's in the menu's item slots now (see SlotsElement); action "slot": which slot changed. */
  slots?: { [slotsId: string]: (ItemStack | null)[] }; index?: number;
  /** "gui" / "message": the mod it's for. ("message" carries what was sent as e.data.) */
  mod?: string;
}

/** A stack of items. */
interface ItemStack { item: Name; count: number; data?: number; }

/** A world event's handler. Return a Promise if you like; errors are listed with the mod. */
type Handler = (e: GameEvent & { [k: string]: any }) => void | Promise<void>;

type WorldEventName =
  | 'start' | 'stop' | 'dimension' | 'join' | 'leave' | 'respawn'
  | 'use' | 'place' | 'break' | 'step' | 'tick' | 'useItem' | 'useItemOn'
  | 'eat' | 'craft' | 'smelt' | 'attack' | 'interact' | 'hurt' | 'death' | 'spawn'
  | 'chat' | 'explode' | 'weather' | 'gametick' | 'gui' | 'message' | 'structure'
  /** a "throwable" mod item landed: e.item, e.x/y/z, e.entity (what it hit, if anything), e.player */
  | 'hit'
  /** this mod's settings changed (e.values: all of them) */
  | 'settings';

interface CommandContext {
  player: Player;
  /** The words after the command's name. */
  args: string[];
  /** Everything typed, "/name ..." */
  text: string;
  /** Typed by the player whose world it is (single player: always). */
  isHost: boolean;
}

interface CommandOptions {
  /** "host": only the player whose world it is may use it. Default "everyone". */
  permission?: 'everyone' | 'host';
  /** Shown by /help. */
  description?: string;
  /** What follows the name, for /help: "<player> <amount>". */
  usage?: string;
}

interface ModApi {
  /** This mod's id (manifest.json). */
  readonly id: string;
  /** A world event - fires once, where the world is (single player or the host). */
  on(event: WorldEventName, fn: Handler): void;
  /** "/name ..." typed in chat. */
  command(name: string, fn: (c: CommandContext) => void | Promise<void>, options?: CommandOptions): void;
  /** Data to client.on("message") on that player's device ("all": everyone's). */
  send(player: Player | number | 'all', data: any): void;
  /** This device's values of the settings in manifest.json ("settings"). Where the world is,
   *  they're the host's; in client code, that player's own. Changes: on("settings"), e.values. */
  readonly settings: {
    get(id: string): any;
    all(): { [id: string]: any };
    /** Change one (kept, like a change in the Settings dialog; the value is fitted to the setting). */
    set(id: string, value: any): void;
  };
}

interface WorldApi {
  setBlock(x: number, y: number, z: number, block: Name, data?: number): void;
  setData(x: number, y: number, z: number, data: number): void;
  getBlock(x: number, y: number, z: number): Promise<{ block: Name; data: number }>;
  /** A "tick" event for a scripted block, this many game ticks (20 a second) from now. */
  scheduleTick(x: number, y: number, z: number, ticks: number): void;
  spawnItem(x: number, y: number, z: number, item: Name, count?: number): void;
  explode(x: number, y: number, z: number, power?: number, fire?: boolean): void;
  /** The world's time in ticks (a day is 19200; 0 is sunrise). */
  time(): Promise<number>;
  setTime(t: number): void;
  /** Is it raining / thundering? */
  weather(): Promise<{ raining: boolean; thundering: boolean }>;
  /** Clear skies, rain (snow where it's cold) or a thunderstorm - for this many seconds, or (none
   *  given) as long as the game's own weather would last. */
  setWeather(kind: 'clear' | 'rain' | 'thunder', seconds?: number): void;
  /** A sound everyone nearby hears, e.g. "random.pop". */
  sound(name: string, x: number, y: number, z: number, volume?: number, pitch?: number): void;
  /** What's in a container (chest, furnace, dispenser, hopper...), slot by slot; null if there's none. */
  container(x: number, y: number, z: number): Promise<(ItemStack | null)[] | null>;
  /** Put items in one slot of a container (item null: empty it). */
  setSlot(x: number, y: number, z: number, slot: number, item: Name | ItemStack | null, count?: number, data?: number): void;
  /** Fill a container from a loot table ("chests/hut" for your own loot_tables/chests/hut.json,
   *  "<mod>:<path>", or the game's: "minecraft:chests/simple_dungeon"...). */
  fillLoot(x: number, y: number, z: number, table: string): void;
  /** Drop a loot table's items there. */
  dropLoot(x: number, y: number, z: number, table: string): void;
  /** Roll a loot table without placing anything. */
  rollLoot(table: string): Promise<ItemStack[]>;
  /** Build one of the mods' worldgen structures with its lowest north-west corner here
   *  ("<name>" for your own worldgen/<name>.json); rotation 0-3 quarters (default: random if it turns). */
  placeStructure(name: string, x: number, y: number, z: number, rotation?: number): void;
  /** A creature: "<name>" (your mod's mobs/<name>.json, or the game's: "pig"), "<mod>:<name>"
   *  or "minecraft:pig". A Promise of its entity id (0 if it couldn't be made). */
  spawnEntity(type: string, x: number, y: number, z: number): Promise<number>;

  // --- creatures (a player, or any creature's id, works in all of these) ---
  /** Every creature, those of one type ("zombie", "minecraft:zombie", "<mod>:<name>"), or
   *  those near a point (radius 16 unless given). */
  entities(filter?: string | { type?: string; x?: number; y?: number; z?: number; radius?: number; limit?: number }): Promise<Creature[]>;
  /** One creature in detail; null if it's gone. */
  entity(id: number | Player | Creature): Promise<CreatureDetail | null>;
  /** Put it there (yaw / pitch in degrees, optional). */
  moveEntity(id: number | Player | Creature, x: number, y: number, z: number, yaw?: number, pitch?: number): void;
  /** Add to its motion (blocks per tick; 0.4 up is about a jump). */
  pushEntity(id: number | Player | Creature, dx: number, dy: number, dz: number): void;
  damageEntity(id: number | Player | Creature, amount: number, source?: number | Player | Creature): void;
  healEntity(id: number | Player | Creature, amount: number): void;
  /** Effects: speed, slowness, haste, mining_fatigue, strength, instant_health, instant_damage,
   *  jump_boost, nausea, regeneration, resistance, fire_resistance, water_breathing,
   *  invisibility, blindness, night_vision, hunger, weakness, poison, wither. */
  addEffect(id: number | Player | Creature, effect: string, seconds?: number, level?: number): void;
  /** One effect, or (none given) all of them. */
  removeEffect(id: number | Player | Creature, effect?: string): void;
  /** Seconds (default 8); 0 puts it out. */
  setOnFire(id: number | Player | Creature, seconds?: number): void;
  /** Who a creature goes for (null: nobody). */
  setTarget(id: number | Creature, target: number | Player | Creature | null): void;
  /** Walk there, if it can find a way (up to 32 blocks). */
  walkTo(id: number | Creature, x: number, y: number, z: number): void;
  /** Gone, without drops (never a player). */
  removeEntity(id: number | Creature): void;

  /** Particles everyone nearby sees: flame, smoke, large_smoke, heart, crit, enchanted_hit,
   *  portal, explosion, large_explosion, huge_explosion, lava, splash, bubble, dust, effect,
   *  entity_effect, enchant, angry_villager, happy_villager, snowball, slime, item, block. */
  particle(name: string, x: number, y: number, z: number, options?: {
    count?: number; spread?: number | [number, number, number]; speed?: number;
    /** dust / effect / entity_effect: "#ff8800", 0xff8800 or [r, g, b] */
    color?: string | number | [number, number, number];
    /** "item" / "block" particles: which */
    item?: Name; block?: Name;
  }): void;

  // --- signs, and data kept on a block ---
  /** A sign's 4 lines; null if there's no sign there. */
  signText(x: number, y: number, z: number): Promise<string[] | null>;
  /** Up to 4 lines of up to 15 letters (an array, or one string with \n). */
  setSignText(x: number, y: number, z: number, lines: string[] | string): void;
  /** What your mod kept on the block there (undefined: nothing, or the block changed). */
  getBlockData(x: number, y: number, z: number): Promise<any>;
  /** Keep a value (anything JSON) on the block there, saved with the world and dropped when
   *  the block is broken or replaced; null removes it. A Promise of whether it was kept
   *  (false: there's no block there). Where the world is only. */
  setBlockData(x: number, y: number, z: number, value: any): Promise<boolean>;
  /** Rules the game itself enforces from now on (scripts can't stop things in time; rules can).
   *  The same id replaces a set; null removes it. Gone when the scripts stop. */
  setRules(id: string, rules: Rules | null): void;
}

/** What the game refuses (a mod's rules/<name>.json has the same form). */
interface Rules {
  no_break?: Name | Name[]; no_place?: Name | Name[]; no_use?: Name | Name[];
  /** Creatures ("minecraft:player", "<mod>:<name>", "*") a kind of damage doesn't hurt. A plain
   *  string: that cause, for players. */
  no_damage?: string | Array<string | { entity?: string | string[]; cause?: DamageCause }>;
  /** false: players can't hurt players; explosions break nothing; fire doesn't spread. */
  pvp?: boolean; explosions_break_blocks?: boolean; fire_spreads?: boolean;
  explosion_proof?: Name | Name[];
  no_spawn?: string | string[];
  /** Only inside this box of blocks [x1, y1, z1, x2, y2, z2], and / or this dimension. */
  area?: [number, number, number, number, number, number];
  dimension?: 'overworld' | 'nether' | 'end' | 'any';
  /** Block rules apply to creative players too. */
  creative?: boolean;
  rules?: Rules[];
}
type DamageCause = 'any' | 'fall' | 'fire' | 'lava' | 'drown' | 'explosion' | 'attack' | 'projectile' | 'magic' | 'void' | 'suffocation' | 'other';

interface PlayersApi {
  all(): Promise<Player[]>;
  message(player: Player | number | 'all', text: string): void;
  /** item: a name ("minecraft:wool:14" for a variant) or a stack ({item, data}, e.g. from client.items()). */
  give(player: Player | number, item: Name | ItemStack, count?: number): void;
  /** Negative amounts hurt. */
  heal(player: Player | number, amount: number): void;
  /** y null: onto the ground there. Never into blocks or off the world. */
  teleport(player: Player | number, x: number, y: number | null, z: number): void;
  /** Everything a player carries: slots 0-8 the hotbar, 9-35 the rest; armour head, chest, legs, feet. */
  inventory(player: Player | number): Promise<{ slots: (ItemStack | null)[]; armor: (ItemStack | null)[]; selected: number } | null>;
  /** Put items in one of a player's slots (0-35, or "head" / "chest" / "legs" / "feet"); item null empties it. */
  setSlot(player: Player | number, slot: number | 'head' | 'chest' | 'legs' | 'feet', item: Name | ItemStack | null, count?: number, data?: number): void;
  /** Take up to count of an item from a player (data: only that variant); how many were taken. */
  take(player: Player | number, item: Name, count?: number, data?: number): Promise<number>;
  /** Empty a player's inventory (armorToo: the armour as well). */
  clear(player: Player | number, armorToo?: boolean): void;
}

interface TextElement { type: 'text'; text: string; color?: string; size?: number; align?: 'left' | 'center' | 'right'; bold?: boolean; }
interface ButtonElement {
  type: 'button'; id: string; text: string; color?: string; textColor?: string;
  /** An item ("minecraft:diamond") or a picture in the mod ("textures/gui/coin.png"). */
  icon?: string;
}
/** A picture in the mod, or an item's icon. */
interface ImageElement { type: 'image'; src?: string; item?: Name; width?: number; height?: number; align?: 'left' | 'center' | 'right'; }
/** Elements in columns: up to "columns", fewer when the screen is narrow. */
interface GridElement { type: 'grid'; columns?: number; elements: Element[]; }
/** live: true - a "gui" event with action "input" for every change (a search as you type). */
interface InputElement { type: 'input'; id: string; placeholder?: string; value?: string; live?: boolean; }
interface RowElement { type: 'row'; elements: Element[]; }
interface DividerElement { type: 'divider'; }
/** Item slots the player can move items in and out of. Every change is a "gui" event with
 *  action "slot"; every gui event carries e.slots (what's in each slots element). */
interface SlotsElement {
  type: 'slots'; id: string;
  /** How many slots (default: as many as items), and per row (up to 9). */
  count?: number; columns?: number;
  /** What's in them. Leave it out when updating an open menu to keep what's there. */
  items?: (ItemStack | Name | null)[];
  /** May the player put items in / take them out (default true). put: false = an output slot. */
  put?: boolean; take?: boolean;
  /** Only these items may go in. */
  accept?: Name[];
  /** true: the script looks after what's left when the menu closes. Otherwise it goes back to
   *  the player (from slots they can put into). */
  keep?: boolean;
}
/** The player's own inventory, to move items to and from. */
interface InventoryElement { type: 'inventory'; title?: string; }
type Element = TextElement | ButtonElement | InputElement | RowElement | DividerElement | SlotsElement | InventoryElement | ImageElement | GridElement;

/** How a drawn menu looks (all optional; it still adapts to phones and computers). */
interface MenuStyle {
  /** "#203040", or a picture in the mod ("textures/gui/bg.png"). */
  background?: string;
  backgroundSize?: 'cover' | 'tile';
  border?: string; color?: string; title?: string; accent?: string;
  /** Rounded corners, 0-24. */
  radius?: number;
  font?: 'pixel' | 'sans' | 'serif';
}

interface Menu {
  /** Open a menu again with the same id to update it. */
  id: string;
  /** false: a panel - beside the game instead of over it. No dimmed backdrop, the game keeps the
   *  mouse and keys everywhere else, several can be open at once (one per id). Place it with
   *  position and width / height in CSS pixels - client.on("screen") says where the game's
   *  inventory window is, to dock one beside it. No Close button unless closeButton: true. */
  modal?: boolean;
  /** A panel's place: {left | right, top | bottom} in CSS pixels. */
  position?: { left?: number; right?: number; top?: number; bottom?: number };
  /** A panel kept but out of sight (an html one keeps running); open it again without to show it. */
  hidden?: boolean;
  title?: string;
  /** In pixels, 200-720 (default 380). For an html menu: pixels or "80%". */
  width?: number | string;
  height?: number | string;
  elements?: Element[];
  style?: MenuStyle;
  /** Your own page instead of elements: "gui/shop.html" in the mod. It gets window.mcre and nothing
   *  else - no internet, no game page: data, send(x), on(fn), close(), touch, and
   *    icons(items) -> Promise [{item, data, id, name, max, icon}] (icon: a 32 x 32 picture URL),
   *    asset(path) -> Promise URL of one of the game's pictures ("font/default8.png"),
   *    panel (true for a panel), area(rects | null): only these parts [{x, y, width, height}] of a
   *    panel show and take the mouse - the game gets the rest. A panel hands the game the keys it
   *    doesn't type with (or preventDefault) and the mouse's movement. */
  html?: string;
  /** For an html menu: mcre.data; opening it again with the same id passes new data to mcre.on. */
  data?: any;
  /** false: no Close button (Esc still closes it). */
  closeButton?: boolean;
}

interface GuiApi {
  open(player: Player | number, menu: Menu): void;
  close(player: Player | number): void;
}

interface StorageApi {
  /** Kept with the world, where the world is (a joined device's storage is empty). */
  get(key: string): any;
  set(key: string, value: any): void;
  all(): { [key: string]: any };
}

type ClientEventName = 'start' | 'stop' | 'tick' | 'key' | 'message' | 'gui' | 'dimension' | 'settings'
  /** the game's open screen changed (see ScreenInfo) - also when it moves, or the held stack changes */
  | 'screen'
  /** one of this mod's "key" settings went down / up: e.id, e.down, e.code (Options > Controls lists them) */
  | 'keybind'
  /** a click on a slot of the game's inventory screens: e.area, e.index, e.item, e.button, e.shift */
  | 'slotClick';

/** The game's own screen on this device (client.screen(), client.on("screen")). */
interface ScreenInfo {
  /** "none" (playing), "inventory", "crafting", "chest", "furnace", "container" (dispenser, dropper,
   *  hopper), "creative", "station" (enchanting / anvil / brewing), "trading", "pause", "chat",
   *  "death", "sign", "bed", "menu" (no world), "other". */
  screen: string;
  /** Where an inventory screen draws its window, in CSS pixels; null for other screens. */
  rect: { x: number; y: number; width: number; height: number } | null;
  /** The stack on the cursor of an inventory screen. */
  held: ItemStack | null;
  /** The window's size in CSS pixels, and CSS pixels per GUI pixel (a slot is 18 GUI pixels). */
  width: number; height: number; scale: number;
  /** The screen's close X, in CSS pixels (null: it has none). It is always on top: the game cuts
   *  it out of every mod panel, so lay a panel out round it rather than under it. */
  close?: { x: number; y: number; width: number; height: number } | null;
}

interface KeyEvent extends GameEvent { key: string; code: string; down: boolean; }

interface ClientApi {
  /** This device's own events: "key" {key, code, down}, "tick" {player}, "message" {data}... */
  on(event: ClientEventName, fn: Handler): void;
  /** True where the world is (single player or the host). */
  readonly isHost: boolean;
  /** This device's player. */
  player(): Promise<Player>;
  /** To mod.on("message") where the world is. */
  send(data: any): void;
  /** close(id): that menu or panel; close(): the menu and this mod's panels. */
  gui: { open(menu: Menu): void; close(id?: string): void; };
  /** A sound only this device hears. */
  sound(name: string, volume?: number, pitch?: number): void;
  /** A line in this device's chat. */
  message(text: string): void;
  /** A line of text at the top right; null removes it. */
  hud(id: string, text: string | null): void;
  /** What's open in the game on this device, and where. */
  screen(): Promise<ScreenInfo>;
  /** The game's Controls screen (Options > Controls > Key Bindings), on this mod's keys. */
  openControls(): void;
  /** The open inventory screen's slots by area, and changing one. */
  screenSlots(): Promise<{ [area: string]: (ItemStack | null)[] } | null>;
  setScreenSlot(area: string, index: number, item: Name | ItemStack | null, count?: number, data?: number): Promise<boolean>;
  /** true: clicks on the game's inventory slots are this mod's ("slotClick" decides). */
  captureSlots(on: boolean): void;
  /** What the game knows about an item. */
  itemInfo(item: Name | ItemStack): Promise<{ name: string; max: number; block: boolean; category: string; rarity: string; durability?: number; food?: number; armor?: string; id: number | null } | null>;
  /** The stack on the cursor of an open inventory screen (null: nothing). */
  held(): Promise<ItemStack | null>;
  /** Put a stack on that cursor (null: take it away). False when no inventory screen is open. */
  setHeld(item: Name | ItemStack | null, count?: number, data?: number): Promise<boolean>;
  /** Every block and item the game has - variants and mods' included - in the creative
   *  inventory's order, each a full stack. */
  items(): Promise<ItemStack[]>;
  /** Kept on this device for this mod, in every world (settings a player chose, their favourites...). */
  storage: { get(key: string): any; set(key: string, value: any): void; all(): { [key: string]: any } };
}

declare const mod: ModApi;
declare const world: WorldApi;
declare const players: PlayersApi;
declare const gui: GuiApi;
declare const storage: StorageApi;
declare const client: ClientApi;
/** To the browser console (F12). */
declare function log(...args: any[]): void;
