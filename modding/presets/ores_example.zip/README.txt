Example Ores
============
blocks/ruby_ore.json     the ore: "ore" makes it generate in new chunks (vein size, veins per chunk,
                         heights). It drops a Ruby; smelting it gives one too.
worldgen/ruby_ore_nether.json   the same ore in the Nether, replacing netherrack.
blocks/ruby_block.json   a storage block (9 rubies, and back).
items/                   the Ruby, a pickaxe and sword ("tool"), a helmet and chestplate ("armor").
recipes/                 shaped, shapeless and smelting recipes.
The textures are the game's (redstone ore, emerald, diamond tools...) - put your own .png files in
textures/blocks/ and textures/items/ and use their names instead.
Only chunks generated from now on get the ore: explore somewhere new.

The modding guide: https://colinthepwner.github.io/MCRE/modding.html
