// Example Creature - scripts/main.js
// Its events carry e.entity.type "creature_example:waddler".

mod.on('interact', function (e) {
  if (e.entity.type === 'creature_example:waddler') players.message(e.player, 'The Waddler waddles.');
});

// /waddler - one appears next to you.
mod.command('waddler', function (c) {
  world.spawnEntity('waddler', c.player.x + 2, c.player.y, c.player.z);
}, { description: 'a Waddler next to you' });
