// Example Creature - scripts/main.js
// Its events carry e.entity.type "creature_example:waddler".

// Right-click one: its hat on or off (a part of its model it's made without - "hidden_parts" in
// mobs/waddler.json; world.entity(id).hiddenParts says which parts are hidden on this one).
mod.on('interact', async function (e) {
  if (e.entity.type !== 'creature_example:waddler') return;
  var d = await world.entity(e.entity.id);
  var wearing = d && d.hiddenParts && d.hiddenParts.indexOf('hat') < 0;
  world.setPartVisible(e.entity.id, 'hat', !wearing);
  players.message(e.player, wearing ? 'The Waddler takes its hat off.' : 'The Waddler puts its hat on.');
});

// /waddler - one appears next to you.
mod.command('waddler', function (c) {
  world.spawnEntity('waddler', c.player.x + 2, c.player.y, c.player.z);
}, { description: 'a Waddler next to you' });
