Example Creature
================
models/entity/waddler.geo.json   its model: Bedrock geometry (Blockbench: File > Export > Bedrock
                                 Geometry). Parts named head / leg0... move by themselves.
mobs/waddler.json   what it is: behaviour, health, speed, size, breeding, drops, sounds, where it
                    spawns ("spawn"), its spawn egg colours. "texture" here is the game's pig
                    picture ("minecraft:mob/pig.png") - put your own .png in the mod and name it.
scripts/main.js     right-click it, or type /waddler.

The modding guide: https://colinthepwner.github.io/MCRE/modding.html
