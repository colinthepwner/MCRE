Example Rules
=============
rules/gentle.json   always on: no fall damage for players, explosions don't break blocks, chests
                    are explosion proof.
scripts/main.js     /protect switches on a set of rules for an area (world.setRules), /protect off
                    lifts it. Rules are checked by the game at the moment things happen - scripts
                    hear about things after, so they can't stop them; rules can.

The modding guide: https://colinthepwner.github.io/MCRE/modding.html
