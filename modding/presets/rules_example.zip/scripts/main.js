// Example Rules - scripts/main.js
// rules/gentle.json is always on. A script can switch more on and off: world.setRules(id, rules).

mod.command('protect', function (c) {
  if (c.args[0] === 'off') {
    world.setRules('protect', null);
    return players.message(c.player, 'Protection lifted.');
  }
  var x = Math.floor(c.player.x), z = Math.floor(c.player.z);
  world.setRules('protect', {
    area: [x - 16, 0, z - 16, x + 16, 127, z + 16], creative: true,
    no_break: '*', no_place: '*', pvp: false
  });
  players.message(c.player, 'Nobody can build or break within 16 blocks of here (/protect off).');
}, { permission: 'op', usage: '[off]', description: 'protect the land around you' });
