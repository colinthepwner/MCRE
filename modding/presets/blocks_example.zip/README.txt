Example Blocks
==============
blocks/ - each .json file is a new block "<mod id>:<file name>":
  "texture"  one name, or {"top", "bottom", "side"} (the game's names, or your own .png files)
  "shape"    slab, pillar, carpet... or your own box in pixels: [x1, y1, z1, x2, y2, z2] (step.json)
  "light", "slippery", "gravity", "hardness", "tool", "sound" - see lamp, ice_tile, loose_rock
models/block/hedge.json   a block that joins up like a wall: each box's "connect" says when it's
                          drawn (hedge.json uses it).
dimensions/sky_realm.json a place of its own: floating islands under a pale sky. Stand in a Sky
                          Realm Portal (realm_portal.json, "portal_to") to go there - and back.
models/block/table.json   a Java block model (what Blockbench exports); table.json uses it, and
                          "rotate": "horizontal" turns it to face whoever places it.
blocks/tar.json, glow_spring.json  liquids ("liquid"): they flow, you wade / swim in them, the
                          bucket picks them up. Tar hardens into polished stone next to water.
recipes/  a few ways to make them.

The modding guide: https://colinthepwner.github.io/MCRE/modding.html
