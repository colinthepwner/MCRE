Example Blocks
==============
blocks/ - each .json file is a new block "<mod id>:<file name>":
  "texture"  one name, or {"top", "bottom", "side"} (the game's names, or your own .png files)
  "shape"    slab, pillar, carpet... or your own box in pixels: [x1, y1, z1, x2, y2, z2] (step.json)
  "light", "slippery", "gravity", "hardness", "tool", "sound" - see lamp, ice_tile, loose_rock
models/block/table.json   a Java block model (what Blockbench exports); table.json uses it, and
                          "rotate": "horizontal" turns it to face whoever places it.
recipes/  a few ways to make them.

The modding guide: https://colinthepwner.github.io/MCRE/modding.html
