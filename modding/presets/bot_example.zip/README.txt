Example Bot Senses
==================
Needs a bot in the world (/bot spawn) and the game rule botSense on (the default).

scripts/main.js   /guide <what>  the bot says where the nearest one is - relative to WHERE YOU
                                 ARE STANDING and which way you are looking - whether you are
                                 facing it, and the route it would walk there (world.botFind).
                                 <what> is plain words: village, water, lava, a cave, the way
                                 out, back, spawn, my mine, diamonds, a chest, a monster, an
                                 animal, a player's name, or any block by name.
                  /around        what is round the bot, landmarks first (world.botSense).
                  /howfar        how far along you are (world.botProgress) - the same reading the
                                 bot's own brain uses to judge whether an ask is reasonable.
                  /point <what>  keeps a heading to it on screen; /point off stops.
                  the "bot" event with action "asked" fires for every such question, whoever asked.

Game rules:  botSense (on) - the bot knows its surroundings and will answer about them.
             botSpoonfeed (off) - with a chat brain, the bot offers the least cheaty way of
             getting something before fetching it outright. It never refuses either way.

The modding guide: https://colinthepwner.github.io/MCRE/modding.html
