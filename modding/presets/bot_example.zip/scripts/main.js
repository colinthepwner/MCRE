// Example Bot Senses - scripts/main.js
// The world's bot (/bot spawn) knows where it is, and will say so: world.botSense, botFind,
// botLook and botProgress answer the same questions its own chat brain asks. Every answer comes
// with ready-made English in `words` as well as the numbers, because an answer about where you
// are is worth nothing as a row of coordinates.
// Needs a bot in the world and the game rule botSense on (it is, by default).

// /guide <what> - the bot points at it: where it is from WHERE YOU ARE STANDING, whether you are
// facing the right way, and the route it would walk.
mod.command('guide', function (c) {
  var what = c.args.join(' ') || 'the way out';
  world.botFind(what, c.player.name).then(function (r) {
    if (!r || !r.ok) return players.message(c.player, 'No bot here to ask (/bot spawn).');
    players.message(c.player, r.words);
    if (!r.found) return;
    if (r.facing) players.message(c.player, r.facing.words);
    if (r.route) players.message(c.player, 'The way there: ' + r.route.words + '.');
  });
}, { usage: '<village|water|lava|a cave|the way out|back|spawn|diamonds|a chest|...>',
     description: "ask the bot where something is" });

// /around - what the bot can see from where it stands, nearest landmark first.
mod.command('around', function (c) {
  world.botSense(c.player.name).then(function (s) {
    if (!s || !s.ok) return players.message(c.player, 'No bot here to ask (/bot spawn).');
    players.message(c.player, s.words);
    s.around.slice(0, 5).forEach(function (a) {
      players.message(c.player, '  ' + a.n + ' x ' + a.what + ' - ' + a.dir.words);
    });
  });
}, { description: 'what the bot can see around it' });

// /howfar - how far along a player is, which is how the bot judges whether an ask is reasonable.
mod.command('howfar', function (c) {
  world.botProgress(c.player.name).then(function (pr) {
    if (!pr || !pr.ok) return players.message(c.player, 'No bot here to ask (/bot spawn).');
    players.message(c.player, pr.words);
    players.message(c.player, 'stage "' + pr.stage + '", tools tier ' + pr.toolTier + ' of 3, armour ' + pr.armourPieces + '/4');
  });
}, { description: 'how far along you are, as the bot sees it' });

// A signpost that keeps pointing: /point <what> starts it, /point off stops it. It uses the same
// lookup every few seconds and writes the answer to the HUD.
var pointing = {};
mod.command('point', function (c) {
  var what = c.args.join(' ');
  if (!what || what === 'off') { delete pointing[c.player.name]; mod.send(c.player, { hud: '' }); return; }
  pointing[c.player.name] = what;
  players.message(c.player, 'Pointing at ' + what + '. /point off to stop.');
}, { usage: '<what|off>', description: 'keep a heading to something on screen' });

var ticks = 0;
mod.on('gametick', function () {
  if (++ticks % 60) return;   // (three times a second is plenty for a signpost: every 3 s)
  Object.keys(pointing).forEach(function (who) {
    world.botFind(pointing[who], who).then(function (r) {
      if (!r || !r.ok) return;
      mod.send(who, { hud: r.found ? pointing[who] + ': ' + r.fromYou.relative + ', ' + r.fromYou.far
                                   : 'no ' + pointing[who] + ' in sight' });
    });
  });
});

client.on('message', function (e) {
  if (e.data && e.data.hud !== undefined) client.hud('point', e.data.hud || null);
});

// Every question put to the bot - by a player in chat, by its own brain, or by this script -
// fires the "bot" event with action "asked".
mod.on('bot', function (e) {
  if (e.action === 'asked') log(e.by + ' asked ' + e.bot + ': ' + e.query + ' ' + (e.about || ''));
});
