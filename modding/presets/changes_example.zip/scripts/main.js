// Example Changes - scripts/main.js
// The JSON files change the game's own blocks, items and creatures. A script can do the same at
// any time (world.setItemProps / setBlockProps / setMobProps) and change the survival rules.

mod.on('start', function () {
  world.setGameRule('regenTicks', 200);       // health comes back 2.5 times slower
  world.setGameRule('regenExhaustion', 3);    // and each point of it costs food
});

// Max health grows with experience level: 6 hearts' worth at level 0, up to 10 at level 20.
var last = {};
mod.on('gametick', function () {
  players.all().then(function (ps) {
    ps.forEach(function (p) {
      players.stats(p).then(function (s) {
        if (!s) return;
        var max = Math.min(20, 12 + Math.floor(s.xpLevel / 5) * 2);
        if (last[p.id] !== max) { last[p.id] = max; players.setStats(p, { maxHealth: max }); }
      });
    });
  });
});
