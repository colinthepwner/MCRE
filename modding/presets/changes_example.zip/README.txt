Example Changes
===============
tiers/copper.json        a tool tier - stone pickaxes use it (overrides/items/stone_pickaxe.json).
overrides/blocks/        stone needs an iron-level pickaxe to drop anything; gravel drops flint a
                         quarter of the time, else itself.
overrides/items/         apples fill less.
overrides/mobs/          zombies have 30 health, hit for 5 and walk a bit faster.
recipes/no_wooden_pickaxe.json   the wooden pickaxe can't be crafted any more.
scripts/main.js          slower healing that costs food (game rules), and max health that grows
                         with experience level (players.stats / setStats).

The modding guide: https://colinthepwner.github.io/MCRE/modding.html
