My Mod - an empty mod
=====================
manifest.json     who the mod is: change "id" (lower case, unique) and "name" first.
scripts/main.js   its script (optional - delete scripts/ if it has none).
blocks/ items/ recipes/      new blocks, items and recipes as .json files.
textures/blocks/ textures/items/   16x16 .png pictures (or use the game's by name).
Open the folder in the Mods tab (Add mod > Open a folder) and press Reload after each change.

The modding guide: https://colinthepwner.github.io/MCRE/modding.html
