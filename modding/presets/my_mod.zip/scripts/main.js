// My Mod - scripts/main.js
// Scripts run in the game: mod.on(...) for what happens in the world, client.on(...) for this
// device, commands, menus... The modding guide lists everything; types/mcre.d.ts gives your editor
// autocomplete.

mod.on('join', function (e) {
  players.message(e.player, 'My Mod is on.');
});
